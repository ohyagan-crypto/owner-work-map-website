# Detailed Skill And Memory Handoff Preference

Owner preference set on 2026-06-27.

When the owner asks to package, export, hand off, transfer, teach, or zip Codex/OpenClaw skills, memories, workflows, or reply rules for another Codex, OpenClaw, or Telegram bot, the package and reply must be highly detailed.

The goal is not just backup. The goal is a one-pass teaching package so the receiving Codex/OpenClaw can learn the owner's workflow without the owner teaching again.

Required behavior:

1. Read the relevant local skill or memory before answering or packaging.
2. Package copies only; do not modify or remove the original skills, memories, or AGENTS rules.
3. Include detailed teaching files, not only folders:
   - `INSTALL_FOR_OTHER_CODEX.md`
   - `FORWARD_TO_RECEIVER_TGBOT.txt`
   - `PACKAGE_MANIFEST.md`
   - `MEMORY_AND_BEHAVIOR_SUMMARY.md` when owner preferences, memories, or reply behavior are involved.
4. The install guide must explain:
   - What the package teaches.
   - Exact Windows copy paths.
   - Restart requirements.
   - Trigger words and natural language triggers.
   - First action after trigger.
   - Full workflow.
   - Required Traditional Chinese reply style.
   - Expected deliverables.
   - Stop conditions and blocker wording.
   - Secret-handling rules.
   - Test prompts.
   - Final checklist before claiming installation is complete.
5. The ready-to-forward message must be detailed enough that the receiver knows what to read, where to copy files, how to restart, how to test, how to reply, and what not to expose.
6. Owner-facing handoff completion replies must include:
   - What was packaged.
   - Included skills and memories.
   - Included teaching documents.
   - Local zip path.
   - Telegram delivery status when applicable.
   - Exact blocker if anything failed.
7. Every generated package, handoff, export, ZIP, companion document, manifest, ready-to-forward text file, and package folder name must include the creation date. Use `YYYYMMDD` at minimum, preferably `YYYYMMDD_HHMMSS` for uniqueness. If a generated package filename lacks today's date, rename it before reporting or delivering it.

Reply hygiene:

- Always use clean Traditional Chinese for owner-facing replies.
- Do not expose raw logs, JSON dumps, internal tool status, token usage, cookies, passwords, API keys, auth files, or debug traces.
- Do not use a vague final reply such as "received", "processing", "will report later", or "please wait".
- Final replies must provide a concrete deliverable, file path, URL, confirmation list, or exact blocker.

Secret exclusions:

Never include passwords, API keys, tokens, cookies, browser profiles, credential stores, auth files, raw logs, or screenshots containing secrets in a handoff package.
