# 統一 TGBOT 技能與記憶說明

建立日期：2026-07-20

此安裝包已把主人原本分散的 Telegram 助理記憶、技能、工作流與回覆規則合併去重。安裝後只執行一個 TGBOT backend，並使用一個 Telegram Bot token。

## 安裝位置

- 技能：`%USERPROFILE%\.codex-api2\skills`
- 記憶：`%USERPROFILE%\.codex-api2\memories`
- Bot backend：`%USERPROFILE%\tg-openai-bot`
- Codex 設定：`%USERPROFILE%\.codex-api2\config.toml`

## 執行原則

1. 先判斷最新訊息與任務類型，再讀對應的 `SKILL.md` 和必要記憶。
2. 所有技能與工作流都由目前這一個 TGBOT 執行，不切換或呼叫其他 Bot。
3. Telegram 來源有檔案成品時，只回傳到當次來源 chat/thread，優先使用 document/file mode。
4. 不輸出 raw log、token、cookie、API key、stdout/stderr、session 或 debug 狀態。
5. 不能把開始、排隊、下載、生成或本機路徑存在當成完成。

## 主要工作流

- `hfsw`：歷史說書影片製作。
- `ims`：圖片、教學圖與海報。
- `nbs`：NotebookLM 簡報、音訊與影片摘要。
- `wbs`：網站製作、部署與公開 URL 驗證。
- `acs` / `acs2`：剪映與 CapCut 自動剪輯。
- `transcribe` / `speech`：語音轉文字與語音生成。
- `codex-skill-handoff`：安全製作技能或記憶交接包。

完整且實際的技能清單請讀 `TRIGGER_INDEX.md`。

## 完成標準

輸出必須存在、格式可讀、相關驗證通過，且 Telegram 同源文件回傳成功。只有來源 chat id 無法取得時，才能改為回報本機備份路徑與具體卡點。
