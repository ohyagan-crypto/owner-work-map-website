# 給 Codex 的指令：安裝龍蝦完整交接 / 做圖技能包到 OpenClaw

你是 Codex。請不要只回覆說你不能學。你的任務是用檔案與終端能力協助安裝使用者提供的 OpenClaw 技能包。

## 任務目標

把使用者上傳的 zip 技能包解壓、讀取、驗證，並安裝到 OpenClaw skills 目錄，讓 OpenClaw 能學會：

- 龍蝦回覆方式
- 做圖 / 生圖 / 產海報技能
- Lanxin AI / 聚合平台流程
- 檔案回傳規則
- 不保存帳密的安全邊界

## 絕對安全規則

不得保存、輸出或打包：

- 帳號
- 密碼
- cookie
- token
- API key
- OAuth 憑證
- SMS 驗證碼
- 2FA 備援碼
- 私鑰
- 瀏覽器登入資料

如果 zip 裡發現疑似真正機密，立刻停止並回報使用者。

## 你要做的步驟

1. 找到使用者剛上傳的 zip 檔。
2. 解壓到暫存資料夾。
3. 找到裡面的技能資料夾，例如：
   - `龍蝦完整交接`
   - 或 `做圖`
4. 讀取 `SKILL.md`。
5. 讀取 `references/*.md`。
6. 檢查內容是否包含：
   - `https://lx.lanxinai.com/`
   - 做圖 / 生圖 / 生成圖片 / 產海報 / 做海報
   - 確認清單
   - 文件模式回傳
   - 不含帳密/token/cookie/API key 的規則
7. 掃描確認沒有真正帳密、cookie、token、API key、私鑰。
8. 找到 OpenClaw 技能目錄，優先嘗試：
   - `%USERPROFILE%\.openclaw\plugin-skills`
   - `%USERPROFILE%\.openclaw\skills`
   - 若不確定，搜尋 `.openclaw` 下是否已有 `plugin-skills` 或 `skills`。
9. 將技能資料夾複製到正確 skills 目錄。
10. 如需 OpenClaw 重啟才生效，先回報使用者，不要擅自停止服務。
11. 用繁體中文回報結果。

## Windows PowerShell 參考腳本

請把 `$zip` 改成實際收到的 zip 路徑。

```powershell
$ErrorActionPreference = 'Stop'

$zip = '請改成實際zip路徑'
$dest = Join-Path $env:TEMP 'openclaw_skill_install'
Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
Expand-Archive -Path $zip -DestinationPath $dest -Force

$skillDirs = Get-ChildItem $dest -Directory -Recurse | Where-Object {
  Test-Path (Join-Path $_.FullName 'SKILL.md')
}
if (-not $skillDirs) { throw '找不到含 SKILL.md 的技能資料夾' }

foreach ($dir in $skillDirs) {
  Write-Output "=== SKILL: $($dir.Name) ==="
  Get-Content -Raw -Encoding UTF8 (Join-Path $dir.FullName 'SKILL.md') | Out-String | Write-Output
  $ref = Join-Path $dir.FullName 'references'
  if (Test-Path $ref) {
    Get-ChildItem $ref -Filter *.md | ForEach-Object {
      Write-Output "=== REF: $($_.Name) ==="
      Get-Content -Raw -Encoding UTF8 $_.FullName | Out-String | Write-Output
    }
  }
}

$allText = (Get-ChildItem $dest -Recurse -File | ForEach-Object { Get-Content -Raw -Encoding UTF8 $_.FullName }) -join "`n"
$required = @('https://lx.lanxinai.com/', '做圖', '確認清單', '文件模式')
foreach ($r in $required) {
  if ($allText -notmatch [regex]::Escape($r)) { throw "缺少必要內容：$r" }
}

$secretPatterns = @(
  'github_pat_[A-Za-z0-9_]+',
  'ghp_[A-Za-z0-9]+',
  'sk-[A-Za-z0-9]{20,}',
  'AIza[0-9A-Za-z_-]+',
  'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
  'BEGIN (RSA |OPENSSH |EC |DSA )?PRIVATE KEY'
)
foreach ($p in $secretPatterns) {
  if ($allText -match $p) { throw "疑似真正機密，停止：$p" }
}

$candidates = @(
  Join-Path $env:USERPROFILE '.openclaw\plugin-skills',
  Join-Path $env:USERPROFILE '.openclaw\skills'
)
$skillsRoot = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $skillsRoot) {
  $skillsRoot = Join-Path $env:USERPROFILE '.openclaw\plugin-skills'
  New-Item -ItemType Directory -Force -Path $skillsRoot | Out-Null
}

foreach ($dir in $skillDirs) {
  $target = Join-Path $skillsRoot $dir.Name
  Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue
  Copy-Item $dir.FullName $target -Recurse -Force
  Write-Output "已安裝：$target"
}

Write-Output "完成：技能包已安裝。若 OpenClaw 未自動載入，請回報使用者需要重啟 OpenClaw。"
```

## 回報格式

完成後請用繁體中文回報：

- 已找到的 zip 路徑
- 已讀取的技能名稱
- 已安裝到哪個 skills 目錄
- 已學到的平台網址
- 已學到的做圖觸發詞
- 已學到的確認清單流程
- 已學到的文件模式回傳規則
- 已確認沒有帳密 / token / cookie / API key
- 是否需要重啟 OpenClaw

## 如果失敗

如果失敗，不要只說不能學。請回報：

- 卡在哪一步
- 缺少什麼工具或權限
- zip 路徑是否存在
- 是否能讀檔
- 是否能寫入 skills 目錄
- 下一個具體解法