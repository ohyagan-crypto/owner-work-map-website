# 安全交接檢查表

交給另一個 Codex 或新伺服器前，逐項檢查。

## 可以交付

- `SKILL.md`
- `agents/openai.yaml`
- `references/`
- `scripts/`
- `assets/`
- `.env.example`
- 非機密安裝說明
- 不含私人資訊的行為規則摘要

## 不可交付

- `.env`
- `.env.bak_*`
- Telegram bot token
- OpenAI/API key
- OAuth token
- Gmail token
- cookie
- 瀏覽器登入資料
- Allowed chat id / user id
- 客戶電話、地址、帳號、密碼
- logs 裡含有私人內容的原始檔

## 新環境啟動前

1. 使用者親自填入 Telegram token。
2. 使用者親自填入 API key。
3. 設定允許使用者或聊天室。
4. 確認 task root 路徑存在。
5. 確認 bridge 能建立任務資料夾。
6. 確認 Codex 指令能執行。
7. 確認回覆是繁體中文自然口語。
8. 確認錯誤不直接露出英文堆疊或內部狀態。

## 交接給另一個 Codex 的建議訊息

```text
這是一個 MiniNew Telegram 橋接端技能包。請把資料夾放到 /root/.codex/skills/mininew-bridge-handoff。

請先閱讀 SKILL.md，再依 references/new_bridge_setup_zh.md 建立橋接端。

請不要要求我提供舊環境的 .env、token、cookie 或登入資料；所有密鑰都要在新環境由使用者自行填入。

安裝後請重啟橋接端，並測試 Telegram 收發、附件下載、任務資料夾建立、中文回覆與健康檢查。
```

