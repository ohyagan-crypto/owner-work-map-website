# 聚合平台簡稱規則

Created: 2026-06-30

Owner rule:

- When the owner says `聚合`, interpret it as `聚合平台`.
- The platform URL is `https://lx.lanxinai.com/`.
- 2026-07-05 owner correction: owner-facing replies must call 蘭心 / Lanxin / Lanxin AI `藍星`. Keep `lanxin` only for technical paths, URLs, API names, credential service names, and existing tool compatibility.
- In image, video planning, Claude analysis, Lanxin AI, or platform workflow contexts, `聚合` means the same Lanxin AI aggregation platform unless the owner explicitly says otherwise.
- Keep owner-facing replies in clean Traditional Chinese.
