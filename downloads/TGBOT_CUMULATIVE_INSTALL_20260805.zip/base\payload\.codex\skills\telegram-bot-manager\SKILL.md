---
name: telegram-bot-manager
description: Manage Telegram bot workflows, delivery, media sending, audio transcription setup, file forwarding, and user-facing automation rules. Use when Codex needs to troubleshoot Telegram bot replies, send generated images/files back through a bot, explain Telegram delivery errors, configure bot access, or plan bot backend memory and automation.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Telegram Bot Manager

Use this skill for Telegram bot operations and bot-facing automation.

## Highest Principle

- First principle: for Telegram-origin tasks, every downloaded, exported, generated, packaged, captured, or otherwise completed deliverable file must be returned to the originating Telegram chat whenever possible.
- "Originating Telegram chat" means the exact current request source: same chat and, when present, same topic/thread. Never use another Telegram chat, another bot, a previous task's chat, a saved/default receiver, or `TELEGRAM_ALLOWED_CHAT_IDS` as the delivery target unless the owner explicitly says so in the current request.
- This includes all files, audio, video, images, screenshots, PDFs, documents, ZIPs, skill packages, install notes, website bundles, exported assets, and verification captures.
- A local path, "downloaded", "generated", "exported", or "packaged" is not completion when Telegram delivery is available. The workflow is complete only after Telegram upload succeeds, or after a real Telegram delivery blocker is reported in clean Traditional Chinese with the local backup path.
- Prefer Telegram document/file mode for original quality. Send each deliverable once by default; resend only when the owner asks or the previous delivery failed.
- Never send secrets, passwords, API keys, tokens, cookies, auth files, browser profiles, credential stores, raw logs, or files/screenshots containing visible secrets.

## Workflow

1. Identify the target bot, chat, file, or delivery method.
2. Check whether a usable bot token, chat id, or backend script is available locally.
3. For image/file delivery, prefer sending as document when the user wants original quality.
4. For voice, verify transcription API key configuration before promising voice understanding.
5. For bot openness, distinguish:
   - Bot searchable username
   - Bot privacy settings
   - Backend server/webhook/polling running
   - API key availability
6. For persistent memory, store structured memory in a local markdown/json file and explain when backend database support is required.

## Restart Semantics

- 2026-07-08 owner correction: if the owner says `重啟`, `重啟一下`, or `restart` in a TGBOT/Telegram bot context, treat it as restarting TGBOT/current bot/current service by default.
- Do not interpret a bare `重啟` as restarting the Windows computer. Only reboot the computer when the owner explicitly says `重啟電腦`, `重開機`, `reboot the computer`, or an equivalent computer-level phrase.
- Before restarting any bot or service, preserve enough non-secret state to report the real result, then verify process/heartbeat/status after restart before saying it is complete.

## User Rules

- Default to Traditional Chinese.
- Be concise and operational.
- If generated images/videos are completed, send or provide them immediately when possible.
- If a platform only forwarded `[document]` without file content, say that the file body is unavailable.
- For Telegram-origin tasks, any deliverable file must be sent back to the originating Telegram chat whenever possible, not only reported as a local path.
- For Telegram-origin delivery, use the current request's `TELEGRAM_ORIGIN_CHAT_ID` and, when present, `TELEGRAM_ORIGIN_MESSAGE_THREAD_ID`. If these are unavailable, stop delivery and report the blocker; do not guess.
- This includes every downloaded, exported, generated, packaged, or captured file: skill handoff ZIPs, install notes, ready-to-forward messages, generated image/poster originals, screenshots, videos, audio, PDFs, documents, website packages, exported assets, and verification captures.
- This is automatic for every completed deliverable: images, videos, audio files, documents, ZIP packages, screenshots, and website/export files must be uploaded to Telegram in the same workflow without waiting for the owner to ask again.
- Prefer Telegram document/file mode for ZIPs, original images, screenshots, PDFs, and other files to preserve quality.
- For Telegram-origin tasks, a deliverable workflow is not complete until Telegram delivery returns success. Creating a local file or giving a local path alone is only a backup, not completion.
- Do not stop after saying a file will be sent. Attempt the Telegram upload in the same workflow, verify the send result, and only then give the final reply.
- If Telegram delivery fails after retry, report the exact blocker in clean Traditional Chinese and provide the local backup path.
- Local backup/output files for Telegram deliverables must go under `C:\Users\max\Desktop\龍蝦記憶` or a task/date subfolder there. Do not place new deliverables on the Desktop root unless a tool forces it, and move them into the lobster memory folder afterward.

## Safety

Do not reveal remote-control temporary passwords, raw account credentials, bot tokens, or unmasked screenshots containing credentials. Use tokens only for authorized local operations when necessary.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














