﻿$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if(-not [Environment]::Is64BitOperatingSystem){ throw 'Unified TGBOT requires 64-bit Windows because the bundled Node.js runtime is x64.' }
if(-not [Environment]::Is64BitProcess){ throw 'Please run the included INSTALL_TGBOT_UNIFIED.cmd so it can select 64-bit Windows PowerShell.' }
$package=Split-Path -Parent $MyInvocation.MyCommand.Path
$requiredPackageItems=@(
    'payload\tg-openai-bot',
    'payload\tg-openai-bot\codex_bot.py',
    'payload\tg-openai-bot\setup_env.ps1',
    'payload\.codex\skills',
    'payload\.codex\memories',
    'payload\.codex\config.toml.template'
)
$missingPackageItems=@($requiredPackageItems | Where-Object {-not (Test-Path -LiteralPath (Join-Path $package $_))})
if($missingPackageItems.Count){
    throw "Installer payload is incomplete after extraction. Missing: $($missingPackageItems -join ', '). Delete this extracted folder, extract the new flat ZIP again, and rerun INSTALL_TGBOT_UNIFIED.cmd."
}
$userHome=[Environment]::GetFolderPath("UserProfile")
$target=Join-Path $userHome "tg-openai-bot"
$codexHome=Join-Path $userHome ".codex-api2"
$backup=Join-Path $userHome "tgbot_backup_$(Get-Date -Format yyyyMMdd_HHmmss)"

function Refresh-Path { $env:Path = "$( [Environment]::GetEnvironmentVariable('Path','User') );$( [Environment]::GetEnvironmentVariable('Path','Machine') )" }
function Find-Python {
    Refresh-Path
    $candidates=@()
    $py=Get-Command py.exe -ErrorAction SilentlyContinue
    if($py){$candidates += @{Path=$py.Source;Args=@('-3')}}
    $python=Get-Command python.exe -ErrorAction SilentlyContinue
    if($python){$candidates += @{Path=$python.Source;Args=@()}}
    $searchRoots=@(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
        (Join-Path $userHome 'AppData\Local\Programs\Python'),
        $env:ProgramFiles
    )
    foreach($root in $searchRoots){
        Get-ChildItem -Path (Join-Path $root 'Python*\python.exe') -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object {$candidates += @{Path=$_.FullName;Args=@()}}
    }
    foreach($candidate in $candidates){
        $job=$null
        try {
            $testArgs=@($candidate.Args + @('-c','import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)'))
            $job=Start-Job -ScriptBlock {param($commandPath,$commandArgs);& $commandPath @commandArgs *> $null;return $LASTEXITCODE} -ArgumentList $candidate.Path,(,$testArgs)
            if((Wait-Job -Job $job -Timeout 15) -and ([int](Receive-Job -Job $job) -eq 0)){return $candidate}
            if($job.State -eq 'Running'){Stop-Job -Job $job -ErrorAction SilentlyContinue}
        } catch {}
        finally {if($job){Remove-Job -Job $job -Force -ErrorAction SilentlyContinue}}
    }
    return $null
}
function Ensure-Python {
    $found=Find-Python
    if($found){return $found}
    Write-Host "Python not found. Downloading Python 3.13.14 from python.org (maximum wait: 5 minutes)..." -ForegroundColor Yellow
    $dir=Join-Path $env:TEMP 'tgbot-python'; New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $installer=Join-Path $dir "python-3.13.14-amd64-$PID.exe"
    Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.13.14/python-3.13.14-amd64.exe' -OutFile $installer -UseBasicParsing -TimeoutSec 300
    if((Get-Item -LiteralPath $installer).Length -lt 1MB){throw 'Python installer download is incomplete.'}
    Write-Host "Python download complete. Installing (maximum wait: 10 minutes)..." -ForegroundColor Yellow
    $pythonTarget=Join-Path $userHome 'AppData\Local\Programs\Python\Python313'
    $arguments="/quiet InstallAllUsers=0 TargetDir=`"$pythonTarget`" PrependPath=1 Include_launcher=1 Include_pip=1 Include_test=0"
    $proc=Start-Process -FilePath $installer -ArgumentList $arguments -PassThru
    if(-not $proc.WaitForExit(600000)){
        try{$proc.Kill()}catch{}
        throw 'Python installation timed out after 10 minutes. Restart Windows and run this installer again.'
    }
    if($proc.ExitCode -notin @(0,3010)){throw "Python installer failed: $($proc.ExitCode)"}
    Write-Host "Python installer finished with code $($proc.ExitCode)." -ForegroundColor Green
    $found=Find-Python; if(-not $found){throw 'Python installation completed but Python was not found.'}; return $found
}
function Ensure-NodeNpm {
    $portableNodeDir=Join-Path $env:LOCALAPPDATA 'Programs\TGBOT\node-v22.22.3-win-x64'
    if(Test-Path -LiteralPath $portableNodeDir){Get-ChildItem -LiteralPath $portableNodeDir -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue}
    Refresh-Path
    $node = Get-Command node.exe -ErrorAction SilentlyContinue
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if($node -and $npm){return @{Node=$node; Npm=$npm}}
    $nodeZip=Get-ChildItem -LiteralPath (Join-Path $package 'runtimes') -Filter 'node-*-win-x64.zip' -File -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1 -ExpandProperty FullName
    if($nodeZip){
        Write-Host "Node.js/npm not found. Using bundled portable runtime: $(Split-Path -Leaf $nodeZip)" -ForegroundColor Yellow
    } else {
        Write-Host "Downloading the portable Node.js ZIP from nodejs.org (maximum wait: 5 minutes)..." -ForegroundColor Yellow
        $dir=Join-Path $env:TEMP 'tgbot-node'; New-Item -ItemType Directory -Path $dir -Force | Out-Null
        $nodeZip=Join-Path $dir "node-v22.22.3-win-x64-$PID.zip"
        Invoke-WebRequest -Uri 'https://nodejs.org/dist/v22.22.3/node-v22.22.3-win-x64.zip' -OutFile $nodeZip -UseBasicParsing -TimeoutSec 300
    }
    if((Get-Item -LiteralPath $nodeZip).Length -lt 1MB){throw 'Node.js portable ZIP is incomplete.'}
    Unblock-File -LiteralPath $nodeZip -ErrorAction SilentlyContinue
    $runtimeRoot=Join-Path $env:LOCALAPPDATA 'Programs\TGBOT'
    $nodeFolderName=([IO.Path]::GetFileNameWithoutExtension((Split-Path -Leaf $nodeZip))) -replace '-\d+$',''
    $nodeDir=Join-Path $runtimeRoot $nodeFolderName
    $nodeExe=Join-Path $nodeDir 'node.exe'
    $npmCmd=Join-Path $nodeDir 'npm.cmd'
    if(-not ((Test-Path -LiteralPath $nodeExe) -and (Test-Path -LiteralPath $npmCmd))){
        Write-Host "Extracting portable Node.js runtime..." -ForegroundColor Yellow
        New-Item -ItemType Directory -Path $runtimeRoot -Force | Out-Null
        Expand-Archive -LiteralPath $nodeZip -DestinationPath $runtimeRoot -Force
    }
    if(-not ((Test-Path -LiteralPath $nodeExe) -and (Test-Path -LiteralPath $npmCmd))){throw 'Portable Node.js extraction completed but node.exe or npm.cmd is missing.'}
    Get-ChildItem -LiteralPath $nodeDir -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    $userPath=[Environment]::GetEnvironmentVariable('Path','User')
    if(-not (($userPath -split ';') -contains $nodeDir)){[Environment]::SetEnvironmentVariable('Path', "$nodeDir;$userPath", 'User')}
    $env:Path="$nodeDir;$env:Path"
    Write-Host "Portable Node.js runtime ready: $nodeDir" -ForegroundColor Green
    return @{Node=[pscustomobject]@{Source=$nodeExe}; Npm=[pscustomobject]@{Source=$npmCmd}}
}
function Assert-CommandVersion([string]$Path, [string[]]$CommandArgs, [string]$Label) {
    $job=$null
    try {
        $job=Start-Job -ScriptBlock {
            param($commandPath,$commandArgs)
            $output=& $commandPath @commandArgs 2>&1 | Out-String
            [pscustomobject]@{ExitCode=$LASTEXITCODE;Output=$output}
        } -ArgumentList $Path,(,$CommandArgs)
        if(-not (Wait-Job -Job $job -Timeout 30)){Stop-Job -Job $job -ErrorAction SilentlyContinue; throw "$Label version check timed out after 30 seconds."}
        $result=Receive-Job -Job $job
        $out=[string]$result.Output
        if($result.ExitCode -ne 0 -or [string]::IsNullOrWhiteSpace($out)){ throw "$Label check failed." }
        Write-Host "$Label OK: $($out.Trim())" -ForegroundColor Green
    } catch { throw "$Label is unavailable: $($_.Exception.Message)" }
    finally {if($job){Remove-Job -Job $job -Force -ErrorAction SilentlyContinue}}
}
function Invoke-CommandWithTimeout([string]$Path, [string[]]$CommandArgs, [string]$Label, [int]$TimeoutSeconds) {
    $job=$null
    try {
        $job=Start-Job -ScriptBlock {
            param($commandPath,$commandArgs)
            $output=& $commandPath @commandArgs 2>&1 | Out-String
            [pscustomobject]@{ExitCode=$LASTEXITCODE;Output=$output}
        } -ArgumentList $Path,(,$CommandArgs)
        $timer=[Diagnostics.Stopwatch]::StartNew()
        while(-not (Wait-Job -Job $job -Timeout 15)){
            $elapsed=[int]$timer.Elapsed.TotalSeconds
            if($elapsed -ge $TimeoutSeconds){Stop-Job -Job $job -ErrorAction SilentlyContinue; throw "$Label timed out after $TimeoutSeconds seconds."}
            Write-Host "$Label is still running ($elapsed / $TimeoutSeconds seconds)..." -ForegroundColor DarkGray
        }
        $result=Receive-Job -Job $job
        if(-not [string]::IsNullOrWhiteSpace([string]$result.Output)){Write-Host ([string]$result.Output).Trim()}
        return [int]$result.ExitCode
    } finally {if($job){Remove-Job -Job $job -Force -ErrorAction SilentlyContinue}}
}
function Get-SafeCodexFailureReason([string]$Output) {
    $text=([string]$Output).ToLowerInvariant()
    if($text -match '401|invalid.api.key|incorrect.api.key|unauthorized|authentication.failed'){return 'GPT API Key 無效、已失效，或與 API URL 不配對。'}
    if($text -match '403|access forbidden|permission denied'){return 'GPT API 拒絕存取；目前金鑰或帳號沒有端點／模型權限。'}
    if($text -match 'model.not.found|unknown.model|unsupported.model|does not have access to model|model is not available'){return 'GPT API 不支援目前模型。'}
    if($text -match '429|rate.limit|quota'){return 'GPT API 目前受到流量、額度或頻率限制。'}
    if($text -match '502|503|504|temporarily unavailable|upstream'){return 'GPT API 上游暫時不可用。'}
    if($text -match 'timed out|timeout'){return 'Codex AI 回覆測試逾時。'}
    if($text -match 'no such host|name resolution|connection refused|network is unreachable|certificate'){return '無法連到 GPT API；請檢查 URL、DNS、代理、防火牆與 TLS。'}
    if($text -match 'config.toml|failed to parse config|failed to load config|toml parse'){return 'Codex 設定檔無法讀取。'}
    if($text -match 'not recognized|could not find codex|codex cli unavailable'){return '找不到可執行的 Codex CLI。'}
    return 'Codex CLI 已啟動，但沒有產生可用的 AI 回覆。'
}
function Test-CodexAiReply([string]$CommandPath, [string[]]$Models, [int]$TimeoutSeconds=180) {
    $lastReason='未執行任何模型測試。'
    foreach($model in ($Models | Where-Object {-not [string]::IsNullOrWhiteSpace($_)} | Select-Object -Unique)){
        $job=$null
        $outputPath=Join-Path $env:TEMP "tgbot_codex_smoke_$PID`_$([guid]::NewGuid().ToString('N')).txt"
        try {
            Write-Host "Testing real Codex AI reply with model $model (maximum wait: $TimeoutSeconds seconds)..." -ForegroundColor Yellow
            $smokeArgs=@(
                'exec','-C',$userHome,'--skip-git-repo-check','--sandbox','read-only','--color','never',
                '--output-last-message',$outputPath,'--model',$model,'只回覆 OK'
            )
            $job=Start-Job -ScriptBlock {
                param($commandPath,$commandArgs)
                $output=& $commandPath @commandArgs 2>&1 | Out-String
                [pscustomobject]@{ExitCode=$LASTEXITCODE;Output=$output}
            } -ArgumentList $CommandPath,(,$smokeArgs)
            if(-not (Wait-Job -Job $job -Timeout $TimeoutSeconds)){
                Stop-Job -Job $job -ErrorAction SilentlyContinue
                $lastReason="模型 $model 的 Codex AI 回覆測試逾時。"
                continue
            }
            $result=Receive-Job -Job $job
            $answer=''
            if(Test-Path -LiteralPath $outputPath){$answer=[IO.File]::ReadAllText($outputPath).Trim()}
            if($result.ExitCode -eq 0 -and -not [string]::IsNullOrWhiteSpace($answer)){
                return [pscustomobject]@{Success=$true;Model=$model;Reason=''}
            }
            $lastReason="模型 $model 測試失敗：$(Get-SafeCodexFailureReason ([string]$result.Output))"
        } catch {
            $lastReason="模型 $model 測試失敗：$(Get-SafeCodexFailureReason $_.Exception.Message)"
        } finally {
            if($job){Remove-Job -Job $job -Force -ErrorAction SilentlyContinue}
            Remove-Item -LiteralPath $outputPath -Force -ErrorAction SilentlyContinue
        }
    }
    return [pscustomobject]@{Success=$false;Model='';Reason=$lastReason}
}
function Find-RealCodexPath([string]$NpmPath, [string]$ShimPath) {
    $npmDir=Split-Path -Parent $NpmPath
    $candidates=@((Join-Path $npmDir 'codex.cmd'),(Join-Path $npmDir 'codex.ps1'),(Join-Path $npmDir 'codex.exe'))
    $candidates += (Join-Path $env:APPDATA 'npm\codex.cmd'),(Join-Path $env:APPDATA 'npm\codex.ps1'),(Join-Path $env:APPDATA 'npm\codex.exe')
    $candidates += @(Get-Command codex.cmd,codex.ps1,codex.exe -All -ErrorAction SilentlyContinue | ForEach-Object {$_.Source})
    return ($candidates | Where-Object {$_ -and (Test-Path -LiteralPath $_) -and ([IO.Path]::GetFullPath($_) -ne [IO.Path]::GetFullPath($ShimPath))} | Select-Object -First 1)
}
function Find-NpxPath([string]$NpmPath) {
    $candidate=Join-Path (Split-Path -Parent $NpmPath) 'npx.cmd'
    if(Test-Path -LiteralPath $candidate){return $candidate}
    $candidate=Join-Path $env:APPDATA 'npm\npx.cmd'
    if(Test-Path -LiteralPath $candidate){return $candidate}
    return $null
}
function Assert-NpxCodex([string]$NpxPath) {
    if(-not $NpxPath){ return $false }
    try {
        Assert-CommandVersion $NpxPath @('--yes','@openai/codex','--version') 'Codex CLI npx fallback'
        return $true
    } catch {}
    return $false
}
$legacyWatchdogTasks=@(
    'Codex Telegram Bot 2 Watchdog Hourly',
    'Codex Telegram Bot 2 Watchdog Startup',
    'Codex Telegram Bot 3 Watchdog Hourly',
    'Codex Telegram Bot 3 Watchdog Startup'
)
foreach($taskName in $legacyWatchdogTasks){
    try { Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue } catch {}
    try { Disable-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue | Out-Null } catch {}
}
foreach($taskName in @('Codex Telegram Bot Watchdog Hourly','Codex Telegram Bot Watchdog Startup','Telegram Codex Bot','Unified TGBOT Watchdog')){
    try { Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue } catch {}
    try { Disable-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue | Out-Null } catch {}
}
$processNames=@('codex_bot.py','codex_bot_2.py','codex_bot_3.py','simple_bot.py','bot.py','watch_codex_bot.ps1','run_watchdog_hidden.vbs')
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $line=[string]$_.CommandLine
    ($processNames | Where-Object { $line -like "*$_*" }).Count -gt 0
} | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }
Start-Sleep -Seconds 2
$python=Ensure-Python
New-Item -ItemType Directory -Path $target,$codexHome -Force | Out-Null
if(Test-Path $target){
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Get-ChildItem -LiteralPath $target -Force -ErrorAction SilentlyContinue | ForEach-Object {
        try { Move-Item -LiteralPath $_.FullName -Destination $backup -Force -ErrorAction Stop } catch { Write-Warning "Could not back up $($_.Name); it will be overwritten." }
    }
}
$botPayload=Join-Path $package 'payload\tg-openai-bot'
Copy-Item -Path (Join-Path $botPayload '*') -Destination $target -Recurse -Force
$instanceLock=Join-Path $target 'codex_bot_instance.lock'
if(Test-Path -LiteralPath $instanceLock){
    $lockLive=$false
    try {
        $lockData=Get-Content -Raw -LiteralPath $instanceLock | ConvertFrom-Json
        if($lockData.pid){$lockLive=$null -ne (Get-Process -Id ([int]$lockData.pid) -ErrorAction SilentlyContinue)}
    } catch {}
    if(-not $lockLive){
        Move-Item -LiteralPath $instanceLock -Destination (Join-Path $backup 'codex_bot_instance.lock.stale') -Force
    }
}
$bin=Join-Path $userHome 'bin'; New-Item -ItemType Directory -Path $bin -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $target 'codex-launch.ps1') -Destination (Join-Path $bin 'codex-launch.ps1') -Force
Copy-Item -LiteralPath (Join-Path $target 'codex.cmd') -Destination (Join-Path $bin 'codex.cmd') -Force
$userPath=[Environment]::GetEnvironmentVariable('Path','User')
$userSegments=@($userPath -split ';' | Where-Object {$_ -and $_.Trim() -and $_.TrimEnd('\') -ine $bin.TrimEnd('\')})
[Environment]::SetEnvironmentVariable('Path', (($bin + ';' + ($userSegments -join ';')).TrimEnd(';')), 'User')
$env:Path = "$bin;$env:Path"
if(Test-Path (Join-Path $package 'payload\AGENTS.md')){Copy-Item -LiteralPath (Join-Path $package 'payload\AGENTS.md') -Destination (Join-Path $userHome 'AGENTS.md') -Force}
$codexBackup=Join-Path $backup 'codex-api2'
New-Item -ItemType Directory -Path $codexBackup -Force | Out-Null
foreach($name in @('skills','memories')){
    $existing=Join-Path $codexHome $name
    if(Test-Path -LiteralPath $existing){
        Move-Item -LiteralPath $existing -Destination (Join-Path $codexBackup $name) -Force
    }
}
New-Item -ItemType Directory -Path (Join-Path $codexHome 'skills'),(Join-Path $codexHome 'memories') -Force | Out-Null
Copy-Item -Path (Join-Path $package 'payload\.codex\skills\*') -Destination (Join-Path $codexHome 'skills') -Recurse -Force
$systemSkills=Join-Path $package 'payload\.codex\skills\.system'
if(Test-Path -LiteralPath $systemSkills){Copy-Item -LiteralPath $systemSkills -Destination (Join-Path $codexHome 'skills') -Recurse -Force}
Get-ChildItem -LiteralPath (Join-Path $codexHome 'skills') -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '_20\d{6}(?:_\d{6})?$'} | Remove-Item -Recurse -Force
Copy-Item -Path (Join-Path $package 'payload\.codex\memories\*') -Destination (Join-Path $codexHome 'memories') -Recurse -Force
$packageSkillCount=@(Get-ChildItem -LiteralPath (Join-Path $package 'payload\.codex\skills') -Recurse -Filter 'SKILL.md' -File -Force).Count
$installedSkillCount=@(Get-ChildItem -LiteralPath (Join-Path $codexHome 'skills') -Recurse -Filter 'SKILL.md' -File -Force).Count
if($installedSkillCount -ne $packageSkillCount){throw "Unified skill installation count mismatch: expected $packageSkillCount, found $installedSkillCount."}
Write-Host "Unified skills installed: $installedSkillCount" -ForegroundColor Green
$config=[IO.File]::ReadAllText((Join-Path $package 'payload\.codex\config.toml.template'))
$psExe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if(Test-Path (Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe')){$psExe=Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'}
& $psExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $target 'setup_env.ps1')
if($LASTEXITCODE -ne 0){throw 'Credential setup failed.'}
$envFile=Get-Content (Join-Path $target '.env')
$apiUrl=($envFile|Where-Object {$_ -like 'OPENAI_BASE_URL=*'}) -replace '^OPENAI_BASE_URL=',''
$api2Key=($envFile|Where-Object {$_ -like 'API2_KEY=*'}) -replace '^API2_KEY=',''
$config=$config.Replace('__API_URL__',$apiUrl)
[IO.File]::WriteAllText((Join-Path $codexHome 'config.toml'),$config,[Text.UTF8Encoding]::new($false))
[Environment]::SetEnvironmentVariable('CODEX_HOME',$codexHome,'User')
[Environment]::SetEnvironmentVariable('API2_KEY',$api2Key,'User')
[Environment]::SetEnvironmentVariable('OPENAI_BASE_URL',$apiUrl,'User')
$env:CODEX_HOME=$codexHome
$env:API2_KEY=$api2Key
$env:OPENAI_BASE_URL=$apiUrl
Write-Host 'Codex Windows sandbox mode: unelevated fallback (avoids elevated sandbox setup hangs on Windows Server).' -ForegroundColor Yellow
Write-Host "[TGBOT 1/5] Installing Python dependencies..." -ForegroundColor Cyan
$wheelRoot=Join-Path $package 'offline\python-wheels'
if(Test-Path -LiteralPath $wheelRoot){
    $pipExit=Invoke-CommandWithTimeout $python.Path @($python.Args + @('-m','pip','install','--disable-pip-version-check','--no-input','--no-index','--find-links',$wheelRoot,'-r',(Join-Path $target 'requirements.txt'))) 'Offline Python dependency installation' 900
    if($pipExit -ne 0){
        Write-Warning 'Offline Python dependency installation failed; retrying from PyPI.'
        $pipExit=Invoke-CommandWithTimeout $python.Path @($python.Args + @('-m','pip','install','--disable-pip-version-check','--no-input','--default-timeout','120','-r',(Join-Path $target 'requirements.txt'))) 'Online Python dependency installation' 900
    }
} else {
    $pipExit=Invoke-CommandWithTimeout $python.Path @($python.Args + @('-m','pip','install','--disable-pip-version-check','--no-input','--default-timeout','120','-r',(Join-Path $target 'requirements.txt'))) 'Online Python dependency installation' 900
}
if($pipExit -ne 0){throw 'Python dependency installation failed.'}
Write-Host "[TGBOT 2/5] Checking Python syntax..." -ForegroundColor Cyan
& $python.Path @($python.Args + @('-m','py_compile',(Join-Path $target 'codex_bot.py'),(Join-Path $target 'preflight.py')))
if($LASTEXITCODE -ne 0){throw 'Python syntax verification failed.'}
Write-Host '[TGBOT] Testing failure routing and safe error replies...' -ForegroundColor Cyan
& $python.Path @($python.Args + @( (Join-Path $target 'failure_routing_self_test.py') ))
if($LASTEXITCODE -ne 0){throw 'Failure routing self-test failed; refusing to start TGBOT with generic error fallback.'}
Refresh-Path
$shimCodex = Join-Path $bin 'codex.cmd'
Write-Host "[TGBOT 3/5] Checking Node.js and npm..." -ForegroundColor Cyan
$nodeTools=Ensure-NodeNpm
$npm=$nodeTools.Npm
$node=$nodeTools.Node
Assert-CommandVersion $node.Source @('--version') 'Node.js'
Assert-CommandVersion $npm.Source @('--version') 'npm'
Write-Host "[TGBOT 4/5] Installing/verifying Codex CLI..." -ForegroundColor Cyan
$env:npm_config_fetch_timeout = '120000'
$env:npm_config_fetch_retries = '2'
$realCodex=Find-RealCodexPath $npm.Source $shimCodex
if(-not $realCodex){
    $offlineNpm=Join-Path $package 'offline\npm'
    $codexMain=Get-ChildItem -LiteralPath $offlineNpm -Filter 'openai-codex-*.tgz' -File -ErrorAction SilentlyContinue | Where-Object {$_.Name -notmatch 'win32'} | Sort-Object Name -Descending | Select-Object -First 1
    $codexWindows=Get-ChildItem -LiteralPath $offlineNpm -Filter 'openai-codex-win32-x64-*.tgz' -File -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
    if($codexMain -and $codexWindows){
        Write-Host "Installing bundled offline Codex CLI (maximum wait: 10 minutes)..." -ForegroundColor Yellow
        $npmExit=Invoke-CommandWithTimeout $npm.Source @('install','-g',$codexWindows.FullName,$codexMain.FullName,'--offline','--include=optional','--no-fund','--no-audit','--loglevel=notice') 'Offline Codex CLI installation' 600
        if($npmExit -ne 0){
            Write-Warning 'Bundled Codex CLI installation failed; retrying from the npm registry.'
            $npmExit=Invoke-CommandWithTimeout $npm.Source @('install','-g','@openai/codex','--no-fund','--no-audit','--loglevel=notice') 'Online Codex CLI installation' 600
        }
    } else {
        Write-Host "Downloading and installing Codex CLI from npm (maximum wait: 10 minutes; package is about 145 MB)..." -ForegroundColor Yellow
        $npmExit=Invoke-CommandWithTimeout $npm.Source @('install','-g','@openai/codex','--no-fund','--no-audit','--loglevel=notice') 'Online Codex CLI installation' 600
    }
    if($npmExit -ne 0){throw "@openai/codex installation failed with exit code $npmExit."}
    Refresh-Path
    $realCodex=Find-RealCodexPath $npm.Source $shimCodex
}
$npxPath=Find-NpxPath $npm.Source
if($realCodex){
    Write-Host "Codex CLI ready: $realCodex" -ForegroundColor Green
    Assert-CommandVersion $realCodex @('--version') 'Codex CLI'
} elseif(-not (Assert-NpxCodex $npxPath)) {
    throw 'Codex CLI installation failed: neither global codex command nor npx @openai/codex is runnable.'
} else {
    Write-Host "Codex CLI ready through npx: $npxPath" -ForegroundColor Green
}
$botCodexCommand=if($realCodex){[string]$realCodex}else{[string]$shimCodex}
$commandEnv=@()
foreach($line in $envFile){
    if($line -like 'CODEX_COMMAND=*'){$commandEnv += "CODEX_COMMAND=$botCodexCommand";continue}
    $commandEnv += $line
}
$envPath=Join-Path $target '.env'
[IO.File]::WriteAllLines($envPath,$commandEnv,[Text.UTF8Encoding]::new($false))
$envFile=$commandEnv
Write-Host "Codex command shim installed: $shimCodex" -ForegroundColor Green
Write-Host '[TGBOT] Verifying a real Codex AI reply...' -ForegroundColor Cyan
$configuredModel=(($envFile|Where-Object {$_ -like 'CODEX_MODEL=*'}|Select-Object -First 1) -replace '^CODEX_MODEL=','').Trim()
$fallbackModels=(($envFile|Where-Object {$_ -like 'CODEX_FALLBACK_MODELS=*'}|Select-Object -First 1) -replace '^CODEX_FALLBACK_MODELS=','').Split(',')
$modelCandidates=@($configuredModel)+@($fallbackModels|ForEach-Object {$_.Trim()})
$aiSmoke=Test-CodexAiReply -CommandPath $shimCodex -Models $modelCandidates -TimeoutSeconds 180
if(-not $aiSmoke.Success){throw "API verification failed. $($aiSmoke.Reason) Check the API Key, API URL and model before starting TGBOT."}
Write-Host "Codex AI reply OK: model $($aiSmoke.Model)" -ForegroundColor Green
$verifiedModel=$aiSmoke.Model.Trim()
$verifiedEnv=@()
foreach($line in $envFile){
    if($line -like 'CODEX_MODEL=*'){$verifiedEnv += "CODEX_MODEL=$verifiedModel";continue}
    if($line -like 'OPENAI_MODEL=*'){$verifiedEnv += "OPENAI_MODEL=$verifiedModel";continue}
    $verifiedEnv += $line
}
$envPath=Join-Path $target '.env'
[IO.File]::WriteAllLines($envPath,$verifiedEnv,[Text.UTF8Encoding]::new($false))
$envFile=$verifiedEnv
$configPath=Join-Path $codexHome 'config.toml'
$configText=[IO.File]::ReadAllText($configPath)
$modelLine=[regex]::new('(?m)^model\s*=.*$')
$configText=$modelLine.Replace($configText,"model = `"$verifiedModel`"",1)
[IO.File]::WriteAllText($configPath,$configText,[Text.UTF8Encoding]::new($false))
Write-Host "Verified model saved for Codex CLI and TGBOT: $verifiedModel" -ForegroundColor Green
Write-Host '[TGBOT] Checking Telegram Bot API...' -ForegroundColor Cyan
$telegramToken=($envFile|Where-Object {$_ -like 'TELEGRAM_BOT_TOKEN=*'}) -replace '^TELEGRAM_BOT_TOKEN=',''
try {
    $telegramMe=Invoke-RestMethod -Uri ("https://api.telegram.org/bot$telegramToken/getMe") -TimeoutSec 30
    if(-not $telegramMe.ok){throw 'Telegram getMe returned ok=false.'}
    Write-Host "Telegram Bot API OK: @$($telegramMe.result.username)" -ForegroundColor Green
} catch { throw "Telegram Bot API check failed: $($_.Exception.Message)" }
Write-Host '[TGBOT] CHAT ID was intentionally skipped. The Telegram backend will remain stopped until manual binding.' -ForegroundColor Yellow
Write-Host 'Bind later from a Codex CLI terminal with:' -ForegroundColor Cyan
Write-Host '  C:\Users\<user>\tg-openai-bot\BIND_CHAT_ID.cmd' -ForegroundColor White
Write-Host "[TGBOT 5/5] Installation checks complete." -ForegroundColor Cyan
Write-Host "Unified TGBOT and Codex CLI installed. CHAT ID is not set. Backup: $backup" -ForegroundColor Green
