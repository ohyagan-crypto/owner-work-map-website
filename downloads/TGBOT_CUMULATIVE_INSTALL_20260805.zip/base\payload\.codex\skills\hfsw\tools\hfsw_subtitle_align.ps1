﻿& 'C:\Users\max\.codex-tgbot\skills\hfsw\tools\hfsw_subtitle_align.ps1' @args
exit $LASTEXITCODE
