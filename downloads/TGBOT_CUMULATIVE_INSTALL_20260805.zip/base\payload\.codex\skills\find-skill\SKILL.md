---
name: find-skill
description: Find and install Claude Code skills for a project.
---

# Find Skill 鈥?锌芯懈褋泻 懈 褍褋褌邪薪芯胁泻邪 褋泻懈谢芯胁

孝褘 鈥?褝泻褋锌械褉褌 锌芯 锌芯懈褋泻褍 褋泻懈谢芯胁 褋 谢芯泻邪谢褜薪褘屑 泻邪褌邪谢芯谐芯屑 (14 懈褋褌芯褔薪懈泻芯胁, 褉邪薪卸懈褉芯胁邪薪懈械 锌芯 GitHub stars).

---

## 袩邪褉邪屑械褌褉褘 胁褘蟹芯胁邪

小泻懈谢 锌褉懈薪懈屑邪械褌 邪褉谐褍屑械薪褌褘 胁 褋胁芯斜芯写薪芯泄 褎芯褉屑械. 袩邪褉褋懈 懈褏 褌邪泻:

| 肖芯褉屑邪褌 | 袩褉懈屑械褉 | 袟薪邪褔械薪懈械 |
|--------|--------|----------|
| `<蟹邪锌褉芯褋>` | `docker` | 袩芯懈褋泻 锌芯 泻谢褞褔械胁芯屑褍 褋谢芯胁褍, 锌芯泻邪蟹邪褌褜 top 3 |
| `<蟹邪锌褉芯褋> --limit N` | `react --limit 10` | 袩芯泻邪蟹邪褌褜 N 褉械蟹褍谢褜褌邪褌芯胁 |
| `<蟹邪锌褉芯褋> --all` | `design --all` | 袩芯泻邪蟹邪褌褜 袙小袝 薪邪泄写械薪薪褘械 褉械蟹褍谢褜褌邪褌褘 |
| `<蟹邪锌褉芯褋> --page N` | `python --limit 5 --page 2` | 小褌褉邪薪懈褑邪 N (锌芯 `limit` 薪邪 褋褌褉邪薪懈褑褍) |
| `<蟹邪锌褉芯褋> --agent <name>` | `docker --agent cursor` | 肖懈谢褜褌褉 锌芯 邪谐械薪褌褍: `claude`, `codex`, `opencode`, `cursor`, `any` |
| `--top N` | `--top 20` | 袩芯泻邪蟹邪褌褜 top-N 褋泻懈谢芯胁 锌芯 蟹胁褢蟹写邪屑 懈蟹 胁褋械谐芯 泻邪褌邪谢芯谐邪 |
| `--stats` | `--stats` | 小褌邪褌懈褋褌懈泻邪 泻邪褌邪谢芯谐邪 锌芯 懈褋褌芯褔薪懈泻邪屑 懈 邪谐械薪褌邪屑 |
| `--category <cat>` | `--category design` | 袙褋械 褋泻懈谢褘 泻邪褌械谐芯褉懈懈 |

**袟薪邪褔械薪懈褟 锌芯 褍屑芯谢褔邪薪懈褞:** limit=5, page=1, **agent=codex** (褌械泻褍褖懈泄 邪谐械薪褌 鈥?Codex).

**袙邪卸薪芯 锌褉芯 `--agent`:** 锌芯 褍屑芯谢褔邪薪懈褞 锌芯泻邪蟹褘胁邪褞褌褋褟 褌芯谢褜泻芯 褋泻懈谢褘 褋芯胁屑械褋褌懈屑褘械 褋 褌械泻褍褖懈屑 邪谐械薪褌芯屑 (Claude Code). 袠褋锌芯谢褜蟹褍泄 `--agent any` 褔褌芯斜褘 褋薪褟褌褜 褎懈谢褜褌褉 懈 褍胁懈写械褌褜 胁械褋褜 泻邪褌邪谢芯谐, `--agent cursor` 褔褌芯斜褘 薪邪泄褌懈 褋泻懈谢褘 褌芯谢褜泻芯 写谢褟 Cursor 懈 褌.写.

---

## 协褌邪锌 0 鈥?袩褉芯胁械褉懈褌褜 褋胁械卸械褋褌褜 泻邪褌邪谢芯谐邪

```bash
CACHE_FILE="$HOME/.claude/skills/find-skill/cache/catalogue.json"
LAST_UPDATE="$HOME/.claude/skills/find-skill/cache/last_update.txt"

if [ ! -f "$LAST_UPDATE" ]; then
  echo "袣邪褌邪谢芯谐 薪械 懈薪懈褑懈邪谢懈蟹懈褉芯胁邪薪 鈥?薪褍卸薪芯 芯斜薪芯胁懈褌褜"
  NEEDS_UPDATE=true
else
  LAST=$(cat "$LAST_UPDATE")
  NOW=$(date +%s)
  DIFF=$(( (NOW - LAST) / 86400 ))
  if [ "$DIFF" -gt 30 ]; then
    echo "袣邪褌邪谢芯谐 褍褋褌邪褉械谢 ($DIFF 写薪械泄) 鈥?薪褍卸薪芯 芯斜薪芯胁懈褌褜"
    NEEDS_UPDATE=true
  else
    echo "袣邪褌邪谢芯谐 邪泻褌褍邪谢械薪 (芯斜薪芯胁谢褢薪 $DIFF 写薪械泄 薪邪蟹邪写)"
    NEEDS_UPDATE=false
  fi
fi
```

袝褋谢懈 `NEEDS_UPDATE=true` 鈥?蟹邪锌褍褋褌懈 `~/.claude/skills/find-skill/update-skills-catalogue.sh`.

---

## 协褌邪锌 1 鈥?袩芯薪褟褌褜 蟹邪锌褉芯褋

袝褋谢懈 蟹邪锌褉芯褋 薪械褟褋械薪 鈥?蟹邪写邪泄 1-2 胁芯锌褉芯褋邪:
- 袣邪泻芯泄 褋褌械泻/褟蟹褘泻/褎褉械泄屑胁芯褉泻?
- 袛谢褟 泻邪泻芯泄 泻芯薪泻褉械褌薪芯泄 蟹邪写邪褔懈?

袝褋谢懈 蟹邪锌褉芯褋 褟褋械薪 鈥?褋褉邪蟹褍 泻 褝褌邪锌褍 2.

---

## 协褌邪锌 2 鈥?袩芯懈褋泻 胁 谢芯泻邪谢褜薪芯屑 泻邪褌邪谢芯谐械

```bash
cat ~/.claude/skills/find-skill/cache/catalogue.json | \
  python3 -c "
import json, sys, re

data = json.load(sys.stdin)
query = 'QUERY'.lower()
limit = LIMIT        # 蟹邪屑械薪懈褌褜 薪邪 褔懈褋谢芯 懈蟹 锌邪褉邪屑械褌褉邪
page = PAGE          # 蟹邪屑械薪懈褌褜 薪邪 褔懈褋谢芯 懈蟹 锌邪褉邪屑械褌褉邪
show_all = SHOW_ALL  # True/False
agent_filter = 'AGENT_FILTER'  # 'claude', 'codex', 'opencode', 'cursor', 'any'

# 袩褉懈芯褉懈褌械褌 懈褋褌芯褔薪懈泻芯胁 鈥?斜邪谢谢褘 锌褉芯锌芯褉褑懈芯薪邪谢褜薪褘 蟹胁褢蟹写邪屑 薪邪 GitHub (邪锌褉械谢褜 2026)
SOURCE_PRIORITY = {
    'Anthropic': 60,              # 105K stars 鈥?芯褎懈褑懈邪谢褜薪褘械 褋泻懈谢褘 Anthropic
    'skills.sh': 30,              # Vercel-curated 泻邪褌邪谢芯谐, ~4K 褋泻懈谢芯胁
    'hesreallyhim': 28,           # 39.9K stars 鈥?褌芯锌 awesome-list
    'ComposioHQ': 25,             # 49K stars 鈥?泻褍褉懈褉芯胁邪薪薪褘泄 褋锌懈褋芯泻
    'vercel-labs': 12,            # 24K stars 鈥?Vercel agent skills
    'VoltAgent-subagents': 8,     # 15.5K stars 鈥?Claude Code subagents
    'VoltAgent': 7,               # 13K stars 鈥?awesome agent skills
    'travisvn': 5,                # 10K stars 鈥?泻褍褉懈褉芯胁邪薪薪褘泄 褋锌懈褋芯泻
    'BehiSecc': 4,                # 8K stars 鈥?泻褍褉懈褉芯胁邪薪薪褘泄 褋锌懈褋芯泻
    'alirezarezvani': 4,          # 8K stars 鈥?斜芯谢褜褕邪褟 泻芯谢谢械泻褑懈褟
    'heilcheng': 3,               # 3.5K stars 鈥?awesome agent skills
    'daymade': 3,                 # 744 stars 鈥?production-ready 泻芯谢谢械泻褑懈褟
    'mxyhi': 3,                   # 188 stars 鈥?ok-skills
    'SkillsMP': 3,                # 袦邪褉泻械褌锌谢械泄褋 (屑薪芯谐芯, 薪芯 屑械薪械械 锌褉芯胁械褉械薪褘)
}

# 袩芯懈褋泻: 懈屑褟, 芯锌懈褋邪薪懈械, 褌械谐懈 + 褎懈谢褜褌褉 锌芯 邪谐械薪褌褍
results = []
for s in data['skills']:
    # 肖懈谢褜褌褉 锌芯 邪谐械薪褌褍 (械褋谢懈 agent_filter != 'any')
    if agent_filter and agent_filter != 'any':
        skill_agents = s.get('agents', ['claude', 'codex'])  # legacy default
        if agent_filter not in skill_agents:
            continue

    score = 0
    name_l = s['name'].lower()
    desc_l = s.get('description', '').lower()
    tags_l = [t.lower() for t in s.get('tags', [])]

    # 袪械谢械胁邪薪褌薪芯褋褌褜 蟹邪锌褉芯褋褍
    if query == name_l:
        score = 100
    elif query in name_l:
        score = 50
    elif query in desc_l:
        score = 20
    elif any(query in t for t in tags_l):
        score = 10

    if score > 0:
        # 袘芯薪褍褋 蟹邪 懈褋褌芯褔薪懈泻 (锌褉懈芯褉懈褌械褌 写芯胁械褉懈褟)
        source = s.get('source', '')
        source_bonus = SOURCE_PRIORITY.get(source, 0)

        # 袘芯薪褍褋 蟹邪 蟹胁褢蟹写褘 (屑邪泻褋 +20)
        try:
            stars = int(str(s.get('stars', 0) or 0).replace(',','').replace('+',''))
        except:
            stars = 0
        stars_bonus = min(stars / 1000, 20)

        s['_score'] = score + source_bonus + stars_bonus
        s['_stars'] = stars
        s['_source_rank'] = source_bonus
        results.append(s)

# 小芯褉褌懈褉芯胁泻邪: score desc (胁泻谢褞褔邪械褌 source + stars), 蟹邪褌械屑 stars desc
results.sort(key=lambda x: (-x['_score'], -x['_stars']))

total = len(results)
if show_all:
    page_results = results
else:
    start = (page - 1) * limit
    page_results = results[start:start + limit]

total_pages = (total + limit - 1) // limit if not show_all else 1

output = {
    'total': total,
    'showing': len(page_results),
    'page': page if not show_all else 1,
    'total_pages': total_pages,
    'limit': limit,
    'agent_filter': agent_filter,
    'results': page_results
}
print(json.dumps(output, indent=2, ensure_ascii=False))
"
```

**袣邪泻 懈褋锌芯谢褜蟹芯胁邪褌褜 `agent_filter`:**
- 袩芯 褍屑芯谢褔邪薪懈褞 写谢褟 褝褌芯谐芯 褎邪泄谢邪: `agent_filter = 'claude'` (屑褘 胁 Claude Code)
- 袝褋谢懈 锌芯谢褜蟹芯胁邪褌械谢褜 褍泻邪蟹邪谢 `--agent any` 鈥?锌芯泻邪蟹邪褌褜 胁械褋褜 泻邪褌邪谢芯谐 (agent_filter = 'any')
- 袝褋谢懈 褍泻邪蟹邪谢 `--agent cursor|codex|opencode` 鈥?锌芯写褋褌邪胁懈褌褜 褝褌芯 蟹薪邪褔械薪懈械
- 袙 `--stats` 芯褌芯斜褉邪卸邪泄 褉邪褋锌褉械写械谢械薪懈械 锌芯 邪谐械薪褌邪屑

---

## 协褌邪锌 3 鈥?袞懈胁芯泄 锌芯懈褋泻 (械褋谢懈 胁 泻邪褌邪谢芯谐械 < 2 褉械蟹褍谢褜褌邪褌芯胁)

### SkillsMP API:
```bash
source "$HOME/.claude/skills/find-skill/.env" 2>/dev/null

# 袩芯懈褋泻 锌芯 泻谢褞褔械胁芯屑褍 褋谢芯胁褍
curl -s "https://skillsmp.com/api/v1/skills/search?q=QUERY&limit=LIMIT" \
  -H "Authorization=[REDACTED_SECRET] $SKILLSMP_API_KEY"

# AI 褋械屑邪薪褌懈褔械褋泻懈泄 锌芯懈褋泻
curl -s "https://skillsmp.com/api/v1/skills/ai-search?q=QUERY+CONTEXT" \
  -H "Authorization=[REDACTED_SECRET] $SKILLSMP_API_KEY"
```

---

## 协褌邪锌 4 鈥?袩芯泻邪蟹邪褌褜 褉械蟹褍谢褜褌邪褌褘

**袧懈泻芯谐写邪 薪械 褍褋褌邪薪邪胁谢懈胁邪褌褜 斜械蟹 锌芯写褌胁械褉卸写械薪懈褟.**

肖芯褉屑邪褌 胁褘胁芯写邪 蟹邪胁懈褋懈褌 芯褌 泻芯谢懈褔械褋褌胁邪:

### 校褉芯胁薪懈 写芯胁械褉懈褟 (锌芯 懈褋褌芯褔薪懈泻褍, 蟹胁褢蟹写褘 邪锌褉械谢褜 2026):
```
Anthropic (105K)                              鈫?袨褎懈褑懈邪谢褜薪褘泄 (蟹械谢褢薪褘泄)
skills.sh (Vercel-curated, ~4K entries)       鈫?袨褎懈褑懈邪谢褜薪褘泄 泻邪褌邪谢芯谐 (蟹械谢褢薪褘泄)
hesreallyhim (39.9K) / ComposioHQ (49K)       鈫?孝芯锌 awesome-list (蟹械谢褢薪褘泄)
vercel-labs (24K)                             鈫?袣褍褉懈褉芯胁邪薪薪褘泄 (卸褢谢褌褘泄)
VoltAgent-subagents (15.5K) / VoltAgent (13K) 鈫?袣褍褉懈褉芯胁邪薪薪褘泄 (卸褢谢褌褘泄)
travisvn (10K) / BehiSecc (8K)                鈫?袣褍褉懈褉芯胁邪薪薪褘泄 (卸褢谢褌褘泄)
alirezarezvani (8K) / heilcheng (3.5K)        鈫?小芯芯斜褖械褋褌胁芯-锌褉芯胁械褉械薪薪褘泄 (芯褉邪薪卸械胁褘泄)
daymade (744) / mxyhi (188)                   鈫?小芯芯斜褖械褋褌胁芯 (芯褉邪薪卸械胁褘泄)
SkillsMP                                      鈫?袦邪褉泻械褌锌谢械泄褋 (褋械褉褘泄, 锌褉芯胁械褉褟褌褜 胁褉褍褔薪褍褞)
```

### 袣芯屑锌邪泻褌薪褘泄 (写芯 5 褉械蟹褍谢褜褌邪褌芯胁):
```
袧邪泄写械薪芯 N 褋泻懈谢芯胁 锌芯 蟹邪锌褉芯褋褍 "QUERY":

鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣
1. [薪邪蟹胁邪薪懈械] (袪袝袣袨袦袝袧袛袨袙袗袧袨)
   袠褋褌芯褔薪懈泻  : Anthropic        | 袛芯胁械褉懈械: 袨褎懈褑懈邪谢褜薪褘泄
   袨锌懈褋邪薪懈械  : [1-2 锌褉械写谢芯卸械薪懈褟]
   袟胁褢蟹写褘    : [N]
   Repo      : [URL]
鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣鈹佲攣
2. [薪邪蟹胁邪薪懈械]
   袠褋褌芯褔薪懈泻  : SkillsMP         | 袛芯胁械褉懈械: 袦邪褉泻械褌锌谢械泄褋 鈥?锌褉芯胁械褉褜 repo
   ...

校褋褌邪薪芯胁懈褌褜? (1, 2, 胁褋械, 懈谢懈 薪械褌)
```

### 孝邪斜谢懈褔薪褘泄 (6+ 褉械蟹褍谢褜褌邪褌芯胁):
```
袧邪泄写械薪芯 N 褋泻懈谢芯胁 锌芯 蟹邪锌褉芯褋褍 "QUERY" (褋褌褉. PAGE/TOTAL_PAGES):

| #  | 袧邪蟹胁邪薪懈械          | 袠褋褌芯褔薪懈泻   | 袛芯胁械褉懈械 | 袟胁褢蟹写褘 | 袨锌懈褋邪薪懈械 (泻褉邪褌泻芯)      |
|----|-------------------|-----------|---------|--------|------------------------|
| 1  | skill-name        | Anthropic | 袨褎懈褑.   | 9600   | 袣褉邪褌泻芯械 芯锌懈褋邪薪懈械...    |
| 2  | another-skill     | travisvn  | 袣褍褉懈褉.  | 5600   | 袣褉邪褌泻芯械 芯锌懈褋邪薪懈械...    |
| 3  | some-skill        | SkillsMP  | 袦邪褉泻械褌. | 120    | 袣褉邪褌泻芯械 芯锌懈褋邪薪懈械...    |

小褌褉邪薪懈褑邪 PAGE 懈蟹 TOTAL_PAGES. 小谢械写褍褞褖邪褟: /find-skill QUERY --page NEXT
校褋褌邪薪芯胁懈褌褜? (薪芯屑械褉, 写懈邪锌邪蟹芯薪 1-3, 胁褋械, 懈谢懈 薪械褌)
```

袪械蟹褍谢褜褌邪褌褘 邪胁褌芯屑邪褌懈褔械褋泻懈 芯褌褋芯褉褌懈褉芯胁邪薪褘: 褋薪邪褔邪谢邪 芯褎懈褑懈邪谢褜薪褘械 懈 泻褍褉懈褉芯胁邪薪薪褘械, 蟹邪褌械屑 community, 胁 泻芯薪褑械 屑邪褉泻械褌锌谢械泄褋. 袩褉懈 芯写懈薪邪泻芯胁芯屑 懈褋褌芯褔薪懈泻械 鈥?锌芯 蟹胁褢蟹写邪屑.

---

## 协褌邪锌 5 鈥?校褋褌邪薪芯胁懈褌褜 锌芯褋谢械 锌芯写褌胁械褉卸写械薪懈褟

```bash
mkdir -p ~/.claude/skills
git clone [REPO_URL] ~/.claude/skills/[SKILL_NAME]
echo "Skill [SKILL_NAME] 褍褋褌邪薪芯胁谢械薪"

# 袩褉芯胁械褉泻邪
ls ~/.claude/skills/[SKILL_NAME]/
head -10 ~/.claude/skills/[SKILL_NAME]/SKILL.md
```

---

## 协褌邪锌 6 鈥?袩芯写褌胁械褉写懈褌褜 懈 芯斜褗褟褋薪懈褌褜

袩芯褋谢械 褍褋褌邪薪芯胁泻懈:
1. 袚写械 褍褋褌邪薪芯胁谢械薪 褋泻懈谢
2. 袣邪泻 邪泻褌懈胁懈褉芯胁邪褌褜 (`/skill-name` 懈谢懈 邪胁褌芯屑邪褌懈褔械褋泻懈)
3. 袩褉懈屑械褉 懈褋锌芯谢褜蟹芯胁邪薪懈褟 胁 褌械泻褍褖械屑 锌褉芯械泻褌械

---

## 小锌械褑懈邪谢褜薪褘械 泻芯屑邪薪写褘

| 袟邪锌褉芯褋 | 袛械泄褋褌胁懈械 |
|--------|----------|
| `芯斜薪芯胁懈 泻邪褌邪谢芯谐` | 袟邪锌褍褋褌懈褌褜 `update-skills-catalogue.sh` |
| `泻芯谐写邪 芯斜薪芯胁谢褟谢褋褟 泻邪褌邪谢芯谐?` | 袩芯泻邪蟹邪褌褜 写邪褌褍 懈蟹 `last_update.txt` |
| `锌芯泻邪卸懈 胁械褋褜 泻邪褌邪谢芯谐` | 袙褋械 褋泻懈谢褘 锌芯 泻邪褌械谐芯褉懈褟屑 |
| `--top 20` | Top-20 锌芯 蟹胁褢蟹写邪屑 |
| `--stats` | 小褌邪褌懈褋褌懈泻邪 锌芯 懈褋褌芯褔薪懈泻邪屑 |
| `react --all` | 袙褋械 褋泻懈谢褘 锌芯 蟹邪锌褉芯褋褍 |
| `python --limit 10 --page 2` | 小褌褉. 2 锌芯 10 褉械蟹褍谢褜褌邪褌芯胁 |

---

## 袩褉邪胁懈谢邪

- **袧懈泻芯谐写邪 薪械 褍褋褌邪薪邪胁谢懈胁邪褌褜 斜械蟹 锌芯写褌胁械褉卸写械薪懈褟**
- **小薪邪褔邪谢邪 泻褝褕, 锌芯褌芯屑 API** (褝泻芯薪芯屑懈屑 500 req/写械薪褜)
- **袩芯 褍屑芯谢褔邪薪懈褞 5 褉械蟹褍谢褜褌邪褌芯胁**, 薪芯 锌芯谢褜蟹芯胁邪褌械谢褜 屑芯卸械褌 蟹邪锌褉芯褋懈褌褜 斜芯谢褜褕械
- **小懈谐薪邪谢懈蟹懈褉芯胁邪褌褜 褉懈褋泻懈** 械褋谢懈 懈褋褌芯褔薪懈泻 薪械懈蟹胁械褋褌械薪
- **袩褉懈芯褉懈褌械褌**: Anthropic (105K) > skills.sh (Vercel-catalog) > hesreallyhim (39.9K) > ComposioHQ (49K) > vercel-labs (24K) > VoltAgent-subagents (15.5K) > VoltAgent (13K) > travisvn (10K) > BehiSecc/alirezarezvani (8K) > heilcheng (3.5K) > daymade/mxyhi > SkillsMP
- **孝邪斜谢懈褔薪褘泄 褎芯褉屑邪褌** 锌褉懈 6+ 褉械蟹褍谢褜褌邪褌邪褏 写谢褟 泻芯屑锌邪泻褌薪芯褋褌懈

---

## 袛械邪泻褌懈胁邪褑懈褟 / 褍写邪谢械薪懈械

### 袙褉械屑械薪薪芯 芯褌泻谢褞褔懈褌褜
```bash
mv ~/.claude/skills/find-skill ~/.claude/skills/find-skill-disabled
```

### 袙泻谢褞褔懈褌褜 芯斜褉邪褌薪芯
```bash
mv ~/.claude/skills/find-skill-disabled ~/.claude/skills/find-skill
```

### 袨褋褌邪薪芯胁懈褌褜 邪胁褌芯芯斜薪芯胁谢械薪懈械 (cron)
```bash
crontab -l | grep -v "update-skills-catalogue" | crontab -
```

### 袩芯谢薪芯褋褌褜褞 褍写邪谢懈褌褜
```bash
crontab -l | grep -v "update-skills-catalogue" | crontab -
rm -rf ~/.claude/skills/find-skill
```
