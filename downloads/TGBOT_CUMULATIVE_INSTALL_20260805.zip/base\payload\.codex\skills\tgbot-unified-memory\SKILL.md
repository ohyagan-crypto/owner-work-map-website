---
name: tgbot-unified-memory
description: Apply the owner's consolidated memory, cross-skill corrections, Telegram delivery rules, and workflow improvements inside the single unified TGBOT.
---
# Unified TGBOT Memory

This skill carries the consolidated corrections learned from the owner's previous Telegram assistants. Those assistants are source material only; every live task now runs through one TGBOT identity.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## Unified Memory Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: consolidated owner conversation histories and daily summaries
- Runtime: one TGBOT backend, one Bot token, one same-origin delivery route

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級只更新這一個 TGBOT 的 dated memory、技能修正覆蓋區與 learning index；明確穩定規則才寫回 SKILL.md。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














