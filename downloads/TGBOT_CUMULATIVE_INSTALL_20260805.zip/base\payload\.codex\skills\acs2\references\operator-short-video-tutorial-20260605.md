# ACS2 Operator Short-Video Tutorial

This reference comes from the operator-provided YouTube tutorial analyzed on 2026-06-05.

## What The Tutorial Teaches

The tutorial is a phone-style Jianying/CapCut short-video editing process. The key is not random trimming. The key is replicating a reference video's rhythm:

```text
material order -> clip duration -> caption rhythm -> flower text style -> BGM beat points -> transitions -> export
```

## Practical Flow

1. Prepare the reference video and source materials.
2. Analyze the reference video with shot/timecode precision.
3. Create a shot list: start time, end time, duration, visual content, caption, flower text, BGM/transition notes.
4. Open Jianying/CapCut and start a new creation.
5. Import materials in the same order as the reference.
6. Add all materials to the timeline.
7. Cut away unnecessary pauses, repeated frames, and empty sections.
8. Adjust every clip duration to match the reference rhythm.
9. Add transitions or material joins that match the reference.
10. Use built-in subtitle recognition.
11. Correct subtitle text, timing, and placement.
12. Add 花字 / title text / emphasis text.
13. Match flower text style to the reference.
14. Add or align BGM to match the reference beat.
15. Add stickers, effects, and sound effects only if they appear in the reference or help match it.
16. Preview the full edit.
17. Export the final video.

## Quality Checklist

- Reference video has been analyzed before editing.
- Shot/timecode list exists before timeline assembly.
- Materials are imported in reference order.
- Timeline order matches the reference.
- Clip lengths match reference timing as closely as possible.
- Captions use Jianying recognition.
- Captions are readable and timed correctly.
- Flower text matches original video style.
- BGM and cuts align to the same perceived rhythm.
- Transitions match the reference.
- Final video has no blank frames, wrong clips, or broken audio.
