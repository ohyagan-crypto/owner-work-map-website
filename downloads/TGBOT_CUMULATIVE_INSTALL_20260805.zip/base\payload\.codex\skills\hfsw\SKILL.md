---
name: hfsw
description: Use when the owner says hfsw, asks for a Claude-first Hyperframes story video, asks to make a Guan Yu/Zhang Fei style story video, or asks for script-first images-second Hyperframes final video production.
---

## 2026-07-16 Owner-Approved Full QA Upgrade

Owner approval: `可以，全部升級`.

All new HFSW outputs now require the same six gates as TGBOT: final-narration phrase alignment, raised-caption mobile safe-area validation, phone-speaker voice/BGM validation, teaching-step scene mapping, hash-based layer repair protection, and an automated final review report. Canonical tools are exposed in this skill folder as `tools/hfsw_subtitle_align.ps1`, `tools/hfsw_create_layer_state.ps1`, and `tools/hfsw_finalize_qa.ps1`. Any `FAIL` blocks delivery; warnings require manual review notes. Telegram same-origin document delivery remains the final completion gate.

## 2026-07-16 Latest Owner-Approved Default - 0.9x Pace + Synced Raised Captions

Owner approval: `終於可以 保存這次成功方式以後語速預設這個`.

Approved deliverable baseline: `E:\COOCMEMORY\20260716_hfsw_botfather_tutorial\TGBOT_HFSW_BotFather_API_Traditional_9x16_speed0.9_subtitle_synced_raise10pct_20260716.mp4`

This section overrides the older `1.3x` HFSW speed default unless the owner explicitly requests another speed.

1. Default overall HFSW speed is now `0.9x`.
2. Apply the same speed transformation to narration, visuals, BGM, and subtitle timing so the complete output remains synchronized.
3. Rebuild subtitle timing from the final narration timeline; do not rely only on proportional timecode scaling when speech boundaries differ.
4. Default captions remain Traditional Chinese, Kai-style, white with thick black outline, short phrase chunks, and mobile-readable sizing.
5. Place captions 10% of the frame height higher than the prior bottom baseline while keeping them inside the safe area and free from cropping.
6. For requested exact final duration, prepare enough source content so the final `0.9x` output lands on the requested duration.
7. Record `speed=0.9x`, `subtitle_timing=rebuilt_from_final_narration`, and `subtitle_vertical_offset=raise_10pct_frame_height` in the mix manifest.
8. Preserve the approved speed and caption placement during later BGM or visual repairs unless the owner explicitly asks to change them.

## 2026-07-16 Workflow Isolation - No M01/M02 In HFSW

Owner correction: `只有sd視頻才有m01 m02 這些事不要再搞混了`.

1. `M01 / M02 / M03` material numbering belongs only to SD video workflows such as SD, SDF, SDV, Dreamina, and Seedance when they actually receive multiple reference materials.
2. HFSW must never introduce `M01 / M02` labels, even when HFSW receives images, audio, video, documents, or multiple references.
3. HFSW materials must be described by their real role or filename, such as `角色參考圖`, `口音參考`, `指定 BGM`, `字幕參考`, or the actual filename.
4. A no-material HFSW task starts directly from the topic and script. Never invent, import, or discuss material numbers from an older SD, IMS, CMSD, or unrelated task.
5. If prior context contains `M01 / M02`, ignore those labels unless the newest owner instruction explicitly switches the current task to an SD video workflow.

## 2026-07-15 Owner-Approved Default - Accent 1 + 1.3x Pace

Owner approved the latest Codex HFSW accelerated version and requested its accent and speed as the new defaults.

Accent reference: `C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

- Verified as 300 seconds, H.264 720x1280 at 30 fps, AAC 48 kHz stereo.
- This is the official `Accent 1 / Chinese accent` reference.
- Its mixed audio has low-audio gaps around 84s, 174s, and 264s, so use it only for accent/cadence, never as clean BGM or final narration audio.

Successful pace baseline: `E:\COOCMEMORY\20260715_hfsw_codex_speed_1_3x\codex_hfsw_9x16_accent1_bgm_speed_1.3x_compact_20260715.mp4`

- Verified as about 230.92 seconds, H.264 1080x1920, AAC 48 kHz stereo.

Default rules unless the owner explicitly overrides them:

1. Use `Accent 1 / Chinese accent` as the default narration accent. Use the owner's personal Telegram voice only when explicitly requested.
2. Use a `1.3x` overall storytelling pace. Apply the same timing transformation to narration, visuals, subtitles, and BGM.
3. For an exact requested final duration, author enough source content so the final 1.3x output still lands on that duration. Existing videos may shorten normally when accelerated.
4. Keep large bottom Traditional Chinese Kai-style captions synchronized after speed changes; no cropping or double subtitles.
5. Keep clean BGM behind the voice, starting at 0 seconds and continuing through the full output. No noisy SFX by default.
6. BGM, subtitle, or visual repairs must preserve the approved accent and speed unless the owner requests a change.
7. Record `accent=Accent 1` and `speed=1.3x` in each HFSW mix manifest.
8. Completion still requires platform-image validation when expected, audio dropout checks, subtitle sync checks, final media validation, and same-origin document delivery by whichever bot received the task (TGBOT, TGBOT, or TGBOT).

## 2026-07-12 HFSW Production QA Upgrade - Stems, Mix Manifest, Audio Gate, Subtitle Gate

Owner approved the HFSW upgrade after repeated Liu Bang/Zhang Fei issues involving noisy BGM, subtitles not aligned, and segments that sounded like no audio.

This is now the highest active HFSW completion gate and overrides older weaker validation rules.

## 2026-07-13 True Owner Voice Accent Override

Owner correction from TGBOT: `這才是我的口音`.

Exact inspected Telegram voice:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_voice_20260713_204932.ogg`

Backup/reference files:

- `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.ogg`
- `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.wav`

Verification:

- Duration: 105.4 seconds.
- Format: OGG / Opus, 48 kHz, mono.
- Size: 2,170,938 bytes.
- SHA256: `9D6FE481C788F1086A764CC63C826F40E39F13B64AB72FBD5B78D4190C6483E7`.
- Volume: mean about -21.1 dB, max about -1.7 dB.
- Natural speech pauses detected at several boundaries; these are acceptable as cadence reference pauses, not BGM gaps.

Rules:

1. This Telegram voice is now the primary HFSW owner personal accent reference for `我的口音`, `我的語音`, `主人口音`, `主人語音`, `主人本人口音`, `口述口音`, and similar wording.
2. This overrides the earlier 300-second replied-video path as the priority owner accent source. The old video may remain a secondary visual/subtitle/history reference, but it is no longer the primary owner voice reference.
3. Use this OGG/WAV as the voice reference when the production route supports voice reference or cloning.
4. If exact voice cloning is unavailable, do not claim exact cloning. Record the actual fallback voice route and state that it was tuned toward this owner voice reference.
5. Do not use this Telegram voice as BGM. It is only for accent, cadence, rhythm, pause, pronunciation tendency, and speaking-feel reference.
6. Future HFSW manifests must record this path when the owner asks for `我的口音` or `主人口音`, unless the owner later explicitly replaces it with a newer voice sample.

## 2026-07-13 Owner Voice Must Mean Owner Voice Accent

Owner correction from TGBOT: `我是要用我的語音做口音`.

2026-07-13 later priority correction: `這才是我的口音`.

Primary owner voice/accent reference is now:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_voice_20260713_204932.ogg`

The older inspected video below is retained only as secondary context unless the owner explicitly points back to that exact video.

Exact inspected video:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Verification: 300 seconds, 720x1280, H.264, AAC 48 kHz stereo, SHA256 `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`, mean audio level about -16.7 dB, with low-audio gaps around 84.25s, 174.28s, and 264.15s.

Rules:

1. `我的語音`, `我的口音`, `主人語音`, `主人口音`, `主人本人口音`, `用我的語音做口音`, and `用我的口音做口述口音` mean the Telegram voice `telegram_voice_20260713_204932.ogg` must be used as the owner's primary personal narration accent reference.
2. This is an accent / cadence / rhythm / pronunciation reference. It is not a request to use a generic Chinese male TTS voice.
3. If a real voice-cloning route is available, use the Telegram voice file as the voice reference and record that route in the mix manifest.
4. If real cloning is not available, do not claim the voice was changed into the owner's voice. Record the closest available storyteller fallback and clearly mark it as a fallback.
5. Never use the older video's mixed audio as clean BGM or final narration audio. The older source has detected low-audio gaps and production audio.
6. Before reporting that an HFSW output used the owner's voice/accent, inspect the final manifest or final audio route and confirm it did not silently fall back to the old Yunxi/Yunjian/default voice unless explicitly recorded as fallback.

### Required Artifacts For Every New HFSW Task

Each HFSW task folder must keep these non-secret artifacts when technically possible:

1. `voice.*` or a clear approved voice source record.
2. `bgm.*` or a clear BGM source record.
3. `subtitles.srt` / `subtitles.ass` / generated subtitle timing file when subtitles are rebuilt.
4. `mix_manifest_YYYYMMDD_HHMMSS.md` describing voice preset, BGM source, loop method, BGM gain, ducking, subtitle source, image count, ratio, and validation result.
5. Platform image inventory showing which final scenes came from aggregation platform / Blue Star and which scene numbers are missing or replaced.
6. Final MP4 plus QA output from `tools/hfsw_media_qa.ps1` when `ffprobe` and `ffmpeg` are available.

If a legacy task has only a final mixed MP4, state that limitation in the manifest before repairing. Do not claim exact voice/BGM separation if stems are unavailable.

### Audio QA Gate

Before HFSW delivery, validate audio as a practical listening product, not only as a stream:

1. `ffprobe` must show a valid audio stream.
2. BGM must start at 0 seconds when BGM is part of the task.
3. BGM must loop or continue through the full runtime; no silent intro, no mid-video dead air, no early fade-out.
4. Run silence/dropout detection. Reject repeated unintended gaps, especially near known bad boundaries around 84s, 174s, 264s, scene changes, middle sections, and the final minute.
5. Voice must stay dominant and understandable on phone speakers.
6. BGM must be audible but not noisy: avoid low-frequency-only rumble, harsh SFX, metal hits, whooshes, impact booms, or busy percussion unless the owner explicitly requests them.
7. Repairing BGM is a mix-only operation. Do not change an approved accent, narrator, speed, subtitle timing, or visual timing unless the owner explicitly asks.

### Subtitle QA Gate

Before HFSW delivery:

1. Extract frames at the opening, every 10 minutes for long videos, each scene boundary, known issue points, and the final minute.
2. Confirm bottom Kai-style captions are visible, readable, not doubled, not cut off left/right, and not shown before the corresponding voice starts.
3. If source subtitles are burned in and wrong, cover the old subtitle area and re-burn clean subtitles from a reliable timing file. Do not pretend an external subtitle edit fixes burned text.
4. For 1-hour videos, check at minimum: 00:10, 10:00, 20:00, 30:00, 40:00, 50:00, and the final minute, plus any known problem timestamps.

### Platform Image QA Gate

When the owner expects aggregation platform / Blue Star images:

1. Keep valid platform originals already generated and continue from the next missing scene.
2. Do not silently mix local fallback images into the final output.
3. If fallback images were used in a draft, replace them with platform images, force rerender affected segments, and validate late-video frames after rerendering.
4. The final manifest must record requested image count, valid platform image count, missing/replaced scene numbers, and sample frame checks.

### QA Tool

Use `tools/hfsw_media_qa.ps1` for repeatable checks when available:

```powershell
.\tools\hfsw_media_qa.ps1 -VideoPath "<final.mp4>" -ExpectedDurationSeconds 3600 -ExpectedWidth 1280 -ExpectedHeight 720 -OutDir "<task>\qa" -LongVideo
```

For 9:16 300-second videos:

```powershell
.\tools\hfsw_media_qa.ps1 -VideoPath "<final.mp4>" -ExpectedDurationSeconds 300 -ExpectedWidth 720 -ExpectedHeight 1280 -OutDir "<task>\qa"
```

The tool does not replace visual judgment. It creates probe/silence/frame outputs that must be inspected or summarized before completion.

### Completion Rule

HFSW is complete only when:

1. final MP4 exists and validates for duration, ratio, readable subtitles, AAC/usable audio, BGM continuity, and image cadence;
2. approved accent preset was preserved unless the owner requested a change;
3. platform-image expectations were satisfied;
4. final MP4 was uploaded in document mode by the same bot that received the task, to the same originating Telegram conversation and topic/thread when present.

## 2026-07-12 Audio QA Override - Noisy BGM, Subtitle Sync, Dropout Check

Owner correction: when the owner complains about `背景音很雜`, `字幕對上`, `無音頻`, or asks to `徹底檢查`, do not only check whether an audio stream exists.

Inspected reference:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Observed:

- The file is 300 seconds, 720x1280, AAC stereo.
- It has an audio stream, but contains detectable low-audio/silent gaps around 84s, 174s, and 264s.
- Captions are burned into the video, bottom Kai-style, and cannot be repaired as external subtitles.

Rules:

1. For HFSW audio complaints, inspect both the owner-provided/replied video and the latest delivered target video when context points to a different target such as Liu Bang.
2. `有音軌` is not enough. Run silence/dropout detection at practical thresholds and reject outputs with repeated audible gaps.
3. If the reference video itself has noisy BGM or intermittent silent gaps, do not use its mixed audio as a clean BGM or final-quality audio bed. Use it only as an accent/style reference unless the owner explicitly says to reuse its exact audio.
4. Subtitle alignment must be checked by extracted frames near scene and audio-boundary points. If subtitles are burned in and wrong, rebuild or cover the subtitle area and re-burn clean Kai-style subtitles from a reliable timing file.
5. For long HFSW videos, validate at least: first 10 seconds, every major chapter boundary, middle, final minute, and any known silence boundaries from the source/reference.
6. BGM must be clean, midrange-audible on phone speakers, start at 0 seconds, loop continuously, and stay behind the voice. Avoid low-frequency-only beds that sound like noise.
7. If only a final mixed video exists and narration is missing inside a gap, do not pretend it can be perfectly restored from the MP4. Rebuild from voice/script/stems when available; otherwise report that exact limitation.

## 2026-07-12 Latest Clean Accent Numbering Override

Owner latest TGBOT correction after inspecting:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Rules:

1. `口音-1` / `口音1` / `voice 1` / `中國口音` now means the accent in `telegram_replied_video_20260712_134206.mp4`.
2. This inspected file is 300 seconds, 720x1280, H.264, AAC 48 kHz stereo, SHA256 `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`.
3. `口音-2` / `口音2` / `voice 2` / `上一版本口音` means the previous-version HFSW accent before this latest Chinese-accent override.
4. If a concrete previous-version source is needed, first use `C:\Users\max\Desktop\龍蝦記憶\20260712_hfsw_liu_bang_voice1_yunjian_fixed\liu_bang_hfsw_1h_16x9_voice1_yunjian_accent_fixed_loud_tg_20260712.mp4`; older historical `口音-2` reference remains `C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260711_133100.mp4`.
5. Do not interpret `口音-1` or `口音-2` as volume, dB, pitch, or speed changes. They are accent identifiers only unless the owner explicitly says volume/dB/pitch/speed.
6. Keep Kai-style bottom subtitles, BGM from 0 seconds, continuous BGM loop, and voice-forward mix unless separately changed by the owner.

## 2026-07-13 Owner Personal Narration Accent

Owner correction: `要以我的口音做口述口音`.

2026-07-13 later priority correction: `這才是我的口音`.

Primary inspected source is now:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_voice_20260713_204932.ogg`

Backup/reference files:

- `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.ogg`
- `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.wav`

The older video below is no longer the primary owner personal narration accent.

Inspected source:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Verified: 300 seconds, 720x1280, H.264, AAC 48 kHz stereo, SHA256 `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`, mean audio level about -16.7 dB, with low-audio gaps around 84s, 174s, and 264s.

Rules:

1. `我的口音`, `我的語音`, `主人口音`, `主人語音`, `主人本人口音`, and `口述口音` mean the Telegram voice `telegram_voice_20260713_204932.ogg` is the owner's primary personal narration accent reference.
2. This overrides the older video as the primary owner voice source. Keep the older video only as secondary context unless explicitly requested.
3. Use the Telegram voice as a voice/accent reference or cloning reference when the available production route supports voice cloning.
4. If true cloning is not available, do not claim exact cloning. Record the closest storyteller fallback used.
5. Do not use either owner voice reference as clean BGM unless the owner explicitly asks. These are accent/cadence references.
6. HFSW outputs using the owner's personal narration accent still require clean BGM, subtitle sync, dropout checks, platform image validation when required, and same-origin delivery by the receiving bot.

## 2026-07-12 Latest HFSW Accent Override / Voice 1

### 2026-07-12 Voice 1 Correction: Do Not Use Yunxi As Voice 1

Owner correction: after the Liu Bang HFSW delivery, the owner said the accent had not changed.

Concrete issue found: the manifest claimed voice 1, but the narration was generated with `zh-CN-YunxiNeural` at rate `+22%` and pitch `+6Hz`. This must not be treated as the requested voice-1 accent.

Rule:

1. Do not label `zh-CN-YunxiNeural` as HFSW voice 1 for Liu Bang or future HFSW work.
2. The newest voice-1 reference remains `C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`.
3. If true voice cloning from the reference video is not locally available, do not claim that exact cloning happened.
4. Current local fallback for voice-1 storytelling is `zh-CN-YunjianNeural`, rate `+3%`, pitch `-3Hz`, recorded as a closest storyteller fallback.
5. Before reporting that an accent has changed, inspect the manifest and confirm the actual generated voice is not the old Yunxi route.
6. Corrected Liu Bang delivery: `C:\Users\max\Desktop\龍蝦記憶\20260712_hfsw_liu_bang_voice1_yunjian_fixed\liu_bang_hfsw_1h_16x9_voice1_yunjian_accent_fixed_loud_tg_20260712.mp4`.

Owner correction: "這個口音命名口音-1，用這個口音去做劉邦視頻" with the exact TGBOT uploaded/replied video below.

Latest `口音-1` / `口音編號1` / `voice 1` reference:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

SHA256:

`42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`

Inspected media:

- Duration: 300 seconds.
- Video: H.264, 720x1280, 30 fps, vertical.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.
- Visual/subtitle style: historical-storytelling video with large bottom Kai-style Traditional Chinese captions, white text, thick black outline.

Rules:

1. Treat this file as the latest `口音-1` / `口音編號1` / `voice 1` reference for HFSW.
2. This overrides older path wording for voice 1. If an older path has the same SHA256, it may be recognized as the same reference, but new work should record this 20260712_134206 path.
3. `口音-1` is a voice/accent identifier, not a volume reduction. Only change dB/volume when the owner explicitly says volume, dB, louder, quieter, or lower volume.
4. For Liu Bang and future HFSW fixes using `口音-1`, keep Kai-style bottom subtitles and BGM from 0 seconds with a continuous loop so there are no audible gaps.
5. If an existing Liu Bang HFSW render already uses the same SHA256 voice-1 reference, it may be reused only after revalidation and same-origin document delivery by the receiving bot.

## 2026-07-12 Current Correct HFSW Accent Override / Voice 1

Owner correction: "把這個口音變成是口音-1" with the exact TGBOT uploaded/replied video below.

Current `口音-1` / `口音編號1` / `voice 1` reference:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_131534.mp4`

Same-content prior copy:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_131018.mp4`

SHA256 for both copies:

`42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`

Inspected media:

- Duration: 300 seconds.
- Video: H.264, 720x1280, 30 fps, vertical.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.

Rules:

1. Treat this file as `口音-1` / `口音編號1` / `voice 1`, and as the latest correct HFSW replied-video accent source for Zhang Fei/HFSW when the owner says `this accent`, `this version accent`, `change back to this accent`, `kou yin 1`, `口音-1`, or `口音1` in this context.
2. Do not replace this accent with older HFSW references unless the owner explicitly says to use another numbered accent or uploads another new reference video.
3. Accent restoration is mix-only when possible: preserve the approved narration/accent, speech speed, subtitle timing, visual timing, and BGM loop unless the owner explicitly changes them.
4. Keep the accepted Kai-style bottom subtitles: large Traditional Chinese, white fill, thick black outline, bottom centered, short phrase chunks.
5. Keep BGM from 0 seconds and loop continuously to the end when BGM is requested. Voice remains dominant; BGM is audible but ducked under voice.
6. Do not interpret `voice -1`, `voice -2`, `ren sheng -1`, `ren sheng -2`, `口音-1`, or `口音-2` as dB reduction unless the owner clearly says volume, dB, or lower volume. Treat voice-number wording as accent selection.

## 2026-07-11 HFSW Voice Numbering Correction

2026-07-12 latest override:

- `口音-1` / `口音編號1` / `voice 1` now means:
  `C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260712_131534.mp4`
- This overrides older ambiguous "previous approved accent" wording.

Owner correction: the latest TGBOT clarification says `不是降分貝，是這個口音編號，口音編號2，上一個是口音編號1`.

Approved voice/accent number 2 reference:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260711_133100.mp4`

Rules:

1. Treat `口音編號1` as the previous approved HFSW accent before this correction.
2. Treat `口音編號2` as the voice/accent style in `telegram_replied_video_20260711_133100.mp4`.
3. Do not interpret `人聲-2`, `口音2`, `聲音2`, `voice 2`, or similar voice-number wording as lowering volume or dB.
4. Only lower volume when the owner explicitly says `降分貝`, `降低音量`, `音量-2`, or `-2dB`.
5. When applying `口音編號2`, preserve/use that voice/accent while keeping the accepted Kai-style bottom captions, BGM loop from 0 seconds, and visual timing unless the owner explicitly changes them.
6. The earlier `voice_minus2` interpretation was wrong and must not be used as the HFSW baseline.

## 2026-07-11 Keep Accent And Voice -2 Update

Status: superseded by later owner correction. The old interpretation below is retained only as history.

Current rule: `人聲-2`, `口音2`, `口音-2`, and similar wording are accent preset selectors, not volume changes, unless the owner explicitly says `降分貝`, `降低音量`, `音量-2`, or `-2dB`.

Approved additional accent reference:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260711_133100.mp4`

Latest voice-minus output:

`C:\Users\max\Desktop\龍蝦記憶\20260711_hfsw_voice_minus2\zhang_fei_hfsw_keep_this_accent_voice_minus2_20260711.mp4`

Historical rules that must not override the current numbering correction:

1. This replied video is also an approved HFSW accent source.
2. Preserve this accent, voice identity, speech speed, subtitle timing, visual timing, and BGM loop unless the owner explicitly asks to change them.
3. `人聲-2` means lower the dominant narration/voice by about 2 dB with mix-only processing. Do not re-TTS, do not swap narrator, and do not change the accepted accent.
4. If stems exist, reduce only the narration stem by 2 dB and keep BGM unchanged.
5. If only the final mixed video exists, use center-vocal attenuation or the closest non-destructive mix method, then validate BGM still starts at 0 seconds and continues through the whole video.

## 2026-07-11 Owner-Approved HFSW Success Mode

Approved reference video:

`C:\Users\max\tg-openai-bot\telegram_uploads\telegram_replied_video_20260711_115648.mp4`

Latest approved output:

`C:\Users\max\Desktop\龍蝦記憶\20260711_hfsw_revert_to_replied_accent\zhang_fei_hfsw_replied_accent_loop_bgm_from_start_v2_20260711.mp4`

Apply this mode by default for future `hfsw` historical story videos:

1. Keep the approved voice/accent fixed. Do not re-TTS, swap narrator, change accent, change speech speed, or alter narration unless the owner explicitly asks.
2. BGM repair is mix-only: preserve the voice, subtitle timing, and video timing. Do not touch the accepted narration when only BGM is being fixed.
3. Use the approved subtitle look: Kai-style / DFKai-SB when available, large centered Traditional Chinese captions near the bottom, white fill, thick black outline, subtle shadow, short phrase chunks.
4. Use soft original pirate-adventure / heroic orchestral / maritime-epic BGM. Do not use or recreate a copyrighted original recording or exact melody unless the owner provides licensed audio.
5. BGM must start at 0 seconds and loop continuously through the full video. No silent intro, no mid-video gaps, no early fade-out.
6. BGM must be audible but ducked under narration. Voice remains the lead and must stay clear on phone speakers.
7. Do not add noisy SFX by default. Avoid metal hits, whooshes, impact booms, harsh transitions, busy percussion, and low-frequency rumble.
8. If the owner replies to a video and says "this version" for accent, inspect that replied video and treat its audio as the voice/accent reference.
9. Validate output for duration, 9:16 video, AAC audio, readable bottom captions, no mixed-in old materials, BGM audible from the first second, full-length BGM loop, and same-origin Telegram document delivery.
10. Recommended next upgrade: keep a per-task mix manifest with voice source, BGM source, loop method, BGM gain, ducking settings, and ffprobe validation summary so future repairs can be mix-only.

## 2026-07-12 Run-Until-Good Rule

Owner correction: future `hfsw` jobs must continue until the deliverable is actually good, validated, and delivered. Do not stop at partial images, local fallback renders, queued platform tasks, a local path, or a first MP4 if it does not match the owner-approved route.

Rules:

1. If the owner says the aggregation platform already generated some images, inspect the real task folder and platform/cache state, keep valid platform originals, and continue from the next missing scene instead of restarting.
2. Do not silently mix local fallback images into a platform-image HFSW video. Local fallback images are only temporary placeholders and do not count as final when the owner expects platform images.
3. If fallback images were already used in a delivered draft, replace them with platform images, force-rerender affected video segments, then remux the final MP4.
4. Validate the final MP4 after rerendering, not only the image folder: duration, 16:9 or requested ratio, audio, BGM from 0 seconds, subtitle visibility, image count, and representative late-video frames.
5. Completion requires same-origin Telegram document upload success. If delivery is blocked, report the exact blocker and local backup path.

# HFSW - Hyperframes Story Workflow

更新日期：2026-07-10

## 2026-07-13 Owner Voice Reference

Owner provided a TGBOT voice recording to use as an HFSW owner voice/accent reference.

2026-07-13 later priority correction: `這才是我的口音`.

Current primary owner voice reference:

- Original: `C:\Users\max\tg-openai-bot\telegram_uploads\telegram_voice_20260713_204932.ogg`
- Backup: `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.ogg`
- WAV: `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.wav`

The older 143544 voice below is superseded unless the owner explicitly asks for it.

Reference files:

- Original: `C:\Users\max\tg-openai-bot\telegram_uploads\telegram_voice_20260713_143544.ogg`
- Backup: `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_voice_reference_20260713_143544\owner_hfsw_voice_reference_20260713_143544.ogg`
- WAV: `C:\Users\max\Desktop\龍蝦記憶\hfsw_owner_voice_reference_20260713_143544\owner_hfsw_voice_reference_20260713_143544.wav`

Inspection:

- Duration: about 105.4 seconds.
- Audio: Opus, 48 kHz, mono.
- SHA256: `9D6FE481C788F1086A764CC63C826F40E39F13B64AB72FBD5B78D4190C6483E7`.

Rule:

1. Use the 204932 Telegram voice as the current owner voice/accent, rhythm, cadence, and pause reference unless the owner explicitly asks for another numbered sample.
2. Do not treat it as clean BGM.
3. If exact voice cloning is unavailable, state that the closest available HFSW voice preset will be tuned toward this reference instead of claiming exact cloning.
4. The 204932 Telegram voice replaces previous `我的口音` / `主人口音` / `口述口音` references. It does not redefine `口音-2` unless the owner explicitly says so.

`hfsw` 是「先文案、再圖片、最後 Hyperframes 合成」的說書影片工作流。它不是 SD / Seedance 直接圖生影片。

## 觸發詞

收到以下說法時啟用：

- `hfsw`
- `HFSW`
- 關羽成功方式
- 張飛那種影片
- Hyperframes 說書影片
- 先 Claude 產文案，再做圖，再 Hyperframes
- 全新主題、全新圖片、真人口述、BGM、音效、底部字幕的長影片

## 核心原則

1. 新任務預設從零開始，不混入舊素材、舊人物、舊照片、舊影片，除非主人明確說沿用。
2. 沒有素材時，不列 `M01 / M02 / M03`，直接當成「無素材起案」。
3. 第一階段一定先用聚合平台最高可用 Claude，優先 `Claude 4.8 Opus`，產出完整企劃。
4. 第二階段才依文案生成對應圖片；圖片必須對應每一段內容，不做泛用氣氛圖。
5. 第三階段進 Hyperframes 合成；Hyperframes 是影片排版、動畫、字幕、音訊與輸出的主體。
6. Telegram 來源任務必須把最終 MP4 用同一個來源 bot / chat 文件模式回傳，只有本機路徑不算完成。

## 預設成片規格

1. 比例：`9:16` 直式。
2. 長度：預設 `300 秒`，除非主人指定。
3. 圖片節奏：每 `30 秒` 換一張圖；300 秒預設 `10 張圖 / 10 段`。
4. 字幕：標楷體 / DFKai-SB 優先，底部置中，大字白色、粗黑邊、微黑影，短句分段。
5. 口音：若主人說「我的語音／我的口音／主人口音」，優先使用主人本人口音參考；不能用普通 TTS 口音冒充。未指定時才沿用最近已通過的 hfsw 口音基準。
6. 音量：人聲更大、更靠前；BGM 與音效壓低，不能蓋過口述；加限制避免爆音。
7. 語言：繁體中文，禁止簡體字、亂碼、水印、錯誤 logo。

## 升級版標準流程

### 1. 需求鎖定

先確認唯一任務：

- 主題是什麼。
- 是否全新無素材。
- 是否有指定長度、比例、字幕風格、口音或交付方式。
- 是否會消耗藍星 / 聚合平台點數；若會，提交前要等主人確認，除非主人已明確授權直接執行。

### 2. Claude 4.8 Opus 企劃

先到聚合平台用 Claude 4.8 Opus 產出完整企劃，至少包含：

- 300 秒真人說書口述稿。
- 每 30 秒一段，共 10 段。
- 每段主旨、畫面重點、字幕短句。
- 每段圖片提示詞。
- 每段 BGM / 音效提示。
- 每段 Hyperframes 動作設計。
- 角色或主題一致性規則。
- 禁止元素與風險提醒。

企劃品質閘門：

- 文案必須真的講主題，不可泛用空話。
- 口述稿要像真人說書，不可逐字硬念。
- 每段要能獨立對應一張圖片。
- 字幕短句要適合手機閱讀。

### 3. 圖片生成

依 Claude 產出的 10 段文案做 10 張圖：

- 每張圖只對應自己的 30 秒段落。
- 全片風格一致。
- 不加入舊素材或無關人物。
- 圖片本身盡量無字，避免亂字。
- 使用藍星 / IMS 生成圖片時，必須遵守 IMS 確認清單與扣點前確認規則。

### 4. Hyperframes 合成

建立 Hyperframes 專案：

- `index.html` 是主時間軸。
- 10 張圖各約 30 秒。
- 加緩慢推近、視差、光影、煙塵、旗幟、刀鋒或主題相符動態。
- 字幕固定底部，不要飄到上方，不要疊到舊字幕。
- 口述 MP3、BGM、音效分軌處理。
- 人聲明顯在前，BGM / SFX 只做氣氛。

### 5. 口述與混音

口述規格：

- 使用張飛通過版的男聲說書風格。
- 抑揚頓挫明顯，有停頓、有重音。
- 內容要清楚可懂，不能只追求戲劇感。
- 長度要貼合影片總長。

混音規格：

- 先讓人聲可懂，再加 BGM / SFX。
- 手機外放也要聽得清楚。
- 必須限制峰值，避免爆音。
- 若主人要求更大聲，優先提高人聲並壓低 BGM / SFX，而不是整體硬拉。

### 6. 字幕規格

預設字幕：

- 字體：標楷體 / DFKai-SB。
- 位置：底部置中。
- 樣式：白字、粗黑邊、微黑影。
- 節奏：短句分段，對齊口述。
- 禁止：小字、上方標題條、雙層字幕、亂碼、簡體字。

### 7. 驗證

交付前必須驗證：

- MP4 存在且可讀。
- 長度符合目標，例如 300 秒。
- 比例正確，例如 9:16。
- 有音訊。
- 字幕可讀、底部置中、沒有疊字幕。
- 每 30 秒左右有換圖或明確場景變化。
- 抽幀確認不是黑畫面。
- 主題沒有混入舊任務素材。

### 8. Telegram 交付

Telegram 來源任務：

- 只能用同源 bot / chat 回傳。
- TGBOT 任務只能用 TGBOT 回傳，TGBOT 任務只能用 TGBOT 回傳，TGBOT 任務只能用 TGBOT 回傳。
- 優先文件模式送 MP4。
- 上傳成功後才算完成。
- 若來源 chat id 缺失或 Telegram 上傳失敗，才回報本機備份路徑與具體卡點。

## 主人確認前的回覆格式

```text
結論：我會用 hfsw 做成「……」，先確認後才送出會消耗點數的步驟。

製作判斷：
1. 主題：……
2. 是否無素材起案：……
3. 長度／比例：……
4. 圖片節奏：每 30 秒一張，共 … 張
5. 口述：依主人指定口音；若指定「我的語音／我的口音」，使用主人本人口音參考，無法真克隆時要明確標示 fallback
6. 字幕：標楷體大字，底部置中，白字粗黑邊
7. 合成：Claude 4.8 Opus → 藍星做圖 → Hyperframes → MP4

確認清單：
1. 文案：……
2. 圖片：……
3. 口述：……
4. BGM / 音效：……
5. 字幕：……
6. 驗證：……
7. 交付：同源 Telegram 文件模式

請回覆「確認」後，我才送出會扣點的生成步驟。
```

## 完成回覆格式

```text
完成了，已用 hfsw 做好並回傳同一個原始 Telegram 對話。

成品：
- MP4：……

驗證：
- 長度：……
- 尺寸：……
- 音訊：有
- 字幕：標楷體底部字幕可讀
- 圖片節奏：約每 30 秒換圖
- 抽幀：畫面正常，不是黑畫面
```

## 卡點處理

只在真實卡點時停止：

- Claude / 聚合平台登入或權限卡住。
- 藍星登入、驗證、額度、付款或權限卡住。
- 圖片生成失敗且重試後仍無有效圖。
- Hyperframes 渲染失敗且本機狀態確認後仍不可恢復。
- TTS / 口述生成不可用，且本機備援也不可用。
- Telegram 同源 chat id 缺失或上傳失敗。

卡點回覆要說清楚已完成什麼、卡在哪裡、保留的本機備份路徑與需要主人做什麼。

## 禁止事項

- 不要把 `hfsw` 當 SD / Seedance 直接生成。
- 不要先做圖再想文案。
- 不要混入上一輪素材。
- 不要在無素材任務列 M01 / M02。
- 不要只給本機路徑就停。
- 不要輸出 raw log、token、cookie、API key、瀏覽器設定檔、偵錯堆疊或工具狀態。

## 2026-07-11 16:9 Override

Owner correction: if the owner specifies `16:9`, `橫式`, or says the scheduled HFSW video should be changed to 16:9, apply the ratio change to the full pipeline, not only as a final crop.

Rules:

1. Script planning, image prompts, image generation, Hyperframes project, subtitles, render settings, and validation must all use horizontal 16:9.
2. Prefer 1920x1080. If rendering resources are limited, 1280x720 is acceptable.
3. Do not generate vertical 9:16 images for that task.
4. Keep the approved HFSW voice/accent, Kai-style bottom captions, and BGM loop rules unless the owner explicitly changes them.
5. Validation must say horizontal 16:9, not vertical 9:16.
