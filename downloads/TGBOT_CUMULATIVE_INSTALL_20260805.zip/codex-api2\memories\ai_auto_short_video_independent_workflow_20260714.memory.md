# AI Auto Short Video Independent Workflow - 2026-07-14

Owner instruction from TG2: make the learned long-video-to-short-video process an independent workflow, not only a note inside `acs`.

## Workflow identity

Name: `AI 自動剪短影音工作流`

Short alias:
- `自動剪短影音`
- `長影音切短影音`
- `AI剪3支`
- `短影音最小閉環`
- `Claude Code 剪短影音`

This is an independent workflow. It may call `acs`, `acs2`, `transcribe`, `speech`, `video-frame-analysis`, `ffmpeg`, `Auto-Editor`, `Whisper`, or Jianying/CapCut draft tools as execution engines, but the decision flow belongs to this workflow first.

## Core learning integrated

From the Claude Code video workflow:
- Transcribe first, then edit.
- Use transcript and subtitle timing to decide hooks, chapters, highlights, titles, and clip boundaries.
- Remove pauses, silence, filler, and low-value parts before styling.
- Use FFmpeg or code rendering for repeatable subtitle burn-in, title cards, and final output.
- Add B-roll only when it supports the meaning; do not add unrelated visuals.

From the Jianying/CapCut Agent workflow:
- Use natural-language edit intent as the high-level command.
- Prefer editable drafts/projects when possible, so the result can be refined instead of regenerated from zero.
- Use AI rough cut for repetitive tasks: remove dead air, normalize audio, add captions, translate subtitles, apply basic packaging, organize messy clips, and generate narration for silent footage.
- Final professional quality still requires validation and targeted refinement.

## Required input handling

When the owner says `照這個工作流開始剪 3 支` or similar:

1. Identify the source material first:
   - uploaded video file
   - local path
   - authorized YouTube/link source
   - folder of multiple clips
2. If the actual file/path is missing, do not pretend the workflow has started. Ask for the video file or local path.
3. Default output if not specified:
   - `3` short videos
   - `9:16`
   - each `30-60` seconds
   - Traditional Chinese subtitles
   - MP4 output
   - Telegram same-origin document delivery
4. Ask only for missing information that would change the result:
   - target platform if important
   - number of clips if not default
   - style if not obvious
   - permission/rights if using a public video source

## Execution sequence

1. Material inspection
   - Confirm file exists and is readable.
   - Use media probing to record duration, resolution, audio stream, frame rate, and orientation.
   - For multiple materials, analyze every file before selecting clips.

2. Transcript-first analysis
   - Extract audio.
   - Generate transcript and SRT/subtitle timing.
   - If transcription fails, retry with a fallback transcriber or report the concrete blocker.

3. Content selection
   - Find strong hooks, useful sections, golden sentences, teaching points, story turns, or sales points.
   - Build candidate clip list with timestamps.
   - Prefer 3 clips for the first minimal closed loop.

4. Rhythm cleanup
   - Remove silence, long pauses, obvious filler, repeated takes, and dead air.
   - Keep meaning faithful; do not change the speaker's point.

5. Edit package
   - Generate title, opening hook, subtitle text, and optional CTA for each clip.
   - Add simple motion such as punch-in or push zoom only where it improves attention.
   - Add BGM lightly behind speech; speech must remain clear.
   - Add B-roll only when it supports the script and licensing/source is acceptable.

6. Assembly route
   - Prefer deterministic code pipeline when it is enough: FFmpeg / render script / subtitle burn-in.
   - Prefer Jianying/CapCut editable draft when timeline editing, templates, effects, or later manual refinement matters.
   - Use `acs` only as the editor/export engine, not as the workflow owner.

7. Validation
   - Check every MP4 exists.
   - Validate duration, ratio, resolution, audio, subtitle readability, first-frame hook, no blank frames, and no obvious desync.
   - If one clip fails validation, fix that clip before delivery.

8. Telegram delivery
   - For TG2-origin tasks, return final MP4 files only through TG2 same-origin document mode.
   - Local path is only backup, not completion.
   - Completion requires file validation plus Telegram upload success.

## Output naming

Use a dated task folder under:
`C:\Users\你的使用者名稱\Desktop\龍蝦記憶`

Suggested folder:
`auto_short_video_YYYYMMDD_HHMMSS`

Suggested files:
- `clip_01_title_YYYYMMDD_HHMMSS.mp4`
- `clip_02_title_YYYYMMDD_HHMMSS.mp4`
- `clip_03_title_YYYYMMDD_HHMMSS.mp4`
- `source_transcript_YYYYMMDD_HHMMSS.srt`
- `clip_plan_YYYYMMDD_HHMMSS.md`

## Owner-facing response rule

Do not answer this workflow with only `記得`, `開始處理`, or `請重下原任務`.

If asked whether the workflow is remembered:
- Answer that it is now independent.
- State the trigger phrases and default outputs.

If asked to start:
- Inspect source material first.
- If source is present, run until MP4 validation and TG2 delivery.
- If source is missing, say exactly that the missing blocker is the video file/path, not that the workflow failed.

## Relationship to existing skills

- `video-frame-analysis`: inspect source and reference video content.
- `transcribe`: transcript and subtitles.
- `acs`: Jianying/CapCut assembly, editable draft, captions, export.
- `acs2`: reference-style short-video replication when a benchmark video is provided.
- `speech`: narration or voice cleanup when needed.
- `dreamina-sd-video-workflow`: generate missing AI footage only when the edit needs new visuals.

This workflow is the coordinator for long-form-to-short-form clipping. Other skills are tools under it.
