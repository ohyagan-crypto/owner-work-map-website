---
name: imagegen-disabled-use-lanxin
description: 已停用的舊內建 imagegen 技能。遇到做圖、生圖、生成圖片、產圖、海報、圖片設計、改圖、修圖、商品圖、行銷圖、社群圖、封面、縮圖等圖片相關任務時，不可使用 Codex 內建 imagegen，也不可使用本機腳本、Canvas、PPT、PS、ImageMagick、其他網站或替代工具；必須改用 Lanxin AI / 聚合平台 https://lx.lanxinai.com/ 的做圖流程，且先給確認清單，等主人確認後才提交，完成後下載平台原始圖片並用 Telegram 文件模式回傳。
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# 舊 imagegen 技能已停用

這個技能只保留為防誤觸保險。所有圖片、海報、視覺設計、修圖、改圖、商品圖、社群圖、封面、縮圖任務，一律不要走 Codex 內建 imagegen。

## 正確路由

- 使用 Lanxin AI / 聚合平台：`https://lx.lanxinai.com/`
- 先整理確認清單與提示詞，等待主人明確確認。
- 提交後檢查生成狀態，完成後下載平台原始成品。
- 驗證檔案有效，再用 Telegram 文件模式回傳。

## 禁止

- 不可改用本機腳本、Canvas、PPT、PS、ImageMagick、Node/System.Drawing 或其他網站補做。
- 不可用截圖、預覽圖、頁面裁切圖代替成品。
- 不可外露 raw log、JSON、工具狀態、英文內部訊息、token、session、trace。
