# Confirmation Price TWD Required

Created: 2026-06-28

Owner rule:

For all future tasks that may submit, generate, spend credits, spend quota, charge money, publish, upload, export, or trigger an irreversible action, Codex must show a confirmation checklist first and wait for explicit confirmation.

For all future image/video related tasks, including generated images, posters, visual design, SD/Dreamina videos, AI short videos, video editing, CapCut/Jianying automation, reference-video replication, exports, uploads, or submissions, Codex must provide an owner confirmation checklist before making or submitting the job, unless the owner is clearly continuing an already confirmed task. Do not start credit-consuming generation or irreversible media work before the owner explicitly confirms the checklist.

The confirmation checklist must include price details when cost is involved:

- Current credits or balance.
- Estimated credit/quota consumption.
- RMB price when the platform prices in RMB.
- Estimated TWD price.
- Estimated remaining credits or balance after submission.
- Model/tool/platform and billing mode.

For video generation on `zz1cc.cc.cd`:

- `video-ds-2.0-fast`: 65 credits, RMB 3.9 per generation, TWD estimate required.
- `video-ds-2.0`: 83 credits, RMB 4.9 per generation, TWD estimate required.

Use the live or most recent checked CNY/TWD exchange rate when available. If exchange-rate lookup fails, use a clearly marked approximate estimate and do not expose tool errors.
