---
name: video-spec-builder
description: Build AI video production specs from story outlines, scripts, shot lists, or user-provided scenes.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Video Spec Builder

Use this skill to convert user story material into production-ready AI video specs, especially for SD/Dreamina/Lanxin-style video generation.

## Core Rules

- Write output in the user's language. For this user, default to Traditional Chinese.
- For scripts, screenplays, short-video shooting plans, storyboard planning, AI video production specs, or SD/Dreamina prompt planning, first use the aggregation platform `https://lx.lanxinai.com/` AI chat with the highest available Claude model, at least Claude 4.8 or newer. Prefer `claude-opus-4-8` when it is the highest visible Claude model.
- Treat Claude as the upstream analysis pass: it should check story logic, shot feasibility, material needs, dialogue/audio needs, and prompt structure before the owner-facing deliverable is finalized.
- If the work will later submit a generation job or consume credits, return a confirmation checklist first and wait for explicit owner confirmation before submission.
- If Dreamina CLI has already been authorized for the same account, do not ask the owner to authorize again during SD/Dreamina planning. After explicit confirmation, hand off to the SD workflow to verify `version`, `user_credit`, and `list_task --limit=5`; if UID, credits, and membership are returned, submit directly and capture the task id.
- Preserve confirmed user prompts and character constraints exactly when the user says not to alter prompts.
- Keep each generated video segment within 10-15 seconds unless the user requests another duration.
- Prefer 5-8 segments for a 60-90 second episode.
- Keep one emotional beat per segment: setup, conflict, reaction, transition, hook.
- Include enough concrete motion for video generation: camera, body movement, micro-expression, environment, sound.
- Avoid overloading a single segment with too many actions or facial changes.
- If the user provides fixed characters, carry their image/voice identity through every segment.

## Default Segment Format

For each segment, provide:

1. Segment title and time range
2. Scene and visual atmosphere
3. Camera and transition
4. Character actions and micro-expressions
5. Dialogue or voiceover, including pacing and pauses
6. Sound design and music
7. AI video prompt block
8. Negative constraints

Use this concise structure when the user asks only for segmentation:

```text
片段 1：00:00-00:12｜標題
畫面：...
動作：...
鏡頭：...
台詞/旁白：...
音效：...
生成重點：...
```

Use the full structure when the user asks for SD/Dreamina prompts or production specs.

## Prompt Construction

Build prompts in this order:

1. Story context and emotional objective
2. Character identity lock
3. Location, lighting, color, art direction
4. Camera movement and lens language
5. Actions by timestamp
6. Dialogue/voiceover if any
7. Audio environment and BGM
8. Prohibitions and quality constraints

For AI video tools, keep character count manageable but do not delete user-provided confirmed constraints. If a tool limit requires shortening, ask before changing the prompt.

## Character Continuity

When fixed character references exist, restate them briefly in each segment:

- 庫裡：male Taiwanese AI media CEO, face locked to reference, short black side-parted hair, clean youthful face, deep gray turtleneck, black blazer, premium smartwatch, no glasses, no sunglasses.
- 嵐熙：beautiful mature cool young woman, long black wavy side-parted hair, refined face, controlled hurt emotion, teary eyes but restrained.
- 蝦妹：sweet pure young woman, black hair bun with airy bangs, white soft Japanese-style outfit, warm gentle neighborly feeling.

Adapt these descriptions to the user's latest confirmed references.

## Quality Checklist

Before finalizing, check:

- Every segment is 10-15 seconds or clearly justified.
- Timeline is continuous and totals the intended duration.
- Each segment has one clear visual/emotional purpose.
- Camera movement is feasible and not contradictory.
- Dialogue fits the duration.
- Sound cues align with visible actions.
- Character identity constraints are repeated enough for generation.
- Negative constraints include no unwanted subtitles, logos, watermarks, extra characters, cartoon/Q-version, unless requested.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->










