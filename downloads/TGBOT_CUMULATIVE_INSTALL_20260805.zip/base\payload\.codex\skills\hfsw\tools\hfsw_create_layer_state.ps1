﻿& 'C:\Users\max\.codex-tgbot\skills\hfsw\tools\hfsw_create_layer_state.ps1' @args
exit $LASTEXITCODE
