"""Offline checks for safe, actionable Codex failure routing."""

import os
import subprocess
import sys

sys.dont_write_bytecode = True
os.environ["TGBOT_FAILURE_ROUTING_SELF_TEST"] = "1"
os.environ.setdefault("TELEGRAM_BOT_TOKEN", ("0" * 9) + ":" + ("A" * 30))
import codex_bot as bot


def main() -> int:
    cases = [
        (bot.CodexNoResult("empty"), "no_result"),
        (bot.CodexNoProgress("stall"), "no_progress"),
        (RuntimeError("Codex timed out after 300 seconds"), "timeout"),
        (RuntimeError("model not found"), "model_unavailable"),
        (RuntimeError("Codex exited with code 1"), "codex_runtime"),
    ]
    forbidden = [
        "主人" + "這輪任務沒有完成原因",
        "任務處理失敗" + "但原始錯誤可能含內部資訊",
        "我已保留續跑狀態" + "你不用重新組指令",
    ]
    for error, expected_kind in cases:
        kind, reason = bot.codex_failure_kind_and_reason(error, "測試任務")
        if kind != expected_kind or not reason:
            raise AssertionError(f"failure classifier mismatch: {kind!r}, {reason!r}")
        if not bot.is_recoverable_codex_failure(error, "測試任務"):
            raise AssertionError(f"recoverable failure was not marked recoverable: {kind}")
        reply = bot.user_facing_codex_failure(error, "測試任務")
        if not reply or any(fragment in reply for fragment in forbidden):
            raise AssertionError("failure reply was empty or used the forbidden generic wording")

    if bot.is_recoverable_codex_failure(RuntimeError("401 unauthorized"), "測試任務"):
        raise AssertionError("invalid credentials must not be blindly retried")
    if bot.is_transient_codex_error("HTTP 502 Upstream access forbidden"):
        raise AssertionError("upstream permission failures must not be retried as transient 502 errors")
    if not bot.is_transient_codex_error("HTTP 502 Bad Gateway"):
        raise AssertionError("ordinary 502 failures should remain recoverable")
    forbidden_error = RuntimeError("HTTP 502 Upstream access forbidden")
    kind, _ = bot.codex_failure_kind_and_reason(forbidden_error, "測試任務")
    if kind != "api_forbidden" or bot.is_recoverable_codex_failure(forbidden_error, "測試任務"):
        raise AssertionError("API permission failures must fail fast with api_forbidden")

    original_once = bot.run_subprocess_once
    original_sleep = bot.time.sleep
    retry_calls = []
    try:
        def fake_once(*args, **kwargs):
            retry_calls.append(1)
            if len(retry_calls) == 1:
                raise subprocess.TimeoutExpired(cmd="codex", timeout=1)
            return subprocess.CompletedProcess(args=["codex"], returncode=0, stdout="OK", stderr="")

        bot.run_subprocess_once = fake_once
        bot.time.sleep = lambda _seconds: None
        result = bot.run_subprocess_with_retry(["codex"], bot.Path.cwd(), "test", 1)
        if result.returncode != 0 or len(retry_calls) != 2:
            raise AssertionError("timeout retry did not complete on the second attempt")
    finally:
        bot.run_subprocess_once = original_once
        bot.time.sleep = original_sleep

    original_current = bot.current_codex_model
    original_candidates = bot.codex_model_candidates
    original_run_model = bot.run_codex_with_model
    model_calls = []
    try:
        bot.current_codex_model = lambda: "primary-model"
        bot.codex_model_candidates = lambda _model: ["primary-model", "fallback-model"]

        def fake_run_model(_text, model):
            model_calls.append(model)
            if model == "primary-model":
                raise RuntimeError("model not found")
            return "OK"

        bot.run_codex_with_model = fake_run_model
        if bot.run_codex("test") != "OK" or model_calls != ["primary-model", "fallback-model"]:
            raise AssertionError("recoverable model failure did not switch to the fallback model")
    finally:
        bot.current_codex_model = original_current
        bot.codex_model_candidates = original_candidates
        bot.run_codex_with_model = original_run_model
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
