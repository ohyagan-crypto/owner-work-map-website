#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SKILL_NAME="$(basename "$SOURCE_DIR")"
CODEX_HOME_DIR="${CODEX_HOME:-/root/.codex}"
TARGET_ROOT="${1:-$CODEX_HOME_DIR/skills}"
TARGET_DIR="$TARGET_ROOT/$SKILL_NAME"

mkdir -p "$TARGET_ROOT"

if [ -e "$TARGET_DIR" ]; then
  backup="${TARGET_DIR}.bak_$(date +%Y%m%d_%H%M%S)"
  cp -a "$TARGET_DIR" "$backup"
  echo "Existing skill backed up to: $backup"
fi

rm -rf "$TARGET_DIR"
cp -a "$SOURCE_DIR" "$TARGET_DIR"

find "$TARGET_DIR/scripts" -type f -name "*.sh" -exec chmod +x {} \; 2>/dev/null || true
find "$TARGET_DIR/scripts" -type f -name "*.py" -exec chmod +x {} \; 2>/dev/null || true

echo "Installed skill to: $TARGET_DIR"

