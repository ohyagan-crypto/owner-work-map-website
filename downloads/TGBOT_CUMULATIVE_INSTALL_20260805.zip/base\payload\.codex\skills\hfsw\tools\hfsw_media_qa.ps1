﻿param(
    [Parameter(Mandatory = $true)]
    [string]$VideoPath,

    [int]$ExpectedDurationSeconds = 0,
    [int]$ExpectedWidth = 0,
    [int]$ExpectedHeight = 0,

    [string]$OutDir = "",

    [switch]$LongVideo,
    [double]$SilenceThresholdDb = -35,
    [double]$MinimumSilenceSeconds = 0.7
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $VideoPath)) {
    throw "Video file not found: $VideoPath"
}

$resolvedVideo = (Resolve-Path -LiteralPath $VideoPath).Path
if ([string]::IsNullOrWhiteSpace($OutDir)) {
    $OutDir = Join-Path -Path (Split-Path -Parent $resolvedVideo) -ChildPath "qa"
}
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$probePath = Join-Path $OutDir "hfsw_probe_$stamp.json"
$silencePath = Join-Path $OutDir "hfsw_silence_$stamp.txt"
$summaryPath = Join-Path $OutDir "hfsw_qa_summary_$stamp.md"
$framesDir = Join-Path $OutDir "frames_$stamp"
New-Item -ItemType Directory -Force -Path $framesDir | Out-Null

$probeJson = & ffprobe -v error -show_format -show_streams -of json $resolvedVideo
$probeJson | Set-Content -LiteralPath $probePath -Encoding UTF8
$probe = $probeJson | ConvertFrom-Json

$videoStream = @($probe.streams | Where-Object { $_.codec_type -eq "video" } | Select-Object -First 1)[0]
$audioStream = @($probe.streams | Where-Object { $_.codec_type -eq "audio" } | Select-Object -First 1)[0]
$duration = [double]$probe.format.duration
$width = [int]$videoStream.width
$height = [int]$videoStream.height

$durationPass = $true
if ($ExpectedDurationSeconds -gt 0) {
    $durationPass = [math]::Abs($duration - $ExpectedDurationSeconds) -le 3
}

$sizePass = $true
if ($ExpectedWidth -gt 0 -and $ExpectedHeight -gt 0) {
    $sizePass = ($width -eq $ExpectedWidth -and $height -eq $ExpectedHeight)
}

$audioPass = $null -ne $audioStream

$previousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
$silenceOutput = & ffmpeg -hide_banner -nostats -i $resolvedVideo -af "silencedetect=noise=${SilenceThresholdDb}dB:d=$MinimumSilenceSeconds" -f null - 2>&1
$silenceExitCode = $LASTEXITCODE
$ErrorActionPreference = $previousErrorActionPreference
$silenceOutput | ForEach-Object { $_.ToString() } | Set-Content -LiteralPath $silencePath -Encoding UTF8
if ($silenceExitCode -ne 0) {
    Add-Content -LiteralPath $silencePath -Encoding UTF8 -Value "WARNING: ffmpeg silencedetect exited with code $silenceExitCode"
}

$silenceLines = @()
if (Test-Path -LiteralPath $silencePath) {
    $silenceLines = @(Select-String -LiteralPath $silencePath -Pattern "silence_start|silence_end" | ForEach-Object { $_.Line })
}

$checkTimes = New-Object System.Collections.Generic.List[double]
$checkTimes.Add(0.5)
$checkTimes.Add(10)

if ($LongVideo -or $duration -ge 1800) {
    for ($t = 600; $t -lt $duration; $t += 600) {
        $checkTimes.Add([double]$t)
    }
}
else {
    for ($t = 30; $t -lt $duration; $t += 30) {
        $checkTimes.Add([double]$t)
    }
}

foreach ($known in @(84, 174, 264)) {
    if ($known -lt $duration) {
        $checkTimes.Add([double]$known)
        if (($known + 1) -lt $duration) {
            $checkTimes.Add([double]($known + 1))
        }
    }
}

if ($duration -gt 65) {
    $checkTimes.Add([double]($duration - 60))
}
if ($duration -gt 10) {
    $checkTimes.Add([double]($duration - 5))
}

$uniqueTimes = $checkTimes |
    Where-Object { $_ -ge 0 -and $_ -lt $duration } |
    Sort-Object -Unique

$frameRows = New-Object System.Collections.Generic.List[string]
$idx = 1
foreach ($t in $uniqueTimes) {
    $safeTime = "{0:000000.0}" -f $t
    $framePath = Join-Path $framesDir ("frame_{0:000}_{1}s.jpg" -f $idx, ($safeTime -replace "\.", "_"))
    & ffmpeg -hide_banner -loglevel error -y -ss $t -i $resolvedVideo -frames:v 1 -vf "scale=960:-1" $framePath
    if (Test-Path -LiteralPath $framePath) {
        $frameRows.Add(("- {0:N1}s: {1}" -f $t, $framePath))
    }
    $idx++
}

$ratioText = "{0}x{1}" -f $width, $height
$summary = @"
# HFSW Media QA Summary - $stamp

Video: $resolvedVideo

## Probe

- Duration seconds: $([math]::Round($duration, 2))
- Resolution: $ratioText
- Video codec: $($videoStream.codec_name)
- Audio codec: $($audioStream.codec_name)
- Audio stream present: $audioPass

## Expected Checks

- Expected duration: $ExpectedDurationSeconds
- Duration pass: $durationPass
- Expected size: ${ExpectedWidth}x${ExpectedHeight}
- Size pass: $sizePass

## Silence / Dropout Detection

- Threshold: ${SilenceThresholdDb}dB
- Minimum duration: ${MinimumSilenceSeconds}s
- Detected silence lines: $($silenceLines.Count)
- Detail file: $silencePath

## Extracted Frames

$($frameRows -join "`n")

## Manual Review Required

- Check extracted frames for bottom Kai-style subtitles, no double subtitles, no cropped text, and no wrong visual material.
- Listen to the opening, middle, known issue points, and final minute to confirm BGM starts at 0s, loops continuously, and stays behind voice.
- If platform images are required, compare frame cadence against the platform image inventory.
"@

$summary | Set-Content -LiteralPath $summaryPath -Encoding UTF8

Write-Output "QA summary: $summaryPath"
