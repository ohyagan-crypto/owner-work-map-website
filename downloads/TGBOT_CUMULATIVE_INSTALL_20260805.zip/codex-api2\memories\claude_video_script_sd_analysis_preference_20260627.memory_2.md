# Claude Video Script And SD Analysis Preference

Created: 2026-06-27

Owner rule:

- This Claude 4.8+ analysis workflow is now named `cls`; use the installed skill at `C:\Users\RECEIVER\.codex\skills\cls\SKILL.md` when the owner says `cls` or requests this Claude analysis gate.
- For future tasks involving scripts, screenplays, short-video shooting plans, video production content, storyboard planning, SD/SDF/SDV video generation, Dreamina video prompts, or material planning for video, first use the aggregation platform `https://lx.lanxinai.com/` AI chat with the highest available Claude model.
- The Claude model must be at least Claude 4.8 or higher. Prefer the highest visible Claude option, currently known on the platform as `claude-opus-4-8` or any newer Claude model if available.
- Use the Claude analysis as an upstream quality pass before returning the result to the owner. The output should be usable, concrete, and production-ready, not just a rough idea.
- For SD/Dreamina tasks, use Claude first to analyze the story/content, shot needs, material list, character references, audio/dialogue needs, aspect ratio, duration, and prompt structure. Then return a confirmation checklist to the owner.
- Do not submit SD/Dreamina/video generation immediately after analysis. Follow the existing confirmation rule: provide the checklist first and wait for the owner to explicitly confirm before submitting any job that consumes credits or starts generation.
- If the aggregation platform or Claude model is unavailable, report the exact blocker in clean Traditional Chinese and still provide the best local draft/analysis as a backup when possible.

Execution notes:

- Keep owner-facing replies in clean Traditional Chinese.
- Do not expose browser/tool/session/debug/log details.
- Do not include passwords, tokens, cookies, API keys, or other secrets in memory or replies.
