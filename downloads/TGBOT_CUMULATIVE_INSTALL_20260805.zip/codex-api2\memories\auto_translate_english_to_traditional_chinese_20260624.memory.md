# Auto Translate English To Traditional Chinese

- 2026-06-24: User preference confirmed. In Telegram-facing replies, whenever screenshots, webpages, app dialogs, command output, or system messages contain English, automatically translate the relevant English into clean Traditional Chinese and briefly explain the meaning in plain language.
- Do not send raw English-only explanations when the user is likely asking what the screen means.
- Keep replies concise and in Traditional Chinese. Do not expose raw logs, bridge/session/tool/debug state, token usage, JSON dumps, or internal English status.
