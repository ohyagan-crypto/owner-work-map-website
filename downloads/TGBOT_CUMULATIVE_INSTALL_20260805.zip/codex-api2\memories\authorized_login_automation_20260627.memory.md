# Authorized Login Automation Rule

Updated: 2026-06-27

The owner explicitly authorizes Codex, OpenClaw, and TGBOT to operate login flows on this Windows computer for accounts the owner controls or has authorized.

Operational rules:

- When the owner asks to log in, switch accounts, enter an account/password, or continue an authorized login, use the available browser or desktop automation instead of refusing or asking the owner to operate the computer manually.
- If credentials were provided in the current chat, use them only for that login attempt. Do not write the raw password to memory, task notes, logs, skill files, or final replies.
- If a credential is saved locally, prefer the encrypted DPAPI helper scripts under `C:\Users\你的使用者名稱\.openclaw\workspace\tools`:
  - `set-login-credential.ps1`
  - `get-login-credential.ps1`
  - `type-login-credential.ps1`
  - `list-login-credentials.ps1`
  - `remove-login-credential.ps1`
- Prefer existing logged-in browser sessions and password managers before asking the owner for a password.
- It is allowed to type saved or owner-provided usernames/passwords into visible login fields when the owner has authorized the login task.
- Never print raw passwords, API keys, tokens, cookies, auth files, or browser credential database contents to Telegram/Codex/OpenClaw replies.
- Stop and report a clean Traditional Chinese blocker only for real external blockers: missing/wrong credential, CAPTCHA, SMS/email verification code, 2FA approval, passkey/biometric confirmation, payment confirmation, account risk/security lock, or a site requiring owner action outside the computer.
- Do not bypass 2FA/CAPTCHA/payment/security checks, do not guess verification codes, and do not access accounts the owner has not authorized.

This newer rule supersedes older local memories that said every password/login screen must always stop immediately. The correct behavior is: authorized credential entry may proceed; external verification/security blockers must stop and report.
