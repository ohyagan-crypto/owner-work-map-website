---
name: codex-skill-handoff
description: Use when the operator wants to copy, export, package, transfer, or hand off Codex skills/memories to another Codex, OpenClaw, or Telegram bot, including detailed one-pass teaching instructions for the receiver.
---

# Codex Skill Handoff

Use this skill when the operator asks how to copy a skill to another Codex, send a skill through Telegram, make a skill handoff zip, or teach another Telegram bot/Codex to use local skills.

This is the operator's default workflow for sharing skills with other people, other computers, or other Telegram bots.

## Rules

1. Keep the operator-facing reply in Traditional Chinese.
2. Preserve the current Codex memories, skills, and `AGENTS.md`; package copies only.
3. Do not include secrets: passwords, API keys, bot tokens, browser profiles, login cookies, auth files, or raw logs.
4. Include a detailed install and learning guide in every handoff package. The guide must be detailed enough that another Codex/OpenClaw can learn and run the workflow in one pass without the owner teaching again.
5. If the target computer username is unknown, write paths with `C:\Users\你的使用者名稱\.codex\skills\`.
6. Tell the receiving Codex to restart Codex or its Telegram bot after copying skills so metadata reloads.
7. Always give the operator a ready-to-forward message they can copy directly to the receiver's Telegram bot.
8. Every handoff package must be self-contained for a first-time receiver. Codex/OpenClaw must be able to understand when to trigger the skill, how to run it, how to test it, and what safety limits apply without the owner teaching extra instructions.
9. If the install notes or forward message only say "install this skill" without trigger words, workflow summary, test phrases, blockers, and secret-handling rules, improve the package before delivery.
10. For Telegram-origin requests, send every skill-package deliverable back to the originating Telegram chat whenever possible. This includes the handoff ZIP, install notes, ready-to-forward receiver message, generated package manifests, and any verification screenshots.
11. A local desktop path alone is not complete delivery when Telegram sending is available. Prefer Telegram document/file mode and report a clean Traditional Chinese blocker only if upload fails after retry.
12. For Telegram-origin skill-package work, the step is not complete until the Telegram upload returns success. Do not stop after packaging, path reporting, or a claimed send; verify the actual send result first.
13. The operator prefers detailed handoff replies and package documents for all future memory/skill exports. Do not make minimal or summary-only handoffs unless the operator explicitly asks for a short version.
14. Every package must explain the receiving agent's response style: clean Traditional Chinese to the owner, no raw logs, no tokens/secrets, no tool/debug status, and no vague standby-only replies.
15. When memories are included or summarized, provide a human-readable memory summary that explains what the receiver should remember, when it applies, and what it must never expose.
16. Save new handoff packages, local backups, manifests, install notes, and generated package files under `C:\Users\max\Desktop\龍蝦記憶` or a task/date subfolder there. Do not use the Desktop root as the default output folder.
17. Every generated package, handoff, export, ZIP, companion document, manifest, ready-to-forward text file, and package folder name must include the creation date. Use `YYYYMMDD` at minimum, preferably `YYYYMMDD_HHMMSS` when multiple packages may be created in one day. If a generated name lacks today's date, rename it before reporting or delivering it.
18. Do not use standby-only progress replies as a substitute for the handoff work. For packaging requests, continue through package creation, verification, and Telegram delivery when available. If blocked, report the exact blocker and the local backup path. If the owner says `stop`, stop immediately and state the actual stopped state.

## Default Package Contents

- Requested skill folders under `.codex\skills\`
- `AGENTS.md` if operator wants preferences/rules included
- `INSTALL_FOR_OTHER_CODEX.md`
- `FORWARD_TO_RECEIVER_TGBOT.txt`
- `PACKAGE_MANIFEST.md`
- `MEMORY_AND_BEHAVIOR_SUMMARY.md` when memories, owner preferences, reply rules, or operating habits are relevant

## Workflow

1. Ask or infer which skills should be copied.
2. Create a temporary package folder.
3. Copy only the requested skill folders.
4. Optionally copy `C:\AGENTS.md`.
5. Add `INSTALL_FOR_OTHER_CODEX.md` with detailed Chinese instructions, trigger terms, expected workflow, test phrases, blocker handling, reply style, and secret exclusions.
6. Add `MEMORY_AND_BEHAVIOR_SUMMARY.md` when the package contains memories or owner-specific habits. This file should explain the rules in plain language, not just list filenames.
7. Add `PACKAGE_MANIFEST.md` listing every included skill, memory, instruction file, and what each item is for.
8. Add `FORWARD_TO_RECEIVER_TGBOT.txt` with a detailed ready-to-forward message. It must tell the receiving bot exactly what to read, where to copy files, how to restart, how to test, and how to reply.
9. Compress to a zip under `C:\Users\max\Desktop\龍蝦記憶` or a task/date subfolder there.
10. If Telegram sending is configured, send the zip as a document by default.
11. Give the operator a detailed copy-paste message for the receiver.
12. Save the same receiver message as `FORWARD_TO_RECEIVER_TGBOT.txt` inside the package when possible.
13. If the request came from Telegram, send any package-related text/file deliverables back to Telegram once unless the operator explicitly says not to.

## One-Pass Handoff Standard

Before declaring a package ready, verify the receiving Codex/OpenClaw can understand these items by reading the zip alone:

- Skill name and purpose.
- Exact trigger words and natural-language requests that should activate it.
- Required first action after trigger.
- Full happy-path workflow.
- Stop conditions and blocker wording expectations.
- What files or outputs should be returned to the owner.
- What must never be included: passwords, API keys, tokens, cookies, browser profiles, auth files, raw logs, screenshots containing secrets, or local credential stores.
- How to install and where to copy the skill folder.
- Whether Codex or the Telegram bot must be restarted.
- One or more test prompts the receiver can run immediately after restart.
- How the receiver should answer the owner in Traditional Chinese.
- What a complete deliverable looks like: file path, URL, generated file, installed skill, or exact blocker.
- How the receiver should avoid asking the owner to reteach the workflow.

If any of these are missing, update the skill, install guide, and ready-to-forward message before compressing the zip.

## Detailed Teaching Handoff Standard

Every handoff package for memories, skills, workflows, or reply behavior must be written as a teaching package, not a storage backup. The receiver should be able to learn the owner's preference by reading the zip once.

Required sections for `INSTALL_FOR_OTHER_CODEX.md`:

1. Package purpose: what this skill or memory pack teaches.
2. Install paths for Windows, using `C:\Users\你的使用者名稱\.codex\skills\` and `C:\Users\你的使用者名稱\.codex\memories\` when the receiver username is unknown.
3. Restart requirement: restart Codex, OpenClaw, or Telegram bot after copying.
4. Trigger words and natural-language requests.
5. First action after trigger, including any local file the receiver must read before responding.
6. Full happy-path workflow.
7. Required owner-facing reply style in Traditional Chinese.
8. What files, URLs, generated outputs, or confirmation lists must be returned.
9. Clear stop conditions and blocker wording.
10. Secret-handling rules and excluded files.
11. Immediate test prompts for the receiver.
12. A final checklist the receiver can use before saying the skill is installed.

Required sections for `FORWARD_TO_RECEIVER_TGBOT.txt`:

1. Direct instruction to unzip and read `INSTALL_FOR_OTHER_CODEX.md` first.
2. Exact copy paths for skills and memories.
3. Warning not to overwrite existing useful rules blindly.
4. Restart instruction.
5. Trigger/test phrases.
6. Owner-facing reply rules: clean Traditional Chinese, no raw logs, no token/cookie/password exposure, no internal tool/debug wording, no vague "processing" final reply.
7. Request that the receiver reply with an installed/tested summary after completion.

Required sections for `MEMORY_AND_BEHAVIOR_SUMMARY.md`:

1. What the owner wants remembered.
2. When the memory applies.
3. Exact behavior the receiving agent should follow.
4. What the receiving agent must ask before doing.
5. What the receiving agent must never reveal or include.
6. Example correct replies and example blocked replies.

## Operator Reply Standard For Handoffs

When reporting a completed handoff to the operator, include:

- What was packaged.
- Which skills and memories are included.
- Which teaching files are included.
- Where the local zip is saved, normally under `C:\Users\max\Desktop\龍蝦記憶`.
- Whether it was sent by Telegram document mode when applicable.
- A concise but detailed ready-to-forward message or the path to `FORWARD_TO_RECEIVER_TGBOT.txt`.
- Any exact blocker if upload, packaging, or verification failed.

## Helper Script

Use `scripts\make_skill_handoff.ps1` to package skills quickly.

For complete all-skills/all-memories handoff packages, prefer the fast full-package builder:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\max\tg-openai-bot\tools\build_fast_handoff_package.ps1
```

Fast full-package mode still includes skills, memories, install guide, trigger index, memory index, ready-to-forward message, manifest, and redaction/exclusion report. It skips conversation-history snapshots and duplicate full-text learning archives unless the owner explicitly asks for the slow exhaustive archive. For Telegram-origin delivery, send the main ZIP first; companion documents are already inside the ZIP and should only be sent separately when the owner asks.

Example:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\Administrator\.codex\skills\codex-skill-handoff\scripts\make_skill_handoff.ps1 -Skills notebooklm-brief-to-deck-workflow,notebooklm-presentation-prompt,notebooklm-source-builder -Name nbs_skill_handoff -IncludeAgents
```

## Copy-Paste Flow For Receiving Codex

```text
請解壓這個 zip。
把裡面的 .codex\skills 資料夾內容複製到你這台電腦：
C:\Users\你的使用者名稱\.codex\skills\

如果 zip 裡有 AGENTS.md，請讀取裡面的規則，只新增，不要覆蓋你原本的重要資料。
不要保存密碼、token、瀏覽器登入資料。

完成後請重開 Codex 或重啟你的 Telegram bot，讓技能重新載入。
最後測試使用者指定的關鍵字，例如 nbs。
```

## Ready-To-Forward Message

When the operator asks what to send to the other Telegram bot, provide this block directly:

```text
請學習並安裝這個 Codex 技能包。

請解壓 zip，讀取裡面的 INSTALL_FOR_OTHER_CODEX.md。
把 zip 裡面的 .codex\skills 資料夾內容複製到你這台電腦的：
C:\Users\你的使用者名稱\.codex\skills\

如果裡面有 AGENTS.md，請讀取規則，只新增，不要覆蓋原本資料。
不要保存密碼、token、瀏覽器登入資料。

安裝完成後，請重啟 Codex 或 tgbot，讓技能重新載入。
重啟後請回覆「技能已安裝完成」。

測試：
我傳 nbs 時，你要知道這是 NotebookLM 簡報流程。
第一次使用 NBS 時，請先確認 Edge，沒有 Edge 就安裝 Edge。
登入 Google / NotebookLM 到密碼頁時，要停下來問我密碼，不要卡著等。
```
