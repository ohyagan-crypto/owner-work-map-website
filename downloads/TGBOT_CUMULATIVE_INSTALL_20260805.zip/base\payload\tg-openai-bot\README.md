# Telegram OpenAI Bot

這是一個最小可執行的 Telegram Bot。它會把使用者傳來的文字送到 OpenAI-compatible Responses API，然後把模型回覆傳回 Telegram。

## 安裝

```powershell
cd C:\Users\max\tg-openai-bot
.\setup_env.ps1
.\run_bot.ps1
```

或手動建立 `.env`：

```dotenv
TELEGRAM_BOT_TOKEN=你的_BotFather_token
OPENAI_API_KEY=你的_API_key
OPENAI_BASE_URL=https://lanxinai.com/v1
OPENAI_MODEL=gpt-5.5
OPENAI_REASONING_EFFORT=low
OPENAI_STORE=false
```

## 執行

最簡單方式：先雙擊

```text
C:\Users\max\tg-openai-bot\FIX_AND_START.cmd
```

它會依序測 Telegram `/ping`、測一次性 AI 回覆，通過後啟動完整 bot。

如果只想先測 Telegram，雙擊：

```text
C:\Users\max\tg-openai-bot\START_HERE.cmd
```

保持視窗開著，到 Telegram 傳 `/ping`。如果回 `pong`，再開主選單：

```text
C:\Users\max\tg-openai-bot\RUN_ME.cmd
```

第一次建議選：

```text
1. Stop any running bot
2. Recreate .env with new tokens
5. Start Telegram-only test bot
4. One-shot Telegram + AI test
6. Start AI bot in this window
```

也可以直接雙擊 PowerShell bot：

```text
C:\Users\max\tg-openai-bot\START_BOT_POWERSHELL.cmd
```

這個版本不用 venv、不需要安裝第三方 Telegram 套件。

如果 Python 沒裝好，改用 PowerShell 原生版：

```text
C:\Users\max\tg-openai-bot\START_BOT_POWERSHELL.cmd
```

確認 `/ping` 和一般文字訊息都正常後，可以背景啟動：

```text
C:\Users\max\tg-openai-bot\START_BACKGROUND.cmd
```

停止 bot：

```text
C:\Users\max\tg-openai-bot\STOP_BOT.cmd
```

登入後自動啟動：

```text
C:\Users\max\tg-openai-bot\INSTALL_STARTUP_TASK.cmd
```

PowerShell 方式：

```powershell
.\run_bot.ps1
```

如果安裝套件或 `python-telegram-bot` 版本有問題，改跑標準庫版本：

```powershell
.\run_simple_bot.ps1
```

也可以直接雙擊：

```text
C:\Users\max\tg-openai-bot\run_simple_bot.cmd
```

啟動後終端機應該會看到類似：

```text
Telegram bot is online: @your_bot_name (...)
```

先在 Telegram 對該 bot 傳 `/ping`。如果回 `pong`，Telegram 端正常，再測一般文字訊息。

## 診斷

如果 bot 沒回應，先檢查 token：

```powershell
.\.venv\Scripts\python.exe doctor.py
```

如果這個檢查失敗，代表 `.env` 沒讀到 token、token 已失效、OpenAI-compatible API 設定錯誤，或你需要重新到 `@BotFather` 產生 token。

如果 `START_BOT.cmd` 顯示已啟動但 Telegram 仍沒回，先關掉 bot 視窗，對 bot 傳 `/ping`，再雙擊：

```text
C:\Users\max\tg-openai-bot\DEBUG_UPDATES.cmd
```

它會顯示 Telegram API 是否收到你的訊息。

如果 `gpt-5.5` 無法使用，先改成 `gpt-5.4` 或 `gpt-5.4-mini` 測試。

## Telegram Token

1. 到 Telegram 找 `@BotFather`
2. 輸入 `/newbot`
3. 建立 bot 後，把 token 放到 `.env` 的 `TELEGRAM_BOT_TOKEN`
