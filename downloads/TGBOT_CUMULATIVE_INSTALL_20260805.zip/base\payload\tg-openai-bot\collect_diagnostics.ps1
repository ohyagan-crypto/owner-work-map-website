﻿$ErrorActionPreference = "Continue"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvPath = Join-Path $ProjectDir ".env"
$OutPath = Join-Path $ProjectDir "diagnostics.txt"

try {
    [System.Net.ServicePointManager]::SecurityProtocol = `
        [System.Net.ServicePointManager]::SecurityProtocol -bor `
        [System.Net.SecurityProtocolType]::Tls12
}
catch {
}

function Read-DotEnv {
    param([string] $Path)

    $Values = @{}
    if (-not (Test-Path $Path)) {
        return $Values
    }

    foreach ($RawLine in Get-Content -Path $Path -Encoding UTF8) {
        $Line = $RawLine.Trim().Trim([char]0xFEFF)
        if ([string]::IsNullOrWhiteSpace($Line) -or $Line.StartsWith("#") -or -not $Line.Contains("=")) {
            continue
        }

        $EqualsIndex = $Line.IndexOf("=")
        $Key = $Line.Substring(0, $EqualsIndex).Trim()
        $Value = $Line.Substring($EqualsIndex + 1).Trim().Trim('"').Trim("'")
        $Values[$Key] = $Value
    }

    return $Values
}

function Mask {
    param([string] $Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return ""
    }
    if ($Value.Length -le 12) {
        return "***"
    }
    return "$($Value.Substring(0, 6))...$($Value.Substring($Value.Length - 6))"
}

function Redact {
    param([string] $Value)

    if ($null -eq $Value) {
        return ""
    }
    if ($script:TelegramToken) {
        $Value = $Value.Replace($script:TelegramToken, "[TELEGRAM_BOT_TOKEN]")
    }
    if ($script:OpenAiKey) {
        $Value = $Value.Replace($script:OpenAiKey, "[OPENAI_API_KEY]")
    }
    return $Value
}

function Add-Line {
    param([string] $Text = "")
    Add-Content -Path $OutPath -Value (Redact $Text) -Encoding UTF8
}

function Get-HttpErrorText {
    param($ErrorRecord)

    try {
        $Response = $ErrorRecord.Exception.Response
        if ($null -ne $Response) {
            $Stream = $Response.GetResponseStream()
            if ($null -ne $Stream) {
                $Reader = New-Object System.IO.StreamReader($Stream)
                return $Reader.ReadToEnd()
            }
        }
    }
    catch {
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-Json {
    param(
        [string] $Uri,
        [hashtable] $Payload = $null,
        [hashtable] $Headers = $null,
        [int] $TimeoutSec = 30
    )

    $Params = @{
        Uri = $Uri
        Method = "Post"
        TimeoutSec = $TimeoutSec
    }

    if ($Headers) {
        $Params.Headers = $Headers
    }
    if ($script:ProxyUrl) {
        $Params.Proxy = $script:ProxyUrl
    }
    if ($Payload) {
        $Params.ContentType = "application/json; charset=utf-8"
        $JsonBody = $Payload | ConvertTo-Json -Depth 20 -Compress
        $Params.Body = [System.Text.Encoding]::UTF8.GetBytes($JsonBody)
    }

    try {
        return Invoke-RestMethod @Params
    }
    catch {
        throw "$(Get-HttpErrorText $_)"
    }
}

Set-Location $ProjectDir
if (Test-Path $OutPath) {
    Remove-Item -Path $OutPath -Force
}

$Env = Read-DotEnv $EnvPath
$script:TelegramToken = $Env["TELEGRAM_BOT_TOKEN"]
$script:OpenAiKey = $Env["OPENAI_API_KEY"]
$TelegramApiBase = $Env["TELEGRAM_API_BASE"]
$OpenAiBaseUrl = $Env["OPENAI_BASE_URL"]
$OpenAiModel = $Env["OPENAI_MODEL"]
$script:ProxyUrl = $Env["HTTPS_PROXY"]

if (-not $script:ProxyUrl) {
    $script:ProxyUrl = $Env["HTTP_PROXY"]
}
if (-not $script:ProxyUrl) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Process")
}
if (-not $script:ProxyUrl) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTP_PROXY", "Process")
}
if (-not $TelegramApiBase) {
    $TelegramApiBase = "https://api.telegram.org"
}
if (-not $OpenAiBaseUrl) {
    $OpenAiBaseUrl = "https://lanxinai.com/v1"
}
if (-not $OpenAiModel) {
    $OpenAiModel = "gpt-5.5"
}
$TelegramApiBase = $TelegramApiBase.TrimEnd("/")
$OpenAiBaseUrl = $OpenAiBaseUrl.TrimEnd("/")

Add-Line "Telegram AI Bot Diagnostics"
Add-Line "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Add-Line "ProjectDir: $ProjectDir"
Add-Line ""

Add-Line "== Environment =="
Add-Line ".env exists: $(Test-Path $EnvPath)"
Add-Line "TELEGRAM_BOT_TOKEN: $(Mask $script:TelegramToken)"
Add-Line "OPENAI_API_KEY: $(Mask $script:OpenAiKey)"
Add-Line "TELEGRAM_API_BASE: $TelegramApiBase"
Add-Line "OPENAI_BASE_URL: $OpenAiBaseUrl"
Add-Line "OPENAI_MODEL: $OpenAiModel"
Add-Line "OPENAI_FALLBACK_MODELS: $($Env["OPENAI_FALLBACK_MODELS"])"
Add-Line "OPENAI_REASONING_EFFORT: $($Env["OPENAI_REASONING_EFFORT"])"
Add-Line "OPENAI_STORE: $($Env["OPENAI_STORE"])"
Add-Line "Proxy configured: $([bool]$script:ProxyUrl)"
Add-Line ""

Add-Line "== Running Bot Processes =="
try {
    $Processes = Get-CimInstance Win32_Process | Where-Object {
        $CommandLine = [string]$_.CommandLine
        -not [string]::IsNullOrWhiteSpace($CommandLine) -and (
            $CommandLine.Contains("bot_now.ps1") -or
            $CommandLine.Contains("telegram_only_bot.ps1") -or
            $CommandLine.Contains("bot_powershell.ps1") -or
            $CommandLine.Contains("simple_bot.py") -or
            ($CommandLine.Contains($ProjectDir) -and $CommandLine.Contains("bot.py"))
        )
    }
    if ($Processes) {
        foreach ($Process in $Processes) {
            Add-Line "PID=$($Process.ProcessId) Name=$($Process.Name) CommandLine=$($Process.CommandLine)"
        }
    }
    else {
        Add-Line "No running bot process found."
    }
}
catch {
    Add-Line "Process check failed: $($_.Exception.Message)"
}
Add-Line ""

Add-Line "== Telegram API =="
if (-not $script:TelegramToken) {
    Add-Line "FAIL: missing TELEGRAM_BOT_TOKEN"
}
else {
    try {
        $Me = Invoke-Json -Uri "$TelegramApiBase/bot$script:TelegramToken/getMe" -TimeoutSec 30
        Add-Line "getMe: ok=$($Me.ok) username=@$($Me.result.username) id=$($Me.result.id)"
    }
    catch {
        Add-Line "getMe failed: $($_.Exception.Message)"
    }

    try {
        $Webhook = Invoke-Json -Uri "$TelegramApiBase/bot$script:TelegramToken/getWebhookInfo" -TimeoutSec 30
        Add-Line "webhook ok=$($Webhook.ok) url=$($Webhook.result.url) pending=$($Webhook.result.pending_update_count)"
    }
    catch {
        Add-Line "getWebhookInfo failed: $($_.Exception.Message)"
    }
}
Add-Line ""

Add-Line "== OpenAI-compatible API =="
if (-not $script:OpenAiKey) {
    Add-Line "FAIL: missing OPENAI_API_KEY"
}
else {
    $Headers = @{
        Authorization = "Bearer $script:OpenAiKey"
    }

    $ModelsToTry = New-Object System.Collections.Generic.List[string]
    if ($OpenAiModel) {
        [void]$ModelsToTry.Add($OpenAiModel)
    }
    if ($Env["OPENAI_FALLBACK_MODELS"]) {
        foreach ($Model in $Env["OPENAI_FALLBACK_MODELS"].Split(",")) {
            $CleanModel = ([string]$Model).Trim()
            if ($CleanModel -and -not $ModelsToTry.Contains($CleanModel)) {
                [void]$ModelsToTry.Add($CleanModel)
            }
        }
    }
    if ($ModelsToTry.Count -eq 0) {
        [void]$ModelsToTry.Add("gpt-5.5")
    }

    $ApiOk = $false
    foreach ($ModelName in $ModelsToTry) {
        if ($ApiOk) {
            break
        }

        try {
            $Payload = @{
                model = $ModelName
                input = "Reply with only: OK"
                max_output_tokens = 32
            }
            $Result = Invoke-Json -Uri "$OpenAiBaseUrl/responses" -Payload $Payload -Headers $Headers -TimeoutSec 90
            Add-Line "responses OK model=$ModelName"
            $ApiOk = $true
            break
        }
        catch {
            Add-Line "responses failed model=${ModelName}: $($_.Exception.Message)"
        }

        try {
            $Payload = @{
                model = $ModelName
                messages = @(
                    @{ role = "system"; content = "Reply briefly." },
                    @{ role = "user"; content = "Reply with only: OK" }
                )
                max_tokens = 32
            }
            $Result = Invoke-Json -Uri "$OpenAiBaseUrl/chat/completions" -Payload $Payload -Headers $Headers -TimeoutSec 90
            Add-Line "chat/completions OK model=$ModelName"
            $ApiOk = $true
            break
        }
        catch {
            Add-Line "chat/completions failed model=${ModelName}: $($_.Exception.Message)"
        }
    }

    if (-not $ApiOk) {
        Add-Line "FAIL: no OpenAI-compatible API attempt succeeded"
    }
}
Add-Line ""

Add-Line "== Logs =="
foreach ($LogName in @("bot_now.log", "telegram_only.log", "bot_powershell.log", "bot.log")) {
    $LogPath = Join-Path $ProjectDir $LogName
    Add-Line "-- $LogName --"
    if (Test-Path $LogPath) {
        try {
            Get-Content -Path $LogPath -Tail 80 -Encoding UTF8 | ForEach-Object {
                Add-Line $_
            }
        }
        catch {
            Add-Line "Could not read log: $($_.Exception.Message)"
        }
    }
    else {
        Add-Line "Log does not exist."
    }
    Add-Line ""
}

Write-Host "Diagnostics written to:"
Write-Host $OutPath
Write-Host "Open diagnostics.txt and send its contents to Codex. Tokens/API keys are redacted."
