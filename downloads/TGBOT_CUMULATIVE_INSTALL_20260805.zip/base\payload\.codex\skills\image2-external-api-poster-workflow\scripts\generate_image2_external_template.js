﻿const fs = require('fs');
const crypto = require('crypto');

const baseUrl = (process.env.IMAGE2_BASE_URL || '').replace(/\/$/, '');
const apiKey = process.env.IMAGE2_API_KEY;
const model = process.env.IMAGE2_MODEL || 'gpt-image-2';
const promptPath = process.argv[2];
const outputPath = process.argv[3];

if (!baseUrl || !apiKey || !promptPath || !outputPath) {
  throw new Error('請設定 IMAGE2_BASE_URL、IMAGE2_API_KEY，並提供提示詞與輸出路徑。');
}

function pngSize(buffer) {
  if (buffer.length < 24 || buffer.subarray(1, 4).toString('ascii') !== 'PNG') throw new Error('輸出不是有效 PNG');
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

async function download(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(600000) });
  if (!response.ok) throw new Error(`圖片下載失敗：${response.status}`);
  return Buffer.from(await response.arrayBuffer());
}

(async () => {
  const prompt = fs.readFileSync(promptPath, 'utf8').trim();
  const response = await fetch(`${baseUrl}/images/generations`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, prompt, size: '1024x1792', n: 1 }),
    signal: AbortSignal.timeout(600000),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(`生成失敗：${response.status}`);
  const item = payload?.data?.[0] || payload?.images?.[0] || payload?.output?.[0] || payload;
  const buffer = item?.b64_json ? Buffer.from(item.b64_json, 'base64') : item?.base64 ? Buffer.from(item.base64, 'base64') : item?.url ? await download(item.url) : null;
  if (!buffer || buffer.length < 50000) throw new Error('沒有取得有效原始 PNG');
  const dimensions = pngSize(buffer);
  const ratio = dimensions.width / dimensions.height;
  if (Math.abs(ratio - 9 / 16) > 0.03) throw new Error(`比例不符：${dimensions.width}x${dimensions.height}`);
  fs.writeFileSync(outputPath, buffer);
  console.log(JSON.stringify({ status: 'completed', model, width: dimensions.width, height: dimensions.height, bytes: buffer.length, sha256: crypto.createHash('sha256').update(buffer).digest('hex') }));
})().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
