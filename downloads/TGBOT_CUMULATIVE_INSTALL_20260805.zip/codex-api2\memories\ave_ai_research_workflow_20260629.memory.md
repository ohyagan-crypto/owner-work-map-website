# Ave.ai Research Workflow

Created: 2026-06-29

Use this memory when the owner asks about Ave.ai, `m.ave.ai`, token research, chain token lookup, meme coin screening, on-chain data, smart money, contract risk, or DEX trading information.

## 2026-06-30 Owner Hard Rule: Coin Contract Research

- The owner said: for all future coin/token information, always query Ave.ai, the relevant block explorer, and PancakeSwap when applicable.
- For `查詢coin`, also research more external platforms, including YouTube, 抖音, X/Twitter, Telegram, official website, whitepaper, GitHub, news releases, exchange notices, KOL discussions, and community comments, to judge issuer/team quality, project credibility, market heat, and whether social attention is real or inflated.
- When the owner mentions `昨天的 pro`, `PRO`, `幣`, `代幣`, `合約地址`, `CA`, `智能合約`, `底池`, `審計`, `老鼠倉`, `放棄權限`, or sends a contract address, treat it as a token contract research task unless context clearly says otherwise.
- The preferred lookup key is the exact contract address plus chain. If the owner only gives a ticker/name, first identify and confirm the exact chain and contract because duplicate names are common.
- Do not answer coin safety, buying judgment, project risk, holder structure, or contract risk from memory only. Check live sources first and include source links in the reply.

## Required Token Research Checklist

For one token/contract, check all available items before giving a conclusion:

1. Ave.ai token page: token name, symbol, chain, contract address, pair/LP address, price, market cap, liquidity, volume, holder count, buy/sell activity, smart money, dev wallet, top holders, insider/sniper/bundle/cabal signals, and risk labels.
2. Block explorer: contract source/verification, creator address, creation transaction, owner/admin address, proxy/upgradeability, mint ability, blacklist/whitelist, pause/trading controls, fee/tax controls, max transaction/wallet restrictions, hidden owner roles, renounce ownership status, LP/token transfers, and suspicious fund flows.
3. PancakeSwap / DEX data when applicable: active pair, pool depth, LP token holder, liquidity add/remove history, buy/sell tax by route if visible, price impact, slippage sensitivity, and whether trading is actually possible.
4. Audit report: locate official audit links or explorer-linked security reports if available. Check auditor name, report date, audited contract address, unresolved critical/high issues, owner privileges, upgrade risk, mint/blacklist/fee risks, and whether the deployed contract matches the audited address.
5. Liquidity pool data: TVL/liquidity, token/quote composition, LP lock/burn status, LP holder concentration, recent liquidity removals/additions, pool age, and whether one address can drain or heavily affect the pool.
6. Holder distribution: top holder percentages excluding burn/pool where possible, top 10 concentration, developer/team/marketing wallets, exchange/router/pool addresses, new wallet clusters, whale behavior, and whether holders are unusually concentrated.
7. Address behavior: developer wallet buys/sells, suspected insider/rat-trading wallets, snipers, bundled buys, same-funding-source wallets, coordinated sells, large unlocks/transfers, and whether the project side appears to have mouse warehouse/老鼠倉 behavior.
8. Permission and contract control: whether ownership is renounced/放棄權限, who still controls privileged functions, whether privileges are timelocked or multisig, whether contract can be upgraded, and whether trading can be blocked or taxes changed.
9. Issuer/team and social heat: check YouTube and 抖音 videos, posting dates, views, engagement, comment quality, KOL credibility, whether content looks like paid promotion or copied scripts, X/Twitter and Telegram activity, official website, whitepaper, GitHub, news releases, exchange announcements, and whether public heat matches on-chain activity.
10. Final owner-facing report: give a risk-based conclusion, not a guarantee. Separate confirmed facts, warning signals, unknown/unverified points, issuer/team credibility, market heat quality, hype-vs-on-chain consistency, and practical next checks.

## 2026-06-30 Owner Fixed Daily Coin Info Checklist

For any future coin question, when the owner provides a token name, symbol, or contract address, the default deliverable must cover these owner-requested items:

- Daily price and daily change.
- Buy/sell timing reference based on multiple indicators: price action, volume, buy/sell counts, liquidity depth, holder behavior, and risk signals. Phrase this as observation and risk-based reference, never as a guaranteed profit instruction.
- Daily pool increase/decrease data, including liquidity/TVL movement and add/remove liquidity events.
- Daily trading volume and trading depth.
- Daily pool/token user data, including holders, active traders, new holders if available, whale/smart-money behavior, and pool participants.
- Ave.ai data.
- PancakeSwap data.
- Block explorer data.
- Project-side announcements and possible catalysts, including airdrops, roadshows, listings, partnerships, good news, official notices, and roadmap updates.
- YouTube, 抖音, X/Twitter, Telegram and other public heat checks, including issuer/team credibility, KOL quality, community discussion, engagement authenticity, whether the hype may be paid or inflated, and whether social heat matches liquidity, holders, and trading depth.

If any item cannot be verified from available sources, explicitly state that it is not confirmed yet instead of filling it in from memory.

## Owner Default Rule

- When the owner says `研究幣`, `分析幣`, `幫我看這個幣`, `查這個幣`, `數字貨幣`, `加密貨幣`, or sends a token name / ticker / CA / contract address / Ave.ai link, default to using Ave.ai / `https://m.ave.ai/` as the primary research platform.
- The owner explicitly said this platform is for researching digital currencies. Remember that future coin analysis should start from Ave.ai unless the owner specifies another source.
- For coin analysis, do not rely only on general web search. Use Ave.ai-style checks first: chain, contract, market data, liquidity, holders, smart money, developer wallet, security risks, and trading behavior.

## What Ave.ai Is

- Ave.ai is an on-chain crypto trading and data platform for multi-chain DEX tokens.
- Official docs describe support for 130+ public chains and 300+ decentralized exchanges.
- It is used for token discovery, token detail analysis, smart money tracking, security checks, wallet/holder inspection, and trading through web/app/TG bot.

## Default Owner Workflow

When the owner sends a token name, ticker, CA/contract address, pair address, or Ave.ai link:

1. Identify the exact chain and token contract first.
2. Open Ave.ai or official docs/data when available.
3. Check token basics: token name, chain, contract address, LP/pool address, launch platform, creation time.
4. Check market data: price, market cap, liquidity, volume, buy/sell counts, wallets, holders, 1m/5m/24h change.
5. Check security: proxy contract, blacklist, admin permissions, mint permission, top holders, LP lock/burn, buy/sell tax if visible.
6. Check holder and wallet structure: Top 10 Hold%, Dev%, Insiders%, snipers, bundles, whales, cabal/suspected coordinated wallets, phishing labels.
7. Check behavior: smart money buys/sells, KOL buys/sells, DEV activity, trading history, net buys, rug pull index, pool information.
8. Check outside-market signal: official site, whitepaper, GitHub, team background, YouTube, 抖音, X/Twitter, Telegram, KOL discussions, news and exchange announcements. Compare social heat with on-chain evidence to decide whether attention looks organic, paid, or suspicious.
9. If asked for trade setup, explain market buy/sell, limit order, auto sell, double out, slippage, gas, priority fee, and anti-sandwich mode. Do not give financial advice as certainty.
10. If asked whether safe or worth buying, give a risk-based judgment with evidence, not a guarantee.

## Useful Ave.ai Areas

- Discover: choose chain, then review Trending, Gainers, AI Agent, Launchpad and filters.
- Token page: core token details, chart, smart money activity, top holders, security, rug pull index, trading history, holders, wallet quickview, orders/trades, token metrics, pool info.
- Smart Money: leaderboard sorted by PnL, volume, transaction count, win rate, 30-day token distribution, top profitable tokens; can filter by profit range and recent transaction time.
- Copy Trading: mainly through Ave TG Bot; follow smart wallet activity only with risk controls.
- Watchlist: save tokens for monitoring.

## Core Terms

- CA: contract address.
- DEX: decentralized exchange.
- LP: liquidity pool.
- Liquidity: tradable pool depth. Low liquidity means easier manipulation and high slippage.
- MCap: market cap.
- Holders: token holder count.
- Top 10 Hold%: percentage held by top 10 non-pool/non-burn addresses.
- DEV: token creator/developer wallet.
- Insider: suspected internal wallet.
- Sniper: wallet/bot buying immediately after liquidity appears.
- Smart Money: historically profitable on-chain wallet filtered by Ave.ai.
- KOL: key opinion leader / influencer wallet or call.
- Whale: large-balance wallet.
- Cabal: wallets suspected to share creation time/funding source and act as a coordinated group.
- Bundle/Jito Bundle: multiple transactions executed atomically, often used in Solana launch behavior.
- Rug Pull: liquidity removal or developer dumping causing severe price collapse.
- Mint: ability to issue new tokens.
- Blacklist: contract ability to block specific wallets from trading.
- Slippage: maximum acceptable execution deviation.
- Gas: blockchain transaction fee.
- Priority Fee: extra fee to speed transaction inclusion.
- MEV / Sandwich Attack: bot front-runs and back-runs a trade to extract value.
- Anti-Sandwich: mode intended to reduce sandwich attack risk.
- PnL: profit and loss. Total PnL can include realized and unrealized profit.
- Paper Hands: frequent short holding / fast selling behavior.
- Diamond Hands: longer holding and more buy than sell behavior.
- CTO: community take over.

## Risk Notes

- Ave.ai security checks are reference signals, not guarantees.
- Crypto and meme coin trading are high risk.
- Bot wallets and TG bot trading can involve custody/private-key risk. Avoid keeping excessive funds in bot wallets.
- Always prefer exact CA plus chain over only ticker/name, because token names can be duplicated.

## Sources To Recheck

- https://doc.ave.ai/
- https://doc.ave.ai/tutorial/quick-guide-for-beginners
- https://doc.ave.ai/tutorial/pc-web-tutorial
- https://doc.ave.ai/tutorial/pc-web-tutorial/discover
- https://doc.ave.ai/tutorial/pc-web-tutorial/token-page-and-trading-system
- https://doc.ave.ai/tutorial/token-security-check
- https://doc.ave.ai/tutorial/pc-web-tutorial/ave.ai-smart-money
- https://doc.ave.ai/tutorial/pc-web-tutorial/copy-trading
- https://doc.ave.ai/tutorial/pc-web-tutorial/ave.ai-fees-and-settings
- https://doc.ave.ai/ave.ai-token-symbols-description
