---
name: acs2
description: "Use when the operator says acs2 or asks to replicate a reference short video in Jianying/CapCut."
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# ACS2: Benchmark Short-Video Replication

Use this skill when the operator says `acs2` or asks for the simplified reference-video replication workflow learned from the short-video editing tutorial.

ACS2 is separate from `acs`. It focuses only on the operator's repeatable short-video benchmark workflow.

## Operator Rules

- Reply to the operator in short Traditional Chinese.
- Address the operator as `主人`.
- If Jianying/CapCut, import, download, export, login, permissions, desktop control, or any app is stuck, report immediately in Chinese and say the next action.
- Do not wait silently on loading, login, export, or unresponsive UI.
- Do not overwrite source materials or previous exports unless the operator explicitly asks.
- Send screenshots to Telegram when visual verification is produced, but do not resend duplicate unchanged screenshots unless requested.

## Core Workflow

When doing benchmark/reference editing:

1. Watch or analyze the reference video first. Do not only summarize the general process.
2. Identify:
   - material order
   - shot duration
   - rhythm and cut points
   - caption timing
   - flower-text style
   - BGM beat points
   - transitions and material joins
   - ending CTA
3. Import the operator-provided materials in the same order as the reference video.
4. Add all imported materials to the main timeline track in order.
5. Trim each material to match the reference timing as closely as possible.
6. Keep the original visual and audio content of the provided materials unless the operator explicitly asks to replace them.
7. Use Jianying's built-in subtitle recognition for captions.
8. Add 花字 after subtitle recognition.
9. Match the original reference video's flower-text template, color, scale, position, animation, and timing.
10. Match BGM rhythm and transition timing to the reference video.
11. Preview the full timeline.
12. Fix obvious issues:
    - wrong material order
    - missing clips
    - blank frames
    - unreadable captions
    - flower text not matching reference
    - BGM/cuts not aligned
13. Export only after preview is acceptable.
14. Send the final exported file to Telegram once.

## Frame/Shot-Level Analysis Rule

For benchmark replication, ACS2 must do detailed frame/shot-level analysis before editing.

This does not mean manually describing every duplicated frame in a long video. It means producing an edit-useful breakdown with exact or near-exact timecodes:

1. Extract key frames or scene-change frames from the reference video.
2. Build a shot list with start time, end time, duration, and visual content.
3. Mark material changes, cuts, zooms, motion, speed changes, transitions, and black/blank frames.
4. Mark every visible caption/subtitle timing and placement when possible.
5. Mark every 花字 / decorative text timing, style, position, animation, and color when possible.
6. Mark BGM beat/cut points and sound effects when audible or visually implied.
7. Use the shot list to map operator-provided materials onto the timeline.
8. If the video is long, analyze at scene/shot precision first, then zoom into important sections frame-by-frame when matching exact transitions, captions, flower text, or beat cuts.

If only a rough sample analysis has been done, say so clearly and do not claim the video has been fully frame-analyzed.

## Fixed Operator Summary

Use this summary when explaining ACS2:

```text
先看對標影片
逐段/逐鏡頭拆時間碼
照順序導入素材
全部素材加到軌道
逐段對齊對標時間
字幕用剪映識別
花字照原影片版型
BGM 和轉場照原影片節奏
整體預覽修正後再導出
```

## Step-By-Step Jianying Mode

If the operator says they will guide step by step:

1. Do only the exact next UI action requested.
2. After each action, wait 1-2 seconds.
3. Send one verification screenshot if possible.
4. Briefly report the visible result.
5. Stop and wait for the next instruction.

Do not skip ahead to import, timeline assembly, caption recognition, flower text, or export unless the operator explicitly gives that step.

## Reference

Read `references/operator-short-video-tutorial-20260605.md` for the detailed checklist.
Also read `references/youtube-short-video-editing-frame-analysis-20260605.md` when replicating the analyzed YouTube tutorial or applying its detailed timeline method.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-15 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 51則/1對話；TGBOT 34則/1對話；TGBOT 48則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 任何缺檔/漏傳抱怨都要回查同一任務 artifact、下載資料夾與 Telegram delivery 紀錄，不可重開任務或只口頭道歉。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->





