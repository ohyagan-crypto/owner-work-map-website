---
name: cls
description: Use when the owner says cls, asks for Claude analysis, or requests scripts, screenplays, video shooting plans, short-video planning, storyboards, SD/SDF/SDV/Dreamina pre-analysis, prompt planning, material lists, or video production content that must first be analyzed through the aggregation platform Claude model at Claude 4.8 or newer.
---

# CLS

Use this skill as the Claude 4.8+ analysis gate for video, script, and SD/Dreamina planning tasks.

## Core Rule

Before producing the owner-facing result for any matching task, use the Blue Star/Lanxin Claude analysis channel. Prefer the CLI channel when it can call a Claude 4.8+ model through the configured Lanxin-compatible provider, because it avoids repeated web login and keeps Telegram tasks faster.

If the CLI channel is unavailable, fails, or cannot access Claude 4.8+, fall back to the Blue Star web platform:

`https://lx.lanxinai.com/`

The analysis model must be Claude 4.8 or newer. Prefer `claude-opus-4-8` when it is the highest available Claude option, or any newer Claude model if available. Do not claim Claude verification if neither CLI nor web platform can actually use Claude 4.8+.

## Scope

Use CLS for:

- Scripts, screenplays, hooks, shot plans, and short-video shooting plans.
- Storyboards, scene breakdowns, video production plans, and material planning.
- SD, SDF, SDV, Dreamina, image-to-video, and AI short-drama preparation.
- Prompt structure, character references, audio/dialogue needs, aspect ratio, duration, and clip segmentation.

## Workflow

1. Gather the owner request, attached materials, references, target platform, aspect ratio, duration, tone, and any fixed characters.
2. Use the CLI Claude 4.8+ channel as the upstream analysis pass when available; otherwise use the Blue Star web platform AI chat with Claude 4.8+.
3. Ask Claude for a concrete, production-ready analysis, not a rough brainstorming draft.
4. Convert Claude output into a clean Traditional Chinese owner-facing result.
5. Before any confirmation checklist, present the key analysis: goal, audience, story logic, scene/shot structure, material needs, style/tone, platform/model fit, cost or credit impact when relevant, risks, assumptions, and missing items.
6. For SD/Dreamina tasks or any credit-consuming, upload, publish, or generation submission step, return a confirmation checklist first and wait for explicit owner confirmation before submitting.
7. If Dreamina CLI has already been authorized for the same account, do not send the owner back to authorization from CLS. Hand off to `dreamina-sd-video-workflow` to run `version`, `user_credit`, and `list_task --limit=5`; if UID, credits, and membership are returned, continue with the confirmed SD submission path.

## Pre-Confirmation Analysis

The owner prefers deeper analysis before confirmation checklists for skill workflows such as `cls`, `nbs`, `ims`, SD, SDF, SDV, Dreamina, scripts, shooting plans, and storyboards.

For CLS tasks:

- Do not give only a checklist. First summarize the production judgment from Claude 4.8+ or newer.
- Explain why the recommended structure, shot plan, prompt structure, or material list fits the task.
- Identify missing materials and risks, but choose strong defaults when reasonable and mark them as defaults.
- Put the exact next-step instructions or generation prompt into the checklist.
- Wait for explicit owner confirmation before any irreversible, credit-consuming, upload, publish, or generation action.

## SD/Dreamina Checklist

For SD/Dreamina tasks, the confirmation checklist must include:

- Model and platform to be used.
- UID/VIP and current credits when available.
- Estimated or actual credit cost.
- Duration, aspect ratio, and resolution.
- Exact prompt to be submitted.
- Reference images, character assets, audio, dialogue, and storyboard materials.
- Any missing materials or risks that require owner confirmation.
- Authorization state: if same-account Dreamina CLI authorization is already valid, state that the next step after owner confirmation is direct submission and task id capture, not another authorization request.

## Failure Handling

If the CLI channel, Blue Star web platform, or Claude 4.8+ model is unavailable, report the exact blocker in clean Traditional Chinese. When possible, still provide the best local backup draft or analysis, clearly marked as not Claude-verified.

## Output Rules

- Keep replies clean Traditional Chinese.
- Do not expose internal browser, tool, session, debug, raw log, JSON, token, cookie, password, or API key details.
- Do not submit, publish, generate, upload, or spend credits without explicit owner confirmation when the task includes an irreversible or credit-consuming action.
