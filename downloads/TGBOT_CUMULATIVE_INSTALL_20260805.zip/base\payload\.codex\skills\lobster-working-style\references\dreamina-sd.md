# Dreamina / SD / SDF Rules

- `sd` = Seedance 2.0.
- `sdf` = Seedance 2.0 fast.
- `sdv` = Seedance 2.0 VIP.
- All SD/SDF/SDV video generation must use `multimodal2video` unless the user explicitly changes the rule.
- Before any Dreamina/SD/SDF submission, provide a full confirmation checklist and wait for explicit confirmation such as 「確認」「好」「提交」「執行」.
- User saying 「直接上傳」「繼續」「做出來」「不要多加提示詞」 is not enough to submit if no checklist confirmation happened.
- Do not rewrite or compress a confirmed prompt unless platform limits require it; explain and ask first.
- No background music by default; only sound effects unless requested.
- If generated video completes, download the actual MP4, verify it, and send to Telegram as a document/file.
