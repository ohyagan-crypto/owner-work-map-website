import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI


PROJECT_DIR = Path(__file__).resolve().parent
ENV_PATH = PROJECT_DIR / ".env"


def mask(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 12:
        return "***"
    return f"{value[:6]}...{value[-6:]}"


def redact(value: str) -> str:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    api_key = os.getenv("OPENAI_API_KEY", "")
    if token:
        value = value.replace(token, "[TELEGRAM_BOT_TOKEN]")
    if api_key:
        value = value.replace(api_key, "[OPENAI_API_KEY]")
    return value


def print_step(name: str) -> None:
    print(f"\n== {name} ==")


def fail(message: str) -> int:
    print(f"FAIL: {redact(message)}")
    return 1


def pass_line(message: str) -> None:
    print(f"OK: {message}")


def check_env_file() -> int:
    print_step(".env")
    if not ENV_PATH.exists():
        return fail(f"{ENV_PATH} does not exist. Run setup_env.ps1 first.")

    load_dotenv(ENV_PATH, override=True)
    pass_line(f"found {ENV_PATH}")

    required = ["TELEGRAM_BOT_TOKEN", "OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL"]
    missing = [key for key in required if not os.getenv(key)]
    if missing:
        return fail(f"missing values: {', '.join(missing)}")

    token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    api_key = os.getenv("OPENAI_API_KEY", "")

    if token.startswith("123456789:") or "replace" in token.lower():
        return fail("TELEGRAM_BOT_TOKEN still looks like a placeholder.")
    if "replace" in api_key.lower() or api_key.startswith("你的"):
        return fail("OPENAI_API_KEY still looks like a placeholder.")

    print(f"TELEGRAM_BOT_TOKEN={mask(token)}")
    print(f"OPENAI_API_KEY={mask(api_key)}")
    print(f"OPENAI_BASE_URL={os.getenv('OPENAI_BASE_URL')}")
    print(f"OPENAI_MODEL={os.getenv('OPENAI_MODEL')}")
    print(f"OPENAI_REASONING_EFFORT={os.getenv('OPENAI_REASONING_EFFORT', 'low')}")
    print(f"OPENAI_STORE={os.getenv('OPENAI_STORE', 'false')}")
    return 0


def check_telegram() -> int:
    print_step("Telegram")
    token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    url = f"https://api.telegram.org/bot{token}/getMe"

    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        body = redact(error.read().decode("utf-8", errors="replace"))
        print(f"Telegram HTTP {error.code}: {body}")
        return fail("Telegram token is invalid or revoked.")
    except Exception as error:
        return fail(f"cannot reach Telegram API: {error}")

    if not payload.get("ok"):
        print(redact(json.dumps(payload, ensure_ascii=False, indent=2)))
        return fail("Telegram getMe returned ok=false.")

    result = payload["result"]
    pass_line(f"token belongs to @{result.get('username')} id={result.get('id')}")
    return 0


def check_openai() -> int:
    print_step("OpenAI-compatible API")
    base_url = os.getenv("OPENAI_BASE_URL", "https://lanxinai.com/v1")
    model = os.getenv("OPENAI_MODEL", "gpt-5.5")
    effort = os.getenv("OPENAI_REASONING_EFFORT", "low")
    store = os.getenv("OPENAI_STORE", "false").lower() in {"1", "true", "yes", "y"}

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=base_url)
    try:
        response = client.responses.create(
            model=model,
            store=store,
            reasoning={"effort": effort},
            input="只回覆 OK 兩個字。",
            max_output_tokens=32,
        )
    except Exception as error:
        print(f"OpenAI request error: {type(error).__name__}: {redact(str(error))}")
        return fail("OpenAI-compatible API check failed.")

    text = getattr(response, "output_text", "") or ""
    pass_line(f"model replied: {text.strip() or '<empty>'}")
    return 0


def main() -> int:
    print(f"Python: {sys.executable}")
    for check in [check_env_file, check_telegram, check_openai]:
        code = check()
        if code:
            return code

    print("\nAll checks passed. Run: python bot.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
