# Douyin Peipao Runtime Override - 2026-07-12

- Current Windows user is `C:\Users\max`; do not use the obsolete `C:\Users\Administrator\MiniNewBridge3` path.
- Daily schedule task: `Codex Douyin Peipao Daily 1700`.
- Current script: `C:\Users\max\tg-openai-bot\scheduled_reports\run-douyin-peipao-daily.ps1`.
- Local backup/status root: `E:\COOCMEMORY\douyin_peipao_daily\YYYYMMDD\`.
- Telegram delivery: TGBOT only, using `C:\Users\max\tg-openai-bot\tools\send_telegram_text_origin.ps1`.
- Never use TGBOT/TGBOT folders, fallback chat ids, or `TELEGRAM_ALLOWED_CHAT_IDS`.
- Completion requires the daily report to be actually sent to the TGBOT report chat.
- A scheduled task being `Ready`, `started`, or producing a prompt file is not completion.
- If public benchmark material is insufficient, say so and provide new search directions; do not invent benchmark videos, metrics, links, or private analytics.
