---
name: notebooklm-source-builder
description: Prepare source-only material for NotebookLM. Use only when the owner explicitly asks to organize or clean source documents; for actual NBS deliverables use the unified nbs skill.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# NotebookLM Source Builder

Use this skill to turn raw materials into clean NotebookLM sources.

## Goals

- Make each source document self-contained, well titled, and easy for NotebookLM to cite.
- Preserve original facts, names, dates, and user wording.
- Remove noise, duplicates, broken encoding, unrelated chat filler, and repeated operational messages.
- Split large material into source files by topic, episode, course, role, month, or project.
- Generate study and retrieval helpers after the source files are clean.

## Default Workflow

1. Inventory inputs:
   - PDF, DOCX, TXT, Markdown, audio transcript, video transcript, website copy, spreadsheet, Telegram memory, or pasted notes.
2. Choose source structure:
   - `01-overview.md`
   - `02-key-concepts.md`
   - `03-transcript-clean.md`
   - `04-qa-bank.md`
   - `05-glossary.md`
   - `06-action-checklists.md`
3. Clean content:
   - Fix headings.
   - Remove duplicate lines.
   - Convert long chat logs into topic sections.
   - Keep exact dates and names.
   - Mark uncertain claims as uncertain.
4. Add NotebookLM-friendly metadata at the top:
   - Title
   - Source type
   - Date
   - Project
   - People/roles
   - Keywords
5. Add structured sections:
   - Executive summary
   - Key facts
   - Timeline
   - Important quotes or wording
   - Decisions
   - Open questions
6. Produce helper files:
   - FAQ / Q&A bank
   - Glossary
   - Study guide
   - Prompt list for NotebookLM questions

## Output Format

Prefer Markdown unless the user asks for Word/PDF.

Use this header:

```markdown
# <Source Title>

Source type:
Project:
Date range:
People / roles:
Keywords:

## 1. Executive Summary
## 2. Key Facts
## 3. Detailed Notes
## 4. Timeline
## 5. Decisions / Rules
## 6. Q&A Seeds
## 7. Glossary
```

## For User's Common Use Cases

### AI / self-media / business monetization

Organize by:

- Concept
- Platform
- Workflow
- Monetization method
- Script example
- Execution checklist

### Short drama and SD video

Organize by:

- Episode
- Segment
- Character
- Scene
- Prompt
- Negative constraints
- Generated assets

### Course management

Organize by:

- Month
- City/session
- Course info
- Attendee list
- Check-in rules
- Google Sheet / website changes

### Character memory

Organize by:

- Character name
- Reference image description
- Voice/audio notes
- Outfit
- Personality
- Prohibitions
- Latest confirmed prompt wording

## Quality Checklist

Before finishing:

- NotebookLM source is not just a chat dump.
- Every file has a clear title and metadata.
- Important names and dates are preserved.
- Duplicates and broken filler are removed.
- Q&A seeds are included when useful.
- Output files are saved to a clear folder.

