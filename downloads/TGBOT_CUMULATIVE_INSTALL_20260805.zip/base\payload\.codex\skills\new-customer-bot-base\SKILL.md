---
name: new-customer-bot-base
description: Use when working on the new customer BOT handoff, onboarding a new customer bot, transferring bot memory/skills, or applying the handoff document `new_customer_bot_base_v0.md`.
---

# New Customer BOT Base

Use this skill when the operator asks to build, migrate, explain, preserve, or hand off a new customer BOT using `new_customer_bot_base_v0.md`.

## Current Status

- Existing operator memories and skills must be preserved. Do not overwrite them.
- The handoff file name is `new_customer_bot_base_v0.md`.
- If the source file is available, read it first and follow it as the primary handoff guide.
- If the source file is not available, stop and ask the operator to upload or provide the file path before making irreversible changes.

## Default Handling Rules

1. Preserve all current memories, skills, AGENTS instructions, Telegram preferences, and workflow rules.
2. Add new customer BOT material as additive files or additive sections only.
3. Do not replace existing `AGENTS.md`, `.codex/skills`, or `.codex/memories` content unless the operator explicitly asks.
4. Avoid exposing credentials, Telegram tokens, OpenAI keys, browser profiles, or login data in any handoff package.
5. When exporting for another Codex, include only safe handoff files, skills, memories, and setup notes.

## Expected Source File

Preferred path once available:

```text
C:\Users\Administrator\.codex\skills\new-customer-bot-base\references\new_customer_bot_base_v0.md
```

If the operator uploads the file elsewhere, copy it into `references/` and update this skill if needed.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














