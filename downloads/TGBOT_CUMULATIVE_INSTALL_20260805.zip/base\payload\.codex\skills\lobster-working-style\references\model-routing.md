# Model Routing Status

Current verified status as of 2026-06-25:

- OpenClaw current main model: `custom-lanxinai-com/gpt-5.5`.
- api88 provider lists Gemini/Claude-like models, but direct tests failed for Gemini and Claude routes.
- `MiniMax-M2.7` on api88 responded successfully.
- Local `gemini` CLI is installed, but it requires a valid auth method/API key before use.
- Do not claim Gemini or Claude are fully usable until an actual request succeeds through OpenClaw or the CLI/API.

Recommended behavior:
- If user asks to fix Gemini/Claude, verify with live test calls.
- If no valid upstream credential exists, report that external authorization/upstream is blocking.
- Keep OpenClaw usable via known working model while diagnosing.
