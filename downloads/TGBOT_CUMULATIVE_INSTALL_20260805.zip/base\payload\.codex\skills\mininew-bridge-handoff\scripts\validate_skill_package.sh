#!/usr/bin/env bash
set -euo pipefail

SKILL_DIR="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SKILL_MD="$SKILL_DIR/SKILL.md"

if [ ! -f "$SKILL_MD" ]; then
  echo "Missing SKILL.md: $SKILL_MD" >&2
  exit 1
fi

if ! sed -n '1,20p' "$SKILL_MD" | grep -q '^---$'; then
  echo "SKILL.md missing YAML frontmatter start" >&2
  exit 1
fi

if ! sed -n '1,40p' "$SKILL_MD" | grep -q '^name: '; then
  echo "SKILL.md missing name field" >&2
  exit 1
fi

if ! sed -n '1,40p' "$SKILL_MD" | grep -q '^description: '; then
  echo "SKILL.md missing description field" >&2
  exit 1
fi

for required in \
  "$SKILL_DIR/references/new_bridge_setup_zh.md" \
  "$SKILL_DIR/references/future_skill_integration_zh.md" \
  "$SKILL_DIR/references/mininew_behavior_prompt_zh.md" \
  "$SKILL_DIR/references/safe_handoff_checklist_zh.md"
do
  if [ ! -f "$required" ]; then
    echo "Missing reference: $required" >&2
    exit 1
  fi
done

if find "$SKILL_DIR" -type f \( -name ".env" -o -name "*.cookie" -o -name "*token*" -o -name "credentials.json" \) | grep -q .; then
  echo "Potential secret-bearing file found. Review package before handoff." >&2
  find "$SKILL_DIR" -type f \( -name ".env" -o -name "*.cookie" -o -name "*token*" -o -name "credentials.json" \)
  exit 1
fi

echo "Skill package looks valid: $SKILL_DIR"

