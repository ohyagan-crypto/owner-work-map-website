---
name: wbs
description: Website build and GitHub Pages deployment workflow for this owner. Use when the owner says wbs, asks to build, rebuild, update, add to, test, publish, publicly deploy, open-source, connect GitHub, create a shareable website link, or handle no-computer phone GitHub authorization for website work.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# WBS

WBS is the owner's complete website build, verification, and public deployment workflow.

Use this skill whenever the owner asks for website work. Treat short follow-ups such as "公開部署", "加入我的網站", "直接連結github", "好了沒", "再一次", or "以後自動" as continuing the latest website task when recent context identifies the site.

## Owner Communication

- Reply to the owner in clean Traditional Chinese only.
- Keep progress updates short and factual.
- Do not mention internal tool names, raw logs, approval states, token usage, traces, bridge/session details, JSON dumps, or debug output.
- If blocked, state the exact blocker, what is already completed, and what input is needed next.
- When deployment succeeds, return the public website URL and, when useful, the source repository URL.
- When deployment is blocked, still return the local site path or local preview URL if available.

## Non-Negotiable Rules

- Build or update real local website files before saying the website is complete.
- Do not stop at a plan for actionable website requests.
- For static public sites, prefer GitHub Pages unless the owner asks for another host.
- If the owner previously asked for automatic public deployment, deploy after local verification without asking again.
- Do not ask the owner to operate the computer for GitHub authorization.
- Do not launch GitHub CLI device login for Telegram website tasks.
- Never print, save, commit, package, or repeat GitHub tokens, Telegram tokens, cookies, browser profiles, `.env` files, screenshots with codes, or raw credentials.
- Do not commit unrelated files from a dirty worktree.
- Do not use image-generation workflows for website tasks unless the owner explicitly asks to generate a poster or image asset.

## Start Of Every Website Task

1. Identify whether the request is a new site, an update to an existing site, a deployment-only task, or a status follow-up.
2. Use recent context to find the active site folder and public URL when the owner uses short phrasing.
3. Inspect the existing project before editing:
   - project files
   - package scripts
   - current Git remote
   - current deployment state if relevant
4. If no project exists, create a deployable static or frontend project in a clear folder under `C:\Users\max`.
5. Preserve existing user changes and avoid unrelated refactors.

## Site Build Requirements

For a new website, create a complete usable site as the first screen, not a placeholder or marketing-only shell.

Minimum deployable files:

- `index.html` or a framework entry point
- CSS or styling files
- JavaScript files when interactions are needed
- assets needed by the page
- dependency and build files when using a framework

Include the owner's provided business details, product images, contact phone numbers, order forms, booking forms, carts, or copy when present in the conversation. If key content is missing, make a practical first version and clearly say what can be replaced later.

## Frontend Quality Rules

- Make the first screen immediately useful for the requested site.
- Ensure mobile and desktop layouts are readable.
- Keep text inside buttons, cards, forms, and navigation from overflowing.
- Use responsive constraints such as max widths, grid tracks, aspect ratios, and stable toolbar/button sizes.
- Build expected controls and states for the workflow, such as form validation, cart totals, quantity changes, submission summaries, loading states, and disabled states.
- Use real images or provided assets when the site depends on product, place, person, or brand recognition.
- Avoid decorative-only pages, nested cards, oversized empty heroes, one-note palettes, and text that overlaps on small screens.
- For operational tools or business sites, keep the layout quiet, clear, and task-focused.

## Local Verification

Before reporting completion:

1. Confirm files exist.
2. Install dependencies if needed.
3. Run the available build or typecheck command when present.
4. Start or use a local preview server when the site needs one.
5. Verify core flows in a browser when practical:
   - page loads
   - main navigation works
   - forms accept expected input
   - cart or booking calculations work
   - responsive layout works on desktop and mobile sizes
6. Fix visible errors before deploying.

For plain static HTML that works by opening the file directly, a dev server is optional. For framework sites, keep the preview server running when giving the owner a local URL.

## Git And Commit Rules

Before committing:

1. Run `git status --short`.
2. Commit only deployable files relevant to the website task.
3. Exclude temporary screenshots, downloaded drafts, logs, local secrets, caches, and unrelated files.
4. Use a concise commit message describing the website change.

For existing repos, preserve the current remote unless there is a clear reason to change it.

## Deployment Preparation

Before any GitHub Pages deployment, read and follow:

`C:\Users\max\.openclaw\workspace\GITHUB_DEPLOY_RUNBOOK.md`

Prepare the PowerShell environment before Git or GitHub commands:

```powershell
$env:PATH = "C:\Program Files\GitHub CLI;C:\Users\max\PortableGit\cmd;C:\Users\max\PortableGit\bin;C:\Users\max\PortableGit\mingw64\bin;C:\nvm4w\nodejs;C:\Users\max\AppData\Roaming\npm;" + $env:PATH
$env:GIT_TERMINAL_PROMPT = "0"
$env:GCM_INTERACTIVE = "Never"
```

Do not use npm-installed `gh`. Use the installed GitHub CLI only when GitHub CLI is required.

## GitHub Auth Decision

Use this order:

1. If `C:\Users\max\.openclaw\secrets\github-deploy-token.dpapi` exists, use the encrypted token helper. Do not ask the owner to log in.
2. For existing repos where normal push already works, push with Git after checking the remote.
3. For new repos, Pages API calls, rejected credentials, or missing auth, use the encrypted Telegram personal access token setup.

Preferred encrypted-token push helper:

```powershell
C:\Users\max\.openclaw\workspace\tools\git-push-with-github-token.ps1 -RepoDir <site-repo> -Remote origin -Branch main
```

Avoid routine `git credential fill` and `git push --dry-run` because they may hang on this host.

## New GitHub Pages Site Flow

When deploying a new static site:

1. Create or confirm the local repo.
2. Create a GitHub repo under the owner's account when needed.
3. Set `origin` to the GitHub repo.
4. Commit deployable files.
5. Push the main branch.
6. Enable GitHub Pages from the correct branch and folder.
7. Verify the Pages URL returns a successful response.
8. Return the public URL and source repo URL.

For static Vite or frontend builds, choose one clear deployment pattern:

- deploy source directly if `index.html` and assets are at repo root
- deploy built `dist` output only when the repo and Pages settings are configured for that output

Do not leave the repo in a state where Pages points at missing files.

## Existing Website Update Flow

When updating an existing website:

1. Open the existing site folder from recent context or the owner's instruction.
2. Inspect the current project and remote.
3. Apply the requested change locally.
4. Verify the updated behavior locally.
5. Commit only the relevant changes.
6. Push to the existing remote.
7. Verify the public URL after deployment.
8. Tell the owner the update is live.

If the update belongs to a previously deployed site, do not create a new repo unless the owner asks for a separate website.

## Phone GitHub Authorization Flow

Use this only when GitHub deployment credentials are missing or need refreshing.

Tell the owner to send:

```text
github 授權
```

Then run:

```powershell
C:\Users\max\.openclaw\workspace\tools\send-github-token-setup.ps1
```

The owner opens the Telegram phone link, creates the token, then sends:

```text
github_pat TOKEN
```

Store the token immediately through the encrypted helper only:

```powershell
$Token | C:\Users\max\.openclaw\workspace\tools\set-github-deploy-token.ps1
```

After storing it, continue the original deployment. Do not repeat the token back to the owner and do not save it anywhere else.

## Status Follow-Ups

When the owner asks "好了沒" or similar:

- If the task is complete, give the final URL or local path.
- If still working, give the current concrete step.
- If blocked, give the exact blocker and next required input.
- Do not give generic standby or health-check messages.

## Completion Response

A successful final response should include only the useful result:

- public website URL
- source repo URL if deployed to GitHub
- local path or local preview URL when useful
- one short verification note

Keep the message clean and concise.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->












