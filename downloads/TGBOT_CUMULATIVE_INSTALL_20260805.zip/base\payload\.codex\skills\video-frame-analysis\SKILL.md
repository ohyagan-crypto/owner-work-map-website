---
name: video-frame-analysis
description: Use whenever the owner sends a video, asks to analyze a video, asks for teaching-video settings, speech speed, editing rhythm, subtitles, shot timing, benchmark replication, or any conclusion that depends on video content.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Video Frame Analysis

Use this skill for every owner-provided video before giving conclusions about the video. This skill is mandatory for videos.

## Highest Rules

- Reply to the owner only in clean Traditional Chinese.
- Before starting, tell the owner what is being analyzed and the estimated time.
- Do not claim a video was analyzed unless the actual video file or extracted frames were inspected.
- If only a screenshot is available, say that only a screenshot is available and ask for the video or the exact local video path.
- Do not rely on chat memory, filenames, thumbnails, or prior assumptions as proof of video content.
- If extraction, playback, probing, download, or file access fails, report the blocker and next step in Chinese.

## Required Workflow

1. Confirm the video file path exists and record file size.
2. Run `ffprobe` to inspect duration, frame rate, resolution, streams, and audio presence.
3. Extract frames before answering:
   - For very short videos, extract dense frames, ideally 1 frame per second or more when needed.
   - For tutorial, benchmark, editing, and speech-speed tasks, extract enough frames to see every meaningful UI change, subtitle change, shot change, and timing cue.
   - For long videos, first extract a timeline sample, then zoom into important sections.
4. Inspect the extracted frames visually.
5. Build an edit-useful timeline:
   - timecode range
   - visible scene or UI state
   - captions/subtitles and placement
   - shot or screen change
   - transition or animation
   - speaker / presenter action
   - product or interface focus
   - inferred pacing only when supported by visible timing or audio metadata
6. If the owner asks about speech speed, compare:
   - script length if provided
   - video duration
   - visible subtitle density
   - platform recommendation shown in the video
   - whether the content is teaching, sales, or emotional short-form
7. Give a recommendation only after the above analysis.

## Output Style

Keep owner-facing answers concise unless they ask for the full breakdown.

For quick answers:

```text
我看過影片後建議：...
依據是：00:03、00:08、00:14 這幾段字幕切換很快，教學影片節奏偏短影音，所以...
```

For detailed analysis:

```text
00:00-00:03：...
00:03-00:07：...
00:07-00:12：...
結論：...
```

## Commands

Use these command patterns from PowerShell when needed:

```powershell
ffprobe -v error -show_format -show_streams -of json "<video>"
```

Extract one frame per second:

```powershell
ffmpeg -y -i "<video>" -vf "fps=1,scale=720:-1" "<outdir>\frame_%04d.jpg"
```

Extract denser frames for short/tutorial videos:

```powershell
ffmpeg -y -i "<video>" -vf "fps=2,scale=720:-1" "<outdir>\frame_%04d.jpg"
```

Extract scene-change frames:

```powershell
ffmpeg -y -i "<video>" -vf "select='gt(scene,0.18)',scale=720:-1" -vsync vfr "<outdir>\scene_%04d.jpg"
```

## Stop Conditions

Stop and ask/report if:

- The referenced video file does not exist.
- The attachment is only an image or screenshot.
- The video is unreadable or corrupted.
- The task requires audio judgment but no audio track is available.
- Login, permission, payment, captcha, or security prompts block access.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->










