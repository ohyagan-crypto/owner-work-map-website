# 後續技能整合規則

這份文件用來讓另一個 Codex 把未來新增的技能包整合進同一套橋接端。

## 技能放置位置

預設：

```bash
/root/.codex/skills/<skill-name>
```

如果環境有設定：

```bash
echo "$CODEX_HOME"
```

則使用：

```bash
$CODEX_HOME/skills/<skill-name>
```

## 技能基本結構

每個技能至少要有：

```text
skill-name/
└── SKILL.md
```

建議可有：

```text
skill-name/
├── SKILL.md
├── agents/openai.yaml
├── references/
├── scripts/
└── assets/
```

`SKILL.md` 必須有 YAML frontmatter：

```yaml
---
name: skill-name
description: Use when...
---
```

`description` 要清楚寫「什麼時候使用這個技能」，不要只寫功能名稱。

## 安裝流程

```bash
mkdir -p /root/.codex/skills
cp -a <skill-folder> /root/.codex/skills/
```

若同名資料夾已存在：

1. 不要直接覆蓋。
2. 先備份舊版。
3. 比對 `SKILL.md`、`references/`、`scripts/`。
4. 取得使用者確認後再替換。

範例：

```bash
cp -a /root/.codex/skills/example-skill "/root/.codex/skills/example-skill.bak_$(date +%Y%m%d_%H%M%S)"
```

## 驗證

```bash
find /root/.codex/skills -maxdepth 2 -name SKILL.md -print
```

逐一檢查：

```bash
sed -n '1,40p' /root/.codex/skills/<skill-name>/SKILL.md
```

若有腳本：

```bash
find /root/.codex/skills/<skill-name>/scripts -type f -maxdepth 1 -print
```

必要時加執行權限：

```bash
chmod +x /root/.codex/skills/<skill-name>/scripts/*.sh
chmod +x /root/.codex/skills/<skill-name>/scripts/*.py
```

## 重啟

技能 metadata 通常需要新一輪 Codex 或橋接端流程才會載入。安裝後建議重啟橋接端：

```bash
systemctl restart mininew-telegram-bridge.service
```

或 user service：

```bash
systemctl --user restart mininew-telegram-bridge.service
```

若是手動跑，停止後重新執行：

```bash
cd /root/customer-telegram-bot
bash scripts/run.sh
```

## 安全規則

技能包內不可包含：

- `.env`
- API key
- Telegram token
- OAuth token
- cookies
- 瀏覽器登入資料
- allowed chat id / user id
- 私人帳密

如果技能需要這些資料，只能放 placeholder，並請使用者在目標環境自行填入。

## 與橋接端記憶整合

如果新技能有固定用語、流程或安全規則，可把「長期需要遵守的簡短摘要」加入橋接端記憶文件，例如：

```text
/root/customer-telegram-bot/docs/mininew_bridge_memory_zh.md
```

不要把整份技能全文塞進記憶，避免上下文太重。記憶只放日常行為規則；詳細流程留在技能 `references/`。

## 新技能交接格式

交給另一個 Codex 時，建議附上：

```text
請把這個技能資料夾放到 /root/.codex/skills/
不要覆蓋既有同名技能，若已存在請先備份。
安裝後重啟 Telegram 橋接端或開新的 Codex 工作階段。
不要把任何 .env、token、cookie、OAuth token、密碼放進技能包。
```

