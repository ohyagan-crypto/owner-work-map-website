@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

:MENU
cls
echo Telegram AI Bot Control
echo =======================
echo.
echo Recommended first run: double-click BOT_NOW.cmd
echo.
echo 1. Stop any running bot
echo 2. Recreate .env with new tokens
echo 3. One-shot Telegram pong test
echo 4. One-shot Telegram + AI test
echo 5. Start Telegram-only test bot
echo 6. Start AI bot in this window ^(recommended until verified^)
echo 7. Start AI bot in background
echo 8. Install logon auto-start task
echo 9. Uninstall logon auto-start task
echo 10. Collect diagnostics
echo 11. Open logs folder
echo 12. Exit
echo.
set /p CHOICE=Choose 1-12 and press Enter: 

if "%CHOICE%"=="1" goto STOP
if "%CHOICE%"=="2" goto RESET
if "%CHOICE%"=="3" goto ONCE
if "%CHOICE%"=="4" goto AIONCE
if "%CHOICE%"=="5" goto TGONLY
if "%CHOICE%"=="6" goto START
if "%CHOICE%"=="7" goto BACKGROUND
if "%CHOICE%"=="8" goto INSTALL
if "%CHOICE%"=="9" goto UNINSTALL
if "%CHOICE%"=="10" goto DIAG
if "%CHOICE%"=="11" goto LOGS
if "%CHOICE%"=="12" goto END
goto MENU

:STOP
call "%~dp0STOP_BOT.cmd"
goto MENU

:RESET
call "%~dp0RESET_ENV.cmd"
goto MENU

:ONCE
call "%~dp0TEST_REPLY_ONCE.cmd"
goto MENU

:AIONCE
call "%~dp0TEST_AI_ONCE.cmd"
goto MENU

:TGONLY
call "%~dp0START_TELEGRAM_ONLY.cmd"
goto MENU

:START
call "%~dp0BOT_NOW.cmd"
goto MENU

:BACKGROUND
call "%~dp0START_BACKGROUND.cmd"
goto MENU

:INSTALL
call "%~dp0INSTALL_STARTUP_TASK.cmd"
goto MENU

:UNINSTALL
call "%~dp0UNINSTALL_STARTUP_TASK.cmd"
goto MENU

:DIAG
call "%~dp0COLLECT_DIAGNOSTICS.cmd"
goto MENU

:LOGS
start "" "%~dp0"
goto MENU

:END
endlocal
