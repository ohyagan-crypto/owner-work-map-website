@echo off
setlocal
cd /d "%~dp0"

echo Stopping and removing Telegram AI Bot scheduled task...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Stop-ScheduledTask -TaskName 'Telegram AI Bot' -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName 'Telegram AI Bot' -Confirm:$false -ErrorAction SilentlyContinue"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\stop_bot.ps1"
pause
