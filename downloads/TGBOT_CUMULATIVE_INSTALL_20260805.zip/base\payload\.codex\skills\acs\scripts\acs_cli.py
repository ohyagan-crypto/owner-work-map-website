#!/usr/bin/env python
import argparse
import json
import shutil
from pathlib import Path


JY_DEDICATED_DIR = Path(r"C:\Users\Administrator\Desktop\剪映專屬")
DEFAULT_EXPORT_DIR = JY_DEDICATED_DIR / "輸出"
DEFAULT_TASK_DIR = JY_DEDICATED_DIR / "草稿規格"
DEFAULT_DRAFT_DIR = JY_DEDICATED_DIR / "草稿"
DEFAULT_JIANYING_ROOT = Path(r"C:\Users\Administrator\AppData\Local\JianyingPro")
CAPCUT_MCP_ROOT = Path(r"C:\Users\Administrator\Tools\jianying-open-source\capcut-mcp")
PYTHON_EXE = Path(r"C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe")


def write_json(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def ratio_to_size(ratio: str) -> tuple[int, int]:
    normalized = ratio.strip().lower()
    if normalized in {"9:16", "vertical", "shorts"}:
        return 1080, 1920
    if normalized in {"16:9", "horizontal", "youtube"}:
        return 1920, 1080
    if normalized in {"1:1", "square"}:
        return 1080, 1080
    raise ValueError(f"Unsupported ratio: {ratio}")


def detect_kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}:
        return "video"
    if ext in {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}:
        return "audio"
    if ext in {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}:
        return "image"
    return "unknown"


def find_draft_dirs() -> list[str]:
    candidates = []
    if DEFAULT_DRAFT_DIR.exists():
        candidates.append(str(DEFAULT_DRAFT_DIR))
    roots = [
        DEFAULT_DRAFT_DIR,
        JY_DEDICATED_DIR,
        Path.home() / "Documents",
        Path.home() / "AppData" / "Local",
        Path.home() / "AppData" / "Roaming",
        Path(r"C:\Users\Administrator\Documents"),
    ]
    names = ["JianyingPro Drafts", "剪映专业版草稿", "剪映草稿", "CapCut Drafts"]
    for root in roots:
        if not root.exists():
            continue
        for name in names:
            p = root / name
            if p.exists():
                candidates.append(str(p))
        try:
            for p in root.rglob("*Draft*"):
                if p.is_dir() and ("Jianying" in p.name or "CapCut" in p.name):
                    candidates.append(str(p))
        except Exception:
            pass
    return sorted(set(candidates))


def probe_file(path: Path) -> dict:
    item = {
        "path": str(path),
        "exists": path.exists(),
        "kind": detect_kind(path),
        "size_bytes": path.stat().st_size if path.exists() else None,
    }
    if not path.exists() or not path.is_file():
        return item
    try:
        from pymediainfo import MediaInfo
        media = MediaInfo.parse(str(path))
        for track in media.tracks:
            if track.track_type == "Video":
                item.update({
                    "width": track.width,
                    "height": track.height,
                    "duration_ms": track.duration,
                    "frame_rate": track.frame_rate,
                    "codec": track.format,
                })
                break
            if track.track_type == "Audio" and item["kind"] == "audio":
                item.update({
                    "duration_ms": track.duration,
                    "sampling_rate": track.sampling_rate,
                    "channels": track.channel_s,
                    "codec": track.format,
                })
                break
    except Exception as exc:
        item["mediainfo_error"] = f"{type(exc).__name__}: {exc}"
    if item["kind"] == "image" and "width" not in item:
        try:
            from PIL import Image
            with Image.open(path) as img:
                item["width"], item["height"] = img.size
        except Exception as exc:
            item["image_error"] = f"{type(exc).__name__}: {exc}"
    return item


def cmd_check(_args: argparse.Namespace) -> int:
    checks = {}
    for mod in ["pyJianYingDraft", "uiautomation", "cv2", "fastapi", "uvicorn", "pymediainfo", "imageio"]:
        try:
            __import__(mod)
            checks[mod] = "ok"
        except Exception as exc:
            checks[mod] = f"fail: {type(exc).__name__}: {exc}"
    checks["jianying_root"] = "ok" if DEFAULT_JIANYING_ROOT.exists() else "missing"
    checks["ffmpeg"] = shutil.which("ffmpeg") or "missing"
    checks["ffprobe"] = shutil.which("ffprobe") or "missing"
    checks["export_dir"] = str(DEFAULT_EXPORT_DIR)
    checks["dedicated_dir"] = str(JY_DEDICATED_DIR)
    checks["default_draft_dir"] = str(DEFAULT_DRAFT_DIR)
    checks["draft_dirs"] = find_draft_dirs()
    ok = all(
        str(v) == "ok" or isinstance(v, list) or k in {"ffmpeg", "ffprobe", "export_dir", "dedicated_dir", "default_draft_dir"}
        for k, v in checks.items()
    )
    print(json.dumps({"ok": ok, "checks": checks}, ensure_ascii=False, indent=2))
    return 0 if ok else 2


def cmd_find_drafts(_args: argparse.Namespace) -> int:
    print(json.dumps({"draft_dirs": find_draft_dirs()}, ensure_ascii=False, indent=2))
    return 0


def cmd_make_spec(args: argparse.Namespace) -> int:
    width, height = ratio_to_size(args.ratio)
    name = args.name.strip()
    spec = {
        "name": name,
        "draft_name": args.draft_name or f"ACS_{name}",
        "ratio": args.ratio,
        "width": width,
        "height": height,
        "fps": args.fps,
        "assets": {"videos": [], "images": [], "audio": []},
        "timeline": [
            {
                "start": "0s",
                "duration": "3s",
                "type": "hook",
                "asset": "",
                "caption": "",
                "notes": "Opening hook; replace with real source asset.",
            }
        ],
        "captions": [],
        "music": "",
        "benchmark": {
            "hook": "",
            "rhythm": "",
            "caption_style": "",
            "transitions": "",
            "cta": "",
        },
        "export": {
            "folder": str(DEFAULT_EXPORT_DIR),
            "filename": f"{name}.mp4",
            "resolution": "1080p",
            "fps": args.fps,
        },
    }
    out = Path(args.out) if args.out else DEFAULT_TASK_DIR / name / "edit_spec.json"
    write_json(spec, out)
    print(json.dumps({"ok": True, "spec": str(out)}, ensure_ascii=False, indent=2))
    return 0


def cmd_probe_assets(args: argparse.Namespace) -> int:
    paths = []
    for raw in args.paths:
        p = Path(raw)
        if p.is_dir():
            for child in p.rglob("*"):
                if child.is_file() and detect_kind(child) != "unknown":
                    paths.append(child)
        else:
            paths.append(p)
    result = {"ok": True, "assets": [probe_file(p) for p in paths]}
    result["missing"] = [a["path"] for a in result["assets"] if not a.get("exists")]
    if result["missing"]:
        result["ok"] = False
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 2


def cmd_validate_spec(args: argparse.Namespace) -> int:
    spec_path = Path(args.spec)
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    errors = []
    warnings = []
    for key in ["name", "draft_name", "width", "height", "fps", "assets", "timeline", "export"]:
        if key not in spec:
            errors.append(f"missing required key: {key}")
    if "assets" in spec:
        for group in ["videos", "images", "audio"]:
            for raw in spec["assets"].get(group, []):
                if raw and not Path(raw).exists():
                    errors.append(f"missing asset: {raw}")
    if not spec.get("timeline"):
        warnings.append("timeline is empty")
    for idx, item in enumerate(spec.get("timeline", [])):
        if not item.get("duration"):
            errors.append(f"timeline[{idx}] missing duration")
    result = {"ok": not errors, "errors": errors, "warnings": warnings, "spec": str(spec_path)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 2


def cmd_create_draft(args: argparse.Namespace) -> int:
    try:
        import pyJianYingDraft as draft
    except Exception as exc:
        print(json.dumps({"ok": False, "error": f"pyJianYingDraft import failed: {exc}"}, ensure_ascii=False))
        return 2

    spec_path = Path(args.spec)
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    draft_dir = Path(args.draft_dir) if args.draft_dir else None
    if not draft_dir:
        found = find_draft_dirs()
        if not found:
            DEFAULT_DRAFT_DIR.mkdir(parents=True, exist_ok=True)
            draft_dir = DEFAULT_DRAFT_DIR
        else:
            draft_dir = Path(found[0])

    try:
        folder = draft.DraftFolder(str(draft_dir))
        script = folder.create_draft(
            spec["draft_name"],
            int(spec.get("width", 1080)),
            int(spec.get("height", 1920)),
            fps=int(spec.get("fps", 30)),
            allow_replace=bool(args.allow_replace),
        )
        script.add_track(draft.TrackType.video).add_track(draft.TrackType.audio).add_track(draft.TrackType.text)
        for item in spec.get("timeline", []):
            caption = (item.get("caption") or "").strip()
            if not caption:
                continue
            start = item.get("start", "0s")
            duration = item.get("duration", "3s")
            segment = draft.TextSegment(caption, draft.trange(start, duration), clip_settings=draft.ClipSettings(transform_y=-0.75))
            script.add_segment(segment)
        script.save()
    except Exception as exc:
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}", "draft_dir": str(draft_dir)}, ensure_ascii=False))
        return 4

    print(json.dumps({"ok": True, "draft_name": spec["draft_name"], "draft_dir": str(draft_dir)}, ensure_ascii=False, indent=2))
    return 0


def cmd_mcp_info(_args: argparse.Namespace) -> int:
    info = {
        "ok": CAPCUT_MCP_ROOT.exists(),
        "root": str(CAPCUT_MCP_ROOT),
        "main": str(CAPCUT_MCP_ROOT / "main.py"),
        "start_command": f'"{PYTHON_EXE}" "{CAPCUT_MCP_ROOT / "main.py"}"',
        "endpoint": "http://localhost:9000/mcp",
        "note": "Start only when needed; do not leave long-running servers active without reporting.",
    }
    print(json.dumps(info, ensure_ascii=False, indent=2))
    return 0 if info["ok"] else 2


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="ACS helper CLI for Jianying automation")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("check").set_defaults(func=cmd_check)
    sub.add_parser("find-drafts").set_defaults(func=cmd_find_drafts)

    p_spec = sub.add_parser("make-spec")
    p_spec.add_argument("--name", required=True)
    p_spec.add_argument("--draft-name")
    p_spec.add_argument("--ratio", default="9:16")
    p_spec.add_argument("--fps", type=int, default=30)
    p_spec.add_argument("--out")
    p_spec.set_defaults(func=cmd_make_spec)

    p_probe = sub.add_parser("probe-assets")
    p_probe.add_argument("paths", nargs="+")
    p_probe.set_defaults(func=cmd_probe_assets)

    p_validate = sub.add_parser("validate-spec")
    p_validate.add_argument("--spec", required=True)
    p_validate.set_defaults(func=cmd_validate_spec)

    p_draft = sub.add_parser("create-draft")
    p_draft.add_argument("--spec", required=True)
    p_draft.add_argument("--draft-dir")
    p_draft.add_argument("--allow-replace", action="store_true")
    p_draft.set_defaults(func=cmd_create_draft)

    sub.add_parser("mcp-info").set_defaults(func=cmd_mcp_info)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
