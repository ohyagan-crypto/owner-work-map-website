---
name: monthly-course-site-updater
description: Update the recurring Blue Star AI course registration/check-in website each month. Use when Codex needs to replace course information, dates, city sessions, attendee lists, waitlists, Google Sheet tabs, and redeploy the GitHub Pages site.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Monthly Course Site Updater

Use this skill for the user's recurring 藍星 AI 網紅進階班 course site.

## Fixed Template

Current public site:

`https://ohyagan-crypto.github.io/blue-star-ai-course/`

Local project:

`C:\blue-course-checkin-github`

## Site Separation Rule

Do not mix this July/basic AI course site with the separate Jianying practical class site.

- July/basic AI course:
  - Public site: `https://ohyagan-crypto.github.io/blue-star-ai-course/`
  - Deploy root: `C:\Users\Administrator\blue-star-ai-course`
  - Mirror/local frontend: `C:\blue-course-checkin-github`
  - Backend root: `C:\blue-course-checkin`
  - Backend port: `8096`
  - Sessions: `7/6 台南場`, `7/7 高雄場`, `7/9 台北場`, `7/11 台中場`
- Jianying practical class:
  - Public site: `https://ohyagan-crypto.github.io/blue-star-jianying-checkin/`
  - Local/deploy root: `C:\Users\Administrator\blue-star-jianying-checkin`
  - Backend port: `8097`
  - Sessions: `6/24 剪映實戰班`, `7/1 剪映實戰班`

If the owner mentions 剪映, 周三剪映, 數字人克隆, or 剪映實戰, use only the Jianying practical class project. If the owner mentions 七月基礎課程, AI 自媒體基礎班, 台南/高雄/台北/台中場, or 基礎班, use only this July/basic AI course project. Never copy page content, roster fallback data, monitor scripts, or backend session settings between these two projects.

The template should be reused monthly. Update only:

- Course information
- Month and dates
- City/session list
- Registration names
- Waitlist names
- Google Sheet tabs
- GitHub Pages website content

## Workflow

1. Parse user-provided course announcement and name lists.
2. Split sheets by city/session instead of putting all names together.
3. Keep course information shown before long lists.
4. Keep PIN hidden from public display unless explicitly requested.
5. Ensure check-in voice prompt works where browser support allows.
6. Update local site files.
7. Commit, push, and verify GitHub Pages URL.
8. Return final URL and concise update summary.

## Automatic Repair Rule

When checking the Blue Star AI course site, do not stop at reporting a repairable issue. First run the known local repair path, then report the result.

- Use `C:\blue-course-checkin\site-monitor.ps1` for checks.
- Use `C:\blue-course-checkin\site-auto-repair.ps1` for automatic repair.
- Repairable issues include public backend API failure, roster API failure, API target mismatch, missing public API config, local backend down, deploy cache/version mismatch, fallback roster problems, and Google Sheet link/check failures.
- Always back up `C:\blue-course-checkin\data\db.json` before updating public API URLs or fallback roster data.
- Do not overwrite roster data if the local roster is empty or has fewer total records than the last known safe total.
- If the repair succeeds, reply with the concrete repair result. If the repair fails, reply with the blocker and next action in clean Traditional Chinese.
- Avoid sending the owner only a problem list for issues that can be repaired automatically.

## Confirmed Google Sheet Repair Pattern

Use this when the public website/API is already updated to the new month but the owner still sees old-month rows inside the Google Sheet mobile view.

- The real backend project is usually `C:\blue-course-checkin`; the GitHub Pages project is `C:\blue-course-checkin-github`.
- First inspect and clean `C:\blue-course-checkin\data\db.json`; back it up before removing old-month rows.
- Keep only the new-month rows in `registrations`, `checkins`, and `cancellations`.
- Verify `http://127.0.0.1:8096/api/roster` and the public Cloudflare API do not contain the old month.
- The Sheet itself may still contain stale static rows even when the backend/API is correct. In that case, repair the Sheet body directly.
- Reuse the existing Microsoft Edge / Google Sheet page through CDP on `http://127.0.0.1:9444/json/list`; do not launch a second Edge with the same profile.
- Successful Sheet direct-write scripts created in `C:\blue-course-checkin`:
  - `rebuild-visible-july-tabs-cdp.js`: rename visible tabs and clear old rows.
  - `paste-active-clipboard-to-tab-cdp.js`: paste the current Windows clipboard into a tab by its visible x-coordinate.
  - `write-july-tsv-files.js`: generate UTF-8 TSV files with correct Traditional Chinese text.
- Reliable paste sequence:
  1. Generate UTF-8 TSV files with English filenames, e.g. `current-tainan-utf8.tsv`.
  2. From PowerShell with `-STA`, read the UTF-8 file and set `[System.Windows.Forms.Clipboard]::SetText($text)`.
  3. Run `node C:\blue-course-checkin\paste-active-clipboard-to-tab-cdp.js <tabX>`.
  4. Repeat per visible tab; avoid doing all steps inside one Node process because clipboard writes can fail or reuse stale content.
- Known visible tab x-coordinates in the current Sheet layout:
  - 台南場: `174`
  - 高雄場: `265`
  - 台北場: `356`
  - 台中場: `447`
- After writing, use `cdp-sheet-screenshot.js` and inspect the screenshot. Do not trust a text-only check if the screenshot still shows stale old-month rows.
- Avoid relying on raw `Input.insertText` for Chinese table data; it can produce garbled question marks in Google Sheets. Use UTF-8 file -> PowerShell STA clipboard -> CDP paste instead.
- If the owner says “為什麼還是六月”, explain that the backend/site may be updated while the Google Sheet static rows are stale, then repair the Sheet body directly.

## Access Notes

Known allowed Sheet viewers from previous setup:

- `[REDACTED_EMAIL]`
- `[REDACTED_EMAIL]`

Do not expose credentials in output.
