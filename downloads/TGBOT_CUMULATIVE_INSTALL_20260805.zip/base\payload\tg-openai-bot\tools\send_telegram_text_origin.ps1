﻿param(
    [Parameter(Mandatory = $true)]
    [string]$Text,

    [string]$ChatId = "",

    [string]$MessageThreadId = ""
)

$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$envPath = Join-Path $projectDir ".env"

if (Test-Path -LiteralPath $envPath -PathType Leaf) {
    foreach ($line in [System.IO.File]::ReadLines($envPath)) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith("#") -or -not $trimmed.Contains("=")) {
            continue
        }
        $parts = $trimmed.Split("=", 2)
        [Environment]::SetEnvironmentVariable($parts[0].Trim(), $parts[1].Trim().Trim('"').Trim("'"), "Process")
    }
}

$token = [Environment]::GetEnvironmentVariable("TELEGRAM_BOT_TOKEN", "Process")
if ([string]::IsNullOrWhiteSpace($token)) {
    throw "Telegram token is not configured."
}

$originChatId = [Environment]::GetEnvironmentVariable("TELEGRAM_ORIGIN_CHAT_ID", "Process")
$originThreadId = [Environment]::GetEnvironmentVariable("TELEGRAM_ORIGIN_MESSAGE_THREAD_ID", "Process")

if ([string]::IsNullOrWhiteSpace($originChatId)) {
    throw "Telegram origin chat id is missing; refusing to guess a delivery target."
}

if ([string]::IsNullOrWhiteSpace($ChatId)) {
    $ChatId = $originChatId
}

if ($ChatId.Trim() -ne $originChatId.Trim()) {
    throw "Refusing to send Telegram text to a chat other than the originating chat."
}

if ([string]::IsNullOrWhiteSpace($MessageThreadId) -and -not [string]::IsNullOrWhiteSpace($originThreadId)) {
    $MessageThreadId = $originThreadId
}

if (-not [string]::IsNullOrWhiteSpace($originThreadId) -and $MessageThreadId.Trim() -ne $originThreadId.Trim()) {
    throw "Refusing to send Telegram text to a topic other than the originating topic."
}

$apiBase = [Environment]::GetEnvironmentVariable("TELEGRAM_API_BASE", "Process")
if ([string]::IsNullOrWhiteSpace($apiBase)) {
    $apiBase = "https://api.telegram.org"
}
$apiBase = $apiBase.TrimEnd("/")

$payload = @{
    chat_id = $ChatId
    text = $Text
    disable_web_page_preview = $true
}

if (-not [string]::IsNullOrWhiteSpace($MessageThreadId)) {
    $payload.message_thread_id = $MessageThreadId
}

$json = $payload | ConvertTo-Json -Depth 5
$uri = "$apiBase/bot$token/sendMessage"
$response = Invoke-RestMethod -Uri $uri -Method Post -Body $json -ContentType "application/json; charset=utf-8" -TimeoutSec 60

if (-not $response.ok) {
    throw "Telegram text upload failed."
}

Write-Output "Telegram text sent to originating chat."
