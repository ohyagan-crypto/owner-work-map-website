﻿$ErrorActionPreference = "Continue"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvPath = Join-Path $ProjectDir ".env"
$ReportPath = Join-Path $ProjectDir "e2e_report.txt"

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [System.Net.ServicePointManager]::SecurityProtocol = `
        [System.Net.ServicePointManager]::SecurityProtocol -bor `
        [System.Net.SecurityProtocolType]::Tls12
}
catch {
}

function Read-DotEnv {
    param([string] $Path)

    $Values = @{}
    if (-not (Test-Path $Path)) {
        return $Values
    }

    foreach ($RawLine in Get-Content -Path $Path -Encoding UTF8) {
        $Line = $RawLine.Trim().Trim([char]0xFEFF)
        if ([string]::IsNullOrWhiteSpace($Line) -or $Line.StartsWith("#") -or -not $Line.Contains("=")) {
            continue
        }

        $EqualsIndex = $Line.IndexOf("=")
        $Key = $Line.Substring(0, $EqualsIndex).Trim()
        $Value = $Line.Substring($EqualsIndex + 1).Trim().Trim('"').Trim("'")
        $Values[$Key] = $Value
    }

    return $Values
}

function Redact {
    param([string] $Value)

    if ($null -eq $Value) {
        return ""
    }
    if (-not [string]::IsNullOrWhiteSpace($script:TelegramToken)) {
        $Value = $Value.Replace($script:TelegramToken, "[TELEGRAM_BOT_TOKEN]")
    }
    if (-not [string]::IsNullOrWhiteSpace($script:OpenAiKey)) {
        $Value = $Value.Replace($script:OpenAiKey, "[OPENAI_API_KEY]")
    }
    return $Value
}

function Add-Line {
    param([string] $Text = "")
    $SafeText = Redact $Text
    Write-Host $SafeText
    Add-Content -Path $ReportPath -Value $SafeText -Encoding UTF8
}

function Get-HttpErrorText {
    param($ErrorRecord)

    try {
        $Response = $ErrorRecord.Exception.Response
        if ($null -ne $Response) {
            $Stream = $Response.GetResponseStream()
            if ($null -ne $Stream) {
                $Reader = New-Object System.IO.StreamReader($Stream)
                return $Reader.ReadToEnd()
            }
        }
    }
    catch {
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-Json {
    param(
        [string] $Uri,
        [hashtable] $Payload = $null,
        [hashtable] $Headers = $null,
        [int] $TimeoutSec = 60
    )

    $Params = @{
        Uri = $Uri
        Method = "Post"
        TimeoutSec = $TimeoutSec
    }

    if ($null -ne $Headers) {
        $Params.Headers = $Headers
    }
    if (-not [string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
        $Params.Proxy = $script:ProxyUrl
    }
    if ($null -ne $Payload) {
        $Params.ContentType = "application/json; charset=utf-8"
        $JsonBody = $Payload | ConvertTo-Json -Depth 50 -Compress
        $Params.Body = [System.Text.Encoding]::UTF8.GetBytes($JsonBody)
    }

    try {
        return Invoke-RestMethod @Params
    }
    catch {
        throw "HTTP request failed for $(Redact $Uri): $(Redact (Get-HttpErrorText $_))"
    }
}

function Invoke-Telegram {
    param(
        [string] $Method,
        [hashtable] $Payload = $null,
        [int] $TimeoutSec = 60
    )

    $Result = Invoke-Json `
        -Uri "$script:TelegramApiBase/bot$script:TelegramToken/$Method" `
        -Payload $Payload `
        -TimeoutSec $TimeoutSec

    if ($Result.ok -ne $true) {
        throw "Telegram $Method returned ok=false: $(Redact ($Result | ConvertTo-Json -Depth 50 -Compress))"
    }

    return $Result.result
}

function Get-ResponseText {
    param($Response)

    if ($null -ne $Response.output_text -and -not [string]::IsNullOrWhiteSpace([string]$Response.output_text)) {
        return ([string]$Response.output_text).Trim()
    }

    $Chunks = New-Object System.Collections.Generic.List[string]
    foreach ($Item in @($Response.output)) {
        if ($null -eq $Item) {
            continue
        }
        foreach ($Content in @($Item.content)) {
            if ($null -ne $Content -and $null -ne $Content.text -and -not [string]::IsNullOrWhiteSpace([string]$Content.text)) {
                [void]$Chunks.Add(([string]$Content.text).Trim())
            }
        }
    }

    if ($Chunks.Count -gt 0) {
        return ($Chunks -join "`n").Trim()
    }

    return ""
}

function Get-ChatText {
    param($Response)

    $Choices = @($Response.choices)
    if ($Choices.Count -gt 0 -and $null -ne $Choices[0]) {
        $Content = $Choices[0].message.content
        if (-not [string]::IsNullOrWhiteSpace([string]$Content)) {
            return ([string]$Content).Trim()
        }
    }

    return ""
}

function Invoke-Ai {
    param([string] $Prompt)

    $Headers = @{}
    if (-not [string]::IsNullOrWhiteSpace($script:OpenAiKey)) {
        $Headers.Authorization = "Bearer $script:OpenAiKey"
    }

    $Models = New-Object System.Collections.Generic.List[string]
    [void]$Models.Add($script:OpenAiModel)
    foreach ($Model in @($script:OpenAiFallbackModels)) {
        $CleanModel = ([string]$Model).Trim()
        if (-not [string]::IsNullOrWhiteSpace($CleanModel) -and -not $Models.Contains($CleanModel)) {
            [void]$Models.Add($CleanModel)
        }
    }

    $LastError = $null
    foreach ($ModelName in $Models) {
        $Attempts = @(
            @{
                label = "responses/full"
                uri = "$script:OpenAiBaseUrl/responses"
                payload = @{
                    model = $ModelName
                    store = $script:OpenAiStore
                    reasoning = @{ effort = $script:OpenAiReasoningEffort }
                    input = @(
                        @{ role = "developer"; content = "You are a Telegram bot assistant. Reply in Traditional Chinese, concise and direct." },
                        @{ role = "user"; content = $Prompt }
                    )
                    max_output_tokens = 1024
                }
                parser = "responses"
            },
            @{
                label = "responses/string-input"
                uri = "$script:OpenAiBaseUrl/responses"
                payload = @{
                    model = $ModelName
                    input = "You are a Telegram bot assistant. Reply in Traditional Chinese, concise and direct.`n`nUser: $Prompt"
                    max_output_tokens = 1024
                }
                parser = "responses"
            },
            @{
                label = "responses/bare-minimum"
                uri = "$script:OpenAiBaseUrl/responses"
                payload = @{
                    model = $ModelName
                    input = $Prompt
                }
                parser = "responses"
            },
            @{
                label = "chat-completions/fallback"
                uri = "$script:OpenAiBaseUrl/chat/completions"
                payload = @{
                    model = $ModelName
                    messages = @(
                        @{ role = "system"; content = "You are a Telegram bot assistant. Reply in Traditional Chinese, concise and direct." },
                        @{ role = "user"; content = $Prompt }
                    )
                    max_tokens = 1024
                }
                parser = "chat"
            }
        )

        foreach ($Attempt in $Attempts) {
            try {
                $Response = Invoke-Json -Uri $Attempt.uri -Payload $Attempt.payload -Headers $Headers -TimeoutSec 120
                if ($Attempt.parser -eq "chat") {
                    $Text = Get-ChatText $Response
                }
                else {
                    $Text = Get-ResponseText $Response
                }
                if ([string]::IsNullOrWhiteSpace($Text)) {
                    $Text = "AI replied, but no displayable text was found."
                }
                Add-Line "AI OK model=$ModelName mode=$($Attempt.label)"
                return $Text
            }
            catch {
                $LastError = $_
                Add-Line "AI failed model=$ModelName mode=$($Attempt.label): $($_.Exception.Message)"
            }
        }
    }

    throw "All AI attempts failed. Last error: $($LastError.Exception.Message)"
}

Set-Location $ProjectDir
if (Test-Path $ReportPath) {
    Remove-Item -Path $ReportPath -Force
}

$Env = Read-DotEnv $EnvPath
$script:TelegramToken = $Env["TELEGRAM_BOT_TOKEN"]
$script:TelegramApiBase = $Env["TELEGRAM_API_BASE"]
$script:OpenAiKey = $Env["OPENAI_API_KEY"]
$script:OpenAiBaseUrl = $Env["OPENAI_BASE_URL"]
$script:OpenAiModel = $Env["OPENAI_MODEL"]
$script:OpenAiFallbackModels = @()
$script:OpenAiReasoningEffort = $Env["OPENAI_REASONING_EFFORT"]
$script:OpenAiStore = $false
$script:ProxyUrl = $Env["HTTPS_PROXY"]

if ([string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
    $script:ProxyUrl = $Env["HTTP_PROXY"]
}
if ([string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Process")
}
if ([string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTP_PROXY", "Process")
}
if ([string]::IsNullOrWhiteSpace($script:TelegramApiBase)) {
    $script:TelegramApiBase = "https://api.telegram.org"
}
if ([string]::IsNullOrWhiteSpace($script:OpenAiBaseUrl)) {
    $script:OpenAiBaseUrl = "https://lanxinai.com/v1"
}
if ([string]::IsNullOrWhiteSpace($script:OpenAiModel)) {
    $script:OpenAiModel = "gpt-5.5"
}
if (-not [string]::IsNullOrWhiteSpace($Env["OPENAI_FALLBACK_MODELS"])) {
    $script:OpenAiFallbackModels = $Env["OPENAI_FALLBACK_MODELS"].Split(",")
}
if ([string]::IsNullOrWhiteSpace($script:OpenAiReasoningEffort)) {
    $script:OpenAiReasoningEffort = "xhigh"
}
if ($Env.ContainsKey("OPENAI_STORE")) {
    $script:OpenAiStore = @("1", "true", "yes", "y") -contains $Env["OPENAI_STORE"].ToLowerInvariant()
}

$script:TelegramApiBase = $script:TelegramApiBase.TrimEnd("/")
$script:OpenAiBaseUrl = $script:OpenAiBaseUrl.TrimEnd("/")
if ($script:OpenAiBaseUrl.TrimEnd("/") -eq "https://lanxinai.com") {
    $script:OpenAiBaseUrl = "https://lanxinai.com/v1"
}

Add-Line "Telegram AI Bot E2E check"
Add-Line "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Add-Line "ProjectDir: $ProjectDir"
Add-Line ""

if ([string]::IsNullOrWhiteSpace($script:TelegramToken)) {
    Add-Line "FAIL: missing TELEGRAM_BOT_TOKEN"
    exit 1
}
if ([string]::IsNullOrWhiteSpace($script:OpenAiKey)) {
    Add-Line "FAIL: missing OPENAI_API_KEY"
    exit 1
}
try {
    $Bot = Invoke-Telegram -Method "getMe" -TimeoutSec 30
    Add-Line "Telegram getMe OK: @$($Bot.username) id=$($Bot.id)"
}
catch {
    Add-Line "FAIL Telegram getMe: $($_.Exception.Message)"
    exit 1
}

try {
    [void](Invoke-Telegram -Method "deleteWebhook" -Payload @{
        drop_pending_updates = $false
    } -TimeoutSec 30)
    Add-Line "Webhook cleared without dropping pending updates."
}
catch {
    Add-Line "WARN deleteWebhook failed: $($_.Exception.Message)"
}

Add-Line "Waiting up to 25 seconds for a Telegram text message. Send a normal message to @$($Bot.username) now."

try {
    $Updates = Invoke-Telegram -Method "getUpdates" -Payload @{ timeout = 25 } -TimeoutSec 35
}
catch {
    Add-Line "FAIL Telegram getUpdates: $($_.Exception.Message)"
    exit 1
}

if ($null -eq $Updates -or @($Updates).Count -eq 0) {
    Add-Line "FAIL: no Telegram update received. Close running bot windows, message the exact bot, then rerun E2E_CHECK.cmd."
    exit 1
}

$Last = @($Updates) | Select-Object -Last 1
$Message = $Last.message
if ($null -eq $Message) {
    $Message = $Last.edited_message
}
if ($null -eq $Message -or $null -eq $Message.chat -or [string]::IsNullOrWhiteSpace([string]$Message.text)) {
    Add-Line "FAIL: latest update has no text message."
    exit 1
}

$ChatId = [long]$Message.chat.id
$Prompt = [string]$Message.text
Add-Line "Telegram update OK: chat_id=$ChatId text=$Prompt"

try {
    [void](Invoke-Telegram -Method "sendMessage" -Payload @{
        chat_id = $ChatId
        text = "E2E Telegram sendMessage OK. Testing AI now..."
    } -TimeoutSec 30)
    Add-Line "Telegram sendMessage OK"
}
catch {
    Add-Line "FAIL Telegram sendMessage: $($_.Exception.Message)"
    exit 1
}

try {
    [void](Invoke-Telegram -Method "sendChatAction" -Payload @{
        chat_id = $ChatId
        action = "typing"
    } -TimeoutSec 15)
}
catch {
    Add-Line "WARN sendChatAction failed: $($_.Exception.Message)"
}

try {
    $Reply = Invoke-Ai $Prompt
    Add-Line "AI reply text: $Reply"
}
catch {
    Add-Line "FAIL AI: $($_.Exception.Message)"
    exit 1
}

try {
    [void](Invoke-Telegram -Method "sendMessage" -Payload @{
        chat_id = $ChatId
        text = $Reply
    } -TimeoutSec 30)
    Add-Line "E2E PASS: AI reply sent to Telegram."
}
catch {
    Add-Line "FAIL sending AI reply to Telegram: $($_.Exception.Message)"
    exit 1
}

try {
    [void](Invoke-Telegram -Method "getUpdates" -Payload @{
        offset = ([long]$Last.update_id + 1)
        timeout = 0
    } -TimeoutSec 15)
}
catch {
    Add-Line "WARN clearing processed update failed: $($_.Exception.Message)"
}

Add-Line ""
Add-Line "Report written to: $ReportPath"
