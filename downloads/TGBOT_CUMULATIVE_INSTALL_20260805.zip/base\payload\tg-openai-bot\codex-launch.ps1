﻿$ErrorActionPreference='Stop'
$userHome=[Environment]::GetFolderPath('UserProfile')
$env:CODEX_HOME=Join-Path $userHome '.codex-api2'
$credential=Join-Path $env:CODEX_HOME 'secrets\mcdesign-api-key.clixml'
if(Test-Path $credential){
    $secure=Import-Clixml -LiteralPath $credential
    $env:API2_KEY=[System.Net.NetworkCredential]::new('', $secure).Password
}
$savedBaseUrl=[Environment]::GetEnvironmentVariable('OPENAI_BASE_URL','User')
$savedApiKey=[Environment]::GetEnvironmentVariable('API2_KEY','User')
if(-not [string]::IsNullOrWhiteSpace($savedBaseUrl)){$env:OPENAI_BASE_URL=$savedBaseUrl}
if(-not [string]::IsNullOrWhiteSpace($savedApiKey)){$env:API2_KEY=$savedApiKey}
$shimPaths = @(
    (Join-Path (Split-Path -Parent $PSCommandPath) 'codex.cmd'),
    (Join-Path $userHome 'bin\codex.cmd'),
    (Join-Path $userHome 'tg-openai-bot\codex.cmd'),
    (Join-Path $userHome 'tg-openai-bot\codex.ps1')
)
function Refresh-Path { $env:Path = "$( [Environment]::GetEnvironmentVariable('Path','User') );$( [Environment]::GetEnvironmentVariable('Path','Machine') )" }
function Ensure-Npm {
    $portableNodeDir=Join-Path $env:LOCALAPPDATA 'Programs\TGBOT\node-v22.22.3-win-x64'
    if(Test-Path -LiteralPath $portableNodeDir){Get-ChildItem -LiteralPath $portableNodeDir -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue}
    Refresh-Path
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if($npm){return $npm}
    $runtimeRoot=Join-Path $env:LOCALAPPDATA 'Programs\TGBOT'
    $nodeDir=Join-Path $runtimeRoot 'node-v22.22.3-win-x64'
    $npmCmd=Join-Path $nodeDir 'npm.cmd'
    if(Test-Path -LiteralPath $npmCmd){
        $userPath=[Environment]::GetEnvironmentVariable('Path','User')
        if(-not (($userPath -split ';') -contains $nodeDir)){[Environment]::SetEnvironmentVariable('Path', "$nodeDir;$userPath", 'User')}
        $env:Path="$nodeDir;$env:Path"
        return [pscustomobject]@{Source=$npmCmd}
    }
    Write-Host 'Node.js/npm not found. Downloading the official portable Node.js ZIP...' -ForegroundColor Yellow
    $dir=Join-Path $env:TEMP 'tgbot-node'; New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $nodeZip=Join-Path $dir "node-v22.22.3-win-x64-$PID.zip"
    Invoke-WebRequest -Uri 'https://nodejs.org/dist/v22.22.3/node-v22.22.3-win-x64.zip' -OutFile $nodeZip -UseBasicParsing -TimeoutSec 300
    if((Get-Item -LiteralPath $nodeZip).Length -lt 1MB){throw 'Node.js portable ZIP is incomplete.'}
    Unblock-File -LiteralPath $nodeZip -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $runtimeRoot -Force | Out-Null
    Expand-Archive -LiteralPath $nodeZip -DestinationPath $runtimeRoot -Force
    if(-not (Test-Path -LiteralPath $npmCmd)){throw 'Portable Node.js extraction completed but npm.cmd is missing.'}
    Get-ChildItem -LiteralPath $nodeDir -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    $userPath=[Environment]::GetEnvironmentVariable('Path','User')
    if(-not (($userPath -split ';') -contains $nodeDir)){[Environment]::SetEnvironmentVariable('Path', "$nodeDir;$userPath", 'User')}
    $env:Path="$nodeDir;$env:Path"
    return [pscustomobject]@{Source=$npmCmd}
}
function Invoke-NpmInstallWithTimeout([string]$NpmPath) {
    $job=$null
    try {
        Write-Host 'Installing Codex CLI from npm (maximum wait: 10 minutes)...' -ForegroundColor Yellow
        $job=Start-Job -ScriptBlock {
            param($commandPath)
            $output=& $commandPath install -g '@openai/codex' --no-fund --no-audit --loglevel=notice 2>&1 | Out-String
            [pscustomobject]@{ExitCode=$LASTEXITCODE;Output=$output}
        } -ArgumentList $NpmPath
        $timer=[Diagnostics.Stopwatch]::StartNew()
        while(-not (Wait-Job -Job $job -Timeout 15)){
            $elapsed=[int]$timer.Elapsed.TotalSeconds
            if($elapsed -ge 600){Stop-Job -Job $job -ErrorAction SilentlyContinue; throw 'Codex CLI npm installation timed out after 10 minutes.'}
            Write-Host "Codex CLI installation is still running ($elapsed / 600 seconds)..." -ForegroundColor DarkGray
        }
        $result=Receive-Job -Job $job
        if(-not [string]::IsNullOrWhiteSpace([string]$result.Output)){Write-Host ([string]$result.Output).Trim()}
        if($result.ExitCode -ne 0){throw "@openai/codex installation failed with exit code $($result.ExitCode)."}
    } finally {if($job){Remove-Job -Job $job -Force -ErrorAction SilentlyContinue}}
}
function Find-RealCodex {
    $candidates = @()
    $found = Get-Command codex.cmd,codex.exe,codex.ps1 -All -ErrorAction SilentlyContinue
    $candidates += @($found | ForEach-Object { $_.Source })
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if($npm){
        $npmDir=Split-Path -Parent $npm.Source
        $candidates += (Join-Path $npmDir 'codex.cmd'), (Join-Path $npmDir 'codex.ps1'), (Join-Path $npmDir 'codex.exe')
    }
    $candidates += (Join-Path $env:APPDATA 'npm\codex.cmd'), (Join-Path $env:APPDATA 'npm\codex.ps1'), (Join-Path $env:APPDATA 'npm\codex.exe')
    foreach($path in ($candidates | Where-Object { $_ } | Select-Object -Unique)){
        if((Test-Path -LiteralPath $path) -and ($shimPaths -notcontains $path)){ return (Get-Item -LiteralPath $path) }
    }
    return $null
}
function Find-Npx {
    $npx=Get-Command npx.cmd -ErrorAction SilentlyContinue
    if($npx){return $npx}
    $npm=Get-Command npm.cmd -ErrorAction SilentlyContinue
    if($npm){
        $candidate=Join-Path (Split-Path -Parent $npm.Source) 'npx.cmd'
        if(Test-Path -LiteralPath $candidate){return (Get-Item -LiteralPath $candidate)}
    }
    return $null
}
$real = Find-RealCodex
if(-not $real){
    $npm = Ensure-Npm
    Invoke-NpmInstallWithTimeout $npm.Source
    Refresh-Path
    $real = Find-RealCodex
}
if($real){
    & $real.FullName @args
    exit $LASTEXITCODE
}
$npx=Find-Npx
if($npx){
    & $npx.FullName --yes '@openai/codex' @args
    exit $LASTEXITCODE
}
throw 'Codex CLI unavailable. Node.js/npm is missing or @openai/codex could not be installed.'
