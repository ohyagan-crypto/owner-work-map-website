# 新橋接端建立流程

這份文件給另一個 Codex 或伺服器使用，用來建立新的 Telegram 橋接端。所有密鑰都要由使用者在目標環境自行填入，不要從舊環境複製。

## 目標

建立一個新的 Telegram 橋接端，具備：

- Telegram 收發文字、圖片、影片、音訊與文件。
- 每個任務建立工作資料夾，保存提示、結果、紀錄與附件。
- 呼叫 Codex 處理任務。
- 使用繁體中文與台灣自然口語回覆。
- 支援任務索引、檔案搜尋、近期記憶與每日摘要。
- 支援日後新增技能包。

## 建議路徑

```bash
BRIDGE_DIR=/root/customer-telegram-bot
TASK_ROOT=/root/.config/MiniNewTelegram/tasks
CODEX_HOME=/root/.codex
```

若是新客戶或第二套環境，可改成：

```bash
BRIDGE_DIR=/root/mininew-telegram-bridge
TASK_ROOT=/root/.config/MiniNewTelegram/tasks
CODEX_HOME=/root/.codex
```

## 系統套件

Ubuntu / Debian 建議先安裝：

```bash
apt-get update
apt-get install -y python3 python3-pip python3-venv git curl jq ffmpeg imagemagick fonts-noto-cjk sox libass9 tesseract-ocr
```

如果需要網頁自動化或 NotebookLM 類工作，再補：

```bash
apt-get install -y nodejs npm
```

## 複製橋接端

如果來源環境已有 `/root/customer-telegram-bot`，可複製非機密檔案到目標環境。

不要複製：

- `.env`
- `.env.bak_*`
- `logs/`
- `runtime/` 裡可能含有測試輸出或暫存資料
- 任何 token、cookie、OAuth token、瀏覽器登入資料

可以複製：

- `app/`
- `scripts/`
- `systemd/`
- `docs/`
- `requirements.txt`
- `.env.example`
- `README.md`

## 建立環境

```bash
cd "$BRIDGE_DIR"
bash scripts/install.sh
```

若沒有 `.env`，用範本建立：

```bash
cp .env.example .env
nano .env
```

必要設定：

```env
TELEGRAM_BOT_TOKEN=[REDACTED_SECRET] BotFather 取得，請在目標環境自行填入
ALLOWED_CHAT_IDS=只允許的 Telegram chat id，可逗號分隔
CODEX_BINARY=codex
CODEX_WORKDIR=/root
CODEX_TIMEOUT_SECONDS=900
CODEX_TASK_ROOT=/root/.config/MiniNewTelegram/tasks
CODEX_EXTRA_ARGS=--dangerously-bypass-approvals-and-sandbox
MEMORY_PATHS=/root/customer-telegram-bot/docs/mininew_bridge_memory_zh.md
BOT_NAME=微新助理（森）
SYSTEM_PROMPT=你是微新助理（森）。固定使用繁體中文與台灣自然口語。不要輸出英文系統狀態、工具日誌或內部訊息。
```

`TELEGRAM_BOT_TOKEN` 與 `ALLOWED_CHAT_IDS` 不可寫入技能包或交接文件。

## 安裝技能

把技能資料夾放到：

```bash
$CODEX_HOME/skills/<skill-name>
```

例如：

```bash
mkdir -p /root/.codex/skills
cp -a mininew-bridge-handoff /root/.codex/skills/
```

如果還要裝 NBS：

```bash
cp -a nbs-skill /root/.codex/skills/
```

完成後重新啟動橋接端或 Codex 相關服務，讓技能 metadata 重新載入。

## 檢查

```bash
cd "$BRIDGE_DIR"
bash scripts/check.sh
```

手動啟動：

```bash
bash scripts/run.sh
```

健康檢查：

```bash
curl http://127.0.0.1:8088/healthz
```

## systemd

系統服務範例：

```bash
cp systemd/mininew-telegram-bridge.service /etc/systemd/system/mininew-telegram-bridge.service
systemctl daemon-reload
systemctl enable --now mininew-telegram-bridge.service
systemctl status mininew-telegram-bridge.service --no-pager
```

看紀錄：

```bash
journalctl -u mininew-telegram-bridge.service -f
tail -f "$BRIDGE_DIR/logs/bot.log"
```

若使用 user service，改放：

```bash
/root/.config/systemd/user/
```

並使用：

```bash
systemctl --user daemon-reload
systemctl --user enable --now mininew-telegram-bridge.service
```

## Telegram 測試

至少測：

1. 傳「你好」：應回繁體中文自然口語。
2. 傳圖片或影片：應能下載附件到 task root。
3. 傳一個小任務：應建立新的任務資料夾。
4. 傳 `/healthz` 或查健康端點：服務應正常。
5. 傳 `/recent`、`/files`：若索引功能啟用，應能列出近期任務或檔案。

## 常見阻塞

- Telegram 沒反應：檢查 token、網路、polling 是否被另一個服務佔用。
- 只有英文錯誤：檢查 SYSTEM_PROMPT 與橋接端錯誤轉中文邏輯。
- Codex 沒跑：檢查 `CODEX_BINARY`、PATH、權限與 timeout。
- 附件太大：調整 `MAX_ATTACHMENT_MB`，或請使用者分段上傳。
- 登入或驗證：停止，請使用者親自操作，不保存登入資訊。

