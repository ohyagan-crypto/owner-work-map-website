# CLS Claude Analysis Skill

Created: 2026-06-27

Owner rule:

- The Claude 4.8+ analysis workflow is named `cls`.
- When the owner says `cls`, or asks for Claude analysis for scripts, screenplays, video shooting plans, short-video plans, storyboards, SD/SDF/SDV/Dreamina preparation, prompt planning, or material lists, use the installed skill `C:\Users\你的使用者名稱\.codex\skills\cls\SKILL.md`.
- `cls` means: first use the aggregation platform `https://lx.lanxinai.com/` AI chat with the highest available Claude model, at least Claude 4.8 or newer, preferably `claude-opus-4-8` or newer.
- For SD/Dreamina tasks, use `cls` to analyze story/content, shot needs, material list, character references, audio/dialogue needs, aspect ratio, duration, and prompt structure, then return a confirmation checklist before any credit-consuming generation.
- If the aggregation platform or Claude 4.8+ model is unavailable, report the exact blocker in clean Traditional Chinese and provide a local backup draft when possible.

Execution notes:

- Keep owner-facing replies clean Traditional Chinese.
- Do not expose internal browser/tool/session/debug/log details.
- Do not include passwords, tokens, cookies, API keys, or other secrets in memory or replies.
