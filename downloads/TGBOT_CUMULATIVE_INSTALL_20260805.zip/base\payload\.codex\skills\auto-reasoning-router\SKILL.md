---
name: auto-reasoning-router
description: Route Telegram/Codex requests to the appropriate reasoning effort. Use when deciding whether a request should run fast with low reasoning for daily chat, lookup, translation, summaries, and simple answers, or with xhigh reasoning for skill creation/update, coding, website work, debugging, deployment, automation, file operations, image/video workflows, and multi-step tasks.
---

# Auto Reasoning Router

Choose the reasoning effort before launching Codex work. Prefer speed for simple conversational tasks and reliability for work that changes files, uses skills, or may affect user deliverables.

## Routing

Use `low` for:

- Daily chat, greetings, quick explanations, and simple Q&A.
- Search or lookup style answers when no file edits, deployments, or long analysis are required.
- Translation, wording polish, short summaries, and simple comparisons.
- Model/status questions that only need local configuration observation.

Use `xhigh` for:

- Creating, updating, installing, packaging, reading, or applying skills, memories, workflows, or handoff packs.
- Coding, repo inspection, tests, refactors, fixes, debugging, errors, logs, and command execution.
- Website/app/game build, update, deployment, GitHub Pages, domain, hosting, or public URL work.
- File-producing tasks: images, posters, videos, audio, PDFs, PPTX, ZIPs, screenshots, generated assets, or Telegram delivery.
- Browser/desktop automation, login/account flows, CapCut/Jianying, NotebookLM, Dreamina, Lanxin, NBS, ACS, NMS, ANS, or other installed skill workflows.
- Multi-step planning where a wrong answer could waste time, cost credits, overwrite files, or break a working setup.

If both simple-answer and work-execution signals appear, choose `xhigh`.

## Telegram Behavior

Do not expose routing labels, internal configuration, command arguments, or diagnostic logs to Telegram users unless they explicitly ask about model or reasoning settings. Final replies stay in clean Traditional Chinese.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














