# 新客戶 Codex / Telegram BOT 基礎設定 V0

用途：把目前這個 Codex 帳號實作過的穩定做法，整理成新客戶 BOT 安裝後的基礎規格。目標是避免英文錯誤外露、避免無限循環、長任務不中斷回報、影片剪輯能直接處理繁中字幕與右上角品牌。

> 注意：本文件不要放任何真實 Token、API Key、顧客個資。交付時只給欄位名稱與設定方式。

## 1. 基本原則

- 全程使用繁體中文與台灣用語回覆。
- 使用者要求影片、圖片、OCR、下載、安裝、轉檔、上傳、模型處理等長任務時，必須先回報「目前正在做什麼」。
- 超過 30 秒仍未完成時，必須再次回報是否正常或卡住。
- 若 Telegram 沒有顯示中途進度，必須用外部進度工具補送訊息，例如 `/root/bin/tg_progress.py "目前正在..."`。
- 不讓英文技術錯誤直接丟給客戶，要翻成中文，例如 timeout、stream disconnected、upstream failed、502、token missing。
- 不要無限重試。相同錯誤連續發生 2 到 3 次，要停止、說明狀況、改做待處理事項或請使用者確認。
- 同一個聊天室一次只處理一個任務。忙碌時不要排無限隊列，要用中文告知「目前正在處理上一個請求」。

## 2. 建議伺服器環境

建議：Ubuntu 24.04 或相近版本，root 或具 sudo 權限。

目前已使用到的核心工具：

```bash
apt update
apt install -y \
  ffmpeg imagemagick \
  python3 python3-pip python3-venv python3-dev \
  nodejs npm git curl jq \
  fonts-noto-cjk fonts-noto-color-emoji fonts-noto-core \
  tesseract-ocr tesseract-ocr-chi-tra tesseract-ocr-chi-sim tesseract-ocr-eng \
  libass9 librubberband2 sox libsox-fmt-base
```

用途：

- `ffmpeg / ffprobe`：影片剪輯、燒字幕、疊貼圖、抽音訊、音量檢查。
- `libass9`：ASS 特效字幕渲染。
- `fonts-noto-cjk`：繁體中文字型，避免字幕缺字。
- `imagemagick`：圖片處理、格式轉換。
- `tesseract-ocr`：圖片文字辨識，支援繁中、簡中、英文。
- `python3 / pip / venv`：BOT、字幕、Logo、影片輔助腳本。
- `node/npm`：Codex / OpenClaw / 前端工具使用。
- `curl / jq`：Telegram API、健康檢查、JSON 處理。
- `git`：版本管理與部署。

## 3. Python 套件

建議建立專用 venv：

```bash
python3 -m venv /root/.venvs/customer-bot
source /root/.venvs/customer-bot/bin/activate
pip install -U pip
pip install requests httpx python-dotenv pillow numpy faster-whisper rembg python-pptx xlsxwriter
```

目前實際用到：

- `requests`：Telegram 上傳影片、圖片、文件。
- `httpx`：Telegram BOT 模板呼叫 AI API。
- `python-dotenv`：讀 `.env`。
- `Pillow`：Logo、貼圖、透明 PNG、總覽圖製作。
- `numpy`：影像與音訊輔助處理。
- `faster-whisper`：影片語音轉文字，產生字幕初稿。
- `rembg`：圖片去背。
- `python-pptx`：簡報製作。
- `xlsxwriter`：Excel 匯出。

可選安裝：

```bash
pip install pydub moviepy opencv-python openai python-telegram-bot yt-dlp
```

目前這台沒有強依賴 `moviepy/openai/python-telegram-bot/whisper`，主要靠 `ffmpeg + faster-whisper + requests`。

## 4. Codex 設定

參考 `/root/.codex/config.toml`：

```toml
approval_policy = "never"
sandbox_mode = "danger-full-access"

[projects."/root"]
trust_level = "trusted"
```

說明：

- `approval_policy = never`：BOT 自動任務不要一直要求人工批准。
- `sandbox_mode = danger-full-access`：允許讀寫檔案、處理影片、上傳 Telegram。
- 實務上要搭配嚴格規則：不能刪除不確定檔案、不能外洩 token、不能做破壞性命令。

## 5. Telegram 設定檔

目前使用 `/root/appsettings.Local.json`，不要直接複製真實 token。新客戶可使用這個結構：

```json
{
  "TelegramBot": {
    "Token": "填入 BotFather 給的 token",
    "Enabled": true,
    "AllowedUserIds": [123456789]
  },
  "CodexTelegram": {
    "Context": {
      "DeveloperInstructions": "固定使用繁體中文；長任務要回報進度；不要無限循環。"
    }
  }
}
```

安全要求：

- 每位客戶使用獨立 Telegram Bot Token。
- 每位客戶使用獨立 AI API Key 或獨立額度控管。
- `AllowedUserIds` 不要空白，避免陌生人使用。
- `.env`、`appsettings.Local.json` 不要提交到 GitHub。

## 6. Telegram 進度工具

建立 `/root/bin/tg_progress.py`，用途是在 Codex commentary 沒有正常顯示時，直接補送 Telegram 訊息。

行為：

- 從 `/root/appsettings.Local.json` 讀取 `TelegramBot.Token`。
- 從 `TelegramBot.AllowedUserIds[0]` 取得預設 chat id。
- 呼叫 Telegram `sendMessage`。

使用方式：

```bash
/root/bin/tg_progress.py "目前正在處理影片字幕，流程正常。"
```

規則：

- 長任務開始前先中文回報。
- 30 秒沒有完成要再次回報。
- 使用者說「進度不見了」「又停了」「怎麼沒回報」時，立刻補送目前進度。

## 7. Telegram BOT 模板邏輯

現有模板位置：

- `/root/customer-telegram-bot`
- `/root/telegram-bot-template`

模板核心功能：

- 同一聊天室一次只處理一個請求。
- 忙碌時直接中文告知，不排隊。
- AI timeout 預設 45 秒。
- 502、upstream、timeout、API key 錯誤轉成中文。
- `/healthz` 健康檢查。
- log 自動輪替。
- systemd 啟動範本。

基本安裝：

```bash
cd /root/telegram-bot-template
bash scripts/install.sh
nano .env
bash scripts/check.sh
bash scripts/run.sh
```

`.env` 範例：

```env
TELEGRAM_BOT_TOKEN=[REDACTED_SECRET] token
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=AI API Key
AI_MODEL=gpt-4.1-mini
ALLOWED_CHAT_IDS=123456789
REQUEST_TIMEOUT_SECONDS=45
```

systemd：

```bash
cp systemd/telegram-bot-template.service /root/.config/systemd/user/customer-telegram-bot.service
systemctl --user daemon-reload
systemctl --user enable --now customer-telegram-bot.service
systemctl --user status customer-telegram-bot.service --no-pager
journalctl --user -u customer-telegram-bot.service -f
```

## 8. 英文錯誤中文化對照

- `Thread error`：連線執行緒發生錯誤。
- `Reconnecting... 5/5`：正在重連，第 5 次嘗試。
- `stream disconnected before completion`：回覆還沒完成，串流連線中斷。
- `Upstream request failed`：上游 AI 服務請求失敗。
- `timeout`：服務回應太久，已停止這次請求。
- `502 / 503`：上游服務暫時不可用。
- `token missing`：Telegram 或 AI 金鑰未設定。

客戶端顯示建議：

```text
目前 AI 服務連線不穩，這次請求已停止。請稍後再試一次，我不會繼續無限重跑。
```

## 9. 避免無限循環規則

必須寫入 BOT 與 Codex 行為規範：

- 同一動作失敗 2 次：改方法或縮小範圍。
- 同一錯誤失敗 3 次：停止處理，列入待處理事項，回報原因。
- 不要在使用者不在線時持續重試下載、安裝、上傳、模型生成。
- 長任務若超過預估時間，先輸出半成品或進度摘要。
- 影片剪輯若某一步失敗，不要從頭無限重跑，保留中間檔並從失敗點接續。

建議回覆：

```text
這一步已連續失敗 3 次，我先停止避免浪費算力。已保留目前檔案，待處理事項是：重新確認來源檔或改用較小模型。
```

## 10. 使用者語氣與用語習慣

固定：

- 使用繁體中文。
- 使用台灣用語：影片、字幕、貼圖、特效、音樂、下載、上傳、檔案、伺服器。
- 回覆要直接、實用，不要過度解釋。
- 使用者常用語要理解：
  - 「剪映」= CapCut。
  - 「不要壓到臉」= 字幕、貼圖、Logo 避開人臉。
  - 「底下要字幕」= 底部繁體中文字幕。
  - 「按照之前風格」= 大重點字、活潑貼圖、右上角品牌、底部字幕。
  - 「不要放背景音樂」= 為了 Facebook 或版權，不加 BGM。
  - 「加 20%」= 背景音樂或音量提高 20%，但不能蓋過人聲。

進度回報口吻：

```text
我正在抓影片字幕，完成後會先檢查有沒有漏字。
目前影片正在合成，流程正常，等輸出後我會抓圖看有沒有壓到臉。
這一步比預期久，但沒有卡住，正在上傳 Telegram。
```

## 11. 影片剪輯標準流程

1. 找來源影片。
2. 用 `ffprobe` 確認長度、尺寸、音訊軌。
3. 用 `faster-whisper` 轉文字。
4. 人工修正專有名詞，例如：`廣生堂`、`聖騏`、`庫里老師`、`藍星科技`、`微新國際`。
5. 產生 ASS 字幕：
   - 底部繁體中文字幕。
   - 重點字大字特效。
   - 紅底白字、紅字白邊、黃字紅邊、粉紅泡泡字。
6. 疊貼圖：OpenMoji 或自製透明 PNG。
7. 疊右上角品牌：Logo + 微新國際。
8. 若需要，降噪、保留人聲、不加背景音樂。
9. 輸出 MP4。
10. 抓 4 到 8 張關鍵畫面檢查：
    - 字幕有沒有漏。
    - 重點字有沒有壓臉。
    - 貼圖有沒有壓臉。
    - Logo 是否太大或太小。
    - 音訊是否存在。
11. Telegram 傳兩份：
    - `sendVideo` 預覽。
    - `sendDocument` 原始檔下載版。

## 12. 影片常用 ffmpeg 指令

檢查影片：

```bash
ffprobe -v error -show_entries format=duration,size:stream=index,codec_type,codec_name,width,height -of default=noprint_wrappers=1 input.mp4
```

音量檢查：

```bash
ffmpeg -hide_banner -i input.mp4 -af volumedetect -f null -
```

抽音訊：

```bash
ffmpeg -y -i input.mp4 -vn -ac 1 -ar 16000 audio.wav
```

燒 ASS 字幕：

```bash
ffmpeg -y -i input.mp4 -vf "subtitles=subtitles.ass" -c:v libx264 -preset veryfast -crf 20 -c:a copy -movflags +faststart output.mp4
```

抓預覽圖：

```bash
ffmpeg -y -ss 00:00:10 -i output.mp4 -frames:v 1 -update 1 preview.jpg
```

## 13. 字幕與特效標準

底部字幕：

- 白字黑邊。
- 位置在底部，但不要太貼底。
- 字幕不能漏掉「好、可以、各位好」這類互動短句。

重點字：

- 9:16 影片要夠大。
- 常用風格：
  - 紅底白字。
  - 紅字白粗邊。
  - 黃字紅邊。
  - 粉紅泡泡字。
- 重點字優先放上方空白、牆面、桌面空白區。
- 不能蓋人臉。
- 介紹人物時，重點字盡量靠近人物附近但不遮臉。

## 14. 右上角品牌 Logo

目前標準：

- 右上角固定顯示。
- 使用「MINI NEW Logo + 微新國際」。
- Logo 在前，文字在後。
- 文字要夠大，手機看得到。
- 可用白底透明 PNG，避免亮背景看不清。

目前已做過的品牌檔案範例：

- `/root/Downloads/codex_video_output/20260605_happy_lively_new/mininew_brand_attached_logo_big.png`
- `/root/Downloads/codex_video_output/weixin_logo_variants/`

## 15. 貼圖素材與版權

目前使用過：OpenMoji 貼圖元素。

位置：

- `/root/Downloads/codex_video_output/20260605_latest_clean/elements_downloaded/`

檔案：

- `sparkles.png`
- `thumbs_up.png`
- `fire.png`
- `star.png`
- `heart.png`
- `pushpin.png`

授權紀錄：

- `elements_license.txt`
- OpenMoji，CC BY-SA 4.0。

規則：

- 貼圖可以活潑，但不能太雜亂。
- 使用者要求「更活潑」時可以增加貼圖數量與大小。
- 人物介紹時，貼圖靠近人物附近，但避開臉。

## 16. 音樂與音訊

規則：

- Facebook 影片若使用者說不要背景音樂，就不要加 BGM。
- 若加音樂，優先使用可商用、免版權或自製簡單 BGM。
- 人聲永遠優先，音樂不可蓋過人聲。
- 使用者說「加 20%」時，音樂音量提高，但要檢查人聲清楚。
- 使用者要求「環境音降噪」時，保留人聲、降低背景雜音。

常用檢查：

```bash
ffmpeg -hide_banner -i output.mp4 -af volumedetect -f null -
```

## 17. OCR / 附圖文字

使用者常問「為何無法讀附圖文字」。新 BOT 要具備：

- 能使用視覺模型讀圖。
- 需要本機 OCR 時使用 tesseract：

```bash
tesseract image.png stdout -l chi_tra+eng
```

若圖片模糊，要回覆：

```text
這張圖文字解析度不足，我可以先嘗試放大銳化再 OCR，但可能需要你補一張較清楚的圖。
```

## 18. 檔案管理與清理

建議固定工作目錄：

```text
/root/Downloads/codex_video_output/YYYYMMDD_task_name/
```

每個任務保留：

- 原始轉錄 JSON。
- ASS 字幕檔。
- 最終 MP4。
- 代表性預覽圖。
- 授權紀錄。

可刪除：

- 中間暫存影格。
- 失敗輸出檔。
- 重複版本。
- 已上傳且確認不用的舊壓縮檔。

不可刪除：

- 原始上傳附件。
- 最終輸出影片。
- Logo、品牌素材。
- 授權檔。
- 設定檔與 Token 檔。

## 19. 新客戶交付檢查表

- [ ] Ubuntu 套件安裝完成。
- [ ] Python venv 建立完成。
- [ ] `ffmpeg` 可用。
- [ ] `faster_whisper` 可用。
- [ ] Noto CJK 字型已安裝。
- [ ] Telegram Bot Token 已填入。
- [ ] `AllowedUserIds` 已設定。
- [ ] `/root/bin/tg_progress.py` 可發訊息。
- [ ] BOT 忙碌時不排隊。
- [ ] timeout 與 upstream 錯誤會中文化。
- [ ] 長任務每 30 秒回報。
- [ ] 測試影片可輸出底部繁中字幕。
- [ ] 測試 Telegram 可傳 `sendVideo` 與 `sendDocument`。
- [ ] Logo 素材已放到固定資料夾。
- [ ] 已建立工作目錄命名規則。

## 20. 建議給新客戶的預設說明

```text
這個 BOT 會用繁體中文處理你的請求。影片、圖片、字幕、下載、上傳等任務可能需要一點時間，我會在處理中回報進度。若同一個步驟連續失敗，我會停止重試並說明原因，避免無限消耗資源。
```
