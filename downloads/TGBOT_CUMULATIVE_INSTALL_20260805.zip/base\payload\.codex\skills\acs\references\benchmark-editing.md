# ACS Benchmark Editing Guide

Use this file when the user asks for 對標剪輯, wants to imitate a reference video, or provides a reference style.

## What To Extract From A Reference

- Hook: first 1-3 seconds, exact viewer promise, visual surprise, text on screen.
- Structure: opening, proof/value section, demonstration, emotional lift, CTA.
- Cut rhythm: average shot duration, fast/medium/slow pacing, where jump cuts happen.
- Visual language: framing, camera movement, zooms, overlays, color palette, filters.
- Captions: font weight, placement, line length, highlight words, emoji/sticker usage.
- Audio: music genre, volume relationship, SFX points, silence or beat drops.
- Transitions: hard cuts, motion blur, zoom, swipe, glitch, mask, match cuts.
- B-roll: what each B-roll shot proves, not just what it shows.
- CTA: final sentence, visual button/QR/action cue.

## Copy Strategy

Do not copy assets or copyrighted footage. Copy structure and editing grammar:

- Same rhythm, different material.
- Same caption logic, new copy.
- Same hook type, user-specific wording.
- Same CTA pattern, user-specific conversion action.

## Analysis Output

```text
主人，ACS 對標分析：
1. 對標核心：
2. 開場鉤子：
3. 節奏：
4. 分鏡/畫面：
5. 字幕：
6. 音樂/音效：
7. 轉場/特效：
8. CTA：
9. 可複製剪輯方案：
10. 需要主人補充：
```

## Edit Translation

Turn benchmark findings into an edit spec:

- Hook finding -> first timeline scene.
- Rhythm finding -> scene duration values.
- Caption finding -> `captions` and timeline `caption`.
- B-roll finding -> `assets.videos/images` mapping.
- Music finding -> `music` plus audio notes.
- CTA finding -> final scene and export caption.

## Quality Gate

Before export, verify:

- The first 3 seconds communicate the core promise.
- Captions do not cover faces, product, QR codes, or important UI.
- Scene duration matches the reference rhythm.
- The CTA is visible and readable.
- Music does not overpower speech.
- Output ratio matches target platform.
## Operator Tutorial Flow 2026-06-05

For the operator's preferred benchmark replication process, also read:

`references/operator-short-video-tutorial-20260605.md`
