---
name: cmsd
description: Use when the owner says cmsd, cmde, or asks for the Claude-script-to-IMS-storyboard-to-SD-video workflow. This skill coordinates owner material/copy analysis through aggregation-platform Claude Opus 4.8 first, then IMS 3x3 storyboard image generation, then SD/Dreamina/Seedance video generation from the storyboard with an explicit confirmation checklist before video generation.
---
## 2026-07-09 Lanxi / Kuli Reference Upload Correction

Owner correction: `cmsdw`, `cmdsw`, `cmsd`, `cmde`, IMS storyboard, SD, SDF, SDV, Dreamina, or Seedance tasks that mention `嵐熙` and `庫裡` must upload the actual character reference images as generation references. It is not enough to write their names or appearance in the prompt.

Hard rules:

1. If the task mentions `嵐熙` and asks for an image storyboard, IMS storyboard, SD video, SDF video, SDV video, Dreamina, or Seedance generation, upload `C:\Users\max\lanxi_new.png` as the Lanxi visual reference.
2. If the task mentions `庫裡` and asks for an image storyboard, IMS storyboard, SD video, SDF video, SDV video, Dreamina, or Seedance generation, upload the correct Kuli visual reference as a generation reference. The expected fixed path is `C:\Users\max\kuli.jpg` only if it has been verified as the correct Kuli image for the current task.
3. Owner correction on 2026-07-16: the black hoodie / orange drawstrings / peeled banana image is the confirmed Kuli identity reference. Use `C:\Users\max\kuli.jpg` unless the owner provides a newer replacement.
4. For Lanxi + Kuli dialogue or lip-sync video tasks, upload `C:\Users\max\lanxi_kuli_dialogue_ref.mp3` as the preferred combined dialogue/audio reference unless the owner provides a new task-specific audio file.
5. The Claude analysis must explicitly mark Lanxi and Kuli as named fixed characters and list the exact reference files that will be uploaded.
6. The IMS storyboard prompt and Blue Star/aggregation image submission must include the actual character images as references, not only text descriptions.
7. The SD/Dreamina/Seedance confirmation checklist must list `角色形象` and `角色音檔` with exact files, and the actual video submission must include those files as `--image` / reference media when the route supports it.
8. If the platform route cannot upload all required references in one submission, report the exact limitation and choose a safe batching or route adjustment. Do not silently omit Lanxi or Kuli references.

## 2026-07-09 Owner Workflow Adjustment

When the owner gives an SD video topic or multiple materials and asks to use the CMSD/CMD SW workflow, follow this exact order:

1. Source intake: accept the owner's SD video topic, script, copy, or multiple materials as the current isolated task. Do not mix older task materials unless the owner explicitly says to reuse them.
2. Claude analysis: send the current task materials to the aggregation platform using Claude Opus 4.8, or the highest available Claude Opus 4.8+ model. This analysis must produce story logic, character settings, scene order, camera rhythm, key text, compliance risks, and storyboard requirements.
3. Storyboard generation: after Claude analysis, use the aggregation/Blue Star image route to create the matching 3x3 storyboard material image. In this CMSD workflow, the storyboard image step is treated as owner-authorized once the materials are sufficient; do not ask for a second confirmation before generating the storyboard unless a required source is missing or a real external blocker exists.
4. Universal SD prompt: combine the Claude analysis, the generated 3x3 storyboard image, and the owner's latest requirements into the universal SD prompt. The prompt must preserve the owner's topic, characters, wording, duration, ratio, product priorities, language, and latest corrections.
5. SD confirmation checklist: present the final SD checklist to the owner before any credit-consuming SD/Dreamina/Seedance generation. The checklist must include video model, ratio, duration, character image, character audio, storyboard material image, full story prompt, universal prompt imported status, route, account/credits when available, expected cost, risks, and delivery method.
6. Owner confirmation gate: only after the owner replies "確認", "可以", "好", "送出", or an equivalent explicit confirmation for the SD video may the SD/Dreamina/Seedance generation be submitted. If the owner changes specifications, return to the SD checklist step and re-issue the updated checklist.
7. Submit once: after SD confirmation, submit exactly according to the confirmed route and model. Do not switch models, rewrite the story, re-run Claude, or regenerate the storyboard unless the owner changes requirements or a real platform blocker requires a corrected route.
8. Download and validate: after generation, download the original video and verify the file exists, format is readable, duration, ratio, resolution, audio/subtitle requirements, and main content match the confirmed checklist. A generated/queued/visible result is not completion.
9. Telegram delivery: for Telegram-origin tasks, return the verified final file only to the same originating Telegram chat/thread by document mode. Local paths are backup only when Telegram delivery is blocked.

Owner-facing explanation should describe this as:
`主題/素材 -> Claude Opus 4.8 分析 -> 9 宮格分鏡素材圖 -> 萬用 SD 提示詞 + 確認清單 -> 主人確認 -> 提交生成 -> 下載驗證 -> 同源 Telegram 文件交付`.

## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# CMSD - Claude 劇本到分鏡圖再到 SD 影片

更新日期：2026-07-07

`cmsd` 是主人指定的串接技能名稱；若主人輸入 `cmde` 且內容是 Claude 分析、IMS 分鏡、SD 影片串接，也視為本流程。收到 `cmsd`、`cmde`、Claude 跑劇本後做分鏡圖、分鏡圖再做 SD 影片、劇情分鏡轉 SD 影片，或類似需求時，使用本技能。

## 快速起手與任務隔離

1. 開始時先判斷唯一任務類型：新 CMSD、續做分鏡圖、分鏡圖後做 SD、查狀態、重傳成品，或修正卡點。
2. 開始時先判斷唯一交付物：Claude 分析、分鏡圖 PNG、SD 確認清單、MP4、任務狀態，或 Telegram 回傳結果。
3. 新任務、重做、重開、不要用上一版時，清空上一個劇本、角色、素材、提示詞與工作紀錄脈絡；除非主人明確說沿用、繼續、用上一張或接著做。
4. 若缺劇本、角色圖、指定角色素材、比例、時長、平台或必要音訊會導致明顯做錯，先問一個直接問題；非關鍵資訊使用合理預設並標明。
5. 主人問「好了沒」、「提交了嗎」、「卡住嗎」、「做到哪」時，先查真實狀態：Claude 分析是否完成、分鏡圖是否已生成下載、SD 任務 id 是否存在、MP4 是否可開啟、Telegram 是否已同源回傳；不可用進度句或 CPU 靜止代替判斷。

## 最高流程順序

1. 先用 `cls`：優先透過 CLI 通道呼叫 Claude 4.8+ 分析主人當次提供的素材、圖片、影片、文案或劇本，重新分析故事節奏、角色、場景、情緒、鏡頭、分鏡需求與後續 SD 影片需求；若 CLI 通道不可用，再改用藍星平台 AI 對話的最高可用 Claude 模型。
2. 再用 `ims`：依 Claude Opus 4.8 分析結果與主人原始素材/文案，在藍星平台 IMS 製作 `3x3` 分鏡圖。若主人另有指定格數才改用指定格數；未指定時一律優先 3x3。
3. 分鏡圖完成後用 SD/Dreamina/Seedance：把已完成並交付的 3x3 分鏡圖當成 SD 影片主要參考素材，整理 SD 影片確認清單，等主人再次明確確認後才提交任何會扣點的影片生成。
4. 每次進入 SD 送出前必須給主人確認清單；確認清單通過後才生成影片，且主人回「確認」後不得再二次卡確認。

不可跳過 Claude 劇本分析；不可先做分鏡圖再補 Claude；不可未確認就送出 SD 影片生成。IMS 分鏡圖在 `cmsd` 流程中視為主人已固定授權自動確認，除非缺少必要素材、劇情資訊會導致明顯錯誤，或平台出現登入/扣點/安全卡點。

## 2026-07-07 CMDE/CMSD 優化流程

主人最新指定的標準順序如下，之後優先於舊的彈性格數流程：

1. 先把主人給的素材或文案送到 CLI Claude 4.8+ 通道重新分析；若 CLI 不可用，再送到藍星平台使用 `Claude Opus 4.8` 或更新模型。若兩個通道都沒有 Claude Opus 4.8 或以上，回報精確卡點，不可假裝已分析。
2. Claude 分析必須產出可直接給 IMS 使用的內容：主題、故事線、角色設定、人物一致性需求、場景順序、鏡頭語言、每格畫面重點、字幕/文字風險、後續 SD 影片提示詞骨架。
3. 分析完成後到藍星平台操作 IMS，直接製作 `3x3` 分鏡圖。CMSD/CMDE 內的 IMS 分鏡圖仍視為已由主人固定授權自動確認；只有缺素材、錯角色、登入/點數/安全驗證、付款或平台外部卡點才停下。
4. 分鏡圖下載、驗證、交付後，才把分鏡圖作為參考素材製作 SD 影片確認清單。
5. SD 影片確認清單必須先給主人看，內容至少包含：Claude 分析摘要、3x3 分鏡圖檔案、角色/產品素材、模型路由、秒數、比例、解析度、預估扣點、完整提示詞、精簡版、強化細節版、負面提示詞、已知風險與完成後 Telegram 同源文件交付方式。
6. 主人對 SD 影片回「確認」、「好」、「可以」或等同明確同意後，直接送出 SD 影片生成，不可再回到 Claude 或 IMS 重新確認，除非主人同時提出修改。

## 使用的既有技能

- `cls`：Claude 4.8+ 劇本與影片規劃前置分析。
- `ims`：藍星平台分鏡圖生成與 Telegram 文件交付。
- `dreamina-sd-video-workflow`：SD/Dreamina/Seedance 影片提示詞、查積分、送出、監控、下載與交付。

## CMSD 工作流

### 1. Claude 劇本分析

先收集主人提供的劇本、角色、素材、比例、時長、風格、平台限制與固定人物。若資訊不足但不會造成錯誤，採用合理預設並標明。

Claude 分析要產出：

- 劇情主軸與觀眾理解路徑
- 角色設定、情緒變化與互動關係
- 場景順序與節奏
- 分鏡圖格數建議，例如 3x3、2x3、4x4
- 每格畫面重點、動作、鏡頭、表情、背景與字幕風險
- 後續 SD 影片所需參考素材、音訊、對嘴、比例、時長與提示詞結構

若 CLI 通道、Claude 或藍星平台不可用，回報精確卡點；可提供本機備用草案，但要標明尚未通過 Claude 分析。

### 2. IMS 分鏡圖自動確認

Claude 分析完成後，直接整理 IMS 分鏡圖方案並提交生成，不再等待主人回覆「確認」、「好」、「可以」或「送出」。這個自動確認只適用於 `cmsd` 內的分鏡圖步驟；一般 `ims` 做圖仍要遵守扣點前確認。提交前仍要自行檢查下列項目；若資訊足夠，直接生成、下載、驗證並用 Telegram 文件模式送回同一來源聊天：

- 劇本摘要與 Claude 分析重點
- 分鏡圖格數與每格內容
- 比例與用途，未指定時優先使用 9:16 直式
- 角色參考與固定人物需求
- 風格、色彩、鏡頭語言、文字與敏感資訊風險
- 藍星平台生成方式
- 完整分鏡圖提示詞
- 完成後下載原圖、驗證尺寸與內容、用 Telegram 文件模式送回同一來源聊天

只有在缺少必要素材、劇情資訊互相矛盾、可能生成錯誤人物/品牌/敏感內容，或藍星平台登入、積分、付款、安全驗證等外部卡點時，才停下回報精確卡點。一般 `cmsd` 任務不可再停在 IMS 分鏡圖確認。

### 3. SD 影片確認

分鏡圖生成、下載、驗證、交付後，才進入 SD 影片確認。

SD 確認清單至少包含：

- 已確認使用的分鏡圖檔案
- SD/Dreamina/Seedance 模型與平台
- 目前積分、預估扣點、人民幣價格、台幣估算與生成後剩餘積分
- 影片比例、時長、解析度
- 參考素材：分鏡圖、角色圖、音色音訊或其他素材
- 完整提示詞；不得壓縮、改寫或刪除主人已確認的腳本
- 是否需要對嘴、音訊、字幕或多段拆分
- 完成後下載原始 MP4、驗證時長/尺寸/音訊，並用 Telegram 文件模式送回同一來源聊天

### 3.1 SD 萬用提示詞優化規則

以後所有 `cmsd` 進入 SD/Dreamina/Seedance 影片提示詞整理時，必須自動套用主人指定的萬用詞：`八維鏡頭級高保真 SD 圖像生成萬用詞`。

套用方式：

- 不可壓縮、刪除、改寫主人已確認的劇本、台詞、商品重點或角色設定。
- 在主人原始內容外，補強八個維度：主體、動作、場景、服裝、光線、構圖、風格、細節。
- 人物提示詞要補強臉部一致性、眼神流向、微表情、手部姿勢、身體重心、皮膚質感、服裝皺褶與物理動態。
- 產品或商業畫面要補強材質、反光、邊緣輪廓、使用場景、品牌感、攝影構圖與背景層次。
- 影片提示詞要保留鏡頭時間軸、運鏡、轉場、肢體動態、口型對嘴、台灣華人口音需求、環境音與音效描述。
- 確認清單中的「完整提示詞」需包含：完整 SD 提示詞、精簡版、強化細節版、負面提示詞；若平台只接受單段提示詞，先把完整 SD 提示詞作為送出版本，其他版本保留在確認清單供主人核對。

必須等待主人再次明確確認後，才提交任何 SD/Dreamina/Seedance 生成。

### 3.2 SD 提交與狀態追蹤

1. SD 路由必須依當次需求判斷：Dreamina CLI、New API、或查詢下載既有任務；若主人明確提到 `zz1cc.cc.cd`、New API、`video-ds-2.0-fast`、`video-ds-2.0`，不可硬套 Dreamina CLI。
2. 確認清單通過後要立即提交，不可再回到二次確認；但未收到主人對 SD 的明確確認前，不可提交任何扣點影片生成。
3. Dreamina CLI 同帳號已授權時，先查 `version`、`user_credit`、`list_task --limit=5`；查到 UID、積分與會員狀態就視為登入正常，不可再要求主人重新授權。
4. 登入正常且 SD 已確認時，要直接提交並取得 `submit_id`；不可回到二次授權、二次確認或重新跑 Claude/IMS 規劃。
5. 提交成功必須有任務 id、路由、模型、秒數、比例、解析度、素材、提示詞路徑、積分消耗與下一次檢查時間；沒有任務 id 不算已提交。
6. 等待生成時要查真實任務狀態；CPU 靜止、視窗沒動、指令沒輸出、沒有新檔案，都不能單獨當作完成或停止依據。
7. 完成後下載原始 MP4，檢查可開啟、時長、解析度、檔案大小、主要畫面、音訊或對嘴需求，再同源 Telegram 文件模式回傳。

### 4. 短片輸出校正與小題材節奏

短時長任務，例如主人只說「5 秒鐘 + 主題」時，優先用精簡敘事處理：Claude 分析要抓出可在 5 秒內看懂的主軸，IMS 分鏡圖以 6 格或 3x2 為優先，避免塞入過多支線、字幕或品牌資訊。

若 Dreamina/Seedance 平台實際輸出長於主人指定秒數，例如 5 秒任務輸出成 15 秒版本，先檢查畫面是否完整、無水印、無錯誤人物、無明顯壞幀；若內容正確，允許用本機影片處理把完整內容等比例壓縮到主人指定秒數，再驗證最終 MP4 的時長、尺寸、檔案大小與主要畫面節奏。這是成品時長校正，不是改寫主人提示詞；不得刪改主人已確認的腳本或提示詞。

短片交付回覆要說明是否曾做時長校正，並交代最終秒數、解析度、檔案大小、本機備份路徑與 Telegram 文件模式交付狀態。

## 固定素材與技術規則

可用固定素材：

- 嵐熙角色圖：`C:\Users\max\lanxi_new.png`
- 庫裡角色圖：`C:\Users\max\kuli.jpg`
- 嵐熙音色：`C:\Users\max\lanxi_voice_ref.mp3`
- 庫裡音色：`C:\Users\max\kuli_voice_ref.mp3`
- 嵐熙+庫裡合併台詞音檔：`C:\Users\max\lanxi_kuli_dialogue_ref.mp3`
- Dreamina 指令：`C:\Users\max\dreamina.exe`

嵐熙或庫裡有台詞時，SD/Dreamina/Seedance 送出素材必須優先上傳 `C:\Users\max\lanxi_kuli_dialogue_ref.mp3` 當台詞/對嘴/音訊參考；除非主人在當次任務提供新的替代音檔，否則不要只用舊的單人台詞音檔。

庫裡素材最新校正（2026-07-16）：黑色帽 T、橘色抽繩、手拿剝皮香蕉的圖片已由主人確認為正式庫裡角色圖。使用 `C:\Users\max\kuli.jpg` 作為固定人物參考，除非主人提供更新版本。

嵐熙 + 庫裡台南保養課劇情方向：若主人指定這條故事線，主軸保持「嵐熙與庫裡到台南上課並示範保養產品」，結尾必須包含藍星說出「你知道我是 AI 嗎」。

常用 SD 預設：

- 模型：`seedance2.0fast_vip`
- 比例：`9:16`
- 解析度：`720p`
- 參考模型：全能參考模型 / multimodal2video

這些是預設，不可覆蓋主人明確指定的模型、比例、素材或提示詞。

## Telegram 與交付規則

Telegram 來源任務完成不等於本機有檔案。任何最終分鏡圖、影片、ZIP 或主人明確要求的交付檔，必須使用文件模式送回同一個來源聊天。

只可使用：

`C:\Users\max\tg-openai-bot\tools\send_telegram_document.ps1 -ChatId $env:TELEGRAM_ORIGIN_CHAT_ID`

不可使用預設 chat id、舊 chat id、允許清單或其他 bot。若缺少 `$env:TELEGRAM_ORIGIN_CHAT_ID`，不要上傳；回報本機備份路徑與「缺少來源聊天 id」這個卡點。

本機備份優先放在：

`C:\Users\max\Desktop\榫嶈潶瑷樻喍`

不要主動把內部技能包、工作紀錄包、安裝說明包或維修包送 Telegram；只有主人明確要求打包、匯出或交接時才產生並回傳。一般 CMSD 任務只回傳主人要的分鏡圖、MP4、ZIP 或確認清單。

## 卡點處理

1. 平台、登入、瀏覽器、生成、下載或上傳失敗時，先做可恢復處理：重試、刷新、檢查登入、檢查既有輸出、查任務列表、改用正確路由或重送同一成品。
2. 同一操作失敗兩次後，先查實際本機狀態與任務狀態，不可盲目重跑。
3. 同一外部卡點重複三次後，停止重試並回報：已完成事項、精確卡點、需要主人提供什麼、可用本機備份路徑。
4. 可恢復卡點不算完成；完成必須看到 Claude 分析、分鏡圖檔、任務 id、MP4 檔或 Telegram 回傳成功其中對應的真實狀態。

## 回覆規則

- 使用乾淨繁體中文。
- 結論先講，再補原因、做法、注意事項。
- 可自然使用柔和 emoji，但不要干擾檔案、路徑、網址或卡點。
- 不輸出 raw log、JSON、工具狀態、英文偵錯、token、cookie、密碼、API key 或任何秘密。
- 不用進度句當完成；完成回覆要包含具體結果、交付狀態、檔案/路徑/網址，或精確卡點。

## 一句話標準

`cmsd` 的完成定義是：Claude 已先分析劇本，IMS 分鏡圖已依自動確認規則生成並交付，SD 影片已在主人再次確認後生成、下載、驗證，並回傳到同一個 Telegram 來源聊天；若任何一步不能完成，已回報精確卡點與本機備份路徑。

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->










