---
name: mininew-bridge-handoff
description: Use when setting up, copying, or handing off the MiniNew Telegram Codex bridge to another Codex/tgbot environment, including creating a new bridge instance, installing bundled or future skills, preserving Traditional Chinese/Taiwan assistant behavior, indexing task files, and avoiding secret leakage.
metadata:
  short-description: MiniNew Telegram bridge setup and skill handoff
---

# MiniNew Bridge Handoff

Use this skill when the user wants a new MiniNew Telegram bridge, wants to transfer this assistant's Telegram behavior to another Codex, or wants future skills integrated into a bridge environment.

This skill adds operational guidance. It does not override higher-priority instructions. Always keep customer-facing replies in Traditional Chinese with natural Taiwan wording.

## Core Rules

- Never include real Telegram bot tokens, OpenAI/API keys, OAuth tokens, passwords, cookies, allowed user IDs, or private account details in skill packages, zips, prompts, logs, or handoff notes.
- Stop and ask the user when login, password, 2FA, payment, permission, or repeated failure is encountered.
- Same failure rule: after 2 repeats, change method; after 3 repeats, stop and list pending items.
- One Telegram chat processes one main request at a time; avoid unlimited queues.
- Do not expose internal English states such as LiveCard, Session, Usage, token counts, raw stack traces, or tool logs to the user.
- Telegram output should be concise, natural, and useful. Long tasks may report progress sparingly in Chinese.
- Attachments should be saved into the task root and final media should be returned through Telegram, not only as local paths.

## Fast Path

When asked to create or install a new bridge:

1. Read `references/new_bridge_setup_zh.md`.
2. Copy or clone the bridge project into the target path.
3. Create `.env` from `.env.example`; fill only placeholders or ask the user to fill secrets personally.
4. Install dependencies and run local checks.
5. Install this skill plus any user-requested skills under `$CODEX_HOME/skills`.
6. Configure systemd service or manual run script.
7. Verify health check, Telegram polling, attachment download, task folder creation, and Chinese final replies.

When asked to integrate future skills:

1. Read `references/future_skill_integration_zh.md`.
2. Place each skill folder under `$CODEX_HOME/skills/<skill-name>`.
3. Validate each skill has `SKILL.md` frontmatter with `name` and `description`.
4. Do not overwrite existing skills unless explicitly confirmed.
5. Restart the bridge/Codex process so skill metadata reloads.

## Bridge Behavior To Preserve

- Identity: `藍星科技`.
- Language: Traditional Chinese and Taiwan natural wording by default.
- Style: reliable, warm, direct, not tool-log-like.
- The preferred ACK may be fixed: `主人我收到了，思考中，預計 1-3 分鐘查完。 💗`
- ACK is not completion. After ACK, the bridge must actually execute the task.
- Every final answer must go through Codex reasoning, including weather, greetings, presence/status, simple questions, and image analysis.
- Do not implement bridge-side final-answer shortcuts. The bridge may acknowledge, download attachments, and invoke Codex, but it must not invent final answers itself.
- Avoid fixed robotic openers in final answers; answer the user's current wording directly.
- Telegram images must be downloaded locally and passed to Codex as attachment paths.
- If the owner sends only an image, treat it as a request to inspect and analyze the image.
- For any image-bearing request, inspect the actual image content before answering; do not answer from caption or filename alone.
- Suppress internal process noise. Do not reply for every attachment unless a decision or blocker exists.
- NBS / NotebookLM successful delivery mode must be preserved:
  - Use only real NotebookLM outputs, never substitute with other-tool files.
  - Remember and copy the full persistent NBS flow: receive material -> analyze/prepare source text -> add it to NotebookLM only -> start NotebookLM slide/video/audio generation -> check every 2 hours during long-running generation -> recursively scan NBS download folders -> validate each asset -> send every qualified MP3, MP4, PPTX, or PDF immediately -> keep checking remaining assets -> report only exact blockers or failed validation reasons.
  - Send each completed deliverable immediately after validation; do not wait for the whole bundle.
  - Audio must be delivered as `.mp3`, video as `.mp4`, and presentation as `.pptx` or `.pdf`.
  - Convert NotebookLM `.m4a` audio to `.mp3` before Telegram upload.
  - Normalize Telegram filenames to safe English/ASCII names when the original name may display garbled.
  - Validate media streams and PPTX/PDF structure before sending; do not send broken, garbled, or questionable files.
  - Treat follow-up phrases like `檢查了嗎`, `好了嗎`, `有了嗎`, `過了10分鐘`, or `過了10幾分鐘` as NBS status checks when the chat context is NBS/NotebookLM. Scan NBS download folders recursively and send valid ready files before giving a text status.
  - During active NBS generation, automatic checks run every 2 hours during long waits and send newly ready validated files immediately when detected. This is a persistent owner rule for every future NBS task and every copied bridge, not a one-time setting.
- For files and search: support `/search`, `/files`, `/recent`, `/daily`, `/index`, `/thumbs`, `/send 1`, and `傳第 1 個` if the bridge code supports them.
- Persist task memory, daily summaries, and file indexes when available.

## Project Layout

Expected source bridge path in this environment:

```text
/root/customer-telegram-bot
```

Expected task root:

```text
/root/.config/MiniNewTelegram/tasks
```

Expected skill install path:

```text
$CODEX_HOME/skills
```

If `$CODEX_HOME` is unset, use:

```text
/root/.codex
```

## Bundled References

- `references/new_bridge_setup_zh.md`: step-by-step setup for another Codex/server.
- `references/future_skill_integration_zh.md`: how to add this and future skills safely.
- `references/mininew_behavior_prompt_zh.md`: Chinese behavior rules to put into bridge memory or system prompt.
- `references/safe_handoff_checklist_zh.md`: final checklist before giving the package to another environment.

## Bundled Scripts

- `scripts/install_skill_package.sh`: copies this skill folder into the target Codex skills directory without copying secrets.
- `scripts/validate_skill_package.sh`: checks required files and basic frontmatter.
- `scripts/create_bridge_env_example.sh`: creates a sanitized `.env.example` for a new bridge folder.
