---
name: notebooklm-presentation-prompt
description: Build prompt-only instruction packs for NotebookLM presentations. Use only when the owner explicitly asks for NotebookLM prompt text or style instructions; for actual NBS deliverables use the unified nbs skill.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# NotebookLM Presentation Prompt

Use this skill when the user wants NotebookLM to generate a presentation, slide outline, speaker notes, report deck, teaching deck, sales deck, brand deck, or visual style prompt.

## Inputs To Collect

- Slide count
- Presentation time
- Speaker role
- Presentation context
- Target audience
- Speaker tone/persona
- Core CTA
- Whether speaker notes are needed
- Presentation purpose
- Outline framework
- Visual style
- Extra requirements

If the user does not provide these, choose sensible defaults and proceed.

## Prompt Formula

Create a copy-ready prompt with this structure:

```text
請你根據我在 NotebookLM 中提供的來源資料，產出一份可直接用於簡報製作的完整內容規劃。

【語言】繁體中文
【預計頁數】<n> 張
【預計報告時間】<n> 分鐘
【簡報角色】<role>
【發表場景】<context>
【目標受眾】<audience>
【講者語氣】<tone>
【核心 CTA】<cta>
【簡報目的】<purpose>
【大綱架構】<framework>
【視覺風格】<style>
【Speaker Notes】需要 / 不需要
【補充需求】<extra>

【輸出格式】
請輸出每一頁：
1. 頁碼與標題
2. 本頁核心訊息
3. 可直接放上投影片的文字
4. 建議圖表、圖片或版面
5. Speaker Notes / 講者備註
6. 與下一頁的銜接邏輯

請避免空泛口號。每一頁都要有明確訊息、可視化建議與可直接放進投影片的文案。
```

## Purpose Presets

- 提案說服：問題、方案、效益、下一步。
- 課程教學：概念、示範、練習、總結、作業。
- 銷售成交：需求、價值、案例、疑慮、行動。
- 成果報告：數據、成果、洞察、未來計畫。
- 品牌介紹：定位、故事、服務、差異化。
- 招商募資：市場、商模、團隊、成長、投資亮點。

## Outline Presets

- 問題-解法-成果
- 故事敘事型
- 金字塔原理
- 教學模組型
- 商業企劃型
- 比較決策型

## Visual Style Presets

- 清爽商務
- 高級黑金
- 科技藍綠
- 溫暖編輯
- 強烈網紅
- 極簡留白

## User Defaults

- Use Traditional Chinese by default.
- Favor AI, self-media, business monetization, course, short-drama, and Taiwan-market contexts when relevant.
- Keep prompts clean, structured, and directly copyable.

