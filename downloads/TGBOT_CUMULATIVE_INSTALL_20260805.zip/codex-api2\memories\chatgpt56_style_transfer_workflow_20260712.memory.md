# ChatGPT 5.6 Style Transfer Workflow Learned From YouTube - 2026-07-12

Source studied: YouTube `wq23biqIIsg`.

Video title meaning:
`ChatGPT 5.6 business workflow collection | five AI workflows to improve work efficiency | 01 - transfer an old presentation style into a new proposal`.

Core lesson:
- Treat advanced AI as a workflow executor, not only a chat answer tool.
- For business deliverables, do not jump directly to generation. First ask the model to analyze the existing reference material and extract a reusable design/work system.
- The first studied workflow is "old presentation style transfer into a new proposal".

Reusable workflow for future PPTX, NBS, proposal, product, course, website, and sales-deck tasks:
1. Use the reference file as a style source, not just content.
2. First prompt: make the assistant act as a brand designer and strategy consultant, then analyze the uploaded reference deck before creating anything.
3. Extract a design-system table:
   - cover structure
   - color palette
   - typography hierarchy
   - image crop and aspect rules
   - layout structure
   - whitespace rhythm
   - chart/table treatment
   - slide master or reusable page patterns when detectable
4. Only after the style table is clear, upload or provide the new content.
5. Second prompt: generate a new editable deck/proposal using the extracted design system plus the new source content.
6. Require audience, purpose, speaker tone, page count, and output format before generation when they are not obvious.
7. Validate the generated file against the original style reference, not only against content accuracy.
8. Use page-specific revision prompts:
   - reduce text-heavy pages
   - increase main visual ratio
   - keep text below a defined visual percentage when needed
   - convert process pages into timelines, tables, or diagrams
   - preserve reference palette and typography hierarchy
9. Remember the principle: the value is not "generation"; the value is "understanding the existing design language and then applying it to new business material".

Operational rule:
- When the owner provides a previous deck, brand material, product deck, course handout, or proposal reference and asks for a new PPTX/NBS/deck/site/proposal, default to a two-stage workflow:
  1. style/system analysis first,
  2. generation and page-level revision second.
- Do not deliver a generic pretty deck when a reference style exists.
- Keep source faithfulness: do not invent claims, prices, certificates, sales data, product functions, or unsupported results.

Useful owner-facing summary:
- First learn the old material's design language, then apply it to the new material.
- Analyze the style first, generate second, and revise page by page at the end.
