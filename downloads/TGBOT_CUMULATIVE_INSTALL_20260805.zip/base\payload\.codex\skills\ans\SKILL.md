---
name: ans
description: Use when the operator says ans, asks to run the WeChat mini-program AI video workflow, opens WeChat to create or download a generated video, or needs the completed WeChat digital-human/AI mini-program video verified, renamed safely, and returned to Telegram.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# ANS WeChat Video Workflow

Use this skill for the operator's WeChat mini-program video workflow from opening WeChat through returning the finished MP4 to Telegram.

## Highest Rules

- Reply to the operator only in clean Traditional Chinese.
- Start every task with what is being done and an estimated time.
- Do not let the operator wait silently. If WeChat, the mini-program, download, export, upload, or Telegram delivery stalls, report the blocker and next step immediately.
- Stop and ask the operator if login, QR scan, account selection, password, 2FA, permission, payment, security prompt, or binding appears.
- Do not expose raw logs, JSON, English tool status, stack traces, tokens, cookies, API keys, or mojibake.
- Send each completed video to Telegram once unless the operator asks to resend.
- Do not restart Telegram, Codex, WeChat, or the computer unless the operator explicitly asks or the current bridge rules allow it for repair.

## Inputs

Infer from the current Telegram context when possible:

- target mini-program or first common WeChat entry to use
- source script, image, video, audio, or benchmark material
- desired video type, ratio, language, subtitles, and branding
- whether the request is new work or a resend/re-download of the latest completed file

If the operator says "重新下載回傳", "亂碼", "影片完成了", or asks to resend, first locate the latest completed MP4 before recreating the work.

## WeChat Start Path

1. Open the existing logged-in WeChat desktop app.
2. Open the mini-program panel.
3. Use the first entry under `我的常用` when the operator refers to the known AI video mini-program from prior work.
4. If the mini-program opens to a dark, black, or blank surface, click once inside the opened mini-program window before deciding it is stuck.
5. Bring the actual mini-program window to the front if it appears behind the mini-program panel.
6. Stop and report if WeChat asks for QR login, account login, permission, payment, or verification.

## Production Flow

1. Confirm the source materials are present locally or attached in Telegram.
2. Enter the selected WeChat mini-program workflow.
3. Upload or paste the required material only after confirming it matches the operator's request.
4. Select the required video mode, digital human, voice, style, ratio, captions, and duration based on the current request.
5. Generate the video and watch for progress.
6. If generation or export takes longer than expected, report progress in Chinese and continue checking.
7. Download/export the completed MP4 to a clear local folder, preferably:
   - `C:\Users\Administrator\MiniNewBridge3\nms-downloads`
   - `C:\Users\Administrator\MiniNewBridge3\ans-downloads`
   - or the app's default download folder if the workflow forces it.

## Download Verification

After download:

1. Verify the file exists and is not a tiny placeholder.
2. Use `ffprobe` when available to confirm duration, size, dimensions, and readable container metadata.
3. If `ffprobe` is unavailable, at minimum verify file size is plausible and the extension is `.mp4`, `.mov`, `.m4v`, or `.webm`.
4. Do not send a corrupt, zero-byte, partial, or suspiciously small file.
5. If the file name is Chinese or contains symbols that may become mojibake, create a safe ASCII copy before sending.

## Telegram Return

Use the helper script when possible:

```powershell
C:\Users\Administrator\.codex\skills\ans\scripts\stage-and-send-telegram-video.ps1 -SourcePath "<finished-video-path>"
```

The helper:

- reads the Telegram bot token from `C:\Users\Administrator\MiniNewBridge3\appsettings.Local.json`
- uses the first allowed Telegram owner id when `-ChatId` is omitted
- copies the video to `C:\Users\Administrator\MiniNewBridge3\telegram-ready` with an ASCII-safe file name
- sends it as a Telegram document with a clean Chinese caption
- does not store or print the token

If the helper fails, do not paste raw errors to the operator. Summarize the blocker in Chinese and try a reasonable repair once.

## Resend Or Mojibake Fix

When the operator says the previous video is garbled, missing, or needs to be re-downloaded/re-sent:

1. Search recent output folders for the newest valid video:
   - `C:\Users\Administrator\MiniNewBridge3\nms-downloads`
   - `C:\Users\Administrator\MiniNewBridge3\ans-downloads`
   - `C:\Users\Administrator\MiniNewBridge3\nbs-downloads`
   - `C:\Users\Administrator\Downloads`
2. Prefer the file that matches the most recent completed task time and content.
3. Probe it with `ffprobe`.
4. Stage it with a safe ASCII file name.
5. Send it to Telegram once.
6. Tell the operator the video was re-sent with a safe file name.

## Related Skills

- Use `nms-digital-human` when the work is specifically the older digital-human workflow.
- Use `acs` or `acs2` when the downloaded video must be edited or benchmark-matched in Jianying/CapCut.
- Use `jianying-editor-skill` when timeline automation, captions, or final export are required.
- Use `video-frame-analysis` when visual verification or frame checking is needed.
