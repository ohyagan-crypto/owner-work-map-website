@echo off
setlocal
cd /d "%~dp0"

echo Installing Telegram AI Bot as a Windows logon scheduled task...
powershell -NoProfile -ExecutionPolicy Bypass -File ".\install_startup_task.ps1"
pause
