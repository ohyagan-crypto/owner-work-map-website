---
name: character-memory-manager
description: Manage reusable character memory for AI images, SD videos, short dramas, voice identity, face references, clothing, personality, and negative constraints. Use when Codex needs to remember, update, or apply fixed characters such as 庫裡, 嵐熙, 蝦妹 across prompts and productions.
---

# Character Memory Manager

Use this skill when the user says 記住角色, 這是某角色形象, 以後固定, 角色設定, or asks to apply character continuity.

## Current Core Characters

### 庫裡

- Male Taiwanese AI/self-media CEO.
- Face identity locked to the user's provided male photo.
- Short black hair, side-parted and swept up.
- Clean, youthful Taiwanese male look.
- CEO outfit when in drama: deep gray turtleneck, black blazer, premium smartwatch.
- Dialogue reference when 庫裡 has lines: use shared merged 嵐熙+庫裡 audio `C:\Users\max\lanxi_kuli_dialogue_ref.mp3`.
- No glasses, no sunglasses.

### 蝦妹

- Young woman with sweet, pure, gentle neighborly feeling.
- Face identity locked to the user's provided female white outfit photo.
- Black hair bun, airy bangs.
- White Japanese-style soft outfit, clean sunny natural-light feeling.

### 嵐熙

- Young woman, beautiful, mature, refined, cool.
- Face identity locked to the user's provided long black wavy hair photo.
- Long black wavy side-parted hair, refined bright facial features, tall slim figure.
- Drama emotion: hurt but restrained, teary eyes, lower lip trembling, controlled calm.
- Dialogue reference when 嵐熙 has lines: use shared merged 嵐熙+庫裡 audio `C:\Users\max\lanxi_kuli_dialogue_ref.mp3`.

## Workflow

1. Extract identity traits from uploaded reference images and user text.
2. Store concise stable character notes.
3. Separate fixed identity from changeable costume/scene/emotion.
4. Include negative constraints such as no glasses or no extra characters when relevant.
5. Reuse the latest confirmed character definition in image/video prompts.
6. For 嵐熙 or 庫裡 dialogue scenes, upload the shared merged dialogue audio `C:\Users\max\lanxi_kuli_dialogue_ref.mp3` as the audio/reference material unless the owner provides a newer replacement.

## Memory Limits

Within a chat, apply these notes directly. For cross-session permanence, store in local memory files or backend database when available.
