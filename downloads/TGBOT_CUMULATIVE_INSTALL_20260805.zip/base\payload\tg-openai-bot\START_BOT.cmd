@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist ".env" "%PS%" -NoProfile -ExecutionPolicy Bypass -File ".\setup_env.ps1"
if errorlevel 1 exit /b 1
"%PS%" -NoProfile -ExecutionPolicy Bypass -File ".\stop_bot.ps1" >nul 2>nul
echo Running unified TGBOT preflight...
%PY% ".\preflight.py"
if errorlevel 1 (pause & exit /b 1)
echo Starting the single unified TGBOT. Keep this window open.
%PY% ".\codex_bot.py"
pause
