---
name: acs
description: Use when the user says acs, nms, asks for 剪映自動剪輯, 對標剪輯, CapCut/Jianying editing automation, video reference analysis, storyboard-to-edit workflows, or wants Codex to operate 剪映專業版 to assemble, match, caption, export, or prepare short videos.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# ACS: 剪映自動 / 對標剪輯

Use this skill when the user says `acs` or asks for 剪映 / 剪映專業版 / CapCut China desktop video editing, automatic editing, benchmark/reference editing, or digital-human video editing workflows.

`nms` remains a legacy alias for this skill.

## User-Facing Rules

- Address the user as `主人`.
- Report in Traditional Chinese, short and direct.
- If login, account selection, QR scan, 2FA, update prompts, permissions, hidden windows, inaccessible desktop, missing files, export errors, or any blocker appears, stop immediately and report the exact blocker. Do not wait silently.
- If screenshots are produced for verification or desktop operation, automatically send each screenshot to Telegram immediately unless the user explicitly says not to. Prefer hidden desktop capture via `C:\Users\Administrator\CodexDesktopCapture\capture-and-send.py` launched with `pythonw.exe`; use `send-telegram-photo.ps1` only for sending existing PNG screenshots.
- After any click/key automation or command that may open a transient terminal/window, wait at least 1-2 seconds before taking the screenshot so the operator receives the actual app state, not a blocked terminal view.
- Screenshots sent to Telegram must not include terminal/PowerShell command windows when avoidable. Before capture, minimize any visible PowerShell, cmd, Windows Terminal, or Codex helper console window, then wait briefly and capture the app state.
- Do not spam duplicate screenshots. If a verification screenshot is visually the same as the previous one and the user did not explicitly request another copy, skip sending it and report that there was no visible change.
- Send ACS screenshots, login QR screens, exports, and verification outputs only once by default. Resend only when the user explicitly asks.
- Do not restart the computer or Telegram bot without asking the user first.
- Do not overwrite source materials or previous exports unless the user explicitly asks.
- Operator-guided step mode: when the operator says they will guide ACS/Jianying one step at a time, stop autonomous editing decisions and do only the exact next UI action requested. After each action, wait 1-2 seconds, send one verification screenshot to Telegram, briefly report the visible result, and wait for the next instruction. Do not skip ahead to import, timeline assembly, subtitle styling, export, or file sending unless the operator explicitly gives that step.
- In operator-guided Jianying UI mode, if the operator says to click "開始創作" / "开始创作", click that button and verify the editor opens. If the next instruction says to click "導入" / "导入" and import the provided materials in benchmark order, open the import dialog and select local material files in filename order such as `material_01.mp4`, `material_02.mp4`, etc., unless the operator provides a different order.

## Trigger Terms

- `acs`
- `nms`
- `數字人skill`
- `剪映自動`
- `對標剪輯`
- `剪映剪片`
- `剪映專業版`
- `CapCut`
- `Jianying`
- requests to imitate a reference video, make a short video, cut digital-human footage, create captions, or export video from 剪映.

## Core Workflow

Before doing implementation work, read [references/workflow.md](references/workflow.md) for the concrete ACS production flow. For reference-video imitation or 對標剪輯, also read [references/benchmark-editing.md](references/benchmark-editing.md). Use `scripts/acs_cli.py` for repeatable checks, asset probing, spec validation, spec creation, MCP info, and draft creation.

1. Clarify the task only if required:
   - final platform: 抖音 / TikTok / 小紅書 / YouTube Shorts / Reels / Telegram
   - target duration
   - output ratio: 9:16, 16:9, 1:1
   - source folder or files
   - reference video or storyboard
   - whether export is required
2. Gather inputs:
   - user-provided images, video clips, audio, scripts, captions, brand text, reference links, and previous style preferences.
   - If a Telegram message only shows `[document]`, `[photo]`, `[video]`, or `[voice]` without a local file, report that the file body is unavailable and ask the user to resend or provide a path.
3. Analyze reference/benchmark:
   - opening hook, scene rhythm, shot lengths, transitions, captions, visual style, sound design, emotional curve, CTA, and export specs.
   - Produce a compact benchmark breakdown before editing if the user asks to review.
4. Build edit plan:
   - timeline outline with timestamps
   - material mapping
   - caption script
   - B-roll and overlay instructions
   - effects/transitions
   - music/SFX notes
   - export settings
5. Choose the automation path:
   - Prefer draft-file automation with `pyJianYingDraft` for deterministic timeline assembly, subtitles, text, audio, images, and video tracks.
   - Use `capcut-mcp` / CapCutAPI when an HTTP API workflow is useful or the user asks for API/server automation.
   - Use `jianying-editor-skill` instructions/tools when UI operation or full 剪映 desktop workflow is required.
   - Use direct UI control only as a fallback after checking desktop visibility.
6. Operate 剪映 only after verifying the desktop is accessible:
   - open installed 剪映 from `C:\Users\Administrator\AppData\Local\JianyingPro\Apps\JianyingPro.exe`
   - if the launcher path is stale, search under `C:\Users\Administrator\AppData\Local\JianyingPro\Apps`
   - if the program opens hidden windows or screenshot fails, report immediately.
7. Import materials and assemble:
   - create/open project
   - import files
   - place clips according to the timeline plan
   - add captions/subtitles
   - add overlays, effects, transitions, audio, and CTA
8. Verify:
   - check that visual screen is not blank
   - inspect first frame, hook, captions, timeline continuity, and ending CTA
   - report any uncertain or unavailable verification.
9. Export:
   - default: 1080p, 30fps, H.264 unless user specifies otherwise
   - save exports under `C:\Users\Administrator\Desktop\剪映專屬\輸出` unless the user specifies another folder.
   - send final export to Telegram once. Do not resend unless requested.

## Desktop Automation Guardrails

- Always check for active blockers before long waits.
- For login-by-scan requests, follow the saved QR login workflow in [references/jianying-login-qr.md](references/jianying-login-qr.md).
- Before writing a real Jianying draft, run `acs_cli.py find-drafts`. Use `C:\Users\Administrator\Desktop\剪映專屬\草稿` as the default dedicated draft folder unless the user specifies another path.
- If a window is hidden, inaccessible, or click/key events return errors such as `Access is denied`, report immediately.
- If screenshot capture fails with `screen grab failed` or `The handle is invalid`, report that Codex cannot see the interactive desktop and ask the user to bring the window forward or operate that step.
- If a 剪映 update window appears, ask the user before installing updates unless the user explicitly says to proceed.
- If the user says they are watching and instructing step by step, follow one operation at a time and report after each visible state change.

## Benchmark Analysis Format

Use this compact structure when analyzing a reference:

```text
主人，對標分析：
1. 開場鉤子：
2. 節奏：
3. 畫面語言：
4. 字幕風格：
5. 音樂/音效：
6. 轉場：
7. 結尾 CTA：
8. 可複製剪輯方案：
```

## Editing Plan Format

```text
主人，剪輯方案：
比例：
時長：
素材：
風格：

時間軸：
00:00-00:03 ...
00:03-00:08 ...

字幕：
...

剪映操作：
1. ...
2. ...
3. ...

輸出：
...
```

## Known Local Paths

- Installed 剪映 root: `C:\Users\Administrator\AppData\Local\JianyingPro`
- Launcher: `C:\Users\Administrator\AppData\Local\JianyingPro\Apps\JianyingPro.exe`
- Versioned executable example: `C:\Users\Administrator\AppData\Local\JianyingPro\Apps\10.7.0.14095\JianyingPro.exe`
- Dedicated 剪映 folder: `C:\Users\Administrator\Desktop\剪映專屬`
- Default material folder: `C:\Users\Administrator\Desktop\剪映專屬\素材`
- Default benchmark folder: `C:\Users\Administrator\Desktop\剪映專屬\對標影片`
- Default draft spec folder: `C:\Users\Administrator\Desktop\剪映專屬\草稿規格`
- Default draft folder: `C:\Users\Administrator\Desktop\剪映專屬\草稿`
- Preferred export folder: `C:\Users\Administrator\Desktop\剪映專屬\輸出`
- Screenshot folder: `C:\Users\Administrator\Desktop\剪映專屬\截圖`
- Desktop control helpers: `C:\Users\Administrator\DesktopControl`
- Open-source tools root: `C:\Users\Administrator\Tools\jianying-open-source`
- Installed reference skill: `C:\Users\Administrator\.codex\skills\jianying-editor-skill`
- `pyJianYingDraft`: `C:\Users\Administrator\Tools\jianying-open-source\pyJianYingDraft`
- `capcut-mcp` / CapCutAPI: `C:\Users\Administrator\Tools\jianying-open-source\capcut-mcp`
- AutoFlowCut saved page: `C:\Users\Administrator\Tools\jianying-open-source\autoflowcut.html`
- ACS CLI: `C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py`

## Open-Source Tool Priority

## Included Skills And Tool Capabilities

ACS must include and coordinate these installed capabilities:

- `jianying-editor-skill`: 剪映桌面自動化、素材導入、字幕、導出、UI/草稿操作參考。
- `pyJianYingDraft`: 直接建立與修改剪映草稿，優先用於時間軸、字幕、音訊、圖片、影片軌道。
- `capcut-mcp / CapCutAPI`: API / MCP 方式建立與修改 CapCut/剪映草稿，適合伺服器化或批量流程。
- `AutoFlowCut`: 目前只有官網資料保存，作為「圖片/影片生成到 CapCut 專案」的流程參考；未確認為可安裝開源工具前不得當成已安裝功能。

1. **pyJianYingDraft**: use first for draft creation/editing. It is installed editable in the local Codex Python runtime and imports as `pyJianYingDraft`.
2. **capcut-mcp / CapCutAPI**: use for API-style draft management. Dependencies are installed, but server startup should be done only when needed.
3. **jianying-editor-skill**: use as an additional reference for desktop automation, UI strategies, and 剪映-specific workflows.
4. **AutoFlowCut**: currently only a saved product page, not a confirmed open-source repo. Do not treat it as an installed executable tool unless a real repo or installer is later provided.

When implementing an edit, prefer generating or modifying the 剪映 draft project over clicking the UI. UI automation remains useful for import/export/login, but draft-file automation is more reliable.

## ACS CLI Quick Commands

```powershell
$py = "C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" check
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" find-drafts
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" probe-assets "C:\path\to\materials"
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" make-spec --name "project-name" --out "C:\tmp\acs\project-name.json"
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" validate-spec --spec "C:\tmp\acs\project-name.json"
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" create-draft --spec "C:\tmp\acs\project-name.json"
& $py "C:\Users\Administrator\.codex\skills\acs\scripts\acs_cli.py" mcp-info
```

Always report CLI failures in Chinese instead of pasting raw stack traces to Telegram.

## Current Limitation Note

As of initial setup, 剪映 can be installed and launched, but Codex may not always see or click the interactive desktop layer. If the visible UI cannot be controlled, switch to assisted mode:

1. Tell the user exactly what is blocked.
2. Ask the user to click the visible button or bring the window forward.
3. Continue once the user confirms.

ACS should keep 剪映 materials, draft specs, generated draft folders, screenshots, and exports under `C:\Users\Administrator\Desktop\剪映專屬` by default.

## Current Operator-Guided ACS/Jianying Steps

Learned on 2026-06-04 for step-by-step Jianying UI operation:

1. When the operator says to import materials against the benchmark video, import the provided clips in benchmark order, normally `material_01.mp4`, `material_02.mp4`, `material_03.mp4`, `material_04.mp4`, `material_05.mp4`.
2. When the operator says "全部添加到軌道" or "第二個素材 第三個 第四個 第五個 照順序拉進去軌道", add every imported material to the main timeline track in order from left to right.
3. When the operator says "選擇字幕，開始識別", click `字幕` > `智能識別` > `識別字幕`, keep `自動檢測語言` unless instructed otherwise, then click `開始識別`.
4. After each guided UI step, wait briefly, send one verification screenshot to Telegram, briefly report the visible result, and stop for the next operator instruction.
## Benchmark Video Replication Flow

Learned from the operator-provided short-video editing tutorial on 2026-06-05. Use this as the default ACS process when the operator asks for 對標剪輯 / 復刻 / 照原視頻 / ACS benchmark editing.

1. First analyze the reference video:
   - opening hook
   - material order
   - shot duration
   - screen rhythm
   - caption rhythm
   - flower-text style
   - BGM beat points
   - transitions and material joins
   - ending CTA
2. Import the operator-provided materials in the same order as the reference video.
3. Put all imported materials onto the main timeline in that order.
4. Trim each clip to match the reference video timing as closely as possible.
5. Keep the original visual and audio content of the provided materials unless the operator explicitly asks to replace them.
6. Use Jianying's built-in caption recognition for subtitles when the operator says subtitles/captions are needed.
7. Add 花字 / decorative text after caption recognition. Match the reference video's flower-text template, color, scale, placement, animation, and timing as closely as possible.
8. Match BGM rhythm and edit points to the reference video. Cuts should land on the same perceived beat or scene-change timing when possible.
9. Match transitions and material connections to the reference video. Avoid adding unrelated effects.
10. Preview the whole timeline and check:
    - material order is correct
    - clips are not missing
    - caption timing is readable
    - flower text follows the reference
    - BGM and transitions feel aligned
    - final export does not contain blank frames or wrong clips

Operator-facing summary for this flow:

```text
先看對標影片
照順序導入素材
全部素材加到軌道
逐段對齊對標時間
字幕用剪映識別
花字照原影片版型
BGM 和轉場照原影片節奏
整體預覽修正後再導出
```

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-15 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 51則/1對話；TGBOT 34則/1對話；TGBOT 48則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 任何缺檔/漏傳抱怨都要回查同一任務 artifact、下載資料夾與 Telegram delivery 紀錄，不可重開任務或只口頭道歉。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->





