﻿param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [string]$ChatId = '',

    [string]$SafeBaseName = '',

    [string]$Caption = '影片完成，已用安全檔名回傳'
)

$ErrorActionPreference = 'Stop'

function Get-SafeNamePart {
    param([string]$Value)
    $clean = $Value -replace '[^A-Za-z0-9._-]+', '_'
    $clean = $clean.Trim('._-')
    if ([string]::IsNullOrWhiteSpace($clean)) { return 'ans_video' }
    return $clean
}

if (-not (Test-Path -LiteralPath $SourcePath)) {
    throw '找不到影片檔'
}

$settingsPath = 'C:\Users\Administrator\MiniNewBridge3\appsettings.Local.json'
if (-not (Test-Path -LiteralPath $settingsPath)) {
    throw '找不到 Telegram 設定檔'
}

$settings = Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
$token = [string]$settings.TelegramBot.Token
if ([string]::IsNullOrWhiteSpace($token)) {
    throw 'Telegram 設定不完整'
}

if ([string]::IsNullOrWhiteSpace($ChatId)) {
    $allowed = @($settings.TelegramBot.AllowedUserIds)
    if ($allowed.Count -eq 0) { throw '找不到可回傳的 Telegram 對象' }
    $ChatId = [string]$allowed[0]
}

$sourceItem = Get-Item -LiteralPath $SourcePath
$ext = $sourceItem.Extension.ToLowerInvariant()
if ($ext -notin @('.mp4', '.mov', '.m4v', '.webm')) {
    throw '不是可回傳的影片格式'
}

if ($sourceItem.Length -lt 1048576) {
    throw '影片檔案太小，可能不是完整成品'
}

$readyDir = 'C:\Users\Administrator\MiniNewBridge3\telegram-ready'
New-Item -ItemType Directory -Force -Path $readyDir | Out-Null

if ([string]::IsNullOrWhiteSpace($SafeBaseName)) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $SafeBaseName = "ans_video_$stamp"
}
$safeName = "$(Get-SafeNamePart $SafeBaseName)$ext"
$stagedPath = Join-Path $readyDir $safeName
Copy-Item -LiteralPath $sourceItem.FullName -Destination $stagedPath -Force

Add-Type -AssemblyName System.Net.Http
$client = [System.Net.Http.HttpClient]::new()
$client.Timeout = [TimeSpan]::FromMinutes(5)
$form = [System.Net.Http.MultipartFormDataContent]::new()
$fs = [System.IO.File]::OpenRead($stagedPath)
try {
    $form.Add([System.Net.Http.StringContent]::new([string]$ChatId), 'chat_id')
    if (-not [string]::IsNullOrWhiteSpace($Caption)) {
        $form.Add([System.Net.Http.StringContent]::new($Caption), 'caption')
    }
    $content = [System.Net.Http.StreamContent]::new($fs)
    $mime = switch ($ext) {
        '.mp4' { 'video/mp4' }
        '.mov' { 'video/quicktime' }
        default { 'application/octet-stream' }
    }
    $content.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse($mime)
    $form.Add($content, 'document', [System.IO.Path]::GetFileName($stagedPath))
    $response = $client.PostAsync("https://api.telegram.org/bot$token/sendDocument", $form).Result
    $bodyText = $response.Content.ReadAsStringAsync().Result
    if (-not $response.IsSuccessStatusCode) { throw 'Telegram 傳送失敗' }
    $body = $bodyText | ConvertFrom-Json
    if (-not [bool]$body.ok) { throw 'Telegram 未確認成功' }
    [pscustomobject]@{
        Sent = $true
        StagedPath = $stagedPath
        ChatId = $ChatId
    }
}
finally {
    $fs.Dispose()
    $form.Dispose()
    $client.Dispose()
}
