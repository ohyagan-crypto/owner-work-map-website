from __future__ import annotations

import json
import re
import sys
import unicodedata
from collections import OrderedDict, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from pypdf import PdfReader


TZ_UTC8 = timezone(timedelta(hours=8))
ROW_RE = re.compile(
    r"^(?P<seq>\d+)\s+"
    r"(?P<name>.+?)\s+"
    r"(?P<identity>新人|複訓)\s+"
    r"(?P<registration>有效報名|已取消)\s+"
    r"(?P<checkin>有簽到|未簽到)"
    r"(?:\s+(?P<checkin_time>\d{4}/\d{1,2}/\d{1,2}\s+\d{1,2}:\d{2}:\d{2}))?"
    r"(?:\s+(?P<referrer>.+))?$"
)
EVENT_RE = re.compile(r"^(?P<event>\d{1,2}/\d{1,2}\s+\S+場)\s+共\s+\d+\s+筆")


@dataclass
class Entry:
    event: str
    seq: int
    name: str
    identity: str
    registration: str
    checkin: str
    checkin_time: str
    referrer: str


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFKC", text or "").replace("\u3000", " ").strip()


def titlecase_alias(value: str) -> str:
    value = normalize_text(value)
    return value if re.search(r"[a-z]", value) else value.title()


def infer_aliases(name: str) -> list[str]:
    aliases: list[str] = []
    latin_groups = re.findall(r"[A-Za-z][A-Za-z0-9._-]*", name)
    for group in latin_groups:
        alias = titlecase_alias(group)
        if alias and alias not in aliases:
            aliases.append(alias)
    return aliases


def parse_pdf(pdf_path: Path) -> list[Entry]:
    reader = PdfReader(str(pdf_path))
    entries: list[Entry] = []
    current_event = ""
    for page in reader.pages:
        text = normalize_text(page.extract_text() or "")
        for raw_line in text.splitlines():
            line = normalize_text(raw_line)
            if not line:
                continue
            event_match = EVENT_RE.match(line)
            if event_match:
                current_event = event_match.group("event")
                continue
            row_match = ROW_RE.match(line)
            if not row_match:
                continue
            entries.append(
                Entry(
                    event=current_event,
                    seq=int(row_match.group("seq")),
                    name=normalize_text(row_match.group("name")),
                    identity=row_match.group("identity"),
                    registration=row_match.group("registration"),
                    checkin=row_match.group("checkin"),
                    checkin_time=normalize_text(row_match.group("checkin_time") or ""),
                    referrer=normalize_text(row_match.group("referrer") or ""),
                )
            )
    return entries


def load_existing(existing_path: Path) -> dict[str, dict[str, Any]]:
    if not existing_path.exists():
        return {}
    try:
        payload = json.loads(existing_path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    result: dict[str, dict[str, Any]] = {}
    for item in payload.get("eligible", []):
        name = normalize_text(str(item.get("name", "")))
        if name:
            result[name] = item
    return result


def build_output(entries: list[Entry], pdf_path: Path, existing: dict[str, dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[Entry]] = defaultdict(list)
    for entry in entries:
        grouped[entry.name].append(entry)

    eligible_rows = [
        entry
        for entry in entries
        if entry.identity == "新人" and entry.registration == "有效報名" and entry.checkin == "有簽到"
    ]
    excluded_checked_in = [
        entry
        for entry in entries
        if entry.identity == "新人" and entry.registration != "有效報名" and entry.checkin == "有簽到"
    ]

    eligible_by_name: "OrderedDict[str, dict[str, Any]]" = OrderedDict()
    for entry in sorted(eligible_rows, key=lambda item: (item.event, item.seq, item.name)):
        if entry.name in eligible_by_name:
            eligible_by_name[entry.name]["events"].append(entry.event)
            continue
        merged = dict(existing.get(entry.name, {}))
        merged["name"] = entry.name
        merged["active"] = True
        merged["events"] = [entry.event]
        merged["lastQualifiedCheckInTime"] = entry.checkin_time
        if entry.referrer:
            merged["referrer"] = entry.referrer

        aliases = []
        for alias in merged.get("aliases", []):
            alias = normalize_text(str(alias))
            if alias and alias not in aliases:
                aliases.append(alias)
        for alias in infer_aliases(entry.name):
            if alias not in aliases:
                aliases.append(alias)
        if aliases:
            merged["aliases"] = aliases
        elif "aliases" in merged:
            merged.pop("aliases", None)

        eligible_by_name[entry.name] = merged

    for item in eligible_by_name.values():
        item["events"] = sorted(set(item["events"]), key=item["events"].index)

    excluded_payload = []
    for entry in sorted(excluded_checked_in, key=lambda item: (item.event, item.seq, item.name)):
        excluded_payload.append(
            {
                "name": entry.name,
                "event": entry.event,
                "reason": entry.registration,
                "checkinTime": entry.checkin_time,
            }
        )

    duplicate_qualified = [
        {"name": name, "events": sorted({entry.event for entry in rows})}
        for name, rows in grouped.items()
        if sum(
            1
            for entry in rows
            if entry.identity == "新人" and entry.registration == "有效報名" and entry.checkin == "有簽到"
        )
        > 1
    ]

    return {
        "updatedAt": datetime.now(TZ_UTC8).isoformat(timespec="seconds"),
        "source": str(pdf_path),
        "criteria": "身分=新人、報名狀態=有效報名、簽到=有簽到",
        "pageCount": len(PdfReader(str(pdf_path)).pages),
        "qualifiedRowCount": len(eligible_rows),
        "eligibleCount": len(eligible_by_name),
        "duplicateQualifiedNames": duplicate_qualified,
        "excludedCheckedIn": excluded_payload,
        "eligible": list(eligible_by_name.values()),
    }


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: import_bluestar_attendance_pdf.py <input-pdf> <output-json>", file=sys.stderr)
        return 1

    pdf_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    if not pdf_path.exists():
        print(f"missing pdf: {pdf_path}", file=sys.stderr)
        return 1

    entries = parse_pdf(pdf_path)
    if not entries:
        print("no rows parsed from pdf", file=sys.stderr)
        return 1

    existing = load_existing(output_path)
    payload = build_output(entries, pdf_path, existing)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"eligibleCount": payload["eligibleCount"], "qualifiedRowCount": payload["qualifiedRowCount"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
