﻿$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvPath = Join-Path $ProjectDir ".env"

try {
    [System.Net.ServicePointManager]::SecurityProtocol = `
        [System.Net.ServicePointManager]::SecurityProtocol -bor `
        [System.Net.SecurityProtocolType]::Tls12
}
catch {
}

function Read-DotEnv {
    param([string] $Path)

    $Values = @{}
    if (-not (Test-Path $Path)) {
        return $Values
    }

    foreach ($RawLine in Get-Content -Path $Path -Encoding UTF8) {
        $Line = $RawLine.Trim().Trim([char]0xFEFF)
        if ([string]::IsNullOrWhiteSpace($Line) -or $Line.StartsWith("#") -or -not $Line.Contains("=")) {
            continue
        }

        $EqualsIndex = $Line.IndexOf("=")
        $Key = $Line.Substring(0, $EqualsIndex).Trim()
        $Value = $Line.Substring($EqualsIndex + 1).Trim().Trim('"').Trim("'")
        $Values[$Key] = $Value
    }

    return $Values
}

function Redact {
    param([string] $Value)

    if ($script:TelegramToken) {
        $Value = $Value.Replace($script:TelegramToken, "[TELEGRAM_BOT_TOKEN]")
    }
    if ($script:OpenAiKey) {
        $Value = $Value.Replace($script:OpenAiKey, "[OPENAI_API_KEY]")
    }
    return $Value
}

function Get-HttpErrorText {
    param($ErrorRecord)

    try {
        $Response = $ErrorRecord.Exception.Response
        if ($null -ne $Response) {
            $Stream = $Response.GetResponseStream()
            if ($null -ne $Stream) {
                $Reader = New-Object System.IO.StreamReader($Stream)
                return $Reader.ReadToEnd()
            }
        }
    }
    catch {
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-Json {
    param(
        [string] $Uri,
        [hashtable] $Payload = $null,
        [hashtable] $Headers = $null,
        [int] $TimeoutSec = 60
    )

    $Params = @{
        Uri = $Uri
        Method = "Post"
        TimeoutSec = $TimeoutSec
    }

    if ($Headers) {
        $Params.Headers = $Headers
    }
    if ($script:ProxyUrl) {
        $Params.Proxy = $script:ProxyUrl
    }
    if ($Payload) {
        $Params.ContentType = "application/json; charset=utf-8"
        $JsonBody = $Payload | ConvertTo-Json -Depth 20 -Compress
        $Params.Body = [System.Text.Encoding]::UTF8.GetBytes($JsonBody)
    }

    try {
        return Invoke-RestMethod @Params
    }
    catch {
        throw "HTTP request failed for $(Redact $Uri): $(Redact (Get-HttpErrorText $_))"
    }
}

function Invoke-Telegram {
    param(
        [string] $Method,
        [hashtable] $Payload = $null,
        [int] $TimeoutSec = 30
    )

    $Result = Invoke-Json -Uri "$script:TelegramApiBase/bot$script:TelegramToken/$Method" -Payload $Payload -TimeoutSec $TimeoutSec
    if ($Result.ok -ne $true) {
        throw "Telegram returned ok=false: $(Redact ($Result | ConvertTo-Json -Depth 20 -Compress))"
    }
    return $Result.result
}

function Get-ResponseText {
    param($Response)

    if ($Response.output_text) {
        return ([string]$Response.output_text).Trim()
    }

    $Chunks = New-Object System.Collections.Generic.List[string]
    if ($Response.output) {
        foreach ($Item in $Response.output) {
            if (-not $Item.content) {
                continue
            }
            foreach ($Content in $Item.content) {
                if ($Content.text) {
                    $Chunks.Add(([string]$Content.text).Trim())
                }
            }
        }
    }

    if ($Chunks.Count -gt 0) {
        return ($Chunks -join "`n").Trim()
    }
    return ""
}

function Get-ChatText {
    param($Response)

    if ($Response.choices -and $Response.choices.Count -gt 0) {
        return ([string]$Response.choices[0].message.content).Trim()
    }
    return ""
}

function Invoke-Ai {
    param([string] $Prompt)

    $Headers = @{}
    if (-not [string]::IsNullOrWhiteSpace($script:OpenAiKey)) {
        $Headers.Authorization = "Bearer $script:OpenAiKey"
    }

    $SystemPrompt = "You are a Telegram bot assistant. Reply in Traditional Chinese, concise and direct."
    $Attempts = @(
        @{
            label = "responses/full"
            uri = "$script:OpenAiBaseUrl/responses"
            payload = @{
                model = $script:OpenAiModel
                store = $false
                reasoning = @{ effort = $script:OpenAiReasoningEffort }
                input = @(
                    @{ role = "developer"; content = $SystemPrompt },
                    @{ role = "user"; content = $Prompt }
                )
                max_output_tokens = 512
            }
            parser = "responses"
        },
        @{
            label = "responses/string-input"
            uri = "$script:OpenAiBaseUrl/responses"
            payload = @{
                model = $script:OpenAiModel
                input = "$SystemPrompt`n`nUser: $Prompt"
                max_output_tokens = 512
            }
            parser = "responses"
        },
        @{
            label = "chat-completions/fallback"
            uri = "$script:OpenAiBaseUrl/chat/completions"
            payload = @{
                model = $script:OpenAiModel
                messages = @(
                    @{ role = "system"; content = $SystemPrompt },
                    @{ role = "user"; content = $Prompt }
                )
                max_tokens = 512
            }
            parser = "chat"
        }
    )

    $LastError = $null
    foreach ($Attempt in $Attempts) {
        try {
            $Response = Invoke-Json -Uri $Attempt.uri -Payload $Attempt.payload -Headers $Headers -TimeoutSec 120
            if ($Attempt.parser -eq "chat") {
                $Text = Get-ChatText $Response
            }
            else {
                $Text = Get-ResponseText $Response
            }
            if ([string]::IsNullOrWhiteSpace($Text)) {
                $Text = "AI 有回應，但沒有可顯示的文字。"
            }
            Write-Host "AI succeeded with $($Attempt.label)"
            return $Text
        }
        catch {
            $LastError = $_
            Write-Host "AI failed with $($Attempt.label): $(Redact ($_.Exception.Message))"
        }
    }

    throw "All AI attempts failed. Last error: $(Redact ($LastError.Exception.Message))"
}

Set-Location $ProjectDir
$Env = Read-DotEnv $EnvPath

$script:TelegramToken = $Env["TELEGRAM_BOT_TOKEN"]
$script:TelegramApiBase = $Env["TELEGRAM_API_BASE"]
$script:OpenAiKey = $Env["OPENAI_API_KEY"]
$script:OpenAiBaseUrl = $Env["OPENAI_BASE_URL"]
$script:OpenAiModel = $Env["OPENAI_MODEL"]
$script:OpenAiReasoningEffort = $Env["OPENAI_REASONING_EFFORT"]
$script:ProxyUrl = $Env["HTTPS_PROXY"]

if (-not $script:ProxyUrl) {
    $script:ProxyUrl = $Env["HTTP_PROXY"]
}
if (-not $script:ProxyUrl) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Process")
}
if (-not $script:ProxyUrl) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTP_PROXY", "Process")
}
if (-not $script:TelegramApiBase) {
    $script:TelegramApiBase = "https://api.telegram.org"
}
if (-not $script:OpenAiBaseUrl) {
    $script:OpenAiBaseUrl = "https://lanxinai.com/v1"
}
if (-not $script:OpenAiModel) {
    $script:OpenAiModel = "gpt-5.5"
}
if (-not $script:OpenAiReasoningEffort) {
    $script:OpenAiReasoningEffort = "xhigh"
}

$script:TelegramApiBase = $script:TelegramApiBase.TrimEnd("/")
$script:OpenAiBaseUrl = $script:OpenAiBaseUrl.TrimEnd("/")

if (-not $script:TelegramToken) {
    throw "Missing TELEGRAM_BOT_TOKEN in .env"
}
if (-not $script:OpenAiKey) {
    throw "Missing OPENAI_API_KEY in .env"
}
$Bot = Invoke-Telegram -Method "getMe"
Write-Host "Bot: @$($Bot.username) id=$($Bot.id)"
Write-Host "Clearing webhook without dropping pending messages..."
[void](Invoke-Telegram -Method "deleteWebhook" -Payload @{
    drop_pending_updates = $false
} -TimeoutSec 30)
Write-Host "Waiting for the normal text message you just sent to @$($Bot.username)..."

$Updates = Invoke-Telegram -Method "getUpdates" -Payload @{ timeout = 25 } -TimeoutSec 35
if (-not $Updates -or $Updates.Count -eq 0) {
    Write-Host "No update received. Close running bot windows, send a message, and retry."
    exit 1
}

$Last = $Updates | Select-Object -Last 1
$Message = $Last.message
if (-not $Message) {
    $Message = $Last.edited_message
}
if (-not $Message -or -not $Message.chat -or -not $Message.text) {
    Write-Host "Latest update has no text message. Send a text message and retry."
    exit 1
}

$ChatId = [long]$Message.chat.id
$Prompt = [string]$Message.text
Write-Host "Prompt: $Prompt"
if ($Prompt.StartsWith("/")) {
    Write-Host "Latest text is a command, not a normal message."
    Write-Host "Send a normal text message to @$($Bot.username), then rerun this test."
    exit 1
}

[void](Invoke-Telegram -Method "sendChatAction" -Payload @{ chat_id = $ChatId; action = "typing" } -TimeoutSec 15)
$Reply = Invoke-Ai $Prompt
[void](Invoke-Telegram -Method "sendMessage" -Payload @{ chat_id = $ChatId; text = $Reply } -TimeoutSec 30)

[void](Invoke-Telegram -Method "getUpdates" -Payload @{
    offset = ([long]$Last.update_id + 1)
    timeout = 0
})

Write-Host "Sent AI reply to Telegram."
