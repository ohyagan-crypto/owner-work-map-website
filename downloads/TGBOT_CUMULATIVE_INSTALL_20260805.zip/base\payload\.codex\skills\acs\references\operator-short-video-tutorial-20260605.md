# Operator Short-Video Editing Tutorial Flow

Source: operator-provided YouTube tutorial analyzed on 2026-06-05.

Use this as the ACS default for benchmark/reference short-video editing.

## Core Flow

1. Watch and analyze the reference video first.
2. Import source materials in the same order as the reference.
3. Add all imported materials to the main timeline.
4. Trim every clip to match reference timing.
5. Keep the original image/video/audio content from the operator's materials unless explicitly told otherwise.
6. Use Jianying's built-in subtitle recognition.
7. Add 花字 after subtitle recognition.
8. Match 花字 template, color, placement, animation, and timing to the reference.
9. Match BGM beat points and transition timing to the reference.
10. Preview the full timeline before export.

## Replication Checklist

- Material order matches the reference.
- Clip durations and cuts are aligned to the reference rhythm.
- Captions are generated with Jianying recognition.
- Flower text follows the original video's style.
- BGM and transitions feel like the reference.
- No missing clips, wrong clips, blank frames, or duplicated screenshots/files.

## Operator-Facing Summary

```text
先看對標影片
照順序導入素材
全部素材加到軌道
逐段對齊對標時間
字幕用剪映識別
花字照原影片版型
BGM 和轉場照原影片節奏
整體預覽修正後再導出
```
