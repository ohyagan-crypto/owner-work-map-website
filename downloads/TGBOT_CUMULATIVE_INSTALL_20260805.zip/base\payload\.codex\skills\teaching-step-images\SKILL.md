---
name: teaching-step-images
description: Use when the owner asks to create, optimize, generate, revise, package, or prompt 教學步驟圖片, SOP 分鏡圖, 手機操作教學圖, 截圖式教學圖, 紅框步驟圖, app/website/tutorial instruction images, Telegram BotFather SOP images, Lanxin/藍星 AI teaching images, or any multi-step visual guide that should become clear vertical instructional images.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Teaching Step Images

## Purpose

Use this skill to turn screenshots, rough instructions, SOP text, or app/website workflows into clean step-by-step teaching images that a beginner can follow directly.

This skill is separate from general image/poster work. Its output must prioritize instructional clarity, one action per image, consistent UI framing, readable Traditional Chinese, and explicit red highlight boxes/arrows over decorative design.

## Trigger

Use this skill for requests such as:

- 教學步驟圖片
- 教學圖
- SOP 圖
- 分鏡圖
- 手機操作教學圖
- 截圖式教學圖
- 紅框標示步驟
- 一步一步教學圖片
- 把這些步驟做成圖片
- BotFather 建立機器人教學圖
- 藍星 AI / Lanxin 操作教學圖
- 網站加入主畫面、複製網址、開新對話、刷新模型等手機教學圖

If the task also requires AI image generation, follow the active Lanxin/IMS generation rules after this skill produces the storyboard and prompt. Do not use disabled local image generation routes.

## Highest Rules

1. Inspect every provided screenshot/photo before answering or building the storyboard.
2. If a recent Telegram uploaded image is available for the current task, inspect that exact image path first.
3. Save any useful reference/material image under `C:\Users\max\Desktop\龍蝦記憶\` or a dated task subfolder before using it for production.
4. Use clean Traditional Chinese for user-facing replies and visible teaching text.
5. Keep every image to one main action. Avoid teaching multiple unrelated steps in one frame.
6. Use red boxes or red arrows to mark the exact button, search field, input box, menu item, or success area.
7. Keep visible text short. Long paragraphs increase AI text errors and make mobile teaching images hard to read.
8. Never show full real API tokens, passwords, cookies, verification codes, private keys, or other secrets. Mask token/account-sensitive content.
9. For Telegram-origin tasks, return finished deliverable files to the same originating Telegram chat by document/file mode whenever possible.
10. For any teaching/explainer/SOP image set, complete the whole approved set in one workflow regardless of count. Do not stop after a partial subset, and do not make the owner ask again for remaining images.
11. After all images are generated, validate every numbered image, then return all verified images to Telegram as documents. When there is more than one image, also build and return a ZIP package unless the owner explicitly says individual images only.
12. If one image in a set needs correction, correct that image, revalidate the full set order/count, rebuild the ZIP, and return the corrected image plus the refreshed full package.

## Workflow

### 1. Understand The Tutorial

Identify:

- Target platform or app, such as Telegram, BotFather, Lanxin AI, Chrome, LINE Keep, or a website.
- User goal, such as create a bot, add website to home screen, start a new AI chat, refresh model, copy URL, or send material to support.
- Audience skill level. Default to beginner-friendly.
- Number of steps/images. If the owner gives no count, choose the smallest complete sequence.
- Required ratio. Default to vertical 9:16, usually 1080x1920, for phone teaching images.
- Branding. Default to subtle Blue Star / 藍星科技 feel when the task is for the owner’s customers.

### 2. Analyze Materials

For every screenshot/photo:

- Read visible UI text.
- Identify the exact object that should be highlighted.
- Separate useful teaching content from status bars, unrelated chat history, private account details, and visual noise.
- Decide whether to use screenshot-realistic composition, regenerated UI mockup, or annotated original screenshot based on the owner’s request and platform constraints.
- If text is not legible, ask for a clearer image, closer crop, or better angle.

For the 2026-06-30 successful reference pattern:

- Lanxin side menu screenshot with red box around `新對話` works as a step teaching image.
- Lanxin side menu screenshot with red box around `刷新模型` works as a step teaching image.
- Mobile browser menu screenshot with red box around `加到主畫面` works as a step teaching image.
- Multi-image phone SOP sets work best when each frame shows one screen/action and one red highlight.

### 3. Build The Storyboard

For each image, write:

- Number and title: `步驟 1｜...`
- Visual scene: what the phone screen should show.
- Highlight: exact object to box/arrow.
- On-image text: one short title plus one or two short instruction lines.
- Sensitive-data handling: what must be blurred, masked, or omitted.
- Quality notes: language, UI style, ratio, and clutter control.

Use this structure:

```text
第 1 張｜標題
畫面內容：
...
紅框重點：
...
畫面文字：
步驟 1｜...
...
注意：
...
```

### 4. Apply The Proven Visual Style

Default teaching-image style:

- Vertical 9:16 phone tutorial image.
- Screenshot-like mobile interface.
- Dark UI when teaching Telegram or Lanxin dark mode.
- Clean Blue Star / 藍星科技 technology feel when appropriate.
- Red rectangle/arrow highlights with enough contrast.
- Consistent top/bottom spacing across all images.
- Same typography hierarchy across the full set.
- No crowded captions, no decorative clutter, no unnecessary English.

For Telegram BotFather SOP images:

- Use dark Telegram interface.
- Show official BotFather with blue check where relevant.
- Show `/newbot`, bot display name, username ending in `_bot`, and masked API Token.
- Token must be partially blurred or replaced with a fake masked token. Never show a complete real token.
- Include customer-service handoff step if the workflow needs 藍星客服 to bind 龍蝦系統.

### 5. Produce A Confirmation Checklist Before Generation

When the task will spend generation credits or use Lanxin/IMS, provide a concise confirmation checklist before submission:

```text
結論：我會做成一組直式 9:16 的教學步驟圖，先請你確認後再送出生成💗

製作判斷：
...

確認清單：
1. 張數：...
2. 尺寸：直式 9:16，預設 1080x1920
3. 風格：...
4. 語言：繁體中文
5. 紅框重點：...
6. 敏感資訊：Token/密碼/私密資料一律遮蔽
7. 完成後：下載原圖、檢查文字與尺寸、用 Telegram 文件模式回傳

完整提示詞：
...

請回覆「確認」或「好」，我再送出生成。
```

If the owner only asks to optimize a prompt/storyboard and not generate images yet, return the optimized storyboard and prompt directly.

### 6. Generation And Delivery

If image generation is required:

1. Use the active Lanxin/IMS workflow, not local disabled image tools.
2. Submit only after explicit owner confirmation unless the owner already clearly asked only for a prompt/storyboard.
3. Generate the complete approved set before final delivery. If the approved storyboard has 3, 5, 8, 12, or any other count, the expected deliverable count is that exact number.
4. Download the platform original outputs.
5. Validate image count, dimensions, readability, order, and key visible text.
6. For multi-image sets, name files with numbered ASCII filenames, for example:
   - `teaching-step-01-search-botfather.png`
   - `teaching-step-02-newbot.png`
7. Package a ZIP when the set has multiple images or the owner needs a shareable bundle.
8. Save backups under `C:\Users\max\Desktop\龍蝦記憶\<task-folder>\`.
9. Return every verified image to the originating Telegram chat by document/file mode. For multi-image sets, also return the ZIP in the same workflow.
10. Final delivery is not complete until Telegram upload succeeds for all expected images/package, or a real delivery blocker is reported with the local backup path.

## Quality Gate

Before final delivery, check:

- Correct image count and sequence.
- Each image teaches only one main step.
- Title and instruction text are Traditional Chinese and readable.
- No Simplified Chinese, mojibake, random extra text, or distracting English unless the app command requires it.
- Red highlight points to the correct UI element.
- Sensitive content is masked.
- Phone UI is plausible and clean.
- Actual files exist, are non-empty, and have expected dimensions.
- Telegram delivery is attempted for Telegram-origin work.

If any critical text is wrong, regenerate or revise before delivery. Do not deliver a known wrong teaching image as final.

## Successful Reference Flow From 2026-06-30

The owner praised the teaching image workflow that produced 4 vertical 1080x1920 images for:

1. 點右下角選單
2. 使用預設瀏覽器開啟
3. 複製網址
4. 傳送至 Keep 筆記

What worked:

- The task was split into separate single-action frames.
- Screenshot-style mobile UI was kept clear and realistic.
- Red boxes marked the exact action target.
- Visible text was short, direct, and in Traditional Chinese.
- The outputs were saved under `C:\Users\max\Desktop\龍蝦記憶\...`.
- Files were returned to the same Telegram chat as documents.

Reuse this as the default production pattern for future teaching-step image tasks.

## Successful Full-Set SOP Flow From 2026-06-30

The owner praised the BotFather SOP workflow because all 8 teaching images were produced and returned through Telegram.

Reuse this as the default for all future explainer/SOP image sets:

1. Decide the complete image count from the requested explanation, or choose the smallest complete count when the owner does not specify.
2. Build the storyboard for the full set before generation: one image per action, numbered in order.
3. Generate the whole set in one continuous workflow after confirmation.
4. Download every original output, rename with safe numbered ASCII filenames, and store them in the task folder.
5. Validate the count, sequence, dimensions, readable Traditional Chinese, red highlight target, and sensitive-data masking for every image.
6. Return all individual images to the originating Telegram chat as documents.
7. For any multi-image set, also create and return a ZIP package containing the full latest set.
8. Do not end with only a progress message, local path, or partial delivery when files can still be returned.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














