# Binance Coin Daily 15:00 With Image - 2026-07-13

Owner latest instruction:

- Future `幣安coin` automatic workflow must execute every day at `15:00`.
- It must include an image card/poster, not only a text report.
- Active bot/report route is TG1.

Execution rule:

1. Daily schedule: `15:00`.
2. Windows scheduled task: `Codex Binance Coin Daily 1500`.
3. Script: `C:\Users\你的使用者名稱\tg-openai-bot\scheduled_reports\run-binance-coin-daily.ps1`.
4. Text report must be sent through TG1 only.
5. Image card must be generated through IMS/Lanxin/Blue Star using TG1 second-account profile:
   `C:\Users\你的使用者名稱\lanxin_task\browser-profile-tg1-ohyaganone`.
6. Do not use `browser-profile-auto` for TG1 Binance image generation; that remains the original TG2/TG3 aggregation channel.
7. Required deliverables:
   - Traditional Chinese Binance/OKX hot meme coin text report.
   - One 9:16 Traditional Chinese Binance coin image card/poster.
8. Image style: black-gold exchange radar, meme coin heat ranking, on-chain monitoring dashboard, dense but readable, current execution date/time visible, 3-5 priority coins, risk notes, and `非投資建議`.
9. Completion requires text delivery, image file validation, and TG1 same-origin document delivery.
10. Recoverable image/report failures require real-state inspection and at least 5 retry/rebuild/revalidate attempts before reporting blocked, unless the blocker is external such as CAPTCHA, 2FA, payment/quota, account lock, missing origin chat id, or confirmed platform outage.

