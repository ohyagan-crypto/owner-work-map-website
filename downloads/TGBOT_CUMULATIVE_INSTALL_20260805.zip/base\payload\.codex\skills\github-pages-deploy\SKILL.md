---
name: github-pages-deploy
description: Deploy static websites to GitHub Pages. Use when Codex needs to prepare a static site folder, initialize or update a Git repository, create or update a GitHub repo, push changes, enable GitHub Pages, verify the public github.io URL, and return the final long-term website URL.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# GitHub Pages Deploy

Use this skill when the user asks to deploy a static website, upload a website to GitHub, make a long-term public URL, or update an existing GitHub Pages site.

## Workflow

1. Identify the site folder and confirm it contains deployable static files such as `index.html`, CSS, JS, and assets.
2. Remove temporary artifacts before committing: login screenshots, tokens, logs, tunnel files, `node_modules`, and generated debug files.
3. Check `git status --short` and do not include unrelated sensitive files.
4. Configure local repo identity if needed:
   - `git config user.name "<github-user>"`
   - `git config user.email "<email>"`
5. Initialize or reuse the repo, commit the current deployable files, and push to GitHub.
6. Create the GitHub repo with `gh repo create <repo> --public --source=. --remote=origin --push` when it does not exist.
7. Enable Pages with JSON input:
   - `{"source":{"branch":"main","path":"/"}} | gh api repos/<owner>/<repo>/pages -X POST --input -`
8. Poll the Pages URL until it returns HTTP 200 and `gh api repos/<owner>/<repo>/pages` reports `built`.
9. Return only the final stable URL plus any short verification note.

## Defaults

- Use public repos unless the user requests private.
- Use `main` branch and `/` root.
- Prefer GitHub Pages for static long-term hosting.
- For this user, respond in Traditional Chinese and give the final URL clearly.

## Safety

Never commit credentials, screenshots containing verification codes, raw remote-control passwords, API keys, `.env`, or browser profile data. Clean them before pushing.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->












