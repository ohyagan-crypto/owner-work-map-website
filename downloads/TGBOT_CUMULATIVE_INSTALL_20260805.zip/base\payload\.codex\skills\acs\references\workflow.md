# ACS Workflow

## Goal

ACS turns user materials and reference videos into a repeatable 剪映 / Jianying editing workflow.

## Production Stages

1. Intake:
   - Confirm source files are actually available locally.
   - If Telegram only shows placeholder metadata, ask the user to resend the file or provide a path.
   - Create a task folder under `C:\Users\Administrator\Desktop\剪映專屬\草稿規格\<task-name>`.

2. Benchmark analysis:
   - Identify hook, visual rhythm, cut density, average shot duration, caption style, music/SFX, overlays, CTA.
   - For detailed benchmark guidance, read `benchmark-editing.md`.
   - Produce a concise Traditional Chinese analysis before editing if the user needs approval.

3. Edit spec:
   - Save a JSON spec with title, ratio, fps, draft name, source assets, timeline scenes, captions, music, export settings, and notes.
   - Use `scripts/acs_cli.py make-spec` as the starting template.
   - Run `scripts/acs_cli.py probe-assets <paths...>` before filling the spec.
   - Run `scripts/acs_cli.py validate-spec --spec <file>` before draft creation.

4. Draft creation:
   - Prefer `pyJianYingDraft` and `DraftFolder.create_draft`.
   - Run `acs_cli.py find-drafts` before writing production drafts.
   - If no draft folder is found, use `C:\Users\Administrator\Desktop\剪映專屬\草稿` as the dedicated draft folder.
   - Current installed 剪映 is 10.x; draft creation may be version-sensitive. If a draft appears but cannot open, report this clearly.
   - For advanced template replacement or desktop export, consult `jianying-editor-skill`.

5. Visual/UI operations:
   - Only use UI automation after checking visible desktop access.
   - If hidden windows, screenshot failure, login, version update, permission, or QR scan appears, stop and ask the user.

6. Export and delivery:
   - Export once and send once.
   - Default export folder: `C:\Users\Administrator\Desktop\剪映專屬\輸出`.

7. API/MCP option:
   - Use `scripts/acs_cli.py mcp-info` to retrieve the local capcut-mcp startup command and endpoint.
   - Start capcut-mcp only when the task requires API/server automation.
   - Report if the server is started and stop it after the task unless the user asks to keep it running.

## Error Reporting

Use short Chinese blockers:

- `主人，卡在登入/掃碼，需要你確認 🌸`
- `主人，剪映更新視窗擋住了，需要你點確定或同意更新 🎀`
- `主人，Codex 目前看不到互動桌面，無法截圖/點擊，請把視窗叫到前景 ✨`
- `主人，草稿建立失敗，原因是：...`

Do not paste raw Python tracebacks, JSON dumps, mojibake, or giant logs into Telegram.

## Edit Spec Shape

```json
{
  "name": "project-name",
  "draft_name": "ACS_project-name",
  "ratio": "9:16",
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "assets": {
    "videos": [],
    "images": [],
    "audio": []
  },
  "timeline": [
    {
      "start": "0s",
      "duration": "3s",
      "type": "hook",
      "asset": "",
      "caption": "",
      "notes": ""
    }
  ],
  "captions": [],
  "music": "",
  "export": {
    "folder": "C:\\Users\\Administrator\\Desktop\\剪映專屬\\輸出",
    "filename": "project-name.mp4",
    "resolution": "1080p",
    "fps": 30
  }
}
```
