# HFSW Mix Manifest - YYYYMMDD_HHMMSS

## Task

- Topic:
- Origin bot/chat: TGBOT same-origin only when Telegram delivery is required
- Requested duration:
- Requested ratio:
- Requested image cadence:
- Requested accent:
- Requested BGM:
- Requested subtitle style:

## Voice

- Voice/accent preset:
- Source file or generated voice route:
- Was voice changed in this repair: no / yes
- If yes, owner instruction authorizing change:
- Voice gain / normalization:

## BGM

- BGM source:
- BGM starts at 0s: yes / no
- Loop method:
- Loop gap check:
- BGM gain:
- Ducking method:
- BGM audible on phone speakers: yes / no

## SFX

- SFX used: no / yes
- If yes, owner instruction authorizing SFX:
- SFX files:
- SFX gain:

## Subtitles

- Subtitle source:
- Subtitle format:
- Phrase alignment report:
- Font:
- Placement:
- Vertical offset: raise 10% of frame height
- Mobile safe-area check:
- Burned old captions covered/replaced: not needed / yes / no
- Sync check points:

## Step Lock

- Step map:
- Scene/image order check:
- Narration keyword check:
- Step-boundary frame check:

## Layer Protection

- Baseline layer state:
- Requested repair layer:
- Locked-layer hash check:
- Unrequested layer changes: none / list

## Images

- Expected image count:
- Valid aggregation/Blue Star platform image count:
- Missing scene numbers:
- Replaced fallback scene numbers:
- Final image inventory path:

## Hyperframes

- Project folder:
- Composition file:
- Render output:
- Render settings:

## QA

- Probe summary:
- Silence/dropout result:
- Extracted frame folder:
- Manual subtitle check:
- Manual opening BGM check:
- Manual middle/final audio check:
- Phone-speaker voice/BGM delta:
- Final automated QA report:
- Telegram document delivery:

## Result

- Final MP4:
- Validation status:
- Notes:
