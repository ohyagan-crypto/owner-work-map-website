---
name: nms-digital-human
description: Use when the operator says nms, 數字人, 數字人skill, AI網紅, 搖錢樹AI, asks to create a digital human from audio/script/image/video, make an AI presenter read a script, clone/use a voice for a script, assemble a digital-human video, or operate the WeChat mini-program digital-human workflow.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# NMS Digital Human Workflow

Use this skill for the operator's dedicated digital-human workflow. Keep replies short, Traditional Chinese, and address the operator as `主人`.

## Highest Rules

- Start every task with a Chinese status update that says what is being done and the estimated time.
- Do not let the operator wait silently. If a tool, app, upload, generation, export, login, 2FA, QR scan, mini-program, browser, or Jianying blocks or hangs, report immediately in Chinese.
- Do not show raw JSON, raw logs, English stack traces, API-key errors, or mojibake to Telegram. Summarize in clean Traditional Chinese.
- Send each screenshot, generated media, and result only once unless the operator asks to resend.
- Do not restart Telegram, Codex, apps, or the computer without asking.

## Inputs

Gather or infer:

- voice/audio file
- script text
- character/person reference image or existing digital-human video
- target length and output ratio
- whether the operator wants original audio unchanged, voice cloning, or a generated voice

If the operator says the voice must be unchanged, only send or use the original audio unchanged. A new script requires generated/cloned speech and cannot be exactly identical to the original voice.

## WeChat Mini-Program Path

For WeChat mini-program digital-human creation:

1. Open the WeChat mini-program page.
2. Use the first entry under `我的常用` for `搖錢樹AI`.
3. If the mini-program opens to a dark or blank surface, click once inside the opened window before deciding it is stuck.
4. If login, QR scan, permission, 2FA, account selection, or payment appears, stop and ask the operator.

### Learned Shaoqianshu AI UI Flow

Verified on 2026-06-19 in the WeChat mini-program panel.

1. In WeChat, open the mini-program panel and choose `搖錢樹AI` from `我的常用` or `最近使用`.
2. If the mini-program window appears behind the mini-program panel, bring the smaller `搖錢樹AI` window to the front before continuing.
3. Home tab entries:
   - `AI數字人`
   - `創意大片`
   - `超級作圖`
4. Bottom tabs:
   - `首頁`
   - `創作屋`
   - `作品`
   - `分享`
   - `我的`
5. Fast digital-human path:
   - `首頁` -> `AI數字人` -> `口播數字人`
   - Choose `文案驅動` when a script is provided.
   - Paste the video script into `輸入文案`.
   - Select a digital human under `選擇數字人`.
   - Select voice under `我的聲音` when needed.
   - Generate only after confirming the script, selected person, and voice.
6. Audio-driven path:
   - `首頁` -> `AI數字人` -> `口播數字人` -> `音頻驅動`
   - Upload audio, choose the digital human, then generate.
7. Other visible digital-human templates:
   - `數字人混剪視頻`
   - `口播視頻智剪`
   - `超能數字人`
   - `全班數字人`
8. Writing path:
   - `創作屋` -> `AI寫作`
   - Fill `生意檔案` first; the app says generated content depends on the business profile.
   - Visible tools include `營銷口播`, `文案優化`, `情感專家`, `知識科普`, `帶貨大咖`, `小紅書筆記`, `標題生成`, and `寫歌詞`.
9. Benchmark path:
   - `創作屋` -> `我有對標`
   - If empty, click the lower-right `添加對標` button to add benchmark accounts.
10. Do not click final generation, upload sensitive material, authorize, pay, or bind accounts unless the operator explicitly asks. Stop and report if login, QR scan, permission, payment, or verification appears.

## Local Production Path

When using local tools:

1. Verify the source files exist.
2. Probe audio/video duration with `ffprobe`.
3. For voice work, prefer existing known paths under:
   - `C:\Users\Administrator\Desktop\voice_clone_current_audio`
   - `C:\Users\Administrator\Tools\voice-clone-f5`
   - `C:\Users\Administrator\Tools\GPT-SoVITS-Package`
4. For video assembly, use existing digital-human visuals or Jianying/ACS tools when appropriate.
5. Export outputs under:
   - `C:\Users\Administrator\Desktop\剪映專案\輸出`
   - or a clearly named folder on Desktop.
6. Verify output duration and nonblank visual frames before sending.
7. Send final MP4/MP3 to Telegram once.

## Related Skills

- Use `acs` for Jianying/CapCut assembly, captions, timeline, and export.
- Use `jianying-editor` for Jianying desktop/API automation.
- Use `dreamina-sd-video-workflow` for AI video generation.
- Use `character-memory-manager` when a fixed character identity must be preserved.
- Use `transcribe` or `speech` when audio transcription or speech tooling is needed.
