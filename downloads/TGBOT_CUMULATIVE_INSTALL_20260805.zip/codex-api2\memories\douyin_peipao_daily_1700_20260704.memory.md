# Douyin Peipao Daily 17:00 Memory

Created: 2026-07-04

Owner approved a daily Douyin coaching workflow. The owner calls the workflow "抖音陪跑".

## Schedule

- Run every day at 17:00 local time.
- Windows scheduled task name: `BluestarDouyinPeipaoDaily1700`.
- Script: `C:\Users\Administrator\MiniNewBridge3\scripts\send-douyin-peipao-daily.ps1`.
- Task root: `C:\Users\Administrator\MiniNewBridge3\tasks\douyin-peipao`.

## Daily Output

The report must include four sections:

1. A 30-second short-video script following the owner's account route.
2. Three Douyin viral benchmark videos/topics based on the account route and the day's usable trends.
3. Practical new Douyin short-video tips and methods.
4. Daily account-operation follow-up and script discussion questions.

## Account Route

- Taiwan version of Malaysia Mage plus CURRY boss-scene feeling.
- Not a travel account, not a pure culture encyclopedia, not personal autobiography.
- Themes: financial intelligence, women entrepreneurship, Taiwan folk customs and belief culture, women growth, spiritual growth.
- Audience: age 30+, Taiwan Chinese-speaking audience, and foreigners interested in Taiwan.
- Style: high-quality woman boss talking-head content with strong first two hook sentences.
- Benchmark topics must be broadly reusable universal topics, not unique personal-life stories.

## Benchmark Selection Rule

Prefer universal talking-head topics:

- women need money-making ability
- ordinary people making money or changing fate after 30
- family, money, belief, and decision order
- high-quality women and choice ability
- Taiwan people's security and folk beliefs
- financial intelligence fundamentals

Avoid benchmarks that are mainly one person's special personal history unless the hook or topic can be generalized.
