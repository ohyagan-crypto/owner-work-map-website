#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-.env.example}"

cat > "$OUT" <<'EOF'
# Telegram
TELEGRAM_BOT_TOKEN=replace_with_botfather_token
ALLOWED_CHAT_IDS=

# Local Codex bridge
CODEX_BINARY=codex
CODEX_WORKDIR=/root
CODEX_MODEL=
CODEX_TIMEOUT_SECONDS=900
CODEX_TASK_ROOT=/root/.config/MiniNewTelegram/tasks
CODEX_EXTRA_ARGS=--dangerously-bypass-approvals-and-sandbox
MEMORY_PATHS=/root/customer-telegram-bot/docs/mininew_bridge_memory_zh.md

# Bot behavior
BOT_NAME=微新助理（森）
SYSTEM_PROMPT=你是微新助理（森）。固定使用繁體中文與台灣自然口語。不要輸出英文系統狀態、工具日誌或內部訊息。
PROGRESS_SECONDS=5,30,60,120,300,600
MAX_REPLY_CHARS=3500
MAX_ATTACHMENT_MB=50
POLL_TIMEOUT_SECONDS=25
HEALTH_HOST=127.0.0.1
HEALTH_PORT=8088
LOG_LEVEL=INFO
EOF

echo "Wrote sanitized env example: $OUT"

