Set shell = CreateObject("WScript.Shell")
If WScript.Arguments.Count < 1 Then
  WScript.Quit 2
End If
ps = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"
cmd = Chr(34) & ps & Chr(34) & " -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & WScript.Arguments(0) & Chr(34)
For i = 1 To WScript.Arguments.Count - 1
  arg = WScript.Arguments(i)
  If InStr(arg, " ") > 0 Or InStr(arg, Chr(34)) > 0 Then
    arg = Replace(arg, Chr(34), Chr(34) & Chr(34))
    cmd = cmd & " " & Chr(34) & arg & Chr(34)
  Else
    cmd = cmd & " " & arg
  End If
Next
shell.Run cmd, 0, False
