---
name: dreamina-sd-video-workflow
description: Run SD/Dreamina/Seedance AI video workflows. Use when Codex needs to analyze materials, prepare 5-15 second SD/SDF/SDV prompts, confirm cost, submit jobs, monitor status, download videos, verify outputs, and deliver results.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Dreamina SD Video Workflow

## 2026-07-07 Universal Prompt After Analysis Update

- After analyzing any owner-provided material, copy, storyboard, image, video, product brief, or script for `sd`, `sdf`, `sdv`, `Dreamina`, `Seedance`, or New API video generation, automatically convert the analysis into the full universal SD prompt before producing the confirmation checklist.
- This rule applies even when the owner does not explicitly say `sd提示詞` or `萬用提示詞`.
- Required order: source material/copy analysis -> full universal SD prompt -> confirmation checklist -> owner confirmation -> credit-consuming submission.
- For `cmsd` / `cmde`, after Claude Opus analysis and IMS 3x3 storyboard creation, feed the analysis and storyboard into the universal SD prompt before SD video submission.
- The universal prompt must preserve the owner's story, wording, product priorities, character settings, duration, ratio, and latest corrections. It must not override Kuli asset safety, one-audio limits, or any confirmed material rule.
- Confirmation checklist must include `萬用提示詞導入：已完成` or the exact reason it could not be completed.
- If the full prompt is too long for a command line, save it as a short-path prompt file in the task folder and submit the full prompt content from that file. Do not silently submit a shortened prompt.

## 2026-07-06 SD Standard Flow Update

- For `sd`, `sdf`, and `sdv`, use the latest standard flow memory: `C:\Users\max\.codex\memories\sd_video_generation_standard_flow_20260706.memory.md`.
- Fixed current paths: Lanxi image `C:\Users\max\lanxi_new.png`, Lanxi dialogue `C:\Users\max\lanxi_dialogue.mp3`, Kuli listed image `C:\Users\max\kuli.jpg`, Kuli dialogue `C:\Users\max\kuli_dialogue.mp3`, full prompt template `C:\Users\max\Desktop\龍蝦記憶\memory_upgrade_20260706\SD提示詞_嵐熙庫裡_終極版.md`.
- Owner correction on 2026-07-16: `C:\Users\max\kuli.jpg`, showing the black hoodie / orange drawstrings / peeled banana image, is the confirmed Kuli generation reference. Use it unless the owner provides a newer replacement.
- When the owner says `sd提示詞` or `萬用提示詞`, use the complete 8-dimension SD template. Do not submit a shortened prompt when the full template is requested.
- Known audio limitation: do not submit Lanxi and Kuli dialogue audio together in one generation if the route fails with dual audio. Choose one speaking character audio; the other character is visual-only unless a supported route is confirmed.
- Confirmation checklist must include full prompt, exact materials, selected one-audio choice, model version, duration, ratio, resolution, estimated credit cost, remaining credits, route, expected command/API, and known blockers.

用於 SD、SDF、SDV、Dreamina、Seedance、圖生影片、短劇影片生成。

## 路由原則

- `sd`、`sdf`、`sdv`、`Dreamina`、`Seedance`、`即夢`、`做影片`、`生成影片` 都啟用本技能。
- `M01 / M02 / M03` 素材編號只屬於本 SD 影片流程，而且只有當次確實收到多份參考素材時才使用；不得把這套編號帶到 HFSW、IMS、NBS、網站或其他工作流。
- 若主人同時說 `cmsd`，先走 `cmsd` 的 Claude 腳本與 IMS 分鏡，再回到本技能提交 SD。
- 若主人只要重新做 SD，必須清空前一任務脈絡，從當次素材重新分析。
- 若主人問狀態，例如「提交了嗎、好了沒、卡住沒」，先查工作紀錄與真實任務狀態，不可只回進度。
- 若主人提到 `zz1cc.cc.cd`、New API、`video-ds-2.0-fast`、`video-ds-2.0`，走 New API 成功流程，不要硬套 Dreamina CLI。

## 快速執行規則

- 送出前要確認；確認後要提交。
- 主人已看過清單並回覆「確認」後，不可再停在二次確認，必須立刻送出。
- Dreamina CLI 同帳號已授權後，先查 `version`、`user_credit`、`list_task --limit=5`；查到 UID、積分與會員狀態就視為登入正常，不可再要求主人重新授權。
- 登入正常且同一任務已確認時，要直接走提交、取得 `submit_id`、寫入工作紀錄；不可回到二次授權、二次確認或重新規劃。
- 如果提交沒有取得任務 id，不算已提交。
- 提交後必須記錄任務 id、路由、模型、秒數、比例、解析度、素材、提示詞路徑、積分消耗、下一次檢查時間。
- 等待生成時可以建立背景工作紀錄，但下一次檢查必須查真實狀態。
- CPU 靜止、CLI 沒輸出、視窗沒動，不可單獨當作完成或停止依據。

## 任務起手檢查

開始前先確認一個任務類型與一個交付物：

- 任務類型：純文字生影片、單圖生影片、多素材全能參考、New API 影片、查詢下載舊任務。
- 交付物：MP4、確認清單、任務狀態、下載檔、Telegram 回傳結果。
- 必要素材：圖片、影片、音訊、產品圖、角色圖、分鏡圖、腳本或提示詞。
- 需要花積分時，先查帳號與積分。
- 若剛完成授權，先用真實 CLI 快檢確認登入態；快檢正常後繼續任務，不可把授權流程當成新的等待點。

## 授權後卡點處理

- `user_credit` 或 `list_task` 一次失敗，不等於授權失敗；先檢查 CLI 執行檔、本機授權狀態、工作紀錄、任務 id 與查詢指令。
- 同一查詢連續失敗兩次後，改查實際平台或任務狀態，不要盲目要求主人重複授權。
- 只有 Dreamina 實際要求 OAuth、CAPTCHA、手機/信箱/2FA、帳號安全確認、授權過期或帳號風控時，才回報需要主人外部操作。
- 狀態問題必須回答「是否已提交、是否有任務 id、是否扣積分、目前卡在哪一步」，不能用進度句替代。

## 指令路由

### Dreamina CLI 多素材全能參考

優先用於圖片 + 音訊、圖片 + 影片、角色圖 + 產品圖、多參考影片：

```powershell
dreamina multimodal2video --image <image> --audio <audio> --model_version=seedance2.0fast_vip --duration=<4-15> --ratio=9:16 --video_resolution=720p --prompt <prompt> --poll=10
```

### Dreamina CLI 單圖生影片

只有一張首圖時使用。比例由圖片推斷，不能手動傳 `--ratio`：

```powershell
dreamina image2video --image <image> --prompt <prompt> --model_version=seedance2.0fast_vip --duration=<4-15> --video_resolution=720p --poll=10
```

### 查詢、下載、驗證

```powershell
dreamina query_result --submit_id=<id>
dreamina query_result --submit_id=<id> --download_dir <artifact_dir>
dreamina list_task --submit_id=<id>
dreamina list_task --gen_status=success --limit=20
```

### New API 成功流程

當任務指定或明顯適合 `zz1cc.cc.cd` New API：

- Submit：`POST https://zz1cc.cc.cd/v1/videos`
- Query：`GET https://zz1cc.cc.cd/v1/videos/<task_id>`
- Download：`GET https://zz1cc.cc.cd/v1/videos/<task_id>/content`
- 既有成功模型：`video-ds-2.0-fast`、`video-ds-2.0`

不要把 `video-ds-2.0-fast` 當成 Dreamina CLI 的 `model_version`。Dreamina CLI 使用 `seedance2.0fast_vip`、`seedance2.0_vip` 等模型值。

## 提交前確認清單

每次提交前列出：

- 帳號/UID/VIP 狀態。
- 目前積分。
- 選用平台與路由：Dreamina CLI 或 New API。
- 選用模型與計費模式。
- 預估積分消耗、人民幣價格、台幣估算、預估剩餘積分。
- 秒數、比例、解析度。
- 素材：參考圖、角色圖、音訊、產品圖、影片參考、分鏡圖。
- 完整提示詞。
- 預期提交指令或 API endpoint。
- 已知風險與卡點。

若即時匯率無法查，不可只因匯率卡住；可標記台幣為估算並繼續。

## 提示詞規則

- 不壓縮、不刪除、不改寫主人已確認的劇情、台詞、產品重點、角色設定或原始提示詞。
- 若平台限制需要縮短或調整，先回報並等待主人確認。
- SD 提示詞要補足八個面向：主體、動作、場景、服裝、光線、構圖、風格、細節。
- 影片提示詞還要補足時間軸、鏡頭運動、轉場、肢體動態、口型、台灣華語口音、環境音與音效。
- 若平台只有一個提示詞欄位，提交「完整 SD 提示詞」；精簡版、細節版、負面提示詞只放在確認清單。
- 長提示詞先存成短路徑文字檔，避免 Windows 命令過長。

## Claude 前置分析

複雜故事、cmsd、多人角色、品牌劇情或主人要求高一致性時，先用藍星平台最高可用 Claude 模型分析腳本、分鏡、素材需求與提示詞結構。

但若同一任務已完成確認清單，且主人已回覆「確認」，不可再用 Claude 前置分析當理由延遲提交；此時直接送出已確認的 SD/SDF 任務。

## 素材安全

- 當次 Telegram 上傳圖必須逐一檢查，不可只看第一張或聊天摘要。
- 庫裡最新修正（2026-07-16）：黑帽 T、橘色抽繩、拿香蕉這張已確認為正式庫裡素材，固定使用 `C:\Users\max\kuli.jpg`，除非主人提供更新版本。
- 嵐熙 + 庫裡台南保養品課程故事：兩人到台南上課並示範保養品，結尾必須包含「你知道我是 AI 嗎」。

## 執行流程

1. 讀取當次素材與需求。
2. 判斷路由：Dreamina CLI、New API、或查詢下載既有任務。
3. 查積分與帳號狀態。
4. 產出確認清單。
5. 主人確認後提交，不再重複確認。
6. 取得任務 id 並寫入工作紀錄。
7. 輪詢到完成或明確失敗。
8. 下載原始影片到 `C:\Users\max\Desktop\榫嶈潶瑷樻喍` 日期子資料夾。
9. 驗證時長、尺寸、可讀性與檔案大小。
10. 用 Telegram 文件模式回傳同一個來源對話。

## 工作紀錄標準

路徑：

```text
C:\Users\max\dreamina_task\jobs
```

至少記錄：

- `ChatId`
- `SubmitId`
- `Route`
- `Model`
- `Duration`
- `Ratio`
- `Resolution`
- `PromptPath`
- `Materials`
- `CreditBefore`
- `CreditCost`
- `CreditAfter`
- `OutputStatus`
- `NextCheckAtUtc`
- `ArtifactFolder`
- `DeliveredFiles`

狀態回覆必須來自這份工作紀錄、CLI 查詢、API 查詢或已驗證的輸出檔，不可憑記憶回答。

## Telegram 回傳規則

- 完成影片後用文件模式回傳原始 MP4 或乾淨副本。
- 只可傳到 `$env:TELEGRAM_ORIGIN_CHAT_ID`。
- 使用 `C:\Users\max\tg-openai-bot\tools\send_telegram_document.ps1`。
- 不可使用 `TELEGRAM_ALLOWED_CHAT_IDS`、`TELEGRAM_CHAT_ID`、舊 chat id、預設 chat id。
- 若來源 chat id 缺失，不可上傳；回報本機備份路徑與卡點。

## 失敗處理

以下狀況必須直接回報：

- 沒有任務 id。
- 查不到任務且積分未扣。
- 積分查詢失敗或積分不足。
- Dreamina OAuth、Web 授權、安全驗證、CAPTCHA、手機/信箱/2FA。
- 高風險模型首次使用要求 Web 授權確認。
- 影片生成失敗。
- 下載或驗證連續失敗。
- Telegram 來源 chat id 缺失或上傳失敗。

回報時只說主人需要知道的結論、原因、已完成動作與下一步；不輸出 raw log。

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->










