#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

function requirePlaywright() {
  const local = "C:\\tmp\\nbs-automation\\node_modules\\playwright-core";
  try {
    return require("playwright-core");
  } catch (_) {
    return require(local);
  }
}

const CHROME = process.env.NBS_BROWSER_EXE || "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
const USER_DATA_DIR = process.env.NBS_USER_DATA_DIR || "";
const CDP = process.env.NBS_CDP_URL || "http://127.0.0.1:9555";
const STATE = process.env.NBS_STATE || "C:\\tmp\\nbs-automation\\nbs-state.json";
const DOWNLOADS = "C:\\Users\\Administrator\\Downloads";
const TG_CONFIG = "C:\\Users\\Administrator\\appsettings.Local.json";
const DEFAULT_CHAT_ID = "[REDACTED_NUMBER]";
const AUTO_CHECK_TASK = "NBSAutoCheck";
const AUTO_CHECK_SCRIPT = "C:\\Users\\Administrator\\.codex\\skills\\notebooklm-brief-to-deck-workflow\\scripts\\nbs-auto-check.ps1";

function arg(name, fallback = undefined) {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : fallback;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function safeJsonParse(raw) {
  try {
    return JSON.parse(raw.replace(/^\uFEFF/, ""));
  } catch (_) {
    const recovered = {};
    const pairs = [
      ["notebookUrl", /"notebookUrl"\s*:\s*"([^"]+)"/],
      ["notebookId", /"notebookId"\s*:\s*"([^"]+)"/],
      ["sourcePath", /"sourcePath"\s*:\s*"([^"]+)"/],
      ["submittedAt", /"submittedAt"\s*:\s*"([^"]+)"/],
      ["downloadedFile", /"downloadedFile"\s*:\s*"([^"]+)"/],
    ];
    for (const [key, regex] of pairs) {
      const match = raw.match(regex);
      if (match) recovered[key] = match[1].replace(/\\\\/g, "\\");
    }
    const bytes = raw.match(/"downloadedBytes"\s*:\s*(\d+)/);
    if (bytes) recovered.downloadedBytes = Number(bytes[1]);
    return recovered;
  }
}

function readState() {
  if (!fs.existsSync(STATE)) return {};
  return safeJsonParse(fs.readFileSync(STATE, "utf8"));
}

function saveState(patch) {
  fs.mkdirSync(path.dirname(STATE), { recursive: true });
  const current = readState();
  const next = { ...current, ...patch, updatedAt: new Date().toISOString() };
  fs.writeFileSync(STATE, JSON.stringify(next, null, 2), "utf8");
  return next;
}

function normalizeUrl(url) {
  return (url || "").replace(/\?.*$/, "");
}

async function runCommand(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "pipe" });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error((stderr || stdout || `${command} exited ${code}`).trim()));
    });
  });
}

async function scheduleAutoCheck(minutes = 20) {
  if (!fs.existsSync(AUTO_CHECK_SCRIPT)) return null;
  const when = new Date(Date.now() + minutes * 60000);
  const localWhen = `${when.getFullYear()}-${String(when.getMonth() + 1).padStart(2, "0")}-${String(when.getDate()).padStart(2, "0")} ${String(when.getHours()).padStart(2, "0")}:${String(when.getMinutes()).padStart(2, "0")}:${String(when.getSeconds()).padStart(2, "0")}`;
  const script = `
    $ErrorActionPreference = 'Stop'
    $at = [datetime]::ParseExact('${localWhen}', 'yyyy-MM-dd HH:mm:ss', [Globalization.CultureInfo]::InvariantCulture)
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-NoProfile -ExecutionPolicy Bypass -File "${AUTO_CHECK_SCRIPT}"'
    $trigger = New-ScheduledTaskTrigger -Once -At $at
    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest
    Register-ScheduledTask -TaskName '${AUTO_CHECK_TASK}' -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
  `;
  await runCommand("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script]);
  saveState({ autoCheckTask: AUTO_CHECK_TASK, nextAutoCheckAt: when.toISOString(), autoCheckDelayMinutes: minutes });
  return when.toISOString();
}

async function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    clearTimeout(timer);
  }
}

async function launch() {
  const args = [
    `--remote-debugging-port=${new URL(CDP).port || "9444"}`,
    "https://notebooklm.google.com/",
  ];
  if (USER_DATA_DIR) {
    fs.mkdirSync(USER_DATA_DIR, { recursive: true });
    args.splice(1, 0, `--user-data-dir=${USER_DATA_DIR}`, "--profile-directory=Default");
  }
  const child = spawn(CHROME, args, { detached: true, stdio: "ignore" });
  child.unref();
  console.log(JSON.stringify({ ok: true, action: "launch", cdp: CDP }));
}

async function connectPlaywright() {
  const { chromium } = requirePlaywright();
  try {
    return await withTimeout(chromium.connectOverCDP(CDP), 10000, "connectOverCDP");
  } catch (_) {
    await launch();
    await sleep(3500);
    return await withTimeout(chromium.connectOverCDP(CDP), 10000, "connectOverCDP");
  }
}

async function release(browser) {
  if (browser && typeof browser.disconnect === "function") {
    await browser.disconnect();
  }
}

async function bodyText(page, limit = 6000) {
  return (await page.locator("body").innerText({ timeout: 10000 }).catch(() => "")).slice(0, limit);
}

async function create() {
  const sourcePath = arg("source");
  if (!sourcePath) throw new Error("Missing --source <path>");
  const title = arg("title", "NotebookLM 簡報來源");
  const source = fs.readFileSync(sourcePath, "utf8");
  const browser = await connectPlaywright();
  const context = browser.contexts()[0];
  const page = context.pages().find((p) => p.url().includes("notebooklm.google.com")) || context.pages()[0];
  await page.bringToFront();
  await page.goto("https://notebooklm.google.com/", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(2500);
  const text = await bodyText(page);
  if (page.url().includes("accounts.google.com") || /登入|選擇帳戶|電子郵件地址|已登出/.test(text)) {
    console.log(JSON.stringify({ ok: false, needsLogin: true, message: "Google login required." }));
    await release(browser);
    return;
  }

  const createNotebook = page.getByText("建立新的筆記本", { exact: true });
  if (await createNotebook.count()) {
    await createNotebook.first().click();
  } else {
    await page.getByText("新增", { exact: true }).first().click();
  }
  await page.waitForTimeout(5000);
  const notebookUrl = normalizeUrl(page.url());
  const notebookId = (notebookUrl.match(/notebook\/([^/?]+)/) || [])[1];

  const titleInput = page.locator("input.title-input").first();
  if (await titleInput.count()) await titleInput.fill(title).catch(() => {});

  await page.getByText("複製的文字", { exact: true }).click({ timeout: 15000 });
  await page.waitForTimeout(1500);
  await page.locator('textarea[placeholder="在這裡貼上文字"]').fill(source, { timeout: 30000 });
  await page.getByRole("button", { name: "插入", exact: true }).click({ timeout: 15000 });
  await page.waitForTimeout(12000);

  await page.getByText("工作室", { exact: true }).click({ timeout: 15000 });
  await page.waitForTimeout(2000);
  await page.getByText("簡報", { exact: true }).click({ timeout: 15000 });
  await page.waitForTimeout(5000);

  const submittedAt = new Date().toISOString();
  saveState({
    notebookUrl,
    notebookId,
    title,
    sourcePath,
    submittedAt,
    downloadedFile: null,
    downloadedBytes: null,
    telegramOk: false,
    telegramMessageId: null,
    telegramFile: null,
    telegramSentAt: null,
  });
  const nextAutoCheckAt = await scheduleAutoCheck(20).catch((error) => {
    saveState({ autoCheckError: error.message });
    return null;
  });
  console.log(JSON.stringify({ ok: true, action: "create", notebookUrl, notebookId, submittedAt }));
  if (nextAutoCheckAt) console.error(JSON.stringify({ ok: true, action: "auto-check-scheduled", nextAutoCheckAt }));
  await release(browser);
}

async function cdpTabs() {
  return await (await fetch(`${CDP}/json`)).json();
}

async function connectCdpPage(state, allowAnyNotebook = false) {
  const tabs = await cdpTabs();
  const tab = tabs.find((candidate) =>
    candidate.type === "page" && state.notebookUrl && normalizeUrl(candidate.url) === state.notebookUrl
  ) || tabs.find((candidate) =>
    candidate.type === "page" && state.notebookId && candidate.url.includes(state.notebookId)
  ) || (allowAnyNotebook ? tabs.find((candidate) =>
    candidate.type === "page" && candidate.url && candidate.url.includes("notebooklm.google.com")
  ) : null);

  if (!tab) throw new Error("Recorded NotebookLM tab not found");

  const ws = new WebSocket(tab.webSocketDebuggerUrl);
  let id = 0;
  const pending = new Map();
  ws.onmessage = (event) => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      pending.get(message.id)(message);
      pending.delete(message.id);
    }
  };
  await withTimeout(new Promise((resolve, reject) => {
    ws.onopen = resolve;
    ws.onerror = reject;
  }), 10000, "CDP WebSocket open");

  const send = (method, params = {}) => new Promise((resolve) => {
    const messageId = ++id;
    pending.set(messageId, resolve);
    ws.send(JSON.stringify({ id: messageId, method, params }));
  });
  await send("Runtime.enable");
  await send("Page.enable").catch(() => {});
  if (state.notebookUrl && normalizeUrl(tab.url) !== state.notebookUrl) {
    if (!allowAnyNotebook) {
      ws.close();
      throw new Error(`Notebook URL mismatch. expected=${state.notebookUrl} current=${normalizeUrl(tab.url)}`);
    }
    await send("Page.navigate", { url: state.notebookUrl });
    await sleep(3500);
  }
  return { tab, ws, send };
}

async function evaluate(send, expression) {
  const result = await send("Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true,
  });
  const exception = result.result && result.result.exceptionDetails;
  if (exception) throw new Error(exception.text || "Runtime.evaluate failed");
  return result.result.result.value;
}

async function pageTextCdp(state) {
  const { tab, ws, send } = await connectCdpPage(state, true);
  try {
    await send("Page.bringToFront").catch(() => {});
    await sleep(1000);
    const currentUrl = await evaluate(send, "location.href || ''");
    const text = await evaluate(send, "document.body.innerText || ''");
    return { url: normalizeUrl(currentUrl || tab.url), text };
  } finally {
    ws.close();
  }
}

async function status() {
  const state = readState();
  const result = await pageTextCdp(state);
  const text = result.text;
  const needsLogin = result.url.includes("accounts.google.com") || /登入|選擇帳戶|電子郵件地址|已登出/.test(text);
  const generating = /正在生成簡報|開始生成/.test(text);
  const hasPresentationCard = /(?:\d+\s*個來源|sources?)\s*·\s*[^\n]+\nmore_vert/i.test(text);
  const ready = !generating && (/已就緒|下載 PowerPoint|PowerPoint \(\.pptx\)/.test(text) || hasPresentationCard);
  const payload = {
    ok: true,
    needsLogin,
    ready,
    generating,
    notebookUrl: result.url,
  };
  if (!arg("brief")) payload.text = text.slice(0, 2000);
  console.log(JSON.stringify(payload, null, arg("brief") ? 0 : 2));
}

function newestDownloaded(format, startMs) {
  const ext = format === "pdf" ? ".pdf" : ".pptx";
  return fs.readdirSync(DOWNLOADS)
    .map((name) => path.join(DOWNLOADS, name))
    .filter((file) => fs.existsSync(file) && file.toLowerCase().endsWith(ext))
    .map((file) => ({ file, stat: fs.statSync(file) }))
    .filter((entry) => entry.stat.size > 0 && entry.stat.mtimeMs >= startMs - 2000)
    .sort((a, b) => b.stat.mtimeMs - a.stat.mtimeMs)[0];
}

async function download() {
  const state = readState();
  const format = arg("format", "pptx").toLowerCase() === "pdf" ? "pdf" : "pptx";
  if (!state.notebookUrl && !state.notebookId) throw new Error("Missing notebookUrl/notebookId in state");
  try {
    const result = await withTimeout(downloadWithPlaywright(state, format), 45000, "downloadWithPlaywright");
    saveState({ downloadedFile: result.file, downloadedBytes: result.bytes });
    console.log(JSON.stringify({ ok: true, file: result.file, bytes: result.bytes, method: "playwright" }));
    return;
  } catch (err) {
    if (process.env.NBS_VERBOSE) {
      console.error(JSON.stringify({ ok: false, stage: "playwright-download", error: err.message }));
    }
  }

  const { ws, send } = await connectCdpPage(state);
  const startedAt = Date.now();
  try {
    await send("Page.bringToFront").catch(() => {});
    await send("Browser.setDownloadBehavior", { behavior: "allow", downloadPath: DOWNLOADS }).catch(() => {});
    await send("Page.setDownloadBehavior", { behavior: "allow", downloadPath: DOWNLOADS }).catch(() => {});
    const text = await evaluate(send, "document.body.innerText || ''");
    if (/正在生成簡報/.test(text)) throw new Error("still generating");

    const menu = await evaluate(send, `(() => {
      const buttons = Array.from(document.querySelectorAll("button"))
        .map((button) => {
          const rect = button.getBoundingClientRect();
          return {
            button,
            text: (button.innerText || button.textContent || "").trim(),
            aria: button.getAttribute("aria-label") || "",
            x: rect.x,
            y: rect.y,
            w: rect.width,
            h: rect.height
          };
        })
        .filter((item) => item.w > 0 && item.h > 0 && (item.text.includes("more_vert") || item.aria.includes("更多")));
      const target = buttons[buttons.length - 1];
      if (!target) return null;
      target.button.click();
      return { x: target.x, y: target.y, w: target.w, h: target.h };
    })()`);
    if (!menu) throw new Error("No presentation card menu found");
    await sleep(1000);

    const option = await evaluate(send, `(() => {
      const wantPdf = ${JSON.stringify(format === "pdf")};
      const elements = Array.from(document.querySelectorAll("button,[role=menuitem],[role=option],div,span"))
        .map((element) => {
          const rect = element.getBoundingClientRect();
          return {
            element,
            text: (element.innerText || element.textContent || "").trim(),
            x: rect.x,
            y: rect.y,
            w: rect.width,
            h: rect.height
          };
        })
        .filter((item) => item.w > 0 && item.h > 0);
      const target = elements.find((item) => wantPdf
        ? item.text.includes("下載 PDF")
        : item.text.includes("下載 PowerPoint") || item.text.includes("Download PowerPoint") || item.text.includes("PowerPoint (.pptx)")
      );
      if (!target) return null;
      return { x: target.x + target.w / 2, y: target.y + target.h / 2, text: target.text };
    })()`);
    if (!option) throw new Error("Download option not found");

    await send("Input.dispatchMouseEvent", { type: "mousePressed", x: option.x, y: option.y, button: "left", clickCount: 1 });
    await send("Input.dispatchMouseEvent", { type: "mouseReleased", x: option.x, y: option.y, button: "left", clickCount: 1 });

    let downloaded = null;
    for (let i = 0; i < 120; i += 1) {
      await sleep(1000);
      downloaded = newestDownloaded(format, startedAt);
      if (downloaded) break;
    }
    if (!downloaded) throw new Error(`${format.toUpperCase()} download did not appear`);

    saveState({ downloadedFile: downloaded.file, downloadedBytes: downloaded.stat.size });
    console.log(JSON.stringify({ ok: true, file: downloaded.file, bytes: downloaded.stat.size }));
  } finally {
    ws.close();
  }
}

async function downloadWithPlaywright(state, format) {
  const browser = await connectPlaywright();
  const context = browser.contexts()[0];
  const page = context.pages().find((candidate) => normalizeUrl(candidate.url()) === state.notebookUrl)
    || context.pages().find((candidate) => state.notebookId && candidate.url().includes(state.notebookId));
  if (!page) throw new Error("Recorded NotebookLM page not found");
  const current = normalizeUrl(page.url());
  if (state.notebookUrl && current !== state.notebookUrl) {
    throw new Error(`Notebook URL mismatch. expected=${state.notebookUrl} current=${current}`);
  }

  await page.bringToFront().catch(() => {});
  await page.waitForTimeout(1000);
  const text = await bodyText(page, 8000);
  if (/正在生成簡報/.test(text)) throw new Error("still generating");

  const moreButtons = page.locator('button:has-text("more_vert")');
  const count = await moreButtons.count();
  if (!count) throw new Error("No presentation card menu found");
  await moreButtons.nth(count - 1).click({ timeout: 10000 });
  await page.waitForTimeout(1000);

  const labels = format === "pdf"
    ? ["下載 PDF 文件 (.pdf)", "下載 PDF", "Download PDF"]
    : ["下載 PowerPoint (.pptx)", "下載 PowerPoint", "PowerPoint (.pptx)", "Download PowerPoint"];

  let downloadEvent = null;
  for (const label of labels) {
    const item = page.getByText(label, { exact: false });
    if (await item.count()) {
      downloadEvent = await Promise.all([
        page.waitForEvent("download", { timeout: 90000 }),
        item.first().click({ timeout: 10000 }),
      ]).then(([download]) => download);
      break;
    }
  }
  if (!downloadEvent) throw new Error("Download option not found");

  const target = path.join(DOWNLOADS, downloadEvent.suggestedFilename());
  await downloadEvent.saveAs(target);
  const stat = fs.statSync(target);
  await release(browser);
  return { file: target, bytes: stat.size };
}

async function send() {
  const state = readState();
  const file = arg("file", state.downloadedFile);
  const chatId = arg("chat", DEFAULT_CHAT_ID);
  const force = Boolean(arg("force"));
  if (!file || !fs.existsSync(file)) throw new Error("Missing downloaded file");
  const sameFileAlreadySent = state.telegramOk
    && (state.telegramFile === file || (!state.telegramFile && state.downloadedFile === file));
  if (sameFileAlreadySent && !force) {
    console.log(JSON.stringify({
      ok: true,
      skipped: true,
      reason: "already sent",
      message_id: state.telegramMessageId,
      file: path.basename(file),
    }));
    return;
  }
  const cfg = JSON.parse(fs.readFileSync(TG_CONFIG, "utf8").replace(/^\uFEFF/, ""));
  const token = cfg.TelegramBot && cfg.TelegramBot.Token;
  if (!token) throw new Error("Telegram bot token not found");
  const form = new FormData();
  form.append("chat_id", chatId);
  form.append("caption", `NotebookLM 原生檔案：${path.basename(file)}`);
  const blob = new Blob([fs.readFileSync(file)], { type: "application/octet-stream" });
  form.append("document", blob, path.basename(file));
  const resp = await fetch(`https://api.telegram.org/bot${token}/sendDocument`, { method: "POST", body: form });
  const json = await resp.json();
  saveState({
    telegramOk: json.ok,
    telegramMessageId: json.result && json.result.message_id,
    telegramFile: file,
    telegramSentAt: new Date().toISOString(),
  });
  console.log(JSON.stringify({ ok: json.ok, message_id: json.result && json.result.message_id, file: path.basename(file) }));
}

async function schedule() {
  const minutes = Number(arg("minutes", "20"));
  const nextAutoCheckAt = await scheduleAutoCheck(Number.isFinite(minutes) && minutes > 0 ? minutes : 20);
  console.log(JSON.stringify({ ok: true, action: "schedule", task: AUTO_CHECK_TASK, nextAutoCheckAt }));
}

const cmd = process.argv[2];
Promise.resolve()
  .then(() => {
    if (cmd === "launch") return launch();
    if (cmd === "create") return create();
    if (cmd === "status") return status();
    if (cmd === "download") return download();
    if (cmd === "send") return send();
    if (cmd === "schedule") return schedule();
    throw new Error("Usage: nbs-runner.js launch|create|status|download|send|schedule");
  })
  .then(() => {
    process.exit(0);
  })
  .catch((err) => {
    console.error(JSON.stringify({ ok: false, error: err.message }));
    process.exit(1);
  });
