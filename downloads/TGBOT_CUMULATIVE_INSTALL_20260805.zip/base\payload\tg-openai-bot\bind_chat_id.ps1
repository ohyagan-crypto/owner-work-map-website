$ErrorActionPreference = 'Stop'

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvPath = Join-Path $ProjectDir '.env'

function Read-DotEnv([string]$Path) {
    $values = @{}
    foreach($raw in Get-Content -LiteralPath $Path -Encoding UTF8) {
        $line = $raw.Trim().Trim([char]0xFEFF)
        if(-not $line -or $line.StartsWith('#') -or -not $line.Contains('=')) { continue }
        $index = $line.IndexOf('=')
        $values[$line.Substring(0,$index).Trim()] = $line.Substring($index + 1).Trim().Trim('"').Trim("'")
    }
    return $values
}

if(-not (Test-Path -LiteralPath $EnvPath)) { throw ".env not found: $EnvPath" }
$settings = Read-DotEnv $EnvPath
$token = [string]$settings['TELEGRAM_BOT_TOKEN']
if([string]::IsNullOrWhiteSpace($token)) { throw 'TGBOT Token is missing. Run the installer first.' }

do {
    $chatId = (Read-Host 'Telegram owner CHAT ID').Trim()
    if($chatId -notmatch '^-?\d+$') {
        Write-Warning 'CHAT ID must contain only digits, with an optional leading minus sign.'
        $chatId = ''
    }
} while([string]::IsNullOrWhiteSpace($chatId))

try {
    $body = @{
        chat_id = $chatId
        text = 'TGBOT CHAT ID bound successfully. The Telegram channel is ready.'
        disable_web_page_preview = $true
    } | ConvertTo-Json -Compress
    $result = Invoke-RestMethod -Uri ("https://api.telegram.org/bot$token/sendMessage") -Method Post -Body $body -ContentType 'application/json; charset=utf-8' -TimeoutSec 30
    if(-not $result.ok) { throw 'Telegram returned ok=false.' }
} catch {
    throw 'CHAT ID verification failed. Start the TGBOT chat first, then confirm the numeric CHAT ID and retry.'
}

$updated = @()
foreach($line in Get-Content -LiteralPath $EnvPath -Encoding UTF8) {
    if($line -like 'TELEGRAM_OWNER_CHAT_ID=*') { $updated += "TELEGRAM_OWNER_CHAT_ID=$chatId"; continue }
    if($line -like 'TELEGRAM_ALLOWED_CHAT_IDS=*') { $updated += "TELEGRAM_ALLOWED_CHAT_IDS=$chatId"; continue }
    $updated += $line
}
[IO.File]::WriteAllLines($EnvPath,$updated,[Text.UTF8Encoding]::new($false))

& (Join-Path $ProjectDir 'stop_bot.ps1') | Out-Null
& (Join-Path $ProjectDir 'install_startup_task.ps1')
Start-Sleep -Seconds 10

$backends = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -in @('python.exe','pythonw.exe') -and [string]$_.CommandLine -match '(^|[\\/ ])codex_bot(?:_[23])?\.py(\s|$)'
})
$heartbeatPath = Join-Path $ProjectDir 'codex_bot_heartbeat.json'
$heartbeat = $null
if(Test-Path -LiteralPath $heartbeatPath) {
    try { $heartbeat = Get-Content -Raw -LiteralPath $heartbeatPath | ConvertFrom-Json } catch {}
}
$heartbeatAge = if($heartbeat -and $heartbeat.timestamp) {
    [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [int64]$heartbeat.timestamp
} else { [int64]::MaxValue }
$heartbeatPid = if($heartbeat -and $heartbeat.pid) { [int]$heartbeat.pid } else { 0 }
$matchingBackend = @($backends | Where-Object { [int]$_.ProcessId -eq $heartbeatPid })
if($backends.Count -ne 1 -or $matchingBackend.Count -ne 1 -or $heartbeatAge -gt 120) {
    throw "CHAT ID was saved, but TGBOT startup verification failed. Run SELF_CHECK.cmd."
}

Write-Host 'CHAT ID verified and saved. Exactly one TGBOT backend is running, with automatic logon startup and a 5-minute watchdog.' -ForegroundColor Green
