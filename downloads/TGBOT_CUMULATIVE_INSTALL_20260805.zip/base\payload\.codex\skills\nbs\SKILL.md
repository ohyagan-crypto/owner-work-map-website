---
name: nbs
description: Use when the operator says nbs, NotebookLM, 簡報, 影片摘要, 語音摘要, audio summary, video summary, presentation deck, or asks to turn websites, YouTube links, files, images, posters, PDFs, or text into NotebookLM deliverables. This is the single authoritative workflow for complete NBS packages: PPTX presentation, MP4 video summary, and MP3 audio summary.
---

# NBS NotebookLM 統一 SOP

## 2026-07-09 Owner Correction

The repeated failure pattern was: source materials were incomplete, only the presentation was created, or the already-generated video/audio was not downloaded and delivered. This skill now treats missing data and missing outputs as hard failures.

## Default Contract

- If the owner says `nbs` without limiting the output, treat it as a complete NBS package: `presentation_pptx` + `video_summary_mp4` + `audio_summary_mp3`.
- If the owner explicitly says only `簡報`, only deliver the PPTX.
- If the owner explicitly says only `影片摘要`, only deliver the MP4.
- If the owner explicitly says only `語音摘要`, `音訊`, `MP3`, or `audio`, only deliver the MP3.
- If the owner requests two outputs, deliver exactly those two outputs.
- Completion is forbidden until every requested output is generated from the same NotebookLM notebook, downloaded or exported, validated, and delivered to the same Telegram origin chat/thread when available.

## Absolute Completion Gate

Never report NBS complete at any of these states: `started`, `queued`, `submitted`, `generating`, `playing`, `visible card`, `downloaded`, `exported`, `local path`, `sent attempt`, or `partial delivery`.

Completion requires all of these:

1. The newest owner instruction is matched.
2. All provided source materials were inventoried and either added to the same NotebookLM notebook or reported as a blocker.
3. The expected output list is explicit.
4. Every expected file exists in the task artifact folder.
5. Every expected file passes validation.
6. Every expected file was returned by Telegram document/file mode to the exact origin chat/thread when available.
7. The NBS job record is updated with per-output status and delivered file paths.
8. The final reply lists every delivered filename by output type.

## Source Completeness Gate

Before creating or reusing a NotebookLM notebook, build a source manifest.

The source manifest must include:

- Every Telegram file, image, audio, video, PDF, document, link, YouTube URL, pasted text block, and caption in the current task.
- File path or URL for each source.
- Source type: website, YouTube, local file, image/poster, PDF, text, audio/video, or unknown.
- NotebookLM add method for each source.
- Status for each source: `pending`, `added`, `unsupported`, or `blocked`.
- A short note when a source is unreadable or missing.

Rules:

- Do not use only the first source when multiple sources were sent.
- Do not use only the latest source when earlier sources are part of the same task.
- Do not silently skip images, captions, PDFs, or links.
- If a source cannot be added, stop before generation unless the owner explicitly says to proceed without it.
- If the source batch is ambiguous, ask one direct blocking question listing the missing item.

## Confirmation Gate

Before spending time generating outputs, send a confirmation checklist unless the owner already confirmed this exact task or explicitly said to proceed immediately.

The checklist must contain:

- `來源清單`: every source and its add method.
- `素材統一分析`: required for multi-source tasks; assign M01, M02, M03, etc., summarize the cross-source topic, order, audience, sensitive-data risks, and which outputs each source supports.
- `成品清單`: PPTX, MP4, MP3, or the exact subset requested.
- `語言`: default `中文（繁體）` and Taiwan wording.
- `簡報風格提示詞`: required when PPTX is requested; include audience, visual direction, slide structure, layout density, typography, color system, diagram/table treatment, style intensity, conversion logic, camera/script treatment when relevant, and sensitive-data handling.
- `影片摘要提示方向`: required when MP4 is requested; include summary purpose, presenter/narration tone, visual emphasis, source order, title/caption language, rhythm, camera/script emphasis when relevant, and no-invention rules.
- `語音摘要提示方向`: required when MP3 is requested; include host role, speaking tone, teaching depth, Taiwan wording, pacing, section transitions, sensitive-data handling, and the key takeaways to emphasize.
- `NotebookLM 筆記本`: create new or reuse the named notebook.
- `驗證方式`: PPTX page/text check, MP4 media check, MP3 media check.
- `交付方式`: Telegram document/file mode to the same origin chat/thread.
- `自動檢查計畫`: job record path, first check window, per-output download/validation/delivery checks.
- `可能卡點`: login, source unsupported, language unavailable, generation failed, download failed, Telegram upload failed.

If the owner replies `確認`, `可以`, `開始`, `做`, `直接做`, or equivalent after this checklist, execute immediately and do not ask for the same confirmation again.

## Browser And Login Channel

Use the fixed NBS Chrome profile:

- Chrome profile folder: `C:\Users\max\nbs_task\chrome-profile`
- Chrome profile name: `Default`
- Control endpoint: `http://127.0.0.1:9444`
- Startup script: `C:\Users\max\nbs_task\start-notebooklm-chrome.ps1`
- NotebookLM URL: `https://notebooklm.google.com/`

Rules:

- Reuse the fixed logged-in profile before asking for credentials.
- Do not switch to Edge, random Chrome profiles, temporary profiles, or unrelated accounts unless the owner explicitly requests it.
- If the control endpoint is unavailable, run the startup script and reconnect to the same endpoint.
- Stop only for real external blockers: password prompt, CAPTCHA, 2FA, passkey, SMS/email verification, account risk, permission issue, payment, or platform outage.
- NotebookLM/NBS has no verified full local CLI replacement. Browser-profile automation is the supported channel unless a real verified local API/CLI is found.

## Notebook Workflow

1. Open the fixed NotebookLM browser/profile.
2. Create or reuse the correct notebook for the current task.
3. Add every source from the source manifest into the same notebook.
4. Verify NotebookLM shows the expected source count or source names.
5. Configure language as `中文（繁體）` wherever the UI allows it.
6. Create all requested output cards before waiting if NotebookLM allows it, so PPTX/MP4/MP3 can generate in parallel.
7. If NotebookLM only allows sequential generation, create and track each output separately.
8. Create or update a job record immediately after submission.
9. Poll real browser/card state and download state; do not rely on CPU idleness or the absence of UI changes.
10. Download/export every requested finished output from the same notebook.

## Output-Specific Requirements

### PPTX Presentation

Required final file: `.pptx`.

Generation requirements:

- Use NotebookLM presentation/deck output, not a locally fabricated replacement.
- Prompt for `中文（繁體）`, Taiwan wording, clear structure, and at least 15 content slides unless the owner specified another count.
- Include a rich presentation-style prompt, not only a content prompt. The prompt must specify:
  - Audience and usage context, such as customer onboarding, internal SOP, sales briefing, course handout, executive summary, or tutorial deck.
  - Visual direction, such as clean tech brand, premium education, calm operational SOP, warm customer-service guide, or professional product training.
  - Slide architecture, including cover, agenda, section divider slides, per-step teaching slides, key reminders, common mistakes, safety/privacy notes, recap, and next actions.
  - Layout rules: one main idea per slide, concise title, 3 to 5 bullets maximum when possible, strong visual hierarchy, enough white space, and no dense paragraph walls.
  - Teaching devices when useful: numbered flow, checklist, before/after, do/don't table, decision tree, timeline, callout boxes, or icon-supported steps.
  - Typography and color guidance: readable mobile-friendly font size, high contrast, restrained brand colors, consistent accent color, and no cluttered decorative background.
  - Source-faithfulness rules: do not invent products, brands, claims, screenshots, pricing, accounts, or unsupported operational steps.
  - Sensitive-data rules: mask API tokens, credentials, private chat IDs, phone numbers, QR codes, and account secrets; describe them generically when needed.
- Do not add unrelated brands, characters, scenarios, or marketing claims not present in the sources.
- For multi-image tutorial decks, require a unified deck style across all steps and preserve the exact source order.

Validation requirements:

- File opens as a valid ZIP/PPTX.
- Contains `ppt/slides/slide*.xml`.
- Has the requested slide count, or at least 15 slides by default.
- Is not a tiny placeholder file.
- Extracted sample text is Traditional Chinese, not Simplified Chinese or English-only.
- Extracted sample text should show real slide structure, such as titles, section flow, step labels, reminders, and next actions; do not accept a deck that only repeats raw OCR text without instructional organization.

### MP4 Video Summary

Required final file: `.mp4`.

Generation requirements:

- Use NotebookLM video summary or equivalent NotebookLM-generated video card from the same notebook.
- Configure/request `中文（繁體）` narration, captions, titles, or visible text when options exist.
- If NotebookLM cannot produce a video output for the current source, report that exact blocker instead of silently delivering only PPTX.

Validation requirements:

- File exists and is non-empty.
- `ffprobe` or a media tool can read duration, codec, and stream information.
- Duration is greater than zero.
- Output is the requested language when text/narration/captions are inspectable.
- Do not deliver HTML pages, login pages, thumbnails, previews, partial downloads, or placeholder media.

### MP3 Audio Summary

Required final file: `.mp3` unless the owner explicitly requested another audio format.

Generation requirements:

- Use NotebookLM audio summary card from the same notebook.
- Playback is never delivery. Pressing play only proves the card exists.
- Open the card menu/download action and save the original audio into the artifact folder.
- If the original is `.m4a`, validate it first, convert to `.mp3`, then validate the MP3.
- If NotebookLM cannot produce audio for the current source, report that exact blocker instead of silently delivering only PPTX/MP4.

Validation requirements:

- File exists and is non-empty.
- `ffprobe` or a media tool can read duration and audio stream.
- Duration is greater than zero.
- Final delivered file is `.mp3`.
- Do not deliver playback screenshots, browser cache files, HTML, partial downloads, or unvalidated audio.

## Artifact Folder And Filenames

Use a task folder under:

`C:\Users\max\nbs_task\artifacts`

Recommended folder name:

`YYYYMMDD_HHMMSS_nbs_<short_slug>`

Recommended final filenames:

- `NBS_presentation_YYYYMMDD_HHMMSS.pptx`
- `NBS_video_summary_YYYYMMDD_HHMMSS.mp4`
- `NBS_audio_summary_YYYYMMDD_HHMMSS.mp3`

Rules:

- Keep final delivery filenames ASCII to avoid Telegram/browser filename corruption.
- Do not leave final files scattered on the Desktop root.
- If NotebookLM or Chrome downloads to `Downloads`, move/copy the completed file into the artifact folder before validation and delivery.
- Do not send internal job records, logs, browser profiles, cookies, credentials, or secret-bearing files.

## Job Record

Create or update a JSON job record under:

`C:\Users\max\nbs_task\jobs`

Required fields:

- `JobId`
- `CreatedAtUtc`
- `UpdatedAtUtc`
- `ChatId`
- `ThreadId`
- `OriginBot`
- `NotebookHint`
- `NotebookUrl`
- `SourceManifest`
- `RequestedOutputs`
- `Language`
- `ArtifactFolder`
- `BrowserProfile`
- `OutputStatus`
- `ValidationStatus`
- `DeliveryStatus`
- `DeliveredFiles`
- `MissingOutputs`
- `NextCheckAtUtc`
- `CheckCount`
- `DownloadAttempts`
- `LastCheckSummary`

Track outputs separately:

```json
{
  "presentation_pptx": {"generated": false, "downloaded": false, "validated": false, "delivered": false},
  "video_summary_mp4": {"generated": false, "downloaded": false, "validated": false, "delivered": false},
  "audio_summary_mp3": {"generated": false, "downloaded": false, "validated": false, "delivered": false}
}
```

For subset requests, include only requested outputs in `RequestedOutputs`, but keep `MissingOutputs` accurate.

## Active Polling And Recovery

NBS waiting must be active, not passive.

Polling rules:

- First `NextCheckAtUtc` should be 3 to 5 minutes after generation submission.
- On every check, inspect the job record, browser page, NotebookLM cards, Downloads folder, artifact folder, validation state, and Telegram delivery state.
- If a card is still generating, update `NextCheckAtUtc` and continue.
- If a card is complete, immediately download/export it.
- If a download/export fails twice, inspect browser/download state before retrying.
- If the same blocker repeats three times, stop blind retries and report the concrete blocker.

Missing-output recovery:

- If the owner says `少了 MP3`, `少了語音`, `少影片`, `少簡報`, `少資料`, `漏傳`, `怎麼少`, `已生成但沒給我`, or equivalent, treat it as the same active NBS job unless the owner explicitly says to start over.
- Reopen the same notebook from the job record.
- Inspect the same artifact folder and Downloads folder.
- Compare `RequestedOutputs` to `DeliveredFiles`.
- Download/export, validate, and deliver only the missing outputs.
- Update `DeliveredFiles`, `MissingOutputs`, `DeliveryStatus`, and `LastCheckSummary`.

## Telegram Delivery Gate

For Telegram-origin NBS tasks:

- Return every final deliverable to the exact same chat and topic/thread that requested it.
- Use Telegram document/file mode to preserve quality.
- Send each requested final file once after validation.
- Do not send deliverables to default chat IDs, allowed-chat fallbacks, previous chats, or another bot.
- A local path is only a backup if Telegram delivery is unavailable or fails.
- If Telegram upload fails, report the concrete upload blocker and the local backup path.

Final reply must list files by type, for example:

- `簡報`: `NBS_presentation_YYYYMMDD_HHMMSS.pptx`
- `影片`: `NBS_video_summary_YYYYMMDD_HHMMSS.mp4`
- `語音`: `NBS_audio_summary_YYYYMMDD_HHMMSS.mp3`

If the final list is missing any requested type, do not say the task is complete.

## Status Questions

When the owner asks `好了沒`, `做完沒`, `提交了嗎`, `回傳了嗎`, `卡住哪裡`, or similar:

1. Read the latest matching NBS job record.
2. Inspect real browser/card state if the job is running.
3. Inspect artifact folder and validation results.
4. Inspect Telegram delivery state.
5. Reply with concrete status: generated, downloading, validating, delivered, or blocked.

Never answer with a fixed standby line or a generic health check.

## Stop Conditions

Stop and report a real blocker only when one of these remains after recoverable fixes:

- Missing source material required for the task.
- NotebookLM login or account security challenge.
- CAPTCHA, 2FA, SMS/email verification, passkey, or payment confirmation.
- NotebookLM cannot add a required source.
- NotebookLM cannot generate the requested output type for the given source.
- NotebookLM cannot generate `中文（繁體）` and the owner did not allow another language.
- Download/export fails three times after real state inspection.
- File validation fails and cannot be corrected in the same notebook.
- Telegram origin chat/thread is unavailable.
- Telegram upload fails after retry and the local backup path is preserved.

## Reboot Recovery

- Rebooting is not a reason to forget an NBS task.
- Use `C:\Users\max\nbs_task\nbs_autostart.ps1` after Windows logon to reopen the fixed profile and run login checks.
- Verify scheduled task `NBS NotebookLM AutoStart` before claiming reboot recovery is configured.
- Check `C:\Users\max\nbs_task\nbs_startup_status.json` and `C:\Users\max\nbs_task\nbs_login_status.json`.
- If `C:\Users\max\nbs_task\nbs_reboot_report_target.json` exists and is enabled, report only to that exact saved Telegram origin chat/thread.

## Final Self-Check

Before final reply, answer these internally:

- Did I use the newest owner instruction, not an older NBS task?
- Did I include every source in the source manifest?
- Did I expand `nbs` to PPTX + MP4 + MP3 unless the owner limited outputs?
- Did every requested output exist in the artifact folder?
- Did every requested output pass validation?
- Did every requested output return to the same Telegram origin chat/thread?
- Did I update the job record?
- Does the final reply list every delivered filename?

If any answer is no, the NBS task is not complete.

## 2026-07-10 Material-Derived Presentation Style Prompts

When an NBS task includes a PPTX / presentation, the assistant must analyze the provided source materials and independently decide which presentation style prompts are needed. Do not leave the style prompt for the owner to define when the materials already show the audience, workflow, tone, and teaching goal.

Required behavior:

- Inspect every current material first and assign M01, M02, M03, etc.
- Identify the material category: tutorial SOP screenshots, customer onboarding, restaurant/ordering flow, product education, platform error diagnosis, course material, sales briefing, internal training, or SD/storyboard planning.
- Infer one suitable deck style from the materials. Avoid generic wording such as only "clear, professional, simple".
- Add a fully filled `簡報風格提示詞` section to the NBS confirmation checklist.
- The section must include audience, usage scenario, visual direction, page structure, layout density, teaching components, privacy handling, and forbidden additions.
- For multi-material decks, define one shared style system: palette, typography feel, annotation/callout language, step labels, icon style, layout density, and slide order.
- Preserve useful source cues such as numbered steps, red boxes, arrows, button names, UI states, and visible instructional text.
- Mask or generalize sensitive content such as API tokens, QR codes, usernames, private IDs, phone numbers, account details, cookies, passwords, and credentials.

Common defaults:

- BotFather / Telegram bot tutorial: clean Blue Star onboarding SOP, mobile-first step cards, red instructional callouts, exact button names, API token masking, no invented credentials.
- Restaurant LINE ordering photo: practical customer instruction deck, scan-order-pay flow, warm storefront tone, QR destination not guessed, privacy-safe QR handling.
- SD/storyboard material: production planning deck, timeline table, scene logic, role setup, product shot structure, prompt handoff, known risks.
- Platform error screenshot: diagnosis/report deck, evidence-first layout, issue summary, possible causes, next actions, no raw logs or secrets.

Quality gate:

- Page count and Traditional Chinese are not enough. The deck must read like a usable presentation with a material-specific visual system and teaching structure.

## 2026-07-10 NotebookLM Prompt Site Style Modules

Source studied: `https://ohyagan-crypto.github.io/notebooklm-prompt-site/`.

When building the `簡報風格提示詞` for NBS presentation tasks, use the site's modular prompt structure as the default style-planning scaffold. The prompt must not only say "make a presentation"; it must fill these modules when source material allows:

- Basic settings: expected slide count, expected presentation minutes, speaker role, presentation context, target audience, speaker tone/persona, core CTA, and whether speaker notes are needed.
- Purpose type: choose or infer one main purpose from proposal persuasion, course teaching, sales conversion, result report, brand introduction, investor/fundraising pitch, or a material-specific custom purpose.
- Outline framework: choose or infer one structure from problem-solution-result, story narrative, pyramid principle, course module, business plan, compare-and-decide, or a material-specific custom outline.
- Visual style: choose or infer one style from clean business, premium black-gold, tech blue-green, warm editorial, bold creator/social, minimal whitespace, or a material-specific custom visual system.
- Output format: require every slide to include slide title, page key points, suggested visual/chart/layout, speaker notes when useful, final summary, and clear next action/CTA.
- Anti-generic rule: avoid empty slogans; every slide must have a clear message, visual recommendation, and ready-to-place slide copy.

Style options from the site should be mapped pragmatically:

- `清爽商務`: white or light background, deep blue titles, clean charts; best for SOP, internal report, onboarding, and operational decks.
- `高級黑金`: dark background with gold lines and premium tone; best for brand, investor, luxury, high-value offer, or executive pitches.
- `科技藍綠`: dark tech mood, cyan/blue-green accents, data visualization; best for AI, automation, software, platform, crypto, analytics, or technical education.
- `溫暖編輯`: warm off-white/brown editorial layout; best for stories, culture, community, customer-service guides, personal-brand teaching, or softer onboarding.
- `強烈網紅`: big titles, high contrast, short sentences; best for short-video planning, creator/IP, social media, viral hooks, or attention-driven sales content.
- `極簡留白`: large whitespace, thin lines, few key words; best for consultants, premium education, executive summary, and high-end professional decks.

The NBS confirmation checklist's `簡報風格提示詞` must now include these filled fields when PPTX is requested:

```text
簡報風格提示詞：
- 預計頁數 / 報告時間：
- 簡報角色：
- 發表場景：
- 目標受眾：
- 講者語氣與人設：
- 核心 CTA：
- 簡報目的 / 類型：
- 大綱架構：
- 視覺風格：
- 頁面輸出格式：
- Speaker Notes：
- 素材保留重點：
- 敏感資訊處理：
- 禁止加入內容：
```

For source-derived NBS jobs, do not ask the owner to fill these fields if the materials are enough to infer them. Fill them yourself, then let the owner confirm the whole checklist.

## 2026-07-10 Integrated NBS Workflow Upgrade

Owner correction: upgrade the whole `nbs` workflow together, not only the PPTX style prompt.

Use this integrated order for every new NBS task:

1. Identify the requested deliverables. Default `nbs` still means PPTX + MP4 + MP3 unless the owner explicitly limits outputs.
2. Inventory all current-task sources first. Assign stable IDs such as M01, M02, M03, and include captions or pasted text as sources.
3. Produce one unified source diagnosis before confirmation:
   - material category and topic
   - intended audience and use case
   - source order and cross-source story
   - sensitive data and privacy risks
   - source add method for NotebookLM
   - per-output usage: what the PPTX, MP4, and MP3 should each emphasize
4. Build a complete confirmation checklist with output-specific prompts:
   - PPTX: `簡報風格提示詞` using the prompt-site modules and material-derived style decisions.
   - MP4: `影片摘要提示方向` covering narration language, title/caption language, visual emphasis, summary depth, and no-invention rules.
   - MP3: `語音摘要提示方向` covering host role, speaking tone, pacing, key teaching points, and sensitive-data handling.
5. Wait for owner confirmation unless the owner already confirmed this exact checklist or explicitly said to proceed.
6. Add every approved source to the same NotebookLM notebook and verify the source count or names before generation.
7. Generate all requested output cards from that same notebook. Create/update the job record immediately after submission.
8. Actively poll real browser/card/download/artifact state. Do not use CPU idle, silence, or a visible player as completion evidence.
9. Download/export every requested output, normalize final filenames, validate each file, and only then deliver by Telegram document mode to the same origin chat/thread.

The confirmation checklist should use this full shape when all three outputs are requested:

```text
NBS 確認清單
1. 來源清單
2. 素材統一分析
3. 成品清單
4. 語言
5. 簡報風格提示詞
6. 影片摘要提示方向
7. 語音摘要提示方向
8. NotebookLM 筆記本
9. 驗證方式
10. 自動檢查計畫
11. 交付方式
12. 可能卡點
```

Output-specific prompt rules:

- PPTX prompt: must include slide count/minutes, speaker role, audience, scenario, tone/persona, CTA, purpose type, outline framework, visual style, slide output format, speaker notes, source cues to preserve, sensitive-data masking, and forbidden additions.
- MP4 prompt: must request `中文（繁體）`, Taiwan wording, source-faithful summary flow, material-specific visual emphasis, and avoid unsupported screenshots, claims, accounts, links, pricing, or brands.
- MP3 prompt: must request `中文（繁體）`, Taiwan wording, a natural teaching or briefing host voice, practical takeaways, clear section flow, and no reading of raw tokens, private IDs, passwords, QR contents, or credentials.

Quality gates after generation:

- PPTX: validate file structure, slide count, Traditional Chinese sample text, and whether the deck has a real teaching/presentation structure rather than raw OCR dumping.
- MP4: validate readable media, duration, stream info, and visible/narrated language when inspectable.
- MP3: validate readable audio, duration, final `.mp3` format, and that it is an actual downloaded/exported file, not playback state.
- Delivery: every requested output must be listed in `DeliveredFiles` and returned to the exact Telegram origin before saying complete.

## 2026-07-10 Rich Presentation Style Matrix

Owner correction: NBS presentation style prompts must be richer than a single selected visual style. For every NBS task with PPTX output, build the style prompt as a material-derived design system with these extra layers.

Add these decisions to `簡報風格提示詞` when source material allows:

- `素材氣質`: operational SOP, customer onboarding, product training, issue diagnosis, sales education, creator planning, executive briefing, course handout, or story/case-study.
- `品牌語感`: Blue Star tech service, warm customer support, premium professional, calm internal training, lively social/creator, or evidence-first diagnostic.
- `視覺層級`: cover impact, section divider style, step-page rhythm, reminder/caution pages, summary/checklist pages, final CTA page.
- `版面節奏`: when to use full screenshot focus, split screenshot plus instruction, comparison table, timeline, checklist, FAQ, mistake/fix, decision tree, or handoff prompt page.
- `圖像與標註規則`: preserve useful red frames, arrows, numbered markers, button names, visible UI states, and source order; simplify cluttered screenshots; never recreate sensitive UI details inaccurately.
- `色彩系統`: define primary color, accent color, warning color, neutral background, and contrast rule. Avoid one-note palettes and avoid decorative backgrounds that reduce readability.
- `字體與可讀性`: mobile-readable Traditional Chinese, short titles, no dense paragraph walls, consistent heading/body/callout sizes, and no tiny instruction text.
- `教學互動感`: add "你要做什麼", "畫面應該看到什麼", "完成判斷", "常見錯誤", and "下一步" where useful.
- `可信度保護`: separate source facts from inferred guidance; do not invent products, links, accounts, prices, claims, platform abilities, or customer promises.
- `交付用途`: specify whether the deck is for customer self-study, customer-service forwarding, class teaching, internal training, sales explanation, or production handoff.

For richer source-derived style selection, combine one base style plus one functional layer:

- Tutorial SOP: `清爽商務` + mobile step cards + red callout preservation + completion checklist.
- Blue Star / AI platform onboarding: `科技藍綠` or clean Blue Star tech + friendly customer-service wording + UI-state callouts.
- Sensitive credential/token tutorial: clean SOP + privacy warning pages + masked examples + strict no-secret rule.
- Product or skincare demo: premium product training + before/after logic + benefits table + no unsupported medical claims.
- Error/diagnosis material: evidence-first report + issue/cause/fix table + exact blocker and next action.
- SD/storyboard planning: creator production deck + timeline table + character/material mapping + final prompt handoff.
- Course or class material: premium education + module flow + practice checklist + speaker notes.

The `簡報風格提示詞` in confirmations should now include these additional fields when useful:

```text
- 素材氣質：
- 品牌語感：
- 視覺層級：
- 版面節奏：
- 圖像與標註規則：
- 色彩系統：
- 字體與可讀性：
- 教學互動感：
- 可信度保護：
- 交付用途：
```

Quality gate: a successful NBS deck must feel like a deliberately designed teaching or briefing deck, not a screenshot dump, OCR dump, or generic NotebookLM outline.

## 2026-07-11 Strong Style NBS Upgrade

Owner correction: NBS must support a stronger, more memorable style system when the materials call for it. The assistant must not leave decks bland when the goal is teaching, conversion, launch, pitch, sales, creator/IP, product demo, or customer onboarding.

Apply this upgrade to the full NBS package, not only the presentation. PPTX, MP4, and MP3 must share the same strategic direction, source faithfulness, and delivery strength.

### Style Intensity

Every NBS confirmation checklist must include a `風格強度分級`, even when the owner requests only MP4 or MP3. If PPTX is requested, put the field in `簡報風格提示詞`; if only MP4 or MP3 is requested, put the same decision in the video/audio prompt direction.

- `低`: calm SOP, compliance, internal reference, low-emotion documentation.
- `中`: polished onboarding, class teaching, customer-service forwarding, standard product training.
- `高`: product demo, course sales, creator/IP training, agent recruitment, public presentation.
- `極強`: launch event, hard-hitting sales deck, investor/agent pitch, black-tech release, battle-room briefing, viral short-video planning.

The assistant must choose the intensity from the source material and task purpose. Do not ask the owner to choose when the materials are enough to infer it. The selected intensity must affect PPTX structure, MP4 rhythm, MP3 host tone, validation, and revision decisions.

### Strong Visual Direction Options

When useful, the `簡報風格提示詞` may choose a stronger visual system such as:

- `硬核工業`: heavy structure, machinery/process feel, sharp contrast, process diagrams, capability proof.
- `黑科技發布會`: dark tech stage, cyan/blue glow accents, product reveal rhythm, strong chapter dividers.
- `戰情室`: dashboard layout, key metrics, risk zones, decision panels, command-center tone.
- `實驗室拆解`: evidence-first, component breakdown, before/after, method/test/result structure.
- `招商路演`: opportunity, pain point, solution, proof, cooperation model, scarcity, CTA, follow-up flow.
- `短影音爆款感`: big hooks, short lines, punchy page titles, creator logic, scene rhythm, retention points.

Use these as style directions, not as permission to invent facts.

### Conversion And Sales Logic

For sales, course, product, onboarding, or recruitment materials, every relevant slide should answer:

- `觀眾看到什麼`: the visible proof, UI state, product benefit, result, or action cue.
- `主播說什麼`: the speaker line, teaching point, sales point, or trust-building explanation.
- `助播做什麼`: what support staff, customer service, co-host, or assistant should point to, demonstrate, or prepare.
- `這頁如何推動成交`: how the slide moves the audience toward registration, reply, booking, trial, purchase, agent inquiry, or the next action.

If the source is not a sales/conversion task, translate this into "how this page helps the learner complete the task".

### Camera And Production Script Layer

When materials are videos, tutorials, products, demos, courses, scenes, or short-video planning, the confirmation checklist must include a `鏡頭腳本提示` inside the PPTX/MP4 direction:

- Camera scale: wide shot, medium shot, close-up, product close-up, hand operation, over-the-shoulder UI view.
- Action focus: tap, swipe, open menu, copy, paste, show product texture, product operation, result confirmation.
- Sound capture: narration, on-site sound, button/operation sound, product operation sound, classroom ambience, transition point.
- Transition points: where to cut, pause, zoom, compare, reveal, recap, or ask the next question.

For pure document/source-summary NBS tasks, keep this layer minimal.

### Pitch And Recruitment Pages

For agent recruitment, course signup, brand pitch, product sales, or business cooperation sources, the deck should include pages when supported by sources:

- why this opportunity matters now
- what problem it solves
- why the owner/brand/course/product is credible
- cooperation or participation path
- scarcity or limited seats only when provided or clearly authorized
- action instruction and follow-up handoff flow

Do not invent quotas, lifetime value, revenue, price, certification, warranty, medical claims, official partnerships, user counts, sales numbers, or platform capabilities.

### MP4 And MP3 Synchronization

The same intensity chosen for PPTX must guide MP4 and MP3:

- MP4 should have stronger section rhythm, clearer opening hook, more decisive transitions, and a tighter final CTA or next step.
- MP3 should sound like a host who understands the goal, not a flat reading. It should include clear opening conclusion, structured explanation, key reminders, and a firm closing summary.
- MP4/MP3 must remain source-faithful and use Traditional Chinese with Taiwan wording.

### Strong Style Validation

After generation, validation must include a style-quality check in addition to file checks:

- `風格強度是否符合確認清單`: low/medium/high/extreme must match the approved checklist.
- `每頁是否有明確目的`: teaching, proof, decision, warning, CTA, or transition.
- `是否有素材推導出的視覺系統`: not generic OCR dumping or bland outline.
- `成交/教學頁是否有下一步`: what the viewer should do after the page or section.
- `是否守住真實性`: no unsupported specs, pricing, lifecycle, certification, sales data, account details, or exaggerated claims.

If the deck is too bland and NotebookLM can still revise in the same notebook, revise the prompt and regenerate or update from the same notebook before delivery. Do not deliver a bland file as complete when the approved checklist asked for high or extreme style.

The `簡報風格提示詞` should add these fields when relevant:

```text
- 風格強度分級：
- 視覺攻擊性方向：
- 成交/教學推進邏輯：
- 主播/助播分工：
- 鏡頭腳本提示：
- 招商/轉換頁規劃：
- MP4/MP3 同步節奏：
- 強烈但不造假限制：
```

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->












