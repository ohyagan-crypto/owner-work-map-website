# Video Segment Templates

## Short segment template
片段 N：00:00-00:12｜標題
畫面：
動作：
鏡頭：
台詞/旁白：
音效：
生成重點：

## Full AI video spec template
### 片段 N：00:00-00:12｜標題
#### 1. 畫面與場景
#### 2. 運鏡與轉場
#### 3. 角色動作與微表情
#### 4. 台詞、口型與旁白
#### 5. 音效與音樂
#### 6. AI 影片提示詞
#### 7. 負面限制
