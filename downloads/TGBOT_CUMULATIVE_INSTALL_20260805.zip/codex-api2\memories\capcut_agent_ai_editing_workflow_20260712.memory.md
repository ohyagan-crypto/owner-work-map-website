# CapCut / Jianying Agent AI Editing Workflow - 2026-07-12

Source learned from owner-provided YouTube video `IdylAyrQxl0`, title: `剪映Agent终于来了！AI自动剪辑～【小白必备】`.

Reusable rules:
- Treat Jianying/CapCut Agent as an AI editing operator, not just a normal editor feature. It can understand natural-language instructions, material content, and editing intent.
- Best use case is fast rough editing and batch editing, not final cinema-level precision.
- Strong tasks for the agent:
  - remove filler words, swear words, dead air, or unwanted speech segments;
  - normalize audio volume across clips;
  - change aspect ratio;
  - add captions;
  - transcribe and translate speech into Chinese or bilingual captions;
  - search/apply suitable effects, templates, transitions, sound effects, big text, and packaging elements;
  - generate narration from silent footage after recognizing visual content;
  - organize unordered clips into a Vlog-like sequence with music, captions, and transitions;
  - generate missing AI shots, images, video clips, logos, endings, or transition materials inside the same workflow;
  - use text-to-video / text-to-film for quick demos, inspiration drafts, or first-pass material generation.
- Practical workflow:
  1. Import source footage.
  2. Give a clear natural-language editing command.
  3. Let the agent create an editable project file.
  4. Review the result as a rough cut.
  5. Manually refine timing, parameters, visual style, and final polish.
- Key advantage: output remains editable as a project/timeline, unlike fully generated videos that often require rerolling from scratch.
- Quality expectation: useful for speed, demo creation, batch cuts, short-video packaging, subtitles, and creative drafts; final professional polish still needs human review.
- Owner-facing takeaway: future video workflows should consider whether Jianying/CapCut Agent can handle repetitive rough-cut work before doing everything manually.

## 2026-07-12 follow-up research: similar local skills and external tools

Owner asked whether we have similar skills to Jianying/CapCut Agent and requested web research.

Local capability mapping:
- `acs`: closest local workflow. It analyzes reference videos, builds timeline/caption/music/export specs, prefers Jianying draft automation, and falls back to UI operation when needed.
- `acs2`: simplified benchmark short-video replication flow. It focuses on shot-level reference breakdown, material ordering, caption timing, decorative text, BGM beat points, transitions, preview, and export.
- `video-frame-analysis`: required before making claims from video content. Use ffprobe plus frame extraction to build an edit-useful timeline.
- `transcribe` + `speech`: useful for subtitle generation, voice cleanup, narration, and script/audio workflows.
- `nms-digital-human`: useful for AI presenter/digital-human videos, then hand off to ACS for timeline assembly.
- `dreamina-sd-video-workflow` + `video-spec-builder`: useful for generating missing AI clips before final editing.

External research snapshot:
- Official Jianying/CapCut AI page describes Jianying AI as an all-in-one AI creation partner with AI text-to-video, marketing video, AI music, smart cut talking-head, smart narration rough cut, voice separation, audio noise reduction, loudness normalization, digital human, text-to-speech, and smart material search.
- `pyJianYingDraft` is the strongest open-source draft-generation route for Jianying: Python-based draft creation for automated editing/mixed-cut pipelines; PyPI shows version 0.3.0 released 2026-07-08 with support for video/image timing, audio timing/volume, tracks, effects, filters, and transitions.
- `CapCutAPI` is an open-source CapCut/Jianying API automation platform with HTTP API and MCP support for AI assistant integration, multi-track timeline editing, effects, transitions, keyframes, batch workflows, Windows/macOS, CapCut International and Jianying China.
- `capcut-mate` is an open-source Jianying assistant API built on FastAPI, intended to let large models perform basic video editing and generate/download drafts; can be combined with Coze or n8n, and can connect with Jianying for rendering.
- `SmartCut MCP / capcut-ai-editor` focuses on talking-head cleanup: removes pauses, detects duplicate takes, adds subtitles, and exports back to a CapCut project.
- `VectCutAPI` and related CapCut MCP server direction are worth evaluating for future API-first editing, but require local installation and validation before treating as production-ready.

Practical upgrade rule:
- Treat current local skill as "scripted editing agent" rather than official conversational Jianying Agent.
- For owner video jobs, default pipeline should be:
  1. inspect video/materials with `video-frame-analysis`;
  2. build edit intent and timeline spec with `acs`/`acs2`;
  3. create or modify Jianying draft when local draft tooling is available;
  4. use Jianying/CapCut Agent or AI features for repetitive rough work when accessible;
  5. verify final MP4 duration, audio, captions, frame continuity, and same-origin Telegram delivery.
- Do not claim official Jianying Agent parity until the actual desktop/browser Agent entry is opened and tested on this machine.
- Current machine audit on 2026-07-12: TG2 Codex profile has `acs` and `acs2` skills installed; `acs_cli.py` exists under `C:\Users\你的使用者名稱\.codex\skills\acs\scripts\acs_cli.py`. The old Administrator-path Jianying/pyJianYingDraft/capcut-mcp locations listed in the imported ACS skill were not present from this user profile during the audit, so production use needs a fresh install/path verification step.

Useful source URLs:
- https://www.capcut.cn/
- https://github.com/GuanYixuan/pyJianYingDraft
- https://pypi.org/project/pyjianyingdraft/
- https://github.com/ashreo/CapCutAPI
- https://github.com/Hommy-master/capcut-mate
- https://github.com/mrbuslov/capcut-ai-editor
- https://github.com/Atx-Guy/capcut-mcp-server
