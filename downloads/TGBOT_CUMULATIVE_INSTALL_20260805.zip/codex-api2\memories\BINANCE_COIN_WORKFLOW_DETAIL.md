# 幣安 Coin 詳細工作流

建立日期：2026-07-11

## 1. 觸發詞

收到以下任一說法，要啟動幣安 Coin 工作流：

- 幣安coin
- 幣安 coin
- Binance coin
- 查詢coin
- 查詢 coin
- 查coin
- 分析幣
- 研究幣
- 幫我看這個幣
- 幣名、代號、合約地址、Ave.ai 連結、交易對地址

主人說 `幣安coin` 時，意思是 Binance／OKX 熱門迷因幣與土狗幣每日分析，不是查幣安平台教學。

## 2. 完整完成標準

完整完成必須包含：

1. 繁體中文文字研究報告。
2. 可保存的文件版報告。
3. 9:16 黑金金融風圖卡。
4. 圖卡下載平台原圖。
5. 驗證圖片可開啟、檔案大小合理、比例接近 9:16。
6. 圖面顯示資料抓取時間與送出生成時間，送出生成時間要到幾點幾分。
7. Telegram 文件模式回傳。

若圖卡未完成或未回傳，只能說部分完成，不可說全部完成。

## 3. 每次第一步

1. 讀技能：`.codex\skills\binance-coin-research\SKILL.md`
2. 讀記憶：
   - `.codex\memories\binance_okx_hot_meme_daily_1000_20260701.memory.md`
   - `.codex\memories\coin_query_alias_workflow_20260701.memory.md`
   - `.codex\memories\coin_contract_research_workflow_20260630.memory.md`
   - `.codex\memories\ave_ai_research_workflow_20260629.memory.md`
3. 若是即時幣種判斷，必須查最新資料並附來源。
4. 若主人給單一幣名或合約地址，先確認鏈與合約，避免同名假幣。

## 4. 每日報告資料範圍

每日固定檢查：

1. Binance 最新上幣、公告、Launchpool、Alpha、熱門榜、市場熱度。
2. OKX 最新上幣、公告、Jumpstart、熱門榜、市場熱度。
3. CoinGecko、DexScreener、Ave.ai、鏈上瀏覽器與相關 DEX。
4. YouTube、抖音、X、Telegram、官網、白皮書、GitHub、新聞稿、交易所公告與 KOL 討論。

## 5. 每日報告內容

報告至少包含：

1. 今日結論：最值得放前排觀察的 3 到 5 個幣。
2. 判斷邏輯：交易所熱度、鏈上數據、流動性、社群熱度是否互相支持。
3. 每個候選幣：鏈、合約地址或尚未確認、交易對、價格、24 小時變化、流動性、交易量、持幣地址、池子變化、主要風險。
4. 今天最不建議追的幣：資料不足、過熱、流動性差、持幣過度集中或疑似洗量。
5. 實戰策略：只給觀察與風險控管，不保證獲利。
6. 來源連結。
7. 明確標示非投資建議。

## 6. 單幣合約研究順序

收到單一幣名、代號、CA、合約地址或 Ave.ai 連結時：

1. 確認鏈與正確合約地址。
2. 查 Ave.ai：價格、市值、流動性、交易量、持幣數、聰明錢、開發者錢包、風險標籤、池子資料。
3. 查鏈上瀏覽器：合約是否開源、建立者、權限、是否放棄權限、是否可增發、黑名單、暫停交易、改稅率、代理升級。
4. 查 DEX：交易對、池子深度、LP 狀態、是否可交易、最近加池或撤池、滑價與價格衝擊。
5. 查審計：報告來源、日期、合約地址是否一致、重大風險是否已修。
6. 查持幣結構：前十持倉、團隊／市場／可疑地址、大戶轉帳、早期狙擊、同資金來源錢包。
7. 查發幣方與市場熱度：官網、白皮書、GitHub、YouTube、抖音、X、Telegram、KOL、留言品質、是否疑似業配洗量。
8. 給主人結論：安全度、主要風險、發幣方可信度、熱度真假、可觀察買點、賣出警戒、資料缺口。

## 7. 合約核對規則

重要升級：

- DexScreener 同名配對不可直接當官方合約。
- 先用 CoinGecko 搜尋與合約平台資料核對。
- 核對成功才可標示「CoinGecko 合約已核對」。
- 若未通過 CoinGecko 或官方合約核對，報告要標示「同名配對參考」。
- 不可只憑同名地址判斷安全。

## 8. 圖卡要求

幣安 Coin 圖卡固定要求：

- 比例：9:16 直式。
- 風格：黑金金融、交易所雷達、迷因幣熱度榜、鏈上監控感。
- 主視覺：前 3 名完整排行卡。
- 第 4、5 名：放底部觀察名單一行。
- 必須顯示資料抓取時間與送出生成時間。
- 送出生成時間必須使用真正送進藍星平台當下的本機時間，格式 `yyyy/MM/dd HH:mm`。
- 必須標示非投資建議。
- 禁止保證獲利、暴富承諾、假字、亂碼、方形輸出。

## 9. 建議執行腳本

每日穩定版：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\send-binance-okx-hot-meme-report.ps1
```

排程入口：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run-binance-okx-hot-meme-daily.ps1
```

測試不發 Telegram 且不做圖：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\send-binance-okx-hot-meme-report.ps1 -Preview -NoTelegram -SkipPoster
```

只檢查預檢：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\send-binance-okx-hot-meme-report.ps1 -PreflightOnly -NoTelegram
```

## 10. 成功圖卡流程

1. 完整重跑文字報告、文件版報告與圖卡提示詞。
2. 優先檢查已登入 Chrome CDP，成功端口以 `http://127.0.0.1:9444` 為優先。
3. 補跑圖卡前重新建立提示詞，寫入真正送出生成當下的 `送出生成時間：yyyy/MM/dd HH:mm`。
4. 用 `lanxin-pro-daily-poster.js direct`、`--size=2K`、`--ratio=9:16` 直接送出並下載原圖。
5. 驗證圖片可開啟、檔案大小合理、高度大於寬度，比例接近 9:16。
6. 目視確認圖面有「送出生成時間」且包含幾點幾分。
7. 若文字報告與文件版已傳過，補跑成功後只補傳新的圖卡原圖一次。

## 11. 卡點處理

- 資料來源查不到：標示尚未確認，不可補編。
- 交易所或鏈上資料卡住：先交付已確認文字分析與待查清單。
- 藍星卡住：保留文字報告與圖卡提示詞，主動補跑。
- 登入、驗證、付款、額度、權限或平台持續失敗：停止並回報主人。
- 圖卡未完成：不可說工作流已完成。

## 12. 給主人的完成回覆範例

```text
幣安 Coin 已完成，文字報告、文件版與 9:16 圖卡原圖都已回傳。圖卡已驗證為直式，並包含資料抓取時間與送出生成時間。🌷
```

若圖卡卡住：

```text
幣安 Coin 文字報告與文件版已完成，但圖卡還沒成功回傳，所以目前只能算部分完成。卡在藍星平台登入／驗證／額度／權限處理；報告與提示詞已保留，卡點解除後可直接補跑圖卡。🌷
```
