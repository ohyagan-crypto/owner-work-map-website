---
name: lanxin-image-workflow
description: Run the user's Lanxin/藍星 AI image generation workflow. Use when Codex needs to generate images on lanxinai.com, check UID/VIP/credits, preserve user prompts without rewriting, submit image jobs, download original images, save outputs, and deliver generated images back to the user.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Lanxin Image Workflow

Owner-facing naming rule: call Lanxin / 蘭心 / Lanxin AI `藍星` in replies, tutorials, status reports, and completion messages. Keep `lanxin` only for URLs, API names, credential service names, file paths, and internal compatibility.

Use this skill when the user says 做圖, 製作圖片, 到藍星做圖, Lanxin, or requests generated posters/assets through the user's Lanxin workflow.

## Confirmation Checklist

Before generation, include or internally verify:

- Account/Model: UID and VIP status when available.
- Credits: current Dreamina/Lanxin credits checked live before generation when possible.
- Cost: estimated credit consumption for the task.
- Remaining: estimated credits after generation.
- Prompt: use the user-provided or confirmed prompt exactly.

## Hard Prompt Rule

The user has fixed this rule: do not compress, rewrite, delete, or alter user-provided or confirmed prompts for image generation. If the platform requires changes, explain first and get explicit confirmation.

## Workflow

1. Open Lanxin or use existing scripts/session when available.
2. Check account state, balance/credits, UID/VIP if possible.
3. Submit the exact prompt and selected references.
4. Monitor completion.
5. Download original quality image when possible.
6. Save output with a descriptive filename.
7. Deliver the image directly when possible; if not, provide the local path and reason.

## API Auth Self-Repair

If Lanxin/OpenAI-compatible requests fail with 401, missing API key, or `API_KEY_REQUIRED`,
do not show the raw English/API error to the operator. First run:

`C:\Users\Administrator\CodexTelegramHealth\repair-lanxin-api-auth.ps1`

Then retry the request once. If it still fails, report briefly in Traditional Chinese:
`主人 Lanxin 金鑰自動修復後仍失敗，需要重新確認金鑰 🌷`

## Known Local Pattern

Lanxin original download endpoint can return base64 image data:

`https://www.lanxinai.com/api/v1/user/images/history/{id}?timezone=Asia%2FShanghai`

Response path:

`data.images[0].url`

## Defaults

- Traditional Chinese replies.
- Preserve image quality; do not compress unless the user asks.
- Use 財寶府庫, 庫裡, 嵐熙, 蝦妹 memory if relevant.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














