---
name: dreamina-cli
description: Use when the operator says 做sd, sd, sdf, sdv, Dreamina, Seedance, 即夢, 生成影片, or asks to submit, query, download, verify, or deliver AI video jobs through Dreamina CLI.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Dreamina CLI

## Dreamina fixed login reuse policy - 2026-07-09

- Keep using the current local Dreamina CLI login/session by default.
- Do not run `dreamina logout` or `dreamina relogin` unless the owner explicitly asks to switch accounts or clear the current account.
- Before asking the owner to authorize again, always verify the existing session with `C:\Users\max\dreamina.exe user_credit` and `C:\Users\max\dreamina.exe list_task --limit=5`.
- If both checks succeed, continue the task with the current login and do not start OAuth again.
- If a command fails, inspect real CLI state, job records, and logs before requesting authorization. Do not reuse old Device Flow links or expired codes.
- Request new authorization only for a real external blocker: expired/invalid OAuth required by platform, CAPTCHA, 2FA/passkey/SMS/email approval, account security/risk check, permission change, or owner-requested account switch.
- Current verified account on 2026-07-09: user_id `[REDACTED_NUMBER]`, vip_level `standard`, total_credit `857`. Credit/task query works, but generation may still be blocked by missing CLI permission or insufficient membership. Treat that as an account permission blocker, not a login failure.

## 2026-07-06 SD Standard Flow Update

- For `sd`, `sdf`, and `sdv`, use the latest standard flow memory: `C:\Users\max\.codex\memories\sd_video_generation_standard_flow_20260706.memory.md`.
- Fixed current paths: Lanxi image `C:\Users\max\lanxi_new.png`, Lanxi dialogue `C:\Users\max\lanxi_dialogue.mp3`, Kuli listed image `C:\Users\max\kuli.jpg`, Kuli dialogue `C:\Users\max\kuli_dialogue.mp3`, full prompt template `C:\Users\max\Desktop\龍蝦記憶\memory_upgrade_20260706\SD提示詞_嵐熙庫裡_終極版.md`.
- Owner correction on 2026-07-16: `C:\Users\max\kuli.jpg`, showing the black hoodie / orange drawstrings / peeled banana image, is the confirmed Kuli generation reference. Use it unless the owner provides a newer replacement.
- When the owner says `sd提示詞` or `萬用提示詞`, use the complete 8-dimension SD template. Do not submit a shortened prompt when the full template is requested.
- Known audio limitation: do not submit Lanxi and Kuli dialogue audio together in one generation if the route fails with dual audio. Choose one speaking character audio; the other character is visual-only unless a supported route is confirmed.
- Confirmation checklist must include full prompt, exact materials, selected one-audio choice, model version, duration, ratio, resolution, estimated credit cost, remaining credits, route, expected command/API, and known blockers.

用於 SD/SDF/SDV/Dreamina/Seedance 影片生成、查詢、下載、驗證與 Telegram 回傳。

## 每次先做的環境設定

```powershell
$env:PATH = "C:\Users\max\Downloads;C:\Users\max\AppData\Roaming\npm;C:\Users\max\PortableGit\cmd;C:\Users\max\PortableGit\bin;C:\Users\max\PortableGit\mingw64\bin;" + $env:PATH
```

固定執行檔：

```powershell
C:\Users\max\dreamina.exe
```

目前已檢查版本：`2a20fff-dirty`，建置時間 `2026-06-26T06:36:39Z`。

## 回覆與執行鐵律

- 對主人只回乾淨繁體中文；不要輸出 raw log、JSON dump、英文堆疊、token、cookie、金鑰或工具偵錯文字。
- 主人說 `stop`、重做、不要參雜舊任務時，下一個 SD 任務必須從當次素材與最新需求重判，不沿用舊圖片、角色、音訊、產品、劇情或提示詞。
- 有圖片、影片、音訊素材時，先確認當次 Telegram 下載的精確本機路徑；不可只看聊天摘要。
- 任何會消耗積分的生成，送出前必須先給確認清單並等主人明確確認。
- 若同一任務已完成確認清單，主人下一則回「確認」就要直接提交，不可再停在二次確認。
- 提交成功必須取得 `submit_id` 或明確任務 id，並寫入工作紀錄。沒有 id、沒有扣積分、查不到任務狀態，不算已提交。
- 主人問「提交了嗎、好了沒、卡住沒」時，先查工作紀錄、`query_result` 或 `list_task`，再回答真實狀態。

## CLI 快速檢查指令

```powershell
dreamina version
dreamina user_credit
dreamina list_task --limit=5
```

如果 `user_credit` 沒有正常回傳積分，不可宣稱可提交；先走登入檢查。

## 登入與授權

```powershell
dreamina login
dreamina login --headless
dreamina login checklogin --device_code=<device_code> --poll=30
dreamina relogin
```

若出現平台安全確認、OAuth 裝置碼、CAPTCHA、手機/信箱/2FA、帳號風控，停止重試並回報需要主人外部處理；不要猜驗證碼或繞過安全檢查。

## 授權登入後執行標準

- 主人已完成同帳號授權後，下一步固定先查 `version`、`user_credit`、`list_task --limit=5`，確認 CLI、積分與任務列表可用。
- `user_credit` 成功回傳 UID、積分與會員狀態時，視為 Dreamina CLI 登入態正常；不可再要求主人重新授權。
- 若主人已經對同一個 SD/SDF 任務回覆「確認」、「好」、「送出」或等同明確同意，登入正常後要直接提交任務並取得 `submit_id`，不可回到二次確認或二次授權。
- 若 `user_credit` 或 `list_task` 暫時失敗，先檢查 CLI 可執行檔、本機授權狀態、工作紀錄與任務查詢；只有平台實際要求 OAuth、CAPTCHA、2FA、帳號安全確認、授權過期或帳號風控時，才請主人重新處理授權。
- 狀態回覆要直接給結論：CLI 是否正常、UID/VIP/積分是否查到、最近任務是否存在、是否已提交、是否扣分；不可只回正在處理。

## 常用查詢與下載

查詢單一任務：

```powershell
dreamina query_result --submit_id=<id>
```

查詢並下載結果：

```powershell
dreamina query_result --submit_id=<id> --download_dir <artifact_dir>
```

列出任務：

```powershell
dreamina list_task --limit=20
dreamina list_task --gen_status=success --limit=20
dreamina list_task --submit_id=<id>
```

下載後必須用媒體工具驗證 MP4 可讀、大小合理、時長與比例接近需求，再回傳 Telegram。

## 影片提交指令選擇

### 1. 多素材全能參考，優先用 `multimodal2video`

適用：圖片 + 音訊、圖片 + 影片、角色圖 + 產品圖 + 音訊、需要 `9:16` 或 `16:9` 明確比例的 SD/SDF VIP 任務。

```powershell
dreamina multimodal2video --image <image> --audio <audio> --model_version=seedance2.0fast_vip --duration=<4-15> --ratio=9:16 --video_resolution=720p --prompt <prompt> --poll=10
```

已確認限制：

- 至少要有一個 `--image` 或 `--video`。
- `--image` 最多 9 個，`--video` 最多 3 個，`--audio` 最多 3 個。
- 音訊必須 2 到 15 秒。
- 模型可用：`seedance2.0`、`seedance2.0fast`、`seedance2.0_vip`、`seedance2.0fast_vip`、`seedance2.0mini`。
- 比例可用：`1:1`、`3:4`、`16:9`、`4:3`、`9:16`、`21:9`。
- `seedance2.0_vip` 可用 `720p`、`1080p`、`4k`；其他模型通常只用 `720p`。

### 2. 單張首圖轉影片，用 `image2video`

適用：只有一張首圖，且比例要跟圖片本身走。

```powershell
dreamina image2video --image <image> --prompt <prompt> --model_version=seedance2.0fast_vip --duration=<4-15> --video_resolution=720p --poll=10
```

注意：`image2video` 的比例由輸入圖片推斷，不能用 `--ratio` 手動指定。若主人要求固定 `9:16` 或 `16:9`，先確認首圖比例正確，或改用 `multimodal2video`。

### 3. 文字生影片，用 `text2video`

適用：沒有素材，純文字生成影片。仍需提交前確認，且要先查積分。

```powershell
dreamina text2video --prompt <prompt> --model_version=<model> --duration=<seconds> --ratio=9:16 --video_resolution=720p --poll=10
```

## 長提示詞處理

- 不要把超長提示詞塞進單一 Windows 命令。
- 先把提示詞存到短路徑文字檔，例如 `C:\Users\max\dreamina_work\<task>\prompt.txt`。
- 若 CLI 支援提示詞檔案參數，使用檔案參數；若只支援 `--prompt` 字串，先精簡命令行，只保留確認過的完整提示詞文字，不插入未確認改寫。

## 提交前確認清單

提交前必須包含：

- 帳號/UID/VIP 狀態。
- 目前積分。
- 模型與計費模式。
- 預估積分消耗、人民幣價格、台幣估算、預估剩餘。
- 秒數、比例、解析度。
- 指令路由：`multimodal2video`、`image2video`、`text2video`，或 New API。
- 素材：圖片、角色圖、音訊、產品圖、影片參考、分鏡圖。
- 完整提示詞。
- 可能卡點：文字準確度、臉部一致性、音訊限制、比例限制、登入/授權/積分/提交失敗。

## 素材與角色規則

- 當次素材最高優先。
- 嵐熙固定素材可用：`C:\Users\max\lanxi_new.png`、`C:\Users\max\lanxi_voice_ref.mp3`。
- 庫裡素材最新修正（2026-07-16）：黑帽 T、橘色抽繩、拿香蕉這張已確認為正式庫裡素材，固定使用 `C:\Users\max\kuli.jpg`，除非主人提供更新版本。
- 嵐熙 + 庫裡有台詞時，優先用合併對話音檔：`C:\Users\max\lanxi_kuli_dialogue_ref.mp3`。
- 台南保養品課程故事若使用嵐熙 + 庫裡，方向是「兩人到台南上課並展示保養品」，結尾必須包含：「你知道我是 AI 嗎」。

## New API 路由不要混用

若主人明確提到 `zz1cc.cc.cd`、New API、或沿用 `video-ds-2.0-fast` / `video-ds-2.0` 成功流程，不走 Dreamina CLI 提交，改走直接 API：

- Submit：`POST https://zz1cc.cc.cd/v1/videos`
- Query：`GET https://zz1cc.cc.cd/v1/videos/<task_id>`
- Download：`GET https://zz1cc.cc.cd/v1/videos/<task_id>/content`

不得列印或保存明文 API key。參考成功記憶：`C:\Users\max\.codex\memories\dreamina_zz1cc_video_sd_success_flow_20260628.memory.md`。

## 提交後工作紀錄

提交後立即建立或更新：

```text
C:\Users\max\dreamina_task\jobs
```

工作紀錄至少包含：

- `ChatId`
- `SubmitId`
- `Route`
- `Model`
- `Duration`
- `Ratio`
- `Resolution`
- `PromptPath`
- `Materials`
- `CreditBefore`
- `CreditCost`
- `CreditAfter`
- `OutputStatus`
- `NextCheckAtUtc`
- `ArtifactFolder`
- `DeliveredFiles`

若下一步只是等生成，`NextCheckAtUtc` 設為 3 到 5 分鐘後；下一次必須查真實狀態，不可只看 CPU 或沒有輸出。

## 下載、驗證、Telegram 回傳

1. 從 `query_result` 或 API query 取得影片下載資訊。
2. 下載到任務資料夾，優先放在 `C:\Users\max\Desktop\榫嶈潶瑷樻喍` 的日期子資料夾。
3. 驗證 MP4 可讀、檔案大小合理、時長與比例接近需求。
4. Telegram 用文件模式回傳原始 MP4 或乾淨副本。
5. 只可傳到 `$env:TELEGRAM_ORIGIN_CHAT_ID`，使用 `C:\Users\max\tg-openai-bot\tools\send_telegram_document.ps1`。
6. 若 `TELEGRAM_ORIGIN_CHAT_ID` 缺失，不可上傳；回報本機備份路徑與卡點。

## 卡點處理

以下情況不可假裝處理中：

- CLI 無輸出、沒有任務 id、沒有扣積分，且查不到狀態。
- `user_credit` 查不到積分。
- 登入失效、OAuth 未完成、平台安全驗證、積分不足、平台錯誤。
- 高風險內容首次使用需要 Dreamina Web 授權確認。
- 下載連續失敗。
- 影片檔驗證失敗。
- Telegram 無來源 chat id 或上傳失敗。

同一關鍵步驟失敗 3 次後停止重跑，回報具體卡點與下一步需要什麼。

## 同帳號授權沿用硬規則

- 2026-07-06 owner correction: Dreamina CLI / SD / SDF 任務只要主人已完成同帳號授權，就必須沿用既有 CLI 登入態與本機授權資料。
- 主人下驗證單、確認送出或要求繼續提交後，不可再次要求主人重新驗證，除非主人明確說要改帳號，或平台實際回傳安全驗證、授權過期、帳號風控、CAPTCHA、手機/信箱/2FA、掃碼 OAuth 重新授權等外部安全卡點。
- 若提交前 `user_credit`、`list_task` 或 `query_result` 失敗，先檢查本機 CLI 狀態、授權檔、任務紀錄與實際錯誤；不要直接把失敗等同於「請主人重新驗證」。
- 若同一帳號授權剛完成，下一步應立即查積分與任務列表，成功後直接提交已確認的 SD/SDF 任務，取得 `submit_id`，不可回到二次授權或二次確認。
- 只有在確認為外部安全驗證卡點時，才用乾淨繁體中文回報需要主人操作，並說明是平台要求，不得用固定式進度或籠統登入失敗回覆。

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->










