# Coin Contract Research Workflow

Created: 2026-06-30

## Owner Instruction

The owner asked to permanently remember this coin research flow:

- For all future coin/token information, use Ave.ai, the relevant block explorer, and PancakeSwap when applicable.
- Learn to use a contract address to inspect a token fully.
- Check audit reports, full liquidity pool data, holder percentages, holder address condition, possible project-side insider/rat trading, ownership renounce status, and smart contract details.
- For the `查詢coin` alias workflow, expand research beyond on-chain sources to YouTube, 抖音, X/Twitter, Telegram, official website, whitepaper, GitHub, news releases, exchange announcements, KOL discussions, and community sentiment. Use these to judge issuer/team quality, market heat, promotion credibility, and whether social hype matches on-chain data.
- This applies to `PRO`, `昨天的 pro`, token names, tickers, CA/contract addresses, pair addresses, Ave.ai links, and general coin safety questions.

## Default Flow

1. Identify chain and exact contract address first.
2. Query Ave.ai for token overview, chart, liquidity, holders, smart money, developer wallet, risk labels, security signals, and pool data.
3. Query the correct block explorer for contract source, creator, owner/admin, proxy/upgradeability, mint/blacklist/pause/tax controls, transfer history, holder list, and renounced ownership evidence.
4. Query PancakeSwap or the relevant DEX for active pair, pool depth, LP token status, liquidity add/remove history, route, price impact, and tradability.
5. Find and inspect audit reports if available. Verify the audited contract matches the deployed contract and summarize unresolved risks.
6. Analyze liquidity pool: TVL, token/quote ratio, LP holder concentration, lock/burn status, recent pool changes, and drain risk.
7. Analyze holder structure: top holder percentages, top 10 concentration, team/dev/marketing wallets, burn/pool/exchange/router addresses, wallet clusters, whales, and suspicious concentration.
8. Check for project-side insider behavior: creator/dev wallet activity, sniper wallets, same-funding-source wallets, bundled buys, coordinated sells, hidden large wallets, and unusual early allocations.
9. Check smart contract permissions: ownership renounced or not, privileged owner functions, timelock/multisig, upgrade permissions, minting, blacklist/whitelist, pause, fee/tax changes, and transfer limits.
10. Check issuer/team and market heat: YouTube/抖音 video volume, posting dates, views, engagement quality, comments, KOL credibility, possible paid promotion, duplicate scripts, fake traffic signals, X/Twitter and Telegram activity, official site/whitepaper/GitHub maturity, news or exchange announcements, and whether public hype is supported by liquidity, holders, and real trading depth.
11. Reply with a clear risk conclusion, evidence, missing data, source links, issuer credibility, market heat quality, and hype-vs-on-chain consistency. Do not claim certainty or investment advice.

## Report Format For Owner

Use this order when the owner asks for a token check:

- 結論：安全度 / 主要風險 / 是否需要避開或只觀察。
- 基本資料：鏈、合約地址、交易對、價格、市值、流動性、交易量。
- 合約與權限：是否開源、是否可升級、是否放棄權限、是否有鑄造/黑名單/暫停/稅率修改等危險權限。
- 底池：池子深度、LP 鎖定或銷毀、LP 持有人、近期加池/撤池。
- 持幣地址：持有人數、前十大占比、項目方/巨鯨/可疑地址。
- 老鼠倉與內線跡象：早期買入、同源錢包、狙擊、集體出貨、DEV 行為。
- 審計：是否有報告、報告來源、日期、合約是否對得上、未修風險。
- 發幣方與市場熱度：團隊/發幣方資質、官網/白皮書/GitHub、YouTube/抖音/X/Telegram 聲量、KOL 品質、留言互動、是否疑似業配洗量、熱度是否和鏈上數據一致。
- 資料來源：Ave.ai、區塊鏈瀏覽器、PancakeSwap/DEX、審計或官方連結。

## Safety

- Always prefer exact contract address plus chain over token name.
- If data cannot be verified, say which parts are unknown instead of guessing.
- Crypto token checks are risk analysis only, not guaranteed safety or financial advice.

## 2026-06-30 Owner Fixed Coin Info Checklist

When the owner asks anything about a coin/token, and provides only a token name, symbol, or contract address, this checklist is mandatory. If only a name/symbol is provided, first identify the correct chain and contract address before analysis because duplicate token names are common.

Required checks:

1. Daily token price and daily price change.
2. Trade timing reference: combine available indicators, price trend, volume, buy/sell counts, liquidity depth, and risk signals to explain possible buy-watch and sell-watch zones. Do not present it as guaranteed financial advice.
3. Daily liquidity pool increase or decrease, including TVL/liquidity changes and recent add/remove liquidity activity.
4. Daily trading volume and trading depth, including 24h volume, buy/sell transaction count, and available depth/price-impact signals.
5. Daily pool/token user data, including holder count, active traders, new holders if available, pool participant data, and whale behavior.
6. Ave.ai data checks: token overview, chart, holders, liquidity, smart money, developer wallet, risk labels, security signals, pool data, and wallet behavior.
7. PancakeSwap data checks: pair, pool depth, route, tradability, LP status, liquidity movement, slippage/price impact, and buy/sell behavior when visible.
8. Block explorer data checks: contract verification, creator, owner/admin, permissions, renounce status, transfers, holder distribution, LP/token holder addresses, and suspicious wallet flows.
9. Project-side announcements and catalysts: official notices, airdrops, roadshows, listings, partnerships, positive news, roadmap updates, and other market-moving information. Verify source credibility and date.
10. Social and market heat checks: YouTube, 抖音, X/Twitter, Telegram, official website, whitepaper, GitHub, news, exchange notices, and KOL/community discussions. Evaluate issuer/team quality, whether the project has real product or prior track record, whether attention is organic or paid, and whether social heat matches trading volume, holder growth, and liquidity.

Owner-facing response should be in clean Traditional Chinese and include source links when live data or external verification is used.

## 2026-07-01 Owner Alias Update

The owner set fixed trigger phrases for this workflow:

- `查詢coin`, `查詢 coin`, or `查coin` means run the coin research workflow.
- `查詢call in`, `查詢 call in`, or `查詢callin` also means run the coin research workflow.
- `查詢coin` is the umbrella alias for the whole coin research workflow, including the social/platform heat and issuer credibility checks.
- These phrases mean the full workflow: coin lookup, daily monitoring, and poster creation when needed, not only a price check.
- If the alias is used without a token name, contract address, chain, pair, Ave.ai link, or active image/material context, ask the owner for the missing target instead of guessing.
- If the target is `PRO`, `Pro Token`, `Pro-USDT`, or `proims`, apply the PRO daily monitoring and 9:16 black-gold poster workflow.
