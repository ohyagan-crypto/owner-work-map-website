﻿$ErrorActionPreference = "Stop"

$runner = "C:\Users\Administrator\.codex\skills\notebooklm-brief-to-deck-workflow\scripts\nbs-runner.js"
$root = "C:\tmp\nbs-automation"
$mainState = Join-Path $root "nbs-state.json"
$statesDir = Join-Path $root "states"
$log = Join-Path $root "nbs-auto-check.log"
$tgConfig = "C:\Users\Administrator\appsettings.Local.json"
$defaultChatId = "[REDACTED_NUMBER]"

New-Item -ItemType Directory -Path $root -Force | Out-Null
New-Item -ItemType Directory -Path $statesDir -Force | Out-Null

function Write-NbsLog {
    param([string]$Message)
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $log -Value "$stamp $Message" -Encoding UTF8
}

function TextFromCodepoints {
    param([int[]]$Codepoints)
    $builder = [System.Text.StringBuilder]::new()
    foreach ($codepoint in $Codepoints) {
        [void]$builder.Append([System.Char]::ConvertFromUtf32($codepoint))
    }
    return $builder.ToString()
}

function Send-TelegramText {
    param([string]$Text)
    try {
        if (-not (Test-Path $tgConfig)) { return }
        $raw = Get-Content $tgConfig -Raw -Encoding UTF8
        $raw = $raw.TrimStart([char]0xFEFF)
        $cfg = $raw | ConvertFrom-Json
        $token = $cfg.TelegramBot.Token
        if ([string]::IsNullOrWhiteSpace($token)) { return }
        Invoke-RestMethod -Uri "https://api.telegram.org/bot$token/sendMessage" -Method Post -Body @{
            chat_id = $defaultChatId
            text = $Text
        } | Out-Null
    } catch {
        Write-NbsLog "notify error"
    }
}

function Run-NodeJson {
    param(
        [string]$StatePath,
        [string[]]$Arguments
    )
    $previous = $env:NBS_STATE
    $env:NBS_STATE = $StatePath
    try {
        $output = & node $runner @Arguments 2>&1
    } finally {
        $env:NBS_STATE = $previous
    }
    $text = ($output | Out-String).Trim()
    Write-NbsLog "state=$StatePath node $($Arguments -join ' ')"
    if ([string]::IsNullOrWhiteSpace($text)) {
        throw "No output from nbs-runner"
    }
    $json = $null
    foreach ($line in ($text -split "`r?`n")) {
        $trim = $line.Trim()
        if ($trim.StartsWith("{") -and $trim.EndsWith("}")) {
            try { $json = $trim | ConvertFrom-Json } catch { }
        }
    }
    if ($null -eq $json) {
        try { $json = $text | ConvertFrom-Json } catch { }
    }
    if ($null -eq $json) {
        throw "No valid JSON output from nbs-runner"
    }
    return $json
}

function Schedule-NextCheck {
    param([int]$Minutes)
    $next = & node $runner schedule --minutes $Minutes 2>&1
    Write-NbsLog "scheduled next check in $Minutes minutes"
}

function Process-State {
    param([string]$StatePath)
    if (-not (Test-Path $StatePath)) { return $false }
    try {
        $status = Run-NodeJson $StatePath @("status", "--brief", "1")

        if ($status.needsLogin) {
            Write-NbsLog "needsLogin state=$StatePath"
            Send-TelegramText (TextFromCodepoints @(20027,20154,32,27298,26597,65306,38656,35201,30331,20837,32,78,111,116,101,98,111,111,107,76,77,65292,35531,20808,34389,29702,30331,20837,47,39511,35657,32,127872))
            return $false
        }

        if ($status.ready) {
            Write-NbsLog "ready state=$StatePath"
            Send-TelegramText (TextFromCodepoints @(20027,20154,32,27298,26597,65306,24050,29983,25104,22909,65292,27491,22312,19979,36617,20006,20659,36865,32,78,111,116,101,98,111,111,107,76,77,32,21407,29983,27284,26696,32,127800))
            $download = Run-NodeJson $StatePath @("download")
            if (-not $download.ok) { throw "download failed" }
            $send = Run-NodeJson $StatePath @("send", "--file", $download.file)
            if (-not $send.ok) { throw "send failed" }
            Write-NbsLog "sent-or-skipped state=$StatePath message_id=$($send.message_id)"
            if ($StatePath -ne $mainState) {
                Remove-Item -LiteralPath $StatePath -Force -ErrorAction SilentlyContinue
            }
            return $false
        }

        Write-NbsLog "still generating state=$StatePath"
        return $true
    } catch {
        Write-NbsLog "error state=$StatePath"
        Send-TelegramText (TextFromCodepoints @(20027,20154,32,78,66,83,32,33258,21205,27298,26597,22833,25943,65292,35531,25163,21205,27298,26597,32,78,111,116,101,98,111,111,107,76,77,32,29376,24907,32,128166))
        return $false
    }
}

Write-NbsLog "auto check started"
$anyGenerating = $false

$stateFiles = @()
if (Test-Path $mainState) { $stateFiles += $mainState }
$stateFiles += @(Get-ChildItem -Path $statesDir -Filter "*.json" -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
$stateFiles = $stateFiles | Select-Object -Unique

foreach ($stateFile in $stateFiles) {
    if (Process-State $stateFile) { $anyGenerating = $true }
}

if ($anyGenerating) {
    Schedule-NextCheck 5
    Send-TelegramText (TextFromCodepoints @(20027,20154,32,27298,26597,65306,36996,22312,29983,25104,20013,65292,23578,26410,23436,25104,65292,19979,19968,27425,32004,32,53,32,20998,37912,24460,32,127799))
}
