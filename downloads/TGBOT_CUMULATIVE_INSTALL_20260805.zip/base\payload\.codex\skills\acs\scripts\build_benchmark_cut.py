import json
import subprocess
from pathlib import Path


FFMPEG = Path(r"C:\Tools\ffmpeg\ffmpeg.exe")
ROOT = Path(r"C:\Users\Administrator\Desktop\剪映專屬")
BENCHMARK = ROOT / "對標影片" / "benchmark_20260604_143326.mp4"
MATERIALS = ROOT / "素材"
OUT_DIR = ROOT / "輸出"
WORK = Path(r"C:\Users\Administrator\CodexDesktopCapture\acs-analysis\build")
SAFE_OUT_DIR = Path(r"C:\Users\Administrator\CodexDesktopCapture\acs-analysis\outputs")


SCENES = [
    ("material_01.mp4", 0.0, 7.5, "真人跟AI逛街，差點分不清誰是真的"),
    ("material_01.mp4", 7.5, 3.5, "其實我們都是靠這套AI流程拍出來的"),
    ("material_02.mp4", 0.0, 8.0, "你看她講話和表情都很自然"),
    ("material_02.mp4", 8.0, 6.0, "我也不會發脾氣，還能一直配合拍"),
    ("material_03.mp4", 0.0, 7.0, "讓你看看我能做哪些事情"),
    ("material_03.mp4", 7.0, 5.0, "產品展示、口播、探店都可以"),
    ("material_04.mp4", 0.0, 4.5, "這個畫面真的很乾淨"),
    ("material_04.mp4", 4.5, 4.5, "吃播、試用、帶貨都能接上"),
    ("material_05.mp4", 0.0, 5.0, "所以現在開始"),
    ("material_05.mp4", 5.0, 4.0, "實體店和線上流量都能一起做"),
]


def run(cmd):
    subprocess.run([str(x) for x in cmd], check=True)


def ass_time(seconds):
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    SAFE_OUT_DIR.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)
    segs = []
    timeline = []
    t = 0.0
    for idx, (name, src_start, dur, caption) in enumerate(SCENES, 1):
        inp = MATERIALS / name
        out = WORK / f"seg_{idx:02d}.mp4"
        run([
            FFMPEG, "-y", "-hide_banner",
            "-ss", src_start, "-t", dur, "-i", inp,
            "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1",
            "-r", "30",
            "-an",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            out,
        ])
        segs.append(out)
        timeline.append({"start": t, "duration": dur, "caption": caption, "asset": str(inp)})
        t += dur

    concat = WORK / "concat.txt"
    concat.write_text("".join(f"file '{p.as_posix()}'\n" for p in segs), encoding="utf-8")
    video_only = WORK / "video_only.mp4"
    run([FFMPEG, "-y", "-hide_banner", "-f", "concat", "-safe", "0", "-i", concat, "-c", "copy", video_only])

    bgm = WORK / "benchmark_audio.m4a"
    run([FFMPEG, "-y", "-hide_banner", "-i", BENCHMARK, "-vn", "-t", "59.0", "-c:a", "aac", "-b:a", "128k", bgm])

    ass = WORK / "captions.ass"
    header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Microsoft YaHei,62,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,5,0,2,80,80,360,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = [header]
    for item in timeline:
        start = item["start"]
        end = start + item["duration"]
        lines.append(f"Dialogue: 0,{ass_time(start)},{ass_time(end)},Default,,0,0,0,,{item['caption']}\n")
    ass.write_text("".join(lines), encoding="utf-8-sig")

    final = SAFE_OUT_DIR / "acs_benchmark_style_preview.mp4"
    ass_filter_path = str(ass).replace("\\", "/").replace(":", "\\:")
    run([
        FFMPEG, "-y", "-hide_banner",
        "-i", video_only, "-i", bgm,
        "-vf", f"ass='{ass_filter_path}'",
        "-map", "0:v:0", "-map", "1:a:0",
        "-shortest",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-c:a", "aac", "-b:a", "128k",
        final,
    ])
    try:
        import shutil
        shutil.copy2(final, OUT_DIR / final.name)
    except Exception:
        pass
    spec = {
        "benchmark": str(BENCHMARK),
        "output": str(final),
        "duration": t,
        "style": {
            "format": "9:16 Douyin screen-recording style",
            "caption": "large bold white Chinese captions with black outline, lower third",
            "cuts": "hard cuts, fast vlog rhythm, no decorative transitions",
            "audio": "benchmark audio extracted as BGM/reference",
        },
        "timeline": timeline,
    }
    spec_path = WORK / "acs_benchmark_style_spec.json"
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ok": True, "output": str(final), "spec": str(spec_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
