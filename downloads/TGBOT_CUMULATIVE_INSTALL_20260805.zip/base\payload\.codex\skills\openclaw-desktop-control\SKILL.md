---
name: openclaw-desktop-control
description: Imported OpenClaw desktop control notes; use only when local desktop automation is explicitly needed and safe.
---

# Imported From OpenClaw

This skill was copied from `C:\Users\max\.openclaw`. It is available to Codex/TG bot for continuity, but do not call the `openclaw` CLI or OpenClaw-specific tools unless the operator explicitly asks. Prefer Codex built-in tools and existing Codex skills.

Do not expose secrets, raw logs, browser cookies, or auth files while using this skill.

# Desktop Control Skill

_賦予 Codex 操作電腦桌面的能力_

## 能力概覽

| 功能 | 工具/方式 | 需要的環境 |
|------|-----------|-----------|
| 截圖分析 | PowerShell / Python | ✅ 已支援 |
| 滑鼠控制 | PowerShell + User32.dll | ✅ 已支援 |
| 鍵盤輸入 | PowerShell + User32.dll | ✅ 已支援 |
| 應用程式控制 | `start` / `Invoke-Item` / `Start-Process` | ✅ 已支援 |
| OCR 文字辨識 | Tesseract | ⚠️ 需額外安裝 |
| 瀏覽器控制 | OpenClaw Browser Tool | ✅ 已支援 |

---

## 環境檢測

### 必要環境（告訴 Codex 執行）
```powershell
# 檢測 Python
python --version

# 檢測 pip
pip --version

# 檢測 Tesseract
tesseract --version
```

### 必要安裝（告訴 Codex 執行）
```powershell
# 1. 安裝 Python（如果沒有）
# 到 https://python.org 下載 Python 3.10+

# 2. 安裝桌面控制套件
pip install pyautogui pillow pytesseract

# 3. 安裝 Tesseract OCR
# 到 https://github.com/UB-Mannheim/tesseract/wiki 下載，安裝後路徑加入 PATH
```

---

## 功能 1：截圖分析

### PowerShell 截圖
```powershell
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$screenshot = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bitmap = New-Object System.Drawing.Bitmap($screenshot.Width, $screenshot.Height)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.CopyFromScreen($screenshot.Location, [System.Drawing.Point]::Empty, $screenshot.Size)
$bitmap.Save("C:\Users\max\screenshot.png")
```

### Python 截圖
```python
import pyautogui
screenshot = pyautogui.screenshot()
screenshot.save("screenshot.png")
```

### 分析截圖內容（OCR）
```python
import pytesseract
from PIL import Image

img = Image.open("screenshot.png")
text = pytesseract.image_to_string(img, lang='chi_tra+eng')
print(text)
```

---

## 功能 2：滑鼠控制

### PowerShell 移動+點擊
```powershell
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32 {
    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
    public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    public const uint MOUSEEVENTF_LEFTUP = 0x0004;
}
"@

# 移動到座標 (1000, 500)
[Win32]::SetCursorPos(1000, 500)

# 左鍵點擊
[Win32]::mouse_event([Win32]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
[Win32]::mouse_event([Win32]::MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
```

### Python 滑鼠控制
```python
import pyautogui

# 移動到座標
pyautogui.moveTo(1000, 500, duration=0.5)

# 點擊
pyautogui.click(1000, 500)

# 雙擊
pyautogui.doubleClick(1000, 500)

# 右鍵
pyautogui.rightClick(1000, 500)

# 拖曳
pyautogui.drag(200, 0, duration=1)
```

---

## 功能 3：鍵盤輸入

### PowerShell 鍵盤
```powershell
# 輸入文字
[System.Windows.Forms.SendKeys]::SendWait("Hello World")

# 快捷鍵
[System.Windows.Forms.SendKeys]::SendWait("^c")  # Ctrl+C
[System.Windows.Forms.SendKeys]::SendWait("^v")  # Ctrl+V
[System.Windows.Forms.SendKeys]::SendWait("^z")  # Ctrl+Z
[System.Windows.Forms.SendKeys]::SendWait("%{F4}") # Alt+F4
```

### Python 鍵盤
```python
import pyautogui

# 輸入文字
pyautogui.typewrite("Hello World", interval=0.1)

# 按鍵
pyautogui.press("enter")
pyautogui.press("tab")
pyautogui.press("esc")

# 組合鍵
pyautogui.hotkey("ctrl", "c")
pyautogui.hotkey("ctrl", "v")
pyautogui.hotkey("alt", "f4")
pyautogui.hotkey("ctrl", "a")
```

---

## 功能 4：應用程式控制

### 開啟應用
```powershell
# 開啟程式
Start-Process "C:\Path\To\App.exe"

# 開啟 URL（用預設瀏覽器）
Start-Process "https://google.com"

# 開啟資料夾
Invoke-Item "C:\Users\max\Downloads"

# 開啟檔案
Invoke-Item "C:\Users\max\document.pdf"
```

### 關閉應用
```powershell
# 依名稱關閉
Stop-Process -Name "notepad" -Force

# 依視窗標題關閉
Get-Process | Where-Object {$_.MainWindowTitle -like "*Excel*"} | Stop-Process -Force
```

### 列舉視窗
```powershell
Get-Process | Where-Object {$_.MainWindowTitle} | Select-Object Name, MainWindowTitle
```

---

## 功能 5：瀏覽器控制

### OpenClaw Browser Tool（已內建）
```javascript
// 截圖
browser({ action: "screenshot" })

// 導航
browser({ action: "navigate", url: "https://example.com" })

// 點擊元素
browser({ action: "act", kind: "click", ref: "e12" })

// 填入文字
browser({ action: "act", kind: "fill", ref: "e15", text: "輸入內容" })
```

### Selenium WebDriver（進階）
```python
from selenium import webdriver

driver = webdriver.Chrome()
driver.get("https://google.com")
driver.find_element("name", "q").send_keys("搜尋內容")
driver.find_element("name", "btnK").click()
```

---

## 功能 6：OCR 文字辨識

### Tesseract OCR（離線）
```python
import pytesseract
from PIL import Image

# 截圖
img = pyautogui.screenshot("screenshot.png")

# 繁體中文辨識
text = pytesseract.image_to_string(img, lang='chi_tra+eng')
print(text)

# 找特定文字的座標
boxes = pytesseract.image_to_data(img, lang='chi_tra+eng', output_type=pytesseract.Output.DICT)
for i, word in enumerate(boxes['text']):
    if '目標文字' in word:
        x = boxes['left'][i]
        y = boxes['top'][i]
        print(f"找到位置: ({x}, {y})")
```

---

## 整合工作流程

### 典型桌面自動化流程
```
1. 截圖 → 2. OCR 分析畫面 → 3. 找到目標座標 → 4. 移動+點擊 → 5. 等待 → 6. 重複
```

### Python 腳本模板
```python
import pyautogui
import time
from PIL import Image
import pytesseract

def screenshot_and_find(text):
    """截圖並找文字所在座標"""
    img = pyautogui.screenshot("current_screen.png")
    boxes = pytesseract.image_to_data(img, lang='chi_tra+eng', output_type=pytesseract.Output.DICT)
    for i, word in enumerate(boxes['text']):
        if text in word:
            x = boxes['left'][i] + boxes['width'][i] // 2
            y = boxes['top'][i] + boxes['height'][i] // 2
            return x, y
    return None, None

def click_text(text):
    """點擊畫面上的文字"""
    x, y = screenshot_and_find(text)
    if x and y:
        pyautogui.click(x, y)
        return True
    return False

# 使用範例
click_text("開始按鈕")  # 點擊"開始"按鈕
pyautogui.typewrite("輸入內容", interval=0.1)  # 輸入文字
pyautogui.press("enter")  # 按 Enter
```

---

## 安全限制

### 禁止執行的操作
- ❌ 刪除系統檔案
- ❌ 未經確認發送郵件/訊息
- ❌ 格式化磁碟
- ❌ 註冊表修改
- ❌ 下載/執行未知腳本
- ❌ 截圖並外傳敏感資訊

### 需要二次確認的操作
- ⚠️ 執行腳本修改系統設定
- ⚠️ 關閉多個應用程式
- ⚠️ 輸入密碼
- ⚠️ 刪除使用者檔案

---

## 疑難排解

| 問題 | 解決方式 |
|------|----------|
| 截圖空白 | 檢查螢幕解析度設定，嘗試調整座標 |
| 點擊偏移 | 使用 `pyautogui.position()` 確認目前滑鼠位置 |
| OCR 辨識錯誤 | 安裝正確語言包，圖片先做灰階/二值化處理 |
| 視窗被擋住 | 先 `Alt+Tab` 切換到目標視窗 |
| 速度太快 | 加入 `time.sleep(1)` 等待 |
| 座標是 None | 使用 `pyautogui.locateOnScreen()` 圖像比對 |

---

## 快捷指令參考

### PowerShell 常用腳本
```powershell
# 截圖並存檔
Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::PrimaryScreen | ForEach-Object { $bmp = New-Object System.Drawing.Bitmap($_.Bounds.Width, $_.Bounds.Height); $g = [System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($_.Bounds.Location, [System.Drawing.Point]::Empty, $_.Bounds.Size); $bmp.Save("C:\Users\max\capture.png") }

# 取得目前滑鼠座標
Add-Type AssemblyName System.Windows.Forms; [System.Windows.Forms.Cursor]::Position

# 開啟控制台
control

# 開啟工作管理員
taskmgr
```

### Python 常用腳本
```python
# 取得螢幕解析度
import pyautogui
width, height = pyautogui.size()
print(f"{width}x{height}")

# 取得目前滑鼠座標
x, y = pyautogui.position()
print(f"({x}, {y})")

# 等待指定時間
import time
time.sleep(2)  # 等待2秒

# 滾動頁面
pyautogui.scroll(-500)  # 向下500單位
```

---

_此 Skill 為 Codex 桌面控制完整指南，涵蓋截圖、OCR、滑鼠、鍵盤、應用控制、瀏覽器操作_

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-14 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 41則/1對話；TGBOT 43則/1對話；TGBOT 20則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- OpenClaw 修復要先查 port 18789、gateway lock、PID、scheduled task 與 healthz；修復時明確避免影響 TGBOT polling。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 任何缺檔/漏傳抱怨都要回查同一任務 artifact、下載資料夾與 Telegram delivery 紀錄，不可重開任務或只口頭道歉。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->





