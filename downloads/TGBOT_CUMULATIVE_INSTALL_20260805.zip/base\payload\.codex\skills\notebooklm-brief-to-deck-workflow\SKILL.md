---
name: notebooklm-brief-to-deck-workflow
description: Deprecated live NotebookLM deck workflow. Use the unified nbs skill for actual NotebookLM deliverables; use this only when explicitly maintaining the legacy brief-to-deck workflow.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# NotebookLM Brief To Deck Workflow

Use this skill whenever the user says `nbs` or asks to make a NotebookLM presentation/deck.

## Clean User Rules

- User-facing NBS reports must be clean Traditional Chinese. Never paste raw JSON, browser page text, logs, stack traces, mojibake, or decoded automation output into Telegram. Summarize as `檢查：還在生成中`, `檢查：已生成好`, `檢查：需要登入`, `已下載並傳送`, or a short Chinese blocker.
- Multiple NBS jobs may be active at the same time. Use a dedicated state file under `C:\tmp\nbs-automation\states\*.json` via `NBS_STATE` for each new job, and let `nbs-auto-check.ps1` scan all pending state files.
- Do not let a new NBS overwrite or lose an older pending NBS.
- Immediately after submitting NotebookLM presentation generation, report to the operator in Chinese that it has been submitted and is generating, and include the next auto-check time when available.
- NotebookLM may show generated presentation cards with English titles. If the page is not generating and contains a presentation card pattern like `1 個來源 · ...` followed by `more_vert`, treat it as ready and download the native file.
- After a per-job state file is sent successfully, remove or mark that per-job state so scheduled checks do not report or attempt the same file again.
- Send each generated file only once unless the operator explicitly asks to resend.

## User Priority Rules

These rules override other workflow details for this user:

0. First-time Edge setup for every NBS user: before the first NotebookLM/NBS job on a new computer, check Microsoft Edge. If Edge is missing, install Microsoft Edge first or tell the user Edge is required before continuing. Open Edge with the normal existing user profile, not a new browser profile. Navigate to Google/NotebookLM login. If the login reaches password entry and no saved password is available, stop immediately and ask the user to provide the password. Do not wait, loop, guess, or continue silently. Do not save the password in memory, skills, logs, or handoff packages. If 2FA, verification, account selection, permission, or security prompt appears, stop and report it to the user in Chinese.
1. Fixed browser: always reuse the logged-in Edge browser at `http://127.0.0.1:9222`. If Edge is not running with remote debugging, start Edge with `--remote-debugging-port=9222` and the user's existing profile (`--user-data-dir=C:\Users\max\AppData\Local\Microsoft\Edge\User Data`). Do not open a new browser, new profile, or new NotebookLM browser session unless the user explicitly asks.
2. Login blocker: if NotebookLM, Google, Doubao, Telegram, or any required service asks for login, account selection, 2FA, verification, or permissions, stop immediately and ask the user. Do not wait, retry silently, or keep attempting work in the background.
3. NotebookLM generation waiting: after submitting presentation generation and seeing `正在生成簡報...`, stop active work and schedule `NBSAutoCheck` to run 20 minutes later. If still not ready, the scheduled check must report status and schedule another check 5 minutes later. If ready, it must download and send the native file immediately.
4. Download notebook verification: before every download, confirm the current NotebookLM URL matches the notebook URL recorded at generation submission. If it does not match, stop and report the mismatch; do not download from a different notebook.
5. File delivery must be once per generated file. Do not resend the same PPTX/PDF during auto-checks, manual tests, retries, or scheduled reruns unless the user explicitly asks to resend/retransmit.
6. Idle reporting: if there is no active work running, report `完成` in Chinese. Do not use `fin`.

## Fixed Rule

Every new presentation must use a new NotebookLM notebook.

Do not reuse the old `BlueStar` notebook for a new deck unless the user explicitly asks to continue that same notebook. This prevents old sources, old chat history, and old presentation cards from mixing into the new deck.

## Universal Task Rules (Apply To All Tasks)

- If any task has failed 3 times OR taken more than 10 minutes without completion, stop and report the current status in Chinese. Do not keep trying the same failed approach.
- When reporting: state what was attempted, what failed, how long it took, and the current blocker (or `需要登入` if blocked by auth).
- Do not let any task get stuck in a retry loop.
- If a task cannot be completed, free the conversation and tell the user the status.

## Required Workflow

1. Receive the user's topic, image, notes, course info, source copy, script, or rough idea.
2. Organize the material into complete Traditional Chinese slide source content.
3. Design the style automatically from the user's provided material, topic, image, industry, target audience, and CTA.
4. Do not ask the style/settings table by default.
5. Only show the style/settings table if the user explicitly says they want to design the style themselves, asks for the table, or says `我要自己設計`.
6. Open the user's visible normal Chrome browser logged in as `[REDACTED_EMAIL]`.
7. Open NotebookLM and create a brand-new notebook.
8. In the new notebook, click `新增來源`.
9. **If the user provides a YouTube URL or website URL**: choose `網站` → paste the full URL → insert. Do NOT use `複製的文字` for URL-based sources.
10. **If the user provides text, notes, script, or document content**: choose `複製的文字` → paste the complete slide source content → insert.
11. Insert the source.
12. Go to `工作室`.
13. Click `簡報`.
14. When NotebookLM asks for style/customization or after the presentation is generated, paste the auto-designed style prompt into the same new notebook's chat/customization box.
15. Generate or revise the presentation according to the style.
16. In the same new notebook, open the generated presentation card's three-dot menu.
17. Download the requested file format: PPTX or PDF. If the user did not specify, prefer PPTX.
18. Send only the native NotebookLM-downloaded file to Telegram immediately as a document.
19. NotebookLM presentations normally take about 10-15 minutes to generate. Treat `正在生成簡報` as normal progress, not a failure.
20. Do not repeatedly create new notebooks just because generation is still running.
21. After submitting generation, do not block the conversation waiting for NotebookLM.
22. Record the notebook URL and submission time.
23. For generation, queueing, or other waiting states, do not block the conversation. Check status about every 10 minutes when possible.
24. If the presentation is done, download the native NotebookLM PPTX/PDF and send it to Telegram.
25. If it is not done, do not keep the user waiting; keep the task pending and continue with other user requests.
26. Do not create or send a fallback PPT/PDF unless the user explicitly asks for a fallback.
27. If any single `nbs` task has taken more than 30 minutes of active work, pause active work and free the conversation for the user's next request. Continue checking status later without blocking when possible.

## Default Style Table

Use these values when the user says `照預設`:

```text
【輸出語言】繁體中文
【預計頁數】12 張
【預計報告時間】10 分鐘
【簡報角色】行銷總監 / 招商講師
【發表場景】招商說明
【目標受眾】想創業、想增加收入、想了解商業模式的人
【講者語氣】熱血、有說服力、強成交感
【核心 CTA】加入系統 / 預約說明會 / 立即報名
【簡報目的】銷售成交 / 招商募資
【大綱架構】問題-解法-成果
【視覺風格】高級黑金 / 強烈網紅
【是否需要 Speaker Notes】需要
【補充需求】保留使用者提供素材中的核心金句、數字、制度名詞與 CTA。
```

## Style Design Rule

By default, design the presentation style for the user.

Infer the style from:

- the user's uploaded image or source material
- the topic and industry
- the emotional tone of the source
- whether it is for招商, course teaching, sales, brand, report, or personal IP
- the likely target audience
- the CTA

Examples:

- Red/gold wealth poster: high-energy black-gold-red招商 style.
- AI course material: high-tech black-gold or blue-purple AI education style.
- Cultural topic: documentary/editorial style with Taiwanese cultural visuals.
- Luxury venue/brand: premium black-gold, refined serif/sans typography, image-led layout.

Only ask the table if the user explicitly says they want to design the style themselves.

## Style/Settings Table To Ask Only When User Wants To Design

Ask this table before creating or revising visual style:

```text
【輸出語言】
【預計頁數】
【預計報告時間】
【簡報角色】
【發表場景】
【目標受眾】
【講者語氣】
【核心 CTA】
【簡報目的】
【大綱架構】
【視覺風格】
【是否需要 Speaker Notes】
【補充需求】
```

If the user gives partial values, prefill known values and ask only for missing fields. If the user says `照預設`, do not ask again.

## Source Construction

When creating the copied-text source, include:

- Clear title.
- Source summary.
- Core conclusion first.
- Extracted key copy from user materials.
- Audience and conversion goal.
- 10 to 12 slide structure unless the user specifies another count.
- For each slide: title, key points, direct slide copy, visual/layout suggestion, and speaker notes.
- Final CTA.
- Style prompt block for NotebookLM.

Use Traditional Chinese by default.

## NotebookLM Style Prompt

When pasting the style prompt into NotebookLM, include:

- Language.
- Slide count and speaking time.
- Speaker role.
- Scenario.
- Target audience.
- Tone.
- CTA.
- Presentation purpose.
- Outline framework.
- Visual style.
- Speaker Notes requirement.
- Instruction to avoid vague slogans.
- Instruction that every slide must contain usable slide copy and layout suggestions.

## Browser And Account Rules

- Current default for shared NBS skill users: use Microsoft Edge first. This overrides older Doubao/Chrome-first notes unless the local operator explicitly requests another browser.
- First-time setup on a new computer: verify Edge is installed; if missing, install Edge before running NBS. Then open Edge, go to Google/NotebookLM, and complete login as far as possible.
- If Edge reaches the password page and the password is not already saved, immediately report in Chinese and ask the user for the password. Do not keep waiting on the page and do not try random credentials.
- If the user provides credentials for this session, use them only for login. Do not store passwords in `AGENTS.md`, skills, memory files, state files, logs, or Telegram handoff packages.
- If Google/NotebookLM shows account selection, phone verification, 2FA, captcha, permission, security warning, or login failure, stop and report the blocker in Chinese.
- User preference: when browser access is needed, use the user's Doubao browser first.
- If the fixed Doubao browser is not available or has no control port, report the blocker and ask the user before opening or restarting anything.
- Only ask the user when login, account selection, 2FA, verification, or permissions are required.
- Do not silently switch from Doubao to Chrome.
- Use the user's visible Doubao browser by default.
- Use Chrome only if the user explicitly approves it as a fallback for that task.
- Use the NotebookLM account already logged in as `[REDACTED_EMAIL]`.
- Do not use the separate debug Chrome/profile for final NotebookLM downloads unless the visible browser is unavailable.
- If automation clicks fail, use visible OS-level clicks on the normal Chrome window.
- If NotebookLM shows a Google login, account chooser, 2FA, verification, or expired-session page, stop immediately and ask the user to log in. Do not keep retrying profile copying or cookie migration.
- When browser control is unavailable, open a controllable Chrome window on port `9333` and ask the user to log in there. After the user says `好了`, reconnect to `http://127.0.0.1:9333` and continue.
- Do not copy the live Chrome profile as the first fallback. It is slow, can miss locked cookies, and wastes time. Use the explicit login handoff instead.
- Fixed browser rule: use the already restarted Doubao browser on `http://127.0.0.1:9444` for browser tasks. Do not open another browser/profile for NotebookLM unless the user explicitly asks.
- Do not close the fixed Doubao browser. Keep it alive to preserve login state. If automation needs to end, leave the browser running.
- If the fixed Doubao browser is logged out, on an account chooser, blocked by 2FA, or asks for permissions, immediately reply `needsLogin` or the exact blocker. Do not retry, loop, or wait silently.
- When using CDP/browser automation, disconnect or simply let the script exit instead of closing the browser window. Keeping the window alive preserves the login session and generation state.
- For speed, use one fixed logged-in browser session for all `nbs` work. Prefer an already-open CDP browser instead of creating/copying profiles for each task.
- The default fixed control endpoint is `http://127.0.0.1:9444` for Doubao. The helper launches Doubao itself if the endpoint is unavailable. Use `NBS_CDP_URL`, `NBS_BROWSER_EXE`, and `NBS_USER_DATA_DIR` only for overrides.
- Keep status replies short during `nbs` and write them in Chinese: `需要登入`, `還在生成中`, `已生成好`, `已下載`, or `已傳送`, plus the file/message id when relevant.
- Prefer the helper script `scripts/nbs-runner.js` for repeated operations:
  - `launch`: open controllable NotebookLM Chrome.
  - `create`: create a new notebook, add copied-text source, and start presentation generation.
  - `status`: check whether generation is still running or ready.
  - `download`: download the latest native PPTX/PDF from the generated presentation card.
  - `send`: send the downloaded file to Telegram.

## NotebookLM Automation Shortcuts

- Create source content as a local UTF-8 Markdown file first. This gives a stable copy for retries.
- In NotebookLM, always click `建立新的筆記本` for a new `nbs` task.
- For copied-text source upload, select `複製的文字`, then fill the textarea with placeholder `在這裡貼上文字`.
- Avoid filling the chat box placeholder `提問或創作內容`; that is not the source field and keeps the `插入` button disabled.
- After clicking `簡報` in `工作室`, NotebookLM may start generation immediately. If it shows `正在生成簡報...`, treat that as successful submission even if no extra generate button was clicked.
- The generated presentation card can be detected by text like `簡報「...」已就緒` or a card title followed by `more_vert`.
- Open the presentation card's `more_vert` menu and prefer `下載 PowerPoint (.pptx)`.
- If download menu text changes, inspect the menu and choose the PowerPoint option before PDF unless the user requested PDF.
- If Playwright hangs on Doubao, use raw Chrome DevTools Protocol over `http://127.0.0.1:9444/json` and the target tab websocket instead of starting a new browser.
- Raw CDP status check may internally return `generating`, `ready`, or `needsLogin`, but user-facing reports must be Chinese: `還在生成中`, `已生成好`, or `需要登入`.
- For download in Doubao, if DOM click does not trigger, open the presentation card `more_vert` menu, inspect the menu item coordinates, and use `Input.dispatchMouseEvent` on `下載 PowerPoint (.pptx)`.

## Waiting Rule

- After the NotebookLM presentation is submitted and `正在生成簡報...` is visible, stop active work on the deck.
- Do not keep the Codex turn hanging or wait in the foreground after submission.
- Immediately schedule a Windows task named `NBSAutoCheck` to run `scripts/nbs-auto-check.ps1` 20 minutes after submission.
- The scheduled check must report the status to Telegram. If ready, it must download the native NotebookLM PPTX/PDF and send it immediately. If still generating, it must schedule the next check 5 minutes later and report that short status.
- If the native PPTX/PDF was already sent successfully, scheduled checks and manual tests must not send the same file again. Report the existing file/message id instead unless the user explicitly asks to resend.
- While waiting, free the conversation for other user tasks.
- If the user explicitly asks `檢查一次` or similar, check once and report the short status.

## Download Procedure

Use `scripts/nbs-runner.js download` as the standard download path. It must verify the recorded notebook URL first, use Playwright's native `download` event for the actual PPTX/PDF download, save the file path and byte size into `C:\tmp\nbs-automation\nbs-state.json`, print JSON with `ok: true`, and exit cleanly.

Do not use raw DOM click or coordinate click as the primary download method. Raw CDP is reliable for fast status checks and page text inspection, but NotebookLM may ignore synthetic DOM or coordinate clicks for real browser downloads. If a download seems slow, first check `C:\Users\Administrator\Downloads` for a newly modified PPTX/PDF before retrying because the file may already be saved while the automation layer is still waiting.

1. Stay inside the same new notebook used to generate the deck.
2. Before downloading, compare the current NotebookLM notebook URL with the recorded submission URL from step 22.
3. If the URL does not match, stop and report both URLs. Do not download.
4. Go to `工作室`.
5. Find the newest generated presentation card.
6. Click the card's three-dot menu.
7. Choose one:
   - `下載 PowerPoint (.pptx)`
   - `下載 PDF 文件 (.pdf)`
8. Check `C:\Users\Administrator\Downloads`.
9. Confirm the file exists and size is greater than zero.
10. Send the native NotebookLM file to Telegram immediately.

## Runner Reliability Fixes

Use the fixed `scripts/nbs-runner.js` behavior as the standard flow:

- `status`: use raw CDP page text reading through `http://127.0.0.1:9444/json`. It should normally return in about 1 second with `ready`, `generating`, or `needsLogin`.
- `download`: verify the recorded notebook URL first, then use Playwright's native `download` event. This is the reliable path for NotebookLM because DOM click and coordinate click may show the menu but fail to trigger the browser download.
- After a successful `download`, the runner must save the file path and byte size into `C:\tmp\nbs-automation\nbs-state.json`, print JSON with `ok: true`, and exit cleanly. A saved file plus a hanging process should be treated as a runner bug.
- `send`: read the latest downloaded file from state unless `--file` is supplied, send it as a Telegram document, save `telegramOk` and `telegramMessageId`, and print JSON.
- `send`: before sending, check state for the same already-sent file. If `telegramOk` is true and the file matches `telegramFile`/`downloadedFile`, return `skipped: true` with the prior `telegramMessageId` instead of uploading again. Only bypass this with an explicit `--force` after the user asks to resend.
- State files must always be valid UTF-8 JSON. If a prior state file contains mojibake or broken JSON, recover the notebook URL, notebook ID, source path, downloaded file, and byte size where possible, then rewrite valid JSON.
- Do not expose Telegram tokens in logs or replies.

## Telegram Delivery

- Use the local Telegram bot token from `C:\Users\Administrator\appsettings.Local.json`.
- Do not expose the token.
- Default Telegram chat id: `[REDACTED_NUMBER]`.
- Send PPTX/PDF as a Telegram document.
- Send each generated PPTX/PDF only once. Do not duplicate-send during tests, retries, or auto-check reruns unless the user explicitly asks for another copy.
- Report the file name and Telegram `message_id`.

## Operator Report Format

When reporting a completed NBS fix or delivery, use the concise but useful format the operator approved:

- Start with the outcome in Chinese: `已解決`, `已下載並傳送`, `還在生成中`, `已生成好`, or `需要登入`.
- When the user clarifies that multiple uploaded files/images are all source materials, acknowledge the exact count and current deck state in one short sentence, for example: `知道，七張都已納入同一份 ASEA REDOX 簡報素材。現在 NotebookLM 正在生成中。`
- Whenever you manually or automatically check NotebookLM status, report the check result briefly in Chinese. Do not stay silent after a check. Use short statuses such as `檢查：還在生成中`, `檢查：已生成好`, `檢查：需要登入`, or `檢查：尚未完成，下一次約 5 分鐘後。`
- For fixes, list what changed in concrete terms: status check method, download method, state-file handling, Telegram caption/send behavior.
- Include verification results, not long logs: `status 成功`, `download 成功`, elapsed time if known, local file path, file size when relevant, and Telegram `message_id`.
- For delivery, keep it short: file name/path plus Telegram `message_id`.
- If something was slow or failed, explain the real bottleneck plainly and state the corrected flow.

## Completion Checklist

Before saying done:

- Confirm the new NotebookLM notebook was used.
- Confirm the source was added via `複製的文字` (for text content) or `網站` (for URL/YouTube sources).
- Confirm the presentation was generated in that same new notebook.
- Confirm the current notebook URL matches the recorded submission notebook URL before downloading.
- Confirm the PPTX/PDF exists locally and has nonzero size.
- Confirm the PPTX/PDF is a native NotebookLM download, not a locally rebuilt fallback.
- Confirm Telegram returned `ok: true`.
- Confirm the file was not already delivered before sending, unless the user explicitly requested resend.
- Reply with the file name and Telegram `message_id`.

## Important Corrections

- Do not reuse old notebooks for new projects.
- Do not generate from mixed old sources.
- Do not send manually rebuilt PPT/PDF files during `nbs`. The user wants only native NotebookLM exports unless they explicitly ask for a fallback.
- Do not send the same native NotebookLM file more than once unless the user explicitly asks to resend it.
- If login is required, ask the user immediately instead of silently waiting or looping.
- NotebookLM generation usually takes 10-15 minutes. Do not treat this as stuck.
- After triggering NotebookLM generation, do not wait in a blocking loop.
- Do not poll continuously after triggering generation. Follow the 20-minute then 5-minute check rule.
- Record the notebook URL and first submission time.
- For generation, queueing, or other waiting states, check status about every 10 minutes when possible.
- Do not block the user from giving other tasks while waiting.
- Only when generation is complete: download and send the native NotebookLM file.
- Do not create another new notebook unless the first notebook clearly failed, produced an error, or the user explicitly asks to restart.
- While NotebookLM is generating, the assistant may continue helping with other user tasks instead of waiting in a loop.
- If the total task time exceeds 30 minutes, stop active work on this task, tell the user it is paused, and wait for the user to ask `好了沒` or give a resume instruction.

