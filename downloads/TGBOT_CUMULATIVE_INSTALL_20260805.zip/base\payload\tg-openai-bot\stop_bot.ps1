﻿$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$AlwaysStopTargets = @(
    "bot_now.ps1",
    "telegram_only_bot.ps1",
    "bot_powershell.ps1",
    "simple_bot.py",
    "codex_bot.py"
)
$ProjectScopedTargets = @(
    "bot.py",
    "run_codex_bot.ps1"
)

$Stopped = 0
$TaskKill = Join-Path $env:SystemRoot "System32\taskkill.exe"
if (-not (Test-Path $TaskKill)) {
    $TaskKill = "taskkill"
}
$Processes = Get-CimInstance Win32_Process | Where-Object {
    $CommandLine = [string]$_.CommandLine
    $MatchesTarget = $false

    if (-not [string]::IsNullOrWhiteSpace($CommandLine)) {
        foreach ($Target in $AlwaysStopTargets) {
            if ($CommandLine.Contains($Target)) {
                $MatchesTarget = $true
                break
            }
        }
        if (-not $MatchesTarget -and $CommandLine.Contains($ProjectDir)) {
            foreach ($Target in $ProjectScopedTargets) {
                if ($CommandLine.Contains($Target)) {
                    $MatchesTarget = $true
                    break
                }
            }
        }
    }

    $MatchesTarget
}

foreach ($Process in $Processes) {
    if ($Process.ProcessId -eq $PID) {
        continue
    }

    try {
        & $TaskKill /PID $Process.ProcessId /T /F | Out-Null
        Write-Host "Stopped PID $($Process.ProcessId): $($Process.Name)"
        $Stopped += 1
    }
    catch {
        Write-Host "Failed to stop PID $($Process.ProcessId): $($_.Exception.Message)"
    }
}

if ($Stopped -eq 0) {
    Write-Host "No running bot process found."
}
