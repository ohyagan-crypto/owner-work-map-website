# Browser Workflow

Use browser automation when the platform requires a logged-in web UI, file upload, prompt entry, manual buttons, or result download.

## Preflight

1. Confirm browser automation is enabled in the receiving OpenClaw environment.
2. Confirm the user provided the platform URL and their own login method, or that an existing browser session is already logged in.
3. If browser automation is unavailable, ask the operator to enable it or switch to manual browser + CLI/file verification.
4. If the workflow was delegated to a child agent and coordination fails, read `environment-check.md`; the issue may be session visibility, not image generation.

## Steps

1. Open the user-provided platform URL.
2. Check whether the session is already logged in.
3. If login is required, ask the user to provide their own account/password or complete manual verification. Stop for CAPTCHA/2FA.
4. Navigate to the image generation page: AI繪圖, AI绘图, 圖片生成, Image, or equivalent.
5. Select model/style/ratio based on the confirmed checklist.
6. Upload source files if needed.
7. Paste the confirmed prompt unchanged.
8. Submit generation only after explicit user confirmation.
9. Record the task/result area and check every 3 minutes.
10. Download using the platform's download/original button when available.
11. If the image is embedded as data URL or blob, extract the original image bytes rather than taking a screenshot.
12. Verify file header, size, and dimensions before delivery.
13. Deliver the original verified file as a document/file when possible; for Telegram, prefer document/file mode over image preview.
14. If the user reports no file received, verify the saved file still exists and resend it via the provider's direct file-send capability in document mode before attempting regeneration.

## 3-Minute Polling Rule

After submission, continue checking every 3 minutes until one of these is true:

- Original image file is downloaded, verified, and delivered through a confirmed document/file send path.
- Platform shows a clear failure.
- Login/quota/payment/permission blocks the flow.
- The same step fails twice.
- The output cannot be verified after one alternate download attempt.

Do not stop checking just because submission succeeded. Submission is not delivery.

## Stop Conditions

Stop and report clearly if any of these happen:

- Login, CAPTCHA, 2FA, account, quota, permission, or payment block.
- Same browser step fails twice.
- Output cannot be verified as a real image.
- Platform shows repeated generation failure.
- No meaningful progress after 3-5 minutes beyond expected generation wait.
- Required OpenClaw permissions are missing.

## User-Facing Updates

Use clean Traditional Chinese only. Do not mention tool names, raw browser events, logs, selectors, JSON, cookies, tokens, or internal stack traces.

Good examples:

```text
主人，圖片已提交，我會每 3 分鐘檢查一次，直到下載原始成品並用文件模式回傳給你。
```

```text
目前卡在登入驗證，需要你在瀏覽器完成驗證後我才能繼續。
```

Bad examples:

```text
Browser snapshot failed / selector timeout / JSON log...
```
