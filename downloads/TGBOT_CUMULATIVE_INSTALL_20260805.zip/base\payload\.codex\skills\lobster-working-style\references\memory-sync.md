# Memory Sync and Handoff

- Long-term memory: `C:\Users\max\.openclaw\workspace\MEMORY.md`.
- Daily notes: `C:\Users\max\.openclaw\workspace\memory\YYYY-MM-DD.md`.
- Codex memory entry: `C:\Users\max\.codex\memories\`.
- Codex skills entry: `C:\Users\max\.codex\skills\`.
- Important new preferences, rules, and workflows should be written to long-term memory and daily notes.
- Do not hard-link entire workspaces or copy secrets into handoff packages.
- Handoff packages must be no-secrets: no tokens, cookies, API keys, OAuth files, browser profiles, raw logs, or credential dumps.
