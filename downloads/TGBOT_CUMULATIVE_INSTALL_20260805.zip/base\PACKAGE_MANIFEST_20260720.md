# 單一 TGBOT 統一整合包清單

- 建立日期：2026-07-20
- 執行身分：TGBOT
- Backend：1
- Telegram Bot Token 通道：1
- 安裝輸入：僅 TGBOT Token、一般 API Key、一般 API URL、IMAGE2 API Key、IMAGE2 API URL；CHAT ID 不進安裝流程
- 技能：61 個，已去除重複名稱
- 記憶：12 個整合記憶檔
- 自動接線：Codex provider、IMAGE2 與監控設定由安裝器完成；CHAT ID 日後透過 `BIND_CHAT_ID.cmd` 唯一授權，驗證後才啟動單一 backend
- 開機恢復：綁定成功後建立 `Unified TGBOT Watchdog`，Windows 登入時啟動並每 5 分鐘健康檢查
- 失敗恢復：timeout／空轉／空回覆／模型不可用／CLI 異常自動重試並切換備援模型
- 回覆防護：安裝前執行失敗路由自測，禁止固定式概括錯誤與手動續跑提示
- API 設定：一般 API Key／URL 與 IMAGE2 API Key／URL 各自獨立寫入，不互相共用
- 排除：預設 CHAT ID、預設 Token、API Key、聊天紀錄、session、SQLite、log、cookie、瀏覽器 profile、舊多 Bot 路由

安裝入口：`INSTALL_TGBOT_UNIFIED.cmd`

安裝教學：`INSTALL_GUIDE_20260720.txt`

接收端轉發說明：`FORWARD_TO_RECEIVER_TGBOT_20260720.txt`
