---
name: openclaw-browser-automation
description: Imported OpenClaw browser automation rules; adapt them to Codex browser/in-app browser tools when controlling web pages.
---

# Imported From OpenClaw

This skill was copied from `C:\Users\max\.openclaw`. It is available to Codex/TG bot for continuity, but do not call the `openclaw` CLI or OpenClaw-specific tools unless the operator explicitly asks. Prefer Codex built-in tools and existing Codex skills.

Do not expose secrets, raw logs, browser cookies, or auth files while using this skill.

# Browser Automation

Use this skill when you need the `browser` tool for anything beyond a single page check.

## Operating Loop

1. Check browser state before acting:
   - `openclaw browser doctor` or `action="status"` when the browser/plugin setup itself may be broken.
   - `action="status"` for availability.
   - `action="profiles"` if login state or profile choice matters.
   - `action="tabs"` before opening a new tab if retries/timeouts may have left windows behind.
2. Prefer stable tab handles:
   - Open important tabs with `label`, for example `label="meet"`.
   - Use `tabId` handles like `t1` or labels like `meet` as `targetId` in later calls.
   - Avoid relying on raw DevTools `targetId` unless the tool just returned it.
3. Read before you click:
   - Use `action="snapshot"` on the intended `targetId`.
   - Use the same `targetId` for follow-up actions so refs stay on the same tab.
   - For durable Playwright refs, request `refs="aria"` when supported. If you receive `axN` refs from `snapshotFormat="aria"`, use them only after that same snapshot call; stale or unbound `axN` refs fail fast and need a fresh snapshot.
   - Use `urls=true` when link text is ambiguous or a direct navigation target would avoid brittle clicks.
   - Use `labels=true` on snapshot or screenshot when visual position matters.
4. Act narrowly:
   - Prefer `action="act"` with a ref from the latest snapshot.
   - After navigation, modal changes, or form submission, snapshot again before the next action.
   - Avoid blind waits. Wait for visible UI state when possible.
5. Report real blockers:
   - If the page needs login, permission, captcha, 2FA, camera/microphone approval, or another manual step, stop and tell the user exactly what is needed.
   - Do not claim the browser is not logged in just because the current page shows a permission or onboarding dialog. Inspect the visible UI first.

## Tab Hygiene

Before creating a tab for a named task, list tabs and reuse an existing matching label or URL when it is still usable.

Example:

```json
{ "action": "tabs" }
```

If no suitable tab exists:

```json
{ "action": "open", "url": "https://example.com", "label": "task" }
```

Then target it by label:

```json
{ "action": "snapshot", "targetId": "task", "refs": "aria" }
```

If a retry creates duplicates, close the extras by `tabId`:

```json
{ "action": "close", "targetId": "t3" }
```

Do not pass bare numbers like `"2"` as `targetId`. Numeric tab positions are only for the CLI `openclaw browser tab select 2` helper; browser tool calls need a `suggestedTargetId`, label, `tabId`, or raw target id.

## Stale Ref Recovery

If an action fails with a missing or stale ref:

1. Snapshot the same `targetId` again.
2. Find the current visible control.
3. Retry once with the new ref.
4. If the UI moved to a blocker state, report the blocker instead of looping.

## Existing User Browser

Use `profile="user"` only when existing cookies/login matter. This attaches to the user's running Chromium-based browser.

For `profile="user"` and other existing-session profiles, omit `timeoutMs` on `act:type`, `evaluate`, `hover`, `scrollIntoView`, `drag`, `select`, and `fill`; that driver rejects per-call timeout overrides for those actions.

## Google Meet Notes

When creating or joining a Meet:

- Treat camera/microphone permission screens as progress, not login failure.
- If asked whether people can hear you, click the microphone option when voice is required.
- If Google asks for sign-in, 2FA, account chooser confirmation, or permission that needs user approval, report the exact manual action.
- Use one labeled tab per meeting flow, for example `label="meet"`, and reuse it during retries.

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-14 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 41則/1對話；TGBOT 43則/1對話；TGBOT 20則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- OpenClaw 修復要先查 port 18789、gateway lock、PID、scheduled task 與 healthz；修復時明確避免影響 TGBOT polling。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 任何缺檔/漏傳抱怨都要回查同一任務 artifact、下載資料夾與 Telegram delivery 紀錄，不可重開任務或只口頭道歉。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->





