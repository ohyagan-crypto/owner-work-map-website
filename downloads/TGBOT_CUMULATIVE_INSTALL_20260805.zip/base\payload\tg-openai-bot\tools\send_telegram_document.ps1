﻿param(
    [Parameter(Mandatory = $true)]
    [string]$Path,

    [string]$ChatId = "",

    [string]$MessageThreadId = "",

    [string]$Caption = ""
)

$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$envPath = Join-Path $projectDir ".env"

if (-not (Test-Path -LiteralPath $envPath -PathType Leaf)) {
    throw "Telegram environment file not found."
}

foreach ($line in [System.IO.File]::ReadLines($envPath)) {
    $trimmed = $line.Trim()
    if (-not $trimmed -or $trimmed.StartsWith("#") -or -not $trimmed.Contains("=")) {
        continue
    }
    $parts = $trimmed.Split("=", 2)
    [Environment]::SetEnvironmentVariable($parts[0].Trim(), $parts[1].Trim().Trim('"').Trim("'"), "Process")
}

$token = [Environment]::GetEnvironmentVariable("TELEGRAM_BOT_TOKEN", "Process")
if (-not $token) {
    throw "Telegram token is not configured."
}

$originChatId = [Environment]::GetEnvironmentVariable("TELEGRAM_ORIGIN_CHAT_ID", "Process")
$originThreadId = [Environment]::GetEnvironmentVariable("TELEGRAM_ORIGIN_MESSAGE_THREAD_ID", "Process")
$originBotInstance = [Environment]::GetEnvironmentVariable("TELEGRAM_ORIGIN_BOT_INSTANCE", "Process")
$projectName = Split-Path -Leaf $projectDir
$expectedBotInstance = switch ($projectName) {
    "tg-openai-bot" { "TGBOT" }
    default { $projectName }
}
if (-not [string]::IsNullOrWhiteSpace($originBotInstance) -and $originBotInstance.Trim() -ne $expectedBotInstance) {
    throw "Refusing to send Telegram document through a different bot instance."
}

function Get-OpenClawLatestTelegramOrigin {
    $messagesPath = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.openclaw\agents\main\sessions\sessions.json.telegram-messages.json'
    if (-not (Test-Path -LiteralPath $messagesPath -PathType Leaf)) {
        return $null
    }

    try {
        $lines = Get-Content -LiteralPath $messagesPath -Tail 800 -ErrorAction Stop
    } catch {
        return $null
    }

    for ($i = $lines.Count - 1; $i -ge 0; $i--) {
        $line = [string]$lines[$i]
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        try {
            $item = $line | ConvertFrom-Json -ErrorAction Stop
            $message = $item.node.sourceMessage
            if ($null -eq $message -or $null -eq $message.chat -or $null -eq $message.chat.id) {
                continue
            }

            $chatId = [string]$message.chat.id
            $messageDate = 0L
            if ($null -ne $message.date) {
                $messageDate = [int64]$message.date
            }

            $threadId = ""
            if ($null -ne $message.message_thread_id) {
                $threadId = [string]$message.message_thread_id
            }

            return [pscustomobject]@{
                ChatId = $chatId
                ThreadId = $threadId
                Date = $messageDate
            }
        } catch {
            $chatId = ""
            $messageDate = 0L
            $threadId = ""

            if ($line -match '"chat"\s*:\s*\{[^}]*"id"\s*:\s*(-?\d+)') {
                $chatId = $Matches[1]
            } elseif ($line -match '"key"\s*:\s*"[^:"]+:(-?\d+):\d+"') {
                $chatId = $Matches[1]
            }

            if ($line -match '"date"\s*:\s*(\d+)') {
                $messageDate = [int64]$Matches[1]
            }

            if ($line -match '"message_thread_id"\s*:\s*(\d+)') {
                $threadId = $Matches[1]
            }

            if (-not [string]::IsNullOrWhiteSpace($chatId)) {
                return [pscustomobject]@{
                    ChatId = $chatId
                    ThreadId = $threadId
                    Date = $messageDate
                }
            }

            continue
        }
    }

    return $null
}

$latestOpenClawOrigin = $null
if ($null -ne $latestOpenClawOrigin -and $latestOpenClawOrigin.Date -gt 0) {
    $nowUnix = [int64][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $latestAgeSeconds = $nowUnix - [int64]$latestOpenClawOrigin.Date
    $isRecentOpenClawOrigin = $latestAgeSeconds -ge 0 -and $latestAgeSeconds -le (6 * 60 * 60)

    if ($isRecentOpenClawOrigin) {
        if ([string]::IsNullOrWhiteSpace($originChatId)) {
            $originChatId = $latestOpenClawOrigin.ChatId
        } elseif ($originChatId.Trim() -ne $latestOpenClawOrigin.ChatId.Trim()) {
            throw "Telegram origin chat id does not match the latest Telegram request; refusing to guess a delivery target."
        }

        if ([string]::IsNullOrWhiteSpace($originThreadId) -and -not [string]::IsNullOrWhiteSpace($latestOpenClawOrigin.ThreadId)) {
            $originThreadId = $latestOpenClawOrigin.ThreadId
        } elseif (-not [string]::IsNullOrWhiteSpace($originThreadId) -and -not [string]::IsNullOrWhiteSpace($latestOpenClawOrigin.ThreadId) -and $originThreadId.Trim() -ne $latestOpenClawOrigin.ThreadId.Trim()) {
            throw "Telegram origin topic does not match the latest Telegram request; refusing to guess a delivery target."
        }
    }
}

if ([string]::IsNullOrWhiteSpace($originChatId)) {
    throw "Telegram origin chat id is missing; refusing to guess a delivery target."
}

if ([string]::IsNullOrWhiteSpace($ChatId)) {
    $ChatId = $originChatId
}

if (-not [string]::IsNullOrWhiteSpace($originChatId) -and $ChatId.Trim() -ne $originChatId.Trim()) {
    throw "Refusing to send Telegram document to a chat other than the originating chat."
}

if ([string]::IsNullOrWhiteSpace($MessageThreadId) -and -not [string]::IsNullOrWhiteSpace($originThreadId)) {
    $MessageThreadId = $originThreadId
}

if (-not [string]::IsNullOrWhiteSpace($originThreadId) -and $MessageThreadId.Trim() -ne $originThreadId.Trim()) {
    throw "Refusing to send Telegram document to a topic other than the originating topic."
}

$apiBase = [Environment]::GetEnvironmentVariable("TELEGRAM_API_BASE", "Process")
if (-not $apiBase) {
    $apiBase = "https://api.telegram.org"
}
$apiBase = $apiBase.TrimEnd("/")

$file = Get-Item -LiteralPath $Path
if (-not $file -or $file.Length -le 0) {
    throw "Document is missing or empty."
}

function Add-MultipartField {
    param(
        [System.IO.Stream]$Stream,
        [string]$Boundary,
        [string]$Name,
        [string]$Value
    )

    $text = "--$Boundary`r`nContent-Disposition: form-data; name=`"$Name`"`r`n`r`n$Value`r`n"
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
    $Stream.Write($bytes, 0, $bytes.Length)
}

function Add-MultipartFile {
    param(
        [System.IO.Stream]$Stream,
        [string]$Boundary,
        [System.IO.FileInfo]$File
    )

    $header = "--$Boundary`r`nContent-Disposition: form-data; name=`"document`"; filename=`"$($File.Name)`"`r`nContent-Type: application/octet-stream`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)

    $fileStream = [System.IO.File]::OpenRead($File.FullName)
    try {
        $buffer = New-Object byte[] 65536
        while (($read = $fileStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $Stream.Write($buffer, 0, $read)
        }
    } finally {
        $fileStream.Dispose()
    }

    $newlineBytes = [System.Text.Encoding]::UTF8.GetBytes("`r`n")
    $Stream.Write($newlineBytes, 0, $newlineBytes.Length)
}

function Send-DocumentMultipart {
    param(
        [string]$Uri,
        [string]$ChatId,
        [string]$MessageThreadId,
        [string]$Caption,
        [System.IO.FileInfo]$File
    )

    $boundary = "----CodexTelegramBoundary$([Guid]::NewGuid().ToString('N'))"
    $request = [System.Net.HttpWebRequest]::Create($Uri)
    $request.Method = "POST"
    $request.ContentType = "multipart/form-data; boundary=$boundary"
    $request.Timeout = 120000
    $request.ReadWriteTimeout = 120000

    $requestStream = $request.GetRequestStream()
    try {
        Add-MultipartField -Stream $requestStream -Boundary $boundary -Name "chat_id" -Value $ChatId
        if (-not [string]::IsNullOrWhiteSpace($MessageThreadId)) {
            Add-MultipartField -Stream $requestStream -Boundary $boundary -Name "message_thread_id" -Value $MessageThreadId.Trim()
        }
        if ($Caption.Trim()) {
            Add-MultipartField -Stream $requestStream -Boundary $boundary -Name "caption" -Value $Caption.Trim()
        }
        Add-MultipartFile -Stream $requestStream -Boundary $boundary -File $File
        $footerBytes = [System.Text.Encoding]::UTF8.GetBytes("--$boundary--`r`n")
        $requestStream.Write($footerBytes, 0, $footerBytes.Length)
    } finally {
        $requestStream.Dispose()
    }

    try {
        $response = $request.GetResponse()
        try {
            $reader = New-Object System.IO.StreamReader($response.GetResponseStream(), [System.Text.Encoding]::UTF8)
            $body = $reader.ReadToEnd()
            $reader.Dispose()
            if ($body -notmatch '"ok"\s*:\s*true') {
                throw "Telegram document upload failed."
            }
        } finally {
            $response.Dispose()
        }
    } catch {
        throw "Telegram document upload failed."
    }
}

$uri = "$apiBase/bot$token/sendDocument"
Send-DocumentMultipart -Uri $uri -ChatId $ChatId -MessageThreadId $MessageThreadId -Caption $Caption -File $file
Write-Output "OK"
exit 0

Add-Type -AssemblyName System.Net.Http
$client = New-Object System.Net.Http.HttpClient
$client.Timeout = [TimeSpan]::FromMinutes(10)
$content = New-Object System.Net.Http.MultipartFormDataContent
$stream = $null
try {
    $content.Add((New-Object System.Net.Http.StringContent($ChatId)), "chat_id")
    if (-not [string]::IsNullOrWhiteSpace($MessageThreadId)) {
        $content.Add((New-Object System.Net.Http.StringContent($MessageThreadId.Trim())), "message_thread_id")
    }
    if ($Caption.Trim()) {
        $content.Add((New-Object System.Net.Http.StringContent($Caption.Trim(), [System.Text.Encoding]::UTF8)), "caption")
    }

    $stream = [System.IO.File]::OpenRead($file.FullName)
    $fileContent = New-Object System.Net.Http.StreamContent($stream)
    $mimeType = "application/octet-stream"
    if ($file.Extension.ToLowerInvariant() -eq ".docx") {
        $mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    }
    $fileContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse($mimeType)
    $content.Add($fileContent, "document", $file.Name)

    $uri = "$apiBase/bot$token/sendDocument"
    $response = $client.PostAsync($uri, $content).GetAwaiter().GetResult()
    $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    if (-not $response.IsSuccessStatusCode -or $body -notmatch '"ok"\s*:\s*true') {
        throw "Telegram document upload failed."
    }
} finally {
    if ($content -ne $null) { $content.Dispose() }
    if ($stream -ne $null) { $stream.Dispose() }
    if ($client -ne $null) { $client.Dispose() }
}

Write-Output "OK"
