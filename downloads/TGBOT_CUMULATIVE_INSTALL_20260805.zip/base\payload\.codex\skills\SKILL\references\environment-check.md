# Environment Check

Use this when installing the skill on another OpenClaw/Codex setup, or when the receiver says the skill is stuck because of tool/session permissions.

## Key Point

A skill package cannot grant runtime permissions. `SKILL.md` teaches the assistant what to do, but OpenClaw/Gateway policy decides which tools the assistant may use.

If browser, CLI, file, or session tools are disabled, the assistant must ask the operator to enable them. Do not try to bypass policy.

## Required Receiver Capabilities

For full Lanxin image generation automation, the receiving OpenClaw should have:

- Browser automation available for logged-in web pages.
- File read/write available for source files, downloads, and generated outputs.
- CLI/terminal execution available if using the bundled `scripts/lanxin_browser_cli.js` helper.
- Network access to the user-provided image platform.
- Messaging/file delivery support if the final image must be sent back to Telegram/Discord/etc.
- Cross-session visibility only when the main assistant coordinates child agents/subtasks.

## Common Error: Session Visibility Restricted

If the receiver shows:

```text
Session send visibility is restricted. Set tools.sessions.visibility=all to allow cross-agent access.
```

Meaning:

- The main assistant cannot inspect or message child/other sessions.
- This only affects cross-agent coordination.
- The skill can still run in the same assistant session if browser/file/CLI permissions exist.

Operator-side fix:

- Enable cross-session visibility in OpenClaw config, commonly `tools.sessions.visibility=all`.
- Restart/reload Gateway if the config system requires it.
- If the operator does not want cross-agent access, run the image workflow directly in the main session instead of delegating to a sub-agent.

## Install Checklist For Another OpenClaw/Codex

1. Copy the entire `lanxin-image-generation` folder into the receiver's skill directory.
2. Confirm the receiver can read `SKILL.md` and the `references/` and `scripts/` subfolders.
3. Ask the receiver to trigger the skill with a test request such as: `用 Lanxin 做一張測試海報，先給確認清單，不要提交`.
4. Confirm the receiver can open the platform URL in a browser or browser automation session.
5. Confirm the receiver can write a small test file to the intended download/output folder.
6. If using CLI mode, confirm Node.js is available and install Playwright if needed: `npm i playwright`.
7. Confirm credentials are provided by that receiver's user/operator only; never copy credentials from another machine.

## What To Tell The User When Permissions Are Missing

Use clean Traditional Chinese. Example:

```text
目前不是技能包壞掉，是這台 OpenClaw 還沒開完整工具權限。
需要開啟：瀏覽器工具、檔案讀寫、CLI 執行；如果要主助理追蹤子任務，還要開 sessions visibility。
開完後重啟 Gateway，再重新觸發這個做圖技能即可。
```

## Minimal Mode Without Cross-Agent Access

If `tools.sessions.visibility=all` cannot be enabled:

- Do not spawn or coordinate sub-agents.
- Run the full workflow in the current assistant session.
- Use the same 3-minute polling rule after submission.
- Deliver the verified image file directly from the same session.

## Security Stops

Stop immediately and report when encountering:

- CAPTCHA or 2FA.
- Missing login or invalid credentials.
- Quota/payment/permission block.
- Browser cannot access the platform.
- File download is blocked by policy.
- Output cannot be verified as a real image.
