# NBS 可轉傳給對方 tgbot 的安裝文字

用途：當主人要把 NBS skill 包轉給另一個 Codex / tgbot 時，可以直接複製以下文字給對方。

```text
請學習並安裝這個 Codex 技能包。

請解壓 zip，讀取裡面的 INSTALL_FOR_OTHER_CODEX.md。
把 zip 裡面的 .codex\skills 資料夾內容複製到你這台電腦的：
C:\Users\你的使用者名稱\.codex\skills\

如果裡面有 AGENTS.md，請讀取規則，只新增，不要覆蓋原本資料。
不要保存密碼、token、瀏覽器登入資料。

安裝完成後，請重啟 Codex 或 tgbot，讓技能重新載入。
重啟後請回覆「技能已安裝完成」。

測試：
我傳 nbs 時，你要知道這是 NotebookLM 簡報流程。
第一次使用 NBS 時，請先確認 Edge，沒有 Edge 就安裝 Edge。
登入 Google / NotebookLM 到密碼頁時，要停下來問我密碼，不要卡著等。
```

注意：

- 不要把任何真實 Gmail 密碼、Google token、Telegram token、API key 放進 zip 或訊息。
- 若對方 tgbot 已有 `.codex/skills` 或 `AGENTS.md`，只能新增或合併，不可直接覆蓋。
- 安裝後必須重啟 Codex/tgbot，否則技能可能不會載入。
