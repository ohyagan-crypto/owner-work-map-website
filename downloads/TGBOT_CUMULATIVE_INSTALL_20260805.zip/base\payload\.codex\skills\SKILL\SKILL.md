---
name: 做圖
description: 必須在使用者要求做圖、生圖、生成圖片、產圖、圖片生成、產海報、做海報、海報設計、圖片設計、製作圖片、文案轉圖、PPT轉海報、PDF轉海報、繁體中文海報、商品圖、行銷圖、社群圖、廣告圖、Lanxin AI、蘭心AI、聚合平台圖片生成時啟用。此技能專門負責整理確認清單、等待明確確認、到 Lanxin/聚合平台生成圖片、下載原始成品、驗證圖片有效，並用文件模式回傳。
---
# 做圖

## Platform

- Primary platform: Lanxin AI / 聚合平台
- Platform URL: https://lx.lanxinai.com/
- Login credentials are intentionally not included in this skill pack.
- Use the user's already logged-in browser session when available.
- If login is required, ask the user to enter credentials or complete verification locally. Do not store or expose passwords, cookies, tokens, or API keys.
Use this skill for every image-generation related request: 做圖、生圖、生成圖片、產圖、圖片生成、做海報、產海報、海報設計、圖片設計、製作圖片、修圖、改圖、換風格、科技一點、再做一次、重做、下一版、變體、封面、縮圖、Banner、文案轉圖、PPT轉海報、PDF轉海報、繁體中文海報、商品圖、行銷圖、社群圖、廣告圖、Lanxin AI、蘭心AI、聚合平台做圖。

Do **not** use it for website tasks. 建立網站 / 做網站 / 公開部署 must create real website files first.
## Activation Rule

If the user message contains any image-making intent, use this skill first. Trigger words include but are not limited to: `做圖`, `生圖`, `生成圖片`, `產圖`, `圖片生成`, `做海報`, `產海報`, `海報`, `圖片設計`, `製作圖片`, `修圖`, `改圖`, `換風格`, `科技一點`, `再科技一點`, `再做一次`, `重做`, `下一版`, `變體`, `封面`, `縮圖`, `Banner`, `商品圖`, `行銷圖`, `廣告圖`, `社群圖`, `PPT轉海報`, `PDF轉海報`, `文案轉圖`, `繁體中文版海報`, `Lanxin`, `蘭心`, `聚合平台`.

Default behavior after activation:

1. Do not submit generation immediately.
2. Analyze materials and intent.
3. Produce a confirmation checklist.
4. Wait for explicit confirmation: `確認`, `好`, `可以`, `送出`, or equivalent.
5. Submit using the confirmed prompt unchanged.
6. Download the original generated image, verify it, then deliver in document/file mode.

This skill is only for image/poster generation workflows.

## What This Skill Can And Cannot Bundle

This skill can bundle workflow, prompts, browser/CLI procedures, verification rules, and helper scripts.

This skill **cannot** directly grant OpenClaw permissions on another machine. Runtime tools are controlled by that OpenClaw/Gateway configuration, not by `SKILL.md`. If the receiving assistant says `Session send visibility is restricted` or cannot use browser/CLI/files, the skill is not broken; the receiver's OpenClaw environment must enable the required tools first.

Read `references/environment-check.md` first when installing this skill on another OpenClaw/Codex setup or when cross-agent/subtask coordination fails.

## Required Access

The user must provide their own platform URL and login method, or confirm an already logged-in browser session. Do not bundle, store, print, or reuse another user's credentials, cookies, tokens, or passwords. Stop for CAPTCHA, 2FA, payment, quota, permission, or login blocks.

Required runtime capabilities on the receiver:

- File read/write access to the skill folder and output/download folder.
- CLI/terminal execution if using `scripts/lanxin_browser_cli.js` or Playwright.
- Browser automation access for logged-in web UI flows.
- Cross-session visibility only if the main assistant needs to coordinate sub-agents; otherwise run the workflow in the same session.

## Hard Rules

- For long tasks, send a short clean Traditional Chinese ACK first, then keep working until a file/result/blocker is returned.
- If the user gives only a rough direction, one material, or multiple materials, first analyze what was provided and produce a confirmation checklist; do not submit generation immediately.
- Before submitting generation, show a confirmation checklist and wait for explicit confirmation such as `確認`, `好`, `可以`, `送出`.
- Preserve user-confirmed prompt text exactly. Do not silently compress or rewrite it.
- All revisions, style changes, remixes, and continuation requests must still be submitted through Lanxin / 聚合平台. Do not satisfy them with local scripts, Canvas, PPT, built-in imagegen, screenshots, crops, previews, HTML/SVG composition, or any other substitute.
- Never expose browser/tool logs, JSON, raw errors, credentials, cookies, tokens, internal status, or English tool noise to the user.
- Final output must be the original generated image file or extracted original image data; never use screenshots/crops/previews as the final deliverable.
- Deliver generated images using document/file mode when possible to avoid compression and failed media-preview delivery.
- If a `MEDIA:<path>` style reply or normal image preview does not reach the user, immediately retry with the messaging/send-file capability in document mode, then report only after the provider confirms the send succeeded.
- After submitting a generation, check every 3 minutes until the final image is downloaded, verified, and sent back. Stop checking only after delivery or a clear blocker.
- Do not stop only because 5 minutes passed. More than 5 minutes means send a progress update and continue; stop only for a real blocker that cannot be resolved autonomously.
- If the same browser/tool step fails twice or there is no progress for 3-5 minutes beyond normal generation waiting, report the blocker and next concrete step.
- If permissions are missing, report the exact missing capability in clean Traditional Chinese and ask the operator to enable it; do not pretend the skill can bypass OpenClaw policy.

## Standard Workflow

1. **Environment preflight**
   - If this is a newly installed skill, read `references/environment-check.md`.
   - Confirm the receiver has browser, file, and CLI access before promising full automation.
   - If cross-agent coordination is used, confirm session visibility is enabled; otherwise run in the current session.

2. **Understand source material**
   - Download/fetch allowed files or URLs.
   - If the user provides a rough direction only, convert it into a proposed concept and list any missing business-critical information.
   - If the user provides one material, identify its role: reference image, logo, product, background, copy source, or style reference.
   - If the user provides multiple materials, map each material to a purpose before writing the prompt.
   - For PPT/PDF/docs, extract poster title, subtitle, audience, selling points, date/location/price/contact if present.
   - If the source file type is suspicious, inspect the file header before parsing.

3. **Prepare confirmation checklist**
   - Include platform, task type, material mapping, target format/ratio, visual style, title/subtitle, key copy, missing info, estimated cost/quota if known, and the exact prompt to submit.
   - For Traditional Chinese users, require Traditional Chinese text, Taiwan/HK readability, no Simplified Chinese, no garbled text.
   - If information is incomplete, still provide a usable proposed checklist and clearly mark what needs confirmation.
   - Do not submit until the user explicitly confirms.

4. **Browser generation**
   - Use OpenClaw browser automation for login, navigation, uploads, prompt entry, and result download.
   - Read `references/browser-workflow.md` when browser steps are needed.
   - Prefer `AI繪圖` / `AI绘图` / image-generation sections.
   - Choose ratio by use case: poster/story `9:16`, square social graphic `1:1`, banner horizontal.
   - Paste the confirmed prompt unchanged and submit.

5. **CLI-assisted monitoring/download**
   - Use `scripts/lanxin_browser_cli.js` as a reusable Playwright-style helper or reference implementation when a CLI/browser automation path is preferred.
   - The CLI includes a 3-minute polling loop and original-image download helpers.
   - It intentionally requires the caller to provide platform URL and login/session details; no credentials are bundled.

6. **Verify output**
   - Confirm file exists, is non-empty, and has a real image header/dimensions.
   - Reject tiny files, HTML login pages, screenshots, corrupt files, and preview crops.
   - Retry one alternate download path if verification fails; if still bad, report the blocker.

7. **Deliver**
   - Send the verified image back as a document/file when possible to avoid compression.
   - Prefer direct provider messaging/file-send APIs for Telegram delivery when available; attach the local verified file path, set a useful filename, and use document mode.
   - If the user says they did not receive the file, do not regenerate first. Verify the existing file path/size, then resend the same verified file through document/file mode.
   - Include only a short clean completion note after the send call succeeds.

## Confirmation Checklist Template

```text
主人，這張圖我準備這樣做，請確認：

- 平台：Lanxin AI / 使用者提供的聚合做圖平台
- 任務：{海報/圖片/文案轉圖/PPT轉海報}
- 比例：{9:16 / 1:1 / 16:9 / 其他}
- 風格：{高級商務/科技感/可愛/奢華/簡約}
- 文字語言：繁體中文，避免簡體字、亂碼、錯字
- 素材對應：{素材1用途 / 素材2用途 / 若只有方向則寫無素材}
- 來源重點：{摘要}
- 缺少資訊：{若無就寫無；若需主人補充則列出}
- 提交提示詞：
{完整提示詞}

確認後我再提交生成。
```

## Prompt Template

```text
繁體中文高質感{用途}海報設計，主題為「{主題}」，{比例與構圖}，{品牌色與風格}，背景包含{視覺元素}。大標題：{大標題}。副標題：{副標題}。重點文案：{賣點1}、{賣點2}、{賣點3}、{賣點4}、{賣點5}。版面乾淨高級，文字清楚可讀，適合台灣市場宣傳，無錯字，無亂碼，不要簡體字，不要多餘英文。
```

## Files

- `references/environment-check.md`: receiver-side OpenClaw permissions, install path, and common blockers.
- `references/browser-workflow.md`: browser automation procedure and stop-loss rules.
- `scripts/lanxin_browser_cli.js`: CLI/browser automation skeleton for login-aware generation, 3-minute polling, download, and verification.
