@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
fltmc >nul 2>nul
if errorlevel 1 ("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
title Unified TGBOT One-Click Installer
echo Unified TGBOT installer: merged memories, skills, workflows, IMAGE2 API, Node.js, npm, and Codex CLI.
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_TGBOT_UNIFIED.ps1"
if errorlevel 1 (echo Installation failed.&pause&exit /b 1)
echo Installation completed. The Telegram Bot backend is running in the background.
pause
