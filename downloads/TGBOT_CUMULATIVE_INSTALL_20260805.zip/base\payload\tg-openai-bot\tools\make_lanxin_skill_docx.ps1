﻿param(
    [string]$SourceMarkdown = "C:\Users\max\lanxin_skill_center_all_skill_functions_20260628.md",
    [string]$OutputDocx = "C:\Users\max\lanxin_skill_center_all_skill_functions_20260628.docx"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $SourceMarkdown -PathType Leaf)) {
    throw "Source Markdown not found: $SourceMarkdown"
}

$packageDir = Join-Path ([System.IO.Path]::GetTempPath()) "lanxin_docx_pkg_$PID"
$nodeScript = Join-Path ([System.IO.Path]::GetTempPath()) "lanxin_md_to_openxml_$PID.js"
Remove-Item -LiteralPath $packageDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $packageDir | Out-Null

$js = @'
const fs = require("fs");
const path = require("path");
const OpenCC = require("C:/Users/max/.codex/tmp/opencc-js/node_modules/opencc-js");

const source = process.argv[2];
const pkg = process.argv[3];
const converter = OpenCC.Converter({ from: "cn", to: "twp" });

let markdown = fs.readFileSync(source, "utf8")
  .replace(/\r\n/g, "\n")
  .replace(/\r/g, "\n");

markdown = converter(markdown)
  .replace(/\u5e73\u81fa/g, "\u5e73\u53f0")
  .replace(/\u8cea\u91cf/g, "\u54c1\u8cea")
  .replace(/\u71df\u92b7/g, "\u884c\u92b7")
  .replace(/\u8996\u983b/g, "\u5f71\u7247")
  .replace(/\u5468/g, "\u9031");

function mkdirp(p) {
  fs.mkdirSync(p, { recursive: true });
}

function xml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function cleanInline(s) {
  return s
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1 ($2)")
    .trim();
}

function run(text, opts = {}) {
  const props = [];
  if (opts.bold) props.push("<w:b/>");
  if (opts.italic) props.push("<w:i/>");
  if (opts.code) props.push("<w:rStyle w:val=\"CodeChar\"/>");
  const rpr = props.length ? `<w:rPr>${props.join("")}</w:rPr>` : "";
  const space = /^\s|\s$/.test(text) ? " xml:space=\"preserve\"" : "";
  return `<w:r>${rpr}<w:t${space}>${xml(text)}</w:t></w:r>`;
}

function paragraph(text, style = "BodyText", opts = {}) {
  const styleXml = style ? `<w:pStyle w:val="${style}"/>` : "";
  const indentXml = opts.indent ? `<w:ind w:left="${opts.indent}"/>` : "";
  const spacing = opts.compact
    ? "<w:spacing w:after=\"80\" w:line=\"300\" w:lineRule=\"auto\"/>"
    : "<w:spacing w:after=\"120\" w:line=\"320\" w:lineRule=\"auto\"/>";
  return `<w:p><w:pPr>${styleXml}${indentXml}${spacing}</w:pPr>${run(text, { bold: opts.bold })}</w:p>`;
}

const lines = markdown.split("\n");
const out = [];
let para = [];

function flushPara() {
  if (!para.length) return;
  out.push(paragraph(cleanInline(para.join(" ")), "BodyText"));
  para = [];
}

for (const raw of lines) {
  const line = raw.trimEnd();
  if (!line.trim()) {
    flushPara();
    continue;
  }

  const h = line.match(/^(#{1,6})\s+(.+)$/);
  if (h) {
    flushPara();
    const level = h[1].length;
    const text = cleanInline(h[2]);
    if (level === 1) out.push(paragraph(text, "Title"));
    else if (level === 2) out.push(paragraph(text, "Heading1"));
    else if (level === 3) out.push(paragraph(text, "Heading2"));
    else out.push(paragraph(text, "Heading3"));
    continue;
  }

  const numbered = line.match(/^\s*(\d+)\.\s+(.+)$/);
  if (numbered) {
    flushPara();
    out.push(paragraph(`${numbered[1]}. ${cleanInline(numbered[2])}`, "SkillTitle", { bold: true }));
    continue;
  }

  const bullet = line.match(/^(\s*)-\s+(.+)$/);
  if (bullet) {
    flushPara();
    const indent = bullet[1].length >= 3 ? 720 : 360;
    out.push(paragraph(`\u2022 ${cleanInline(bullet[2])}`, "ListParagraph", { indent, compact: true }));
    continue;
  }

  para.push(line.trim());
}
flushPara();

const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${out.join("\n")}
    <w:sectPr>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="1021" w:right="1134" w:bottom="1021" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>`;

const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Microsoft JhengHei" w:eastAsia="Microsoft JhengHei" w:hAnsi="Microsoft JhengHei"/>
        <w:sz w:val="21"/>
      </w:rPr>
    </w:rPrDefault>
    <w:pPrDefault>
      <w:pPr><w:spacing w:after="120" w:line="320" w:lineRule="auto"/></w:pPr>
    </w:pPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="BodyText">
    <w:name w:val="Body Text"/>
    <w:qFormat/>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:sz w:val="21"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="0" w:after="320"/></w:pPr>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:b/><w:color w:val="0F172A"/><w:sz w:val="42"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:basedOn w:val="BodyText"/>
    <w:next w:val="BodyText"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="320" w:after="160"/><w:keepNext/></w:pPr>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:b/><w:color w:val="1D4ED8"/><w:sz w:val="30"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:basedOn w:val="BodyText"/>
    <w:next w:val="BodyText"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="240" w:after="120"/><w:keepNext/></w:pPr>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:b/><w:color w:val="334155"/><w:sz w:val="25"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading3">
    <w:name w:val="heading 3"/>
    <w:basedOn w:val="BodyText"/>
    <w:next w:val="BodyText"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="180" w:after="100"/><w:keepNext/></w:pPr>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:b/><w:color w:val="475569"/><w:sz w:val="23"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="SkillTitle">
    <w:name w:val="Skill Title"/>
    <w:basedOn w:val="BodyText"/>
    <w:qFormat/>
    <w:pPr><w:spacing w:before="160" w:after="80"/><w:keepNext/></w:pPr>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:b/><w:color w:val="111827"/><w:sz w:val="22"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="ListParagraph">
    <w:name w:val="List Paragraph"/>
    <w:basedOn w:val="BodyText"/>
    <w:qFormat/>
    <w:rPr><w:rFonts w:eastAsia="Microsoft JhengHei"/><w:sz w:val="21"/></w:rPr>
  </w:style>
  <w:style w:type="character" w:styleId="CodeChar">
    <w:name w:val="Code Char"/>
    <w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="Microsoft JhengHei"/><w:color w:val="1E3A8A"/></w:rPr>
  </w:style>
</w:styles>`;

mkdirp(path.join(pkg, "_rels"));
mkdirp(path.join(pkg, "word", "_rels"));
fs.writeFileSync(path.join(pkg, "[Content_Types].xml"), `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>`, "utf8");
fs.writeFileSync(path.join(pkg, "_rels", ".rels"), `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`, "utf8");
fs.writeFileSync(path.join(pkg, "word", "_rels", "document.xml.rels"), `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`, "utf8");
fs.writeFileSync(path.join(pkg, "word", "document.xml"), documentXml, "utf8");
fs.writeFileSync(path.join(pkg, "word", "styles.xml"), stylesXml, "utf8");
'@

Set-Content -LiteralPath $nodeScript -Value $js -Encoding UTF8
try {
    node $nodeScript $SourceMarkdown $packageDir
} finally {
    Remove-Item -LiteralPath $nodeScript -Force -ErrorAction SilentlyContinue
}

Remove-Item -LiteralPath $OutputDocx -Force -ErrorAction SilentlyContinue
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($packageDir, $OutputDocx)
Remove-Item -LiteralPath $packageDir -Recurse -Force -ErrorAction SilentlyContinue

$file = Get-Item -LiteralPath $OutputDocx
if ($file.Length -le 0) {
    throw "DOCX is empty: $OutputDocx"
}

Write-Output $file.FullName
