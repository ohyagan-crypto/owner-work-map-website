﻿& 'C:\Users\max\.codex-tgbot\skills\hfsw\tools\hfsw_finalize_qa.ps1' @args
exit $LASTEXITCODE
