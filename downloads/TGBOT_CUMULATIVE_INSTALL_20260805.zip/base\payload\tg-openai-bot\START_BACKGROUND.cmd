@echo off
setlocal
cd /d "%~dp0"

echo Starting Codex bot in the background...
powershell -NoProfile -ExecutionPolicy Bypass -File ".\stop_bot.ps1" >nul 2>nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
start "Codex Telegram Bot Watchdog" /min "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0watch_codex_bot.ps1"

echo Codex bot watchdog started in a minimized PowerShell window.
echo Check Telegram with /ping.
echo Logs:
echo %cd%\codex_bot.log
echo %cd%\codex_bot_watchdog.log
pause
