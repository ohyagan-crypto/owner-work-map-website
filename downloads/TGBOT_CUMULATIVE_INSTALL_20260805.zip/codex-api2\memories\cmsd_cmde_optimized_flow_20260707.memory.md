# CMSD / CMDE Optimized Flow - 2026-07-07

Owner correction:

Future `cmsd` or `cmde` workflows must follow this exact production order:

1. Take the owner's current material, images, video reference, copywriting, or script to the aggregation platform and analyze it with Claude Opus 4.8. If a newer Claude Opus model is available, use the newest one. If Claude Opus 4.8 or newer is unavailable, report the real blocker instead of pretending analysis was done.
2. Claude analysis must be production-ready for IMS: theme, story logic, character setup, character consistency requirements, scene order, camera language, each storyboard cell, text/subtitle risks, and SD video prompt structure.
3. After Claude analysis, use the aggregation platform IMS workflow to create a `3x3` storyboard image. In CMSD/CMDE, the IMS storyboard step is auto-confirmed by the owner once analysis is complete and information is sufficient.
4. Download and verify the storyboard image before moving to SD. The storyboard must be treated as the main reference material for the SD video.
5. Before any SD/Dreamina/Seedance video generation, give the owner a confirmation checklist. The checklist must include Claude analysis summary, 3x3 storyboard file, character/product materials, model route, duration, ratio, resolution, estimated credits, complete prompt, concise prompt, detail-enhanced prompt, negative prompt, known risks, and Telegram same-origin document delivery plan.
6. After the owner confirms the SD checklist, submit video generation immediately. Do not loop back into Claude or IMS confirmation unless the owner also requested a change.

Applies together with the Kuli correction:

- Do not use the black hoodie / orange drawstrings / peeled banana image as Kuli identity reference.
- If the task involves Kuli and the correct Kuli reference is missing, stop before generation and ask for the corrected Kuli character image.

Completion standard:

CMSD/CMDE is not complete until Claude analysis, IMS 3x3 storyboard, SD confirmation checklist, confirmed SD video generation, MP4 verification, and same-origin Telegram document delivery are completed, or a real external blocker is reported with any local backup path.
