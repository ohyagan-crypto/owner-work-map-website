﻿param(
    [Parameter(Mandatory = $true)]
    [string[]]$Skills,

    [string[]]$Memories = @(),

    [string]$Name = 'codex_skill_handoff',

    [switch]$IncludeAgents
)

$ErrorActionPreference = 'Stop'

$root = [Environment]::GetFolderPath('UserProfile')
if ([string]::IsNullOrWhiteSpace($root)) {
    $root = 'C:\Users\max'
}

$codexRoot = Join-Path $root '.codex'
$skillsRoot = Join-Path $codexRoot 'skills'
$memoriesRoot = Join-Path $codexRoot 'memories'
$desktopRoot = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktopRoot)) {
    $desktopRoot = Join-Path $root 'Desktop'
}
$handoffRoot = Join-Path $desktopRoot '龍蝦記憶'
New-Item -ItemType Directory -Path $handoffRoot -Force | Out-Null

$tempRoot = if (-not [string]::IsNullOrWhiteSpace($env:TEMP)) { $env:TEMP } else { 'C:\tmp' }
# Owner rule: every handoff package filename must include the local creation date.
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$workRoot = Join-Path $tempRoot "$Name`_$stamp"
$packageSkillsRoot = Join-Path $workRoot '.codex\skills'
$packageMemoriesRoot = Join-Path $workRoot '.codex\memories'
$zipPath = Join-Path $handoffRoot "$Name`_$stamp.zip"

New-Item -ItemType Directory -Path $packageSkillsRoot -Force | Out-Null
New-Item -ItemType Directory -Path $packageMemoriesRoot -Force | Out-Null

$includedSkills = New-Object System.Collections.Generic.List[string]
$includedMemories = New-Object System.Collections.Generic.List[string]
$missingItems = New-Object System.Collections.Generic.List[string]
$includedTopFiles = New-Object System.Collections.Generic.List[string]

foreach ($skill in ($Skills -join ',' -split ',')) {
    $skillName = $skill.Trim()
    if ([string]::IsNullOrWhiteSpace($skillName)) { continue }

    $src = Join-Path $skillsRoot $skillName
    if (-not (Test-Path -LiteralPath $src)) {
        Write-Warning "Skill not found: $skillName"
        $missingItems.Add("skill:$skillName")
        continue
    }

    Copy-Item -LiteralPath $src -Destination (Join-Path $packageSkillsRoot $skillName) -Recurse -Force
    $includedSkills.Add($skillName)
}

foreach ($memory in ($Memories -join ',' -split ',')) {
    $memoryName = $memory.Trim()
    if ([string]::IsNullOrWhiteSpace($memoryName)) { continue }

    $src = Join-Path $memoriesRoot $memoryName
    if (-not (Test-Path -LiteralPath $src)) {
        Write-Warning "Memory not found: $memoryName"
        $missingItems.Add("memory:$memoryName")
        continue
    }

    Copy-Item -LiteralPath $src -Destination (Join-Path $packageMemoriesRoot $memoryName) -Force
    $includedMemories.Add($memoryName)
}

if ($IncludeAgents) {
    $agentsPath = Join-Path $root 'AGENTS.md'
    if (Test-Path -LiteralPath $agentsPath) {
        Copy-Item -LiteralPath $agentsPath -Destination (Join-Path $workRoot 'AGENTS.md') -Force
        $includedTopFiles.Add('AGENTS.md')
    }
}

function Format-MarkdownList {
    param(
        [System.Collections.IEnumerable]$Items,
        [string]$EmptyText
    )

    $arr = @($Items)
    if ($arr.Count -eq 0) {
        return "- $EmptyText"
    }

    return (($arr | ForEach-Object { "- $_" }) -join [Environment]::NewLine)
}

$skillsList = Format-MarkdownList -Items $includedSkills -EmptyText '本包沒有技能資料夾。'
$memoriesList = Format-MarkdownList -Items $includedMemories -EmptyText '本包沒有記憶檔。'
$missingList = Format-MarkdownList -Items $missingItems -EmptyText '沒有缺漏項目。'
$topFilesList = Format-MarkdownList -Items $includedTopFiles -EmptyText '沒有額外頂層規則檔。'

$install = @"
# 給另一個 Codex / OpenClaw / Telegram Bot 的安裝與學習指南

這不是單純備份包，而是給接收端一次學會用的教學包。請接收端完整讀完本檔，再複製檔案與重啟。

## 1. 這包包含什麼

### 技能
$skillsList

### 記憶
$memoriesList

### 其他頂層檔案
$topFilesList

### 缺漏項目
$missingList

## 2. 安裝位置

請先解壓縮 zip。

把 zip 裡的 `.codex\skills\` 內容複製到接收端電腦：

```text
C:\Users\你的使用者名稱\.codex\skills\
```

如果 zip 裡有 `.codex\memories\`，把內容複製到：

```text
C:\Users\你的使用者名稱\.codex\memories\
```

如果 zip 裡有 `AGENTS.md`，請先閱讀，只把需要的規則新增到接收端既有規則中；不要覆蓋接收端原本重要資料。

## 3. 重啟要求

複製完成後，必須重啟 Codex、OpenClaw，或接收端 Telegram bot。沒有重啟時，技能索引可能不會重新載入。

## 4. 接收端必須怎麼學

1. 先讀本檔。
2. 再讀 `MEMORY_AND_BEHAVIOR_SUMMARY.md`。
3. 再讀每個技能資料夾內的 `SKILL.md`。
4. 如果技能 `SKILL.md` 指向 `references/`、`scripts/` 或其他相對路徑，執行前必須依技能指示讀取相關檔案。
5. 不要只看到技能名稱就回覆完成；要能說出觸發詞、第一步、完整流程、卡點規則、交付方式與安全限制。

## 5. 觸發與執行規則

收到使用者提到本包技能名稱、觸發詞、工作流、記憶、打包、zip、學習、安裝、轉交、做圖、腳本、影片、SD、網站等相關任務時，接收端要先讀本地對應技能或記憶，再回覆或執行。

接收端不能只說「收到、開始處理、稍後回報」當作最後答案。每一輪要交付實際結果、檔案、網址、路徑、確認清單，或明確卡點。

## 6. 使用者可見回覆風格

面向主人時請使用乾淨繁體中文：

- 不輸出 raw log、JSON dump、堆疊、token、cookie、密碼、API key。
- 不輸出工具狀態、內部狀態、偵錯文字、英文錯誤流水。
- 不把「等待中、正在處理」當作任務完成回覆。
- 完成時要給路徑、網址、檔案名稱、已安裝項目或可轉發訊息。
- 卡住時要說清楚卡點、已完成什麼、需要主人提供什麼。

## 7. 安全規則

不要打包、保存、輸出或轉傳：

- 密碼、API key、token、cookie。
- 瀏覽器 profile、登入資料、auth 檔。
- 憑證資料庫、Telegram bot token。
- 原始工具日誌、偵錯 trace、可能含秘密的截圖。

如果遇到登入、驗證碼、二階段驗證、付款確認、帳號風控、權限不足，要停止並用繁體中文說明卡點，不要猜測或繞過。

## 8. 接收端測試方式

重啟後請測試：

```text
請問你已安裝哪些技能？請列出本包技能名稱、觸發詞、第一步和交付方式。
```

再測試每個技能的自然語言觸發，例如：

```text
我說 cls 時，你應該怎麼做？
```

```text
我說 ims 或做圖時，你應該怎麼做？
```

```text
我要把這個技能包交給另一個 Codex，你應該怎麼打包？
```

## 9. 安裝完成前檢查清單

- 已複製 `.codex\skills\`。
- 如有 `.codex\memories\`，已複製記憶檔。
- 已閱讀 `INSTALL_FOR_OTHER_CODEX.md`。
- 已閱讀 `MEMORY_AND_BEHAVIOR_SUMMARY.md`。
- 已閱讀每個技能的 `SKILL.md`。
- 已重啟 Codex / OpenClaw / Telegram bot。
- 已用測試句確認技能會被觸發。
- 回覆主人時只輸出乾淨繁體中文。
- 知道哪些內容不能打包或輸出。

完成後請回覆主人：已安裝、已重啟、已測試，並列出學會的技能與觸發詞。
"@

[System.IO.File]::WriteAllText((Join-Path $workRoot 'INSTALL_FOR_OTHER_CODEX.md'), $install, [System.Text.UTF8Encoding]::new($false))

$memorySummary = @"
# 記憶與行為摘要

這份摘要是給接收端 Codex / OpenClaw / Telegram bot 讀的。目的不是只知道有檔案，而是學會主人的固定偏好。

## 主人要你記住

1. 技能、記憶、工作流、zip、交接包相關任務，要先讀本地技能或記憶檔，再行動。
2. 幫主人打包技能或記憶時，必須做成詳細教學包，讓其他 Codex / OpenClaw 一次學會，不要再讓主人重教。
3. 回覆主人要用乾淨繁體中文，不輸出內部工具狀態、raw log、JSON、token、cookie、密碼或偵錯訊息。
4. 不要把「收到、開始處理、稍後回報」當作最終交付；要交付結果、檔案、網址、路徑、確認清單或明確卡點。

## 什麼時候適用

- 主人要求打包、導出、轉交、安裝、學習技能或記憶。
- 主人要把技能包交給其他 Codex、OpenClaw、Telegram bot。
- 主人提到 workflow、zip、memory、skill、學會、不要再教學。
- 主人要求建立可轉發給接收端的安裝說明。

## 接收端應該怎麼做

1. 先確認本包有哪些技能與記憶。
2. 安裝到正確 `.codex` 位置。
3. 重啟 Codex / OpenClaw / Telegram bot。
4. 讀每個技能的 `SKILL.md` 和相關 reference。
5. 用測試句驗證觸發。
6. 回覆主人完整安裝結果與可用觸發詞。

## 絕對不要做

- 不要要求主人重新教已寫在包內的流程。
- 不要輸出秘密、token、cookie、密碼、auth 檔或 raw log。
- 不要只回「已收到」或「正在處理」就結束。
- 不要把打包包做成只有資料夾、沒有教學文件的備份包。

## 正確回覆範例

已安裝並重啟完成。這包包含 `cls` 與 `ims`，我已讀取兩個 `SKILL.md`、交接說明與記憶摘要。之後你說 `cls`，我會先用 Claude 4.8 以上做腳本/影片/SD 前置分析；你說 `ims` 或做圖，我會使用聚合平台做圖流程，先給確認清單，確認後才提交。

## 卡點回覆範例

目前卡在接收端沒有 `.codex\skills\` 寫入權限。已完成解壓與讀取安裝說明，但無法複製技能。需要主人在該電腦開啟寫入權限，或提供可寫入的 Codex 技能路徑。
"@

[System.IO.File]::WriteAllText((Join-Path $workRoot 'MEMORY_AND_BEHAVIOR_SUMMARY.md'), $memorySummary, [System.Text.UTF8Encoding]::new($false))

$forward = @"
請學習並安裝這個 Codex / OpenClaw 技能與記憶教學包。

請先解壓 zip，第一個讀：
`INSTALL_FOR_OTHER_CODEX.md`

第二個讀：
`MEMORY_AND_BEHAVIOR_SUMMARY.md`

然後把 zip 裡的 `.codex\skills\` 內容複製到你這台電腦：

```text
C:\Users\你的使用者名稱\.codex\skills\
```

如果 zip 裡有 `.codex\memories\`，也複製到：

```text
C:\Users\你的使用者名稱\.codex\memories\
```

如果有 `AGENTS.md`，請只讀取並合併需要的規則，不要覆蓋你原本重要設定。

複製完成後，請重啟 Codex、OpenClaw 或 Telegram bot，讓技能索引重新載入。

重啟後請測試並回覆：
1. 已安裝哪些技能。
2. 每個技能的觸發詞。
3. 觸發後第一步要讀什麼檔案。
4. 完整工作流。
5. 最後要交付什麼給主人。
6. 什麼情況要停止並回報卡點。

回覆主人時只用乾淨繁體中文。不要輸出 raw log、JSON、工具狀態、token、cookie、密碼、API key、偵錯紀錄，也不要只回「收到、開始處理、稍後回報」當作完成。

安裝完成後，請回覆：
「技能包已安裝、已重啟、已讀取教學文件、已完成測試」，並列出你學會的技能與觸發詞。
"@

[System.IO.File]::WriteAllText((Join-Path $workRoot 'FORWARD_TO_RECEIVER_TGBOT.txt'), $forward, [System.Text.UTF8Encoding]::new($false))

$filesForManifest = Get-ChildItem -LiteralPath $workRoot -Recurse -File |
    ForEach-Object { $_.FullName.Substring($workRoot.Length + 1) } |
    Sort-Object

$filesList = Format-MarkdownList -Items $filesForManifest -EmptyText '沒有檔案。'

$manifest = @"
# Package Manifest

## Package

- Name: $Name
- Created: $stamp
- Source user root: $root

## Included Skills

$skillsList

## Included Memories

$memoriesList

## Included Top-Level Files

$topFilesList

## Missing Items

$missingList

## Files

$filesList

## Receiver Must Read

1. `INSTALL_FOR_OTHER_CODEX.md`
2. `MEMORY_AND_BEHAVIOR_SUMMARY.md`
3. Each included skill's `SKILL.md`
4. Any reference files required by each skill

## Safety

This package should not contain passwords, tokens, cookies, browser profiles, auth files, credential stores, or raw logs. The receiver must keep owner-facing replies in clean Traditional Chinese and return concrete deliverables or exact blockers.
"@

[System.IO.File]::WriteAllText((Join-Path $workRoot 'PACKAGE_MANIFEST.md'), $manifest, [System.Text.UTF8Encoding]::new($false))

if (Test-Path -LiteralPath $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}

Compress-Archive -Path (Join-Path $workRoot '*') -DestinationPath $zipPath -Force
Get-Item -LiteralPath $zipPath
