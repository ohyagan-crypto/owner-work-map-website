# Daily Workflow Optimization - 2026-07-07

Created by the daily 01:00 owner work review automation.

## Scope
- Target date: 2026-07-07
- Owner task messages reviewed: 6
- Task types: NBS / NotebookLM, 一般任務, 技能記憶 / 流程優化

## Reusable Improvements
- NBS 任務每日檢查必須以 requested deliverables 為主：PPTX、MP4、MP3 各自完成下載、格式驗證、時長或頁數驗證、Telegram 原來源送達後，才可標記完成。
- 遇到『少了、漏傳、已生成但沒給我』時，優先復原同一筆 NBS 任務與 artifact 資料夾，不重開任務，也不只口頭說明。
- Telegram 任務每日複盤要核對：任務完成文字、實際檔案、Telegram 送達紀錄三者一致；任何一項缺失都列為隔日優先修復點。
- 狀態追問不得用固定待命句；必須先查 request status、artifact、平台頁面或 delivery state，再回覆真實結果。
- 技能與記憶優化採用 dated memory 先落地；只有當規則穩定且能驗證時，再改對應 SKILL.md，避免每日自動改壞技能主檔。
- 每日會報完成後必須刷新 codex_learning_index.json，確認新增記憶可被後續任務檢索。

## Regression Signals
- 22:35 少了mp3語音 為什麼nbs常常少資料
- 22:59 我看已經生成好10分鐘了還是沒給我
- 23:34 我看語音已經生成好10分鐘了還是沒給我
- 23:37 記好並優化nbs 不要再看到錯了 少做少檔案漏傳 檔案

## Completion Rule
- Daily review is complete only after this memory file exists, the learning index is refreshed, and the Telegram daily report is sent or a concrete Telegram blocker is recorded.
