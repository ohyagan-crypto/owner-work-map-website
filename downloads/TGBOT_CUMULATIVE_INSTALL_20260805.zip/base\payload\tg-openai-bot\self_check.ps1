﻿$ErrorActionPreference = "Continue"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvPath = Join-Path $ProjectDir ".env"
$OutPath = Join-Path $ProjectDir "self_check.txt"

function Add-Line {
    param([string] $Text = "")
    Add-Content -Path $OutPath -Value $Text -Encoding UTF8
    Write-Host $Text
}

function Read-DotEnv {
    param([string] $Path)

    $Values = @{}
    if (-not (Test-Path $Path)) {
        return $Values
    }

    foreach ($RawLine in Get-Content -Path $Path -Encoding UTF8) {
        $Line = $RawLine.Trim().Trim([char]0xFEFF)
        if ([string]::IsNullOrWhiteSpace($Line) -or $Line.StartsWith("#") -or -not $Line.Contains("=")) {
            continue
        }

        $EqualsIndex = $Line.IndexOf("=")
        $Key = $Line.Substring(0, $EqualsIndex).Trim()
        $Value = $Line.Substring($EqualsIndex + 1).Trim().Trim('"').Trim("'")
        $Values[$Key] = $Value
    }

    return $Values
}

function Mask {
    param([string] $Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return ""
    }
    return "***present***"
}

function Test-PowerShellSyntax {
    param([string] $Path)

    if (-not (Test-Path $Path)) {
        Add-Line "FAIL missing: $Path"
        return
    }

    try {
        $Tokens = $null
        $Errors = $null
        [System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$Tokens, [ref]$Errors) | Out-Null
        if ($Errors -and $Errors.Count -gt 0) {
            Add-Line "FAIL syntax: $Path"
            foreach ($ErrorItem in $Errors) {
                Add-Line "  line $($ErrorItem.Extent.StartLineNumber): $($ErrorItem.Message)"
            }
        }
        else {
            Add-Line "OK syntax: $Path"
        }
    }
    catch {
        Add-Line "WARN syntax parser unavailable for $Path`: $($_.Exception.Message)"
    }
}

Set-Location $ProjectDir
if (Test-Path $OutPath) {
    Remove-Item -Path $OutPath -Force
}

Add-Line "Telegram AI Bot self-check"
Add-Line "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Add-Line "ProjectDir: $ProjectDir"
Add-Line ""

Add-Line "== Entry files =="
foreach ($Name in @(
    "BOT_NOW.cmd",
    "bot_now.ps1",
    "COLLECT_DIAGNOSTICS.cmd",
    "collect_diagnostics.ps1",
    "RESET_ENV.cmd",
    "setup_env.ps1",
    "STOP_BOT.cmd",
    "stop_bot.ps1"
)) {
    $Path = Join-Path $ProjectDir $Name
    Add-Line "$Name exists: $(Test-Path $Path)"
}
Add-Line ""

Add-Line "== PowerShell syntax =="
foreach ($Name in @(
    "bot_now.ps1",
    "collect_diagnostics.ps1",
    "setup_env.ps1",
    "stop_bot.ps1",
    "test_reply_once.ps1",
    "test_ai_once.ps1",
    "telegram_only_bot.ps1"
)) {
    Test-PowerShellSyntax (Join-Path $ProjectDir $Name)
}
Add-Line ""

Add-Line "== .env =="
$Env = Read-DotEnv $EnvPath
Add-Line ".env exists: $(Test-Path $EnvPath)"
$TelegramToken = $Env["TELEGRAM_BOT_TOKEN"]
$OpenAiKey = $Env["OPENAI_API_KEY"]
$TelegramApiBase = $Env["TELEGRAM_API_BASE"]
$OpenAiBaseUrl = $Env["OPENAI_BASE_URL"]
$OpenAiModel = $Env["OPENAI_MODEL"]
$OpenAiFallbackModels = $Env["OPENAI_FALLBACK_MODELS"]
$OpenAiReasoningEffort = $Env["OPENAI_REASONING_EFFORT"]
$OpenAiStore = $Env["OPENAI_STORE"]

Add-Line "TELEGRAM_BOT_TOKEN: $(Mask $TelegramToken)"
Add-Line "OPENAI_API_KEY: $(Mask $OpenAiKey)"
Add-Line "TELEGRAM_API_BASE: $TelegramApiBase"
Add-Line "OPENAI_BASE_URL: $OpenAiBaseUrl"
Add-Line "OPENAI_MODEL: $OpenAiModel"
Add-Line "OPENAI_FALLBACK_MODELS: $OpenAiFallbackModels"
Add-Line "OPENAI_REASONING_EFFORT: $OpenAiReasoningEffort"
Add-Line "OPENAI_STORE: $OpenAiStore"

if (-not $TelegramToken) {
    Add-Line "FAIL env: missing TELEGRAM_BOT_TOKEN"
}
elseif ($TelegramToken -notmatch "^\d+:[A-Za-z0-9_-]{30,}$") {
    Add-Line "FAIL env: TELEGRAM_BOT_TOKEN format looks wrong"
}
else {
    Add-Line "OK env: TELEGRAM_BOT_TOKEN format"
}

if (-not $OpenAiKey) {
    Add-Line "FAIL env: missing OPENAI_API_KEY"
}
elseif ($OpenAiKey.ToLowerInvariant().Contains("model_provider") -or $OpenAiKey.ToLowerInvariant().Contains("base_url")) {
    Add-Line "FAIL env: OPENAI_API_KEY contains config text, not an API key"
}
else {
    Add-Line "OK env: OPENAI_API_KEY present"
}

if ($OpenAiBaseUrl -eq "https://lanxinai.com") {
    Add-Line "WARN env: OPENAI_BASE_URL should be https://lanxinai.com/v1"
}

Add-Line ""
Add-Line "Self-check written to: $OutPath"
