﻿$ErrorActionPreference = "Stop"
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
function Required([string]$Prompt) { while ($true) { $v=Read-Host $Prompt; if(-not [string]::IsNullOrWhiteSpace($v)){return $v.Trim()} } }
function Secret([string]$Prompt) { while($true){ $s=Read-Host $Prompt -AsSecureString; $v=[System.Net.NetworkCredential]::new('', $s).Password; if(-not [string]::IsNullOrWhiteSpace($v)){return $v.Trim()} } }

$telegram = Required "1/5 TGBOT Token"
$apiKey = Secret "2/5 API Key (hidden)"
$apiUrl = Required "3/5 API URL (example: https://api.mcdesign.cn/v1)"
$image2Key = Secret "4/5 IMAGE2 API Key (hidden)"
$image2Url = Required "5/5 IMAGE2 API URL (example: https://api.xinyunai.cloud/v1)"
$telegram = $telegram.Trim()
$apiUrl = $apiUrl.TrimEnd('/')
$image2Url = $image2Url.TrimEnd('/')
if($apiUrl -notmatch '^https?://'){throw "General API URL must start with http:// or https://"}
if($image2Url -notmatch '^https?://'){throw "IMAGE2 API URL must start with http:// or https://"}
$codexHome = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex-api2'
New-Item -ItemType Directory -Path (Join-Path $codexHome 'secrets') -Force | Out-Null
$apiKey | ConvertTo-SecureString -AsPlainText -Force | Export-Clixml -LiteralPath (Join-Path $codexHome 'secrets\mcdesign-api-key.clixml')
$envLines = @(
 "TELEGRAM_BOT_TOKEN=$telegram",
 "TELEGRAM_OWNER_CHAT_ID=",
 "TELEGRAM_ALLOWED_CHAT_IDS=",
 "CODEX_ALLOW_ALL_CHATS=false",
 "OPENAI_API_KEY=$apiKey",
 "API2_KEY=$apiKey",
 "OPENAI_BASE_URL=$apiUrl",
 "IMAGE2_API_KEY=$image2Key",
 "IMAGE2_BASE_URL=$image2Url",
 "IMAGE2_MODEL=gpt-image-2",
 "IMAGE2_SIZE=1024x1792",
 "IMAGE2_OUTPUT_DIR=$project\outputs\image2",
 "OPENAI_MODEL=gpt-5.6-sol",
 "OPENAI_FALLBACK_MODELS=gpt-5.4,gpt-5.5-openai-compact",
 "OPENAI_REASONING_EFFORT=low",
 "OPENAI_STORE=false",
 "TELEGRAM_API_BASE=https://api.telegram.org",
 "CODEX_COMMAND=codex",
 "CODEX_HOME=$([Environment]::GetFolderPath('UserProfile'))\.codex-api2",
 "CODEX_SANDBOX=danger-full-access",
 "CODEX_BYPASS_APPROVALS_AND_SANDBOX=true",
 "CODEX_TIMEOUT_SECONDS=1800",
 "CODEX_QUICK_TIMEOUT_SECONDS=900",
 "CODEX_MEDIUM_TIMEOUT_SECONDS=1200",
 "CODEX_COMPLEX_TIMEOUT_SECONDS=1800",
 "CODEX_MAX_PARALLEL_REQUESTS=3",
 "CODEX_RETRY_ATTEMPTS=2",
 "CODEX_RESULT_RETRY_ATTEMPTS=2",
 "CODEX_REASONING_SIMPLE=low",
 "CODEX_REASONING_MEDIUM=medium",
 "CODEX_REASONING_COMPLEX=high",
 "CODEX_MODEL=gpt-5.6-sol",
 "CODEX_FALLBACK_MODELS=gpt-5.4,gpt-5.5-openai-compact",
 "CODEX_REASONING_ROUTE_ENABLED=true",
 "TELEGRAM_BOT_INSTANCE_NAME=TGBOT",
 "TELEGRAM_DIRECT_SHORTCUTS_ENABLED=true",
 "TELEGRAM_MAX_UPLOAD_BYTES=20000000",
 "TELEGRAM_DROP_PENDING_UPDATES_ON_START=false"
)
[IO.File]::WriteAllLines((Join-Path $project '.env'),$envLines,[Text.UTF8Encoding]::new($false))
Write-Host "Wrote $project\.env" -ForegroundColor Green
