---
name: ims
description: Use when the owner says ims or asks to generate, create, design, revise, resend, or deliver images/posters/visual designs. This is the single authoritative IMS workflow: Blue Star/Lanxin-only generation, material-first analysis, confirmation before spending credits, fixed profile login continuity, fast stuck detection, original file validation, and same-origin Telegram document delivery.
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

## 2026-07-08 IMS v7 Multi-Material Confirmation Rule

This rule applies to `ims7`, `ims v7`, and any IMS image/poster task that contains more than one material, including multiple Telegram images, screenshots, PDFs, PPT pages, files, reference packs, character assets, product assets, or supplementary uploads.

1. First inspect every material in the current task and assign stable IDs such as `M01`, `M02`, `M03`. Do not analyze only the first, last, newest, or most visually obvious material.
2. Analyze each material separately: visible content, visible text/buttons/marked areas, intended use, useful elements, elements to ignore, privacy/sensitive-data risks, and any platform limitation.
3. After the per-material analysis, make one combined cross-material judgment before writing the confirmation checklist: shared goal, correct order, relationships between materials, conflicts, missing pieces, output count, output format, and which material feeds each final image.
4. Only after the combined judgment is complete may you give the owner the confirmation checklist. The checklist must include material count/order, integrated conclusion, output form, ratio/size, style, required text, brand wording, per-output material usage, redaction rules, Blue Star platform route, and same-origin Telegram document delivery.
5. If a required material is unreadable, missing, unsupported by the platform, or too many materials exceed one platform submission, report the exact affected material ID and choose a safe batching plan instead of silently omitting it.
6. Do not submit to Blue Star or spend credits before the owner confirms this combined checklist, except for a higher-priority workflow that explicitly grants automatic confirmation.
7. If the final deliverable contains more than one image, all outputs must share one coherent style system: same palette family, typography style, layout density, border/radius treatment, icon/annotation language, brand wording, ratio, and filename/order plan. The confirmation checklist must state this shared style system before submission.

## 2026-07-12 Owner Setting: Multi-Material IMS Unified Production

Owner correction: when the owner sends multiple materials for `ims`, `同風格 ims`, `換風格`, batch teaching images, SOP screenshots, product posters, storyboard panels, or any image-making task with recent Telegram uploads, IMS must treat the batch as one unified production task.

1. Inventory every current-task material first and assign stable IDs such as `M01`, `M02`, `M03`. Do not answer from only the first, newest, or most visually obvious image.
2. Analyze each material separately, then produce one cross-material conclusion before asking for confirmation.
3. The confirmation checklist must be unified and must include:
   - total material count and intended order;
   - which materials are in scope and which unrelated older uploads are excluded;
   - output count, output type, ratio, and filename/order plan;
   - one shared visual system for the entire batch;
   - per-output material usage;
   - preserved text/buttons/marked areas;
   - redaction and sensitive-data handling;
   - Blue Star route and same-origin Telegram document delivery.
4. If the user asks for a style change across several images, choose one coherent shared style before generation. All final images must use the same palette family, typography tone, layout density, border/radius treatment, icon/annotation language, brand wording, ratio, and export naming pattern.
5. For tutorial/SOP screenshots, preserve the exact teaching sequence, operation names, red boxes/arrows/callouts, and Traditional Chinese wording. Do not invent UI, add fake buttons, rewrite the step meaning, or introduce Simplified Chinese.
6. If some recent Telegram materials are unrelated to the current IMS task, explicitly exclude them in the checklist instead of silently mixing them into the prompt.
7. If the owner confirms the unified checklist, generate the complete batch through Blue Star, then download, validate, and deliver every final PNG by same-origin Telegram document mode. Do not stop after only one image, only a prompt, or only a local backup.
8. If generation, upload, download, validation, or Telegram delivery fails, apply the global retry rule: inspect the real state and retry recoverable failures up to at least five real attempts before reporting a blocker, unless the blocker is external such as login verification, CAPTCHA, payment, missing material, platform outage, or missing origin chat id.
9. Owner correction: put the unified confirmation checklist at the very end of the pre-generation reply. The readable order must be: conclusion, material inventory, per-material analysis, cross-material judgment, shared style/prompt direction, then the final `確認清單`. Do not place the checklist before analysis or in the middle of the reply.

# IMS - 藍星圖片製作技能

更新日期：2026-07-07
狀態：這份 `C:\Users\max\.codex\skills\ims\SKILL.md` 是唯一主 IMS 技能。舊的 `ims_日期` 與臨時匯入版不得再作為觸發來源。

## 最高原則

1. `ims` 等於做圖，不是閒聊或詢問。收到 `ims`、做圖、生圖、生成圖片、產圖、海報、圖片設計、修圖、改圖、重做、換風格、再一版、補送、重傳、圖片沒有收到，都要進入本技能。
2. 圖片與海報生成只使用藍星平台。技術網址可寫 `https://lx.lanxinai.com/ai-image`，但面向主人時稱呼為「藍星」或「藍星平台」。
3. 不可用 Codex 內建 imagegen、本機腳本、Canvas、PPT、PS、ImageMagick、截圖、舊圖庫、縮圖、預覽圖或其他網站替代藍星輸出。
4. 產出完成不等於本機有檔案。Telegram 來源任務必須把最終檔案用文件模式送回同一個來源聊天；若來源 chat id 缺失，才回報本機備份路徑與卡點。
5. 不可把進度句當完成。必須給可交付結果、檔案、網址、路徑，或明確卡點。
6. 不可曝光密碼、token、API key、cookie、auth 檔、瀏覽器設定檔、raw log、JSON dump、內部錯誤、工具狀態或偵錯文字。

## 觸發範圍

使用本技能處理：

- `ims`
- 做圖、生圖、生成圖片、產圖、圖片生成、圖片設計
- 做海報、產海報、海報設計、繁體中文海報、商品圖、行銷圖、社群圖、廣告圖、封面、縮圖、Banner
- 把文案、截圖、照片、PDF、PPT、網站內容、素材包整理成圖片或海報
- 修改、重做、換風格、科技一點、再做一次、下一版、修這裡、哪裡有錯、補送、重傳
- Telegram 圖片交付失敗、檔名亂碼、主人說沒收到

不要用本技能處理網站建立、網站更新、GitHub Pages 部署、純文字回答、影片剪輯或 NotebookLM 任務。

## 快速起手與任務隔離

1. 開始時先判斷唯一任務類型：新圖、素材轉圖、續改、重傳、補送、批次圖、CMSD 分鏡圖，或 Telegram 交付修復。
2. 開始時先判斷唯一交付物：單張 PNG、多張 PNG、分鏡圖、ZIP、確認清單、補送檔案，或 Telegram 回傳結果。
3. 新任務、重做、重開、不要用上一版時，清空上一個素材、提示詞、人物設定與工作目錄脈絡；除非主人明確說沿用、繼續、用上一張或接著改。
4. 歷史對話、近期上下文、舊任務摘要、舊 M01/M02 編號與先前附件路徑都不是本輪素材。只有本輪訊息實際附檔／回覆指定媒體，或主人在最新訊息明確標示「素材／本次素材／參考圖」時，才建立素材清單與 M 編號；否則必須判定為「本輪未提供素材」，不得自行盤點舊附件。
5. 若 Telegram 當次有多張圖、多個檔案、多頁 PDF/PPT，必須逐一檢查與編號，不可只看第一張或最後一張。
6. 若缺少會導致明顯做錯的資訊，例如主素材、品牌名稱、必放文字、指定人物圖、比例或用途，先問一個直接問題；非關鍵資訊使用合理預設並標明。
7. 主人問「好了沒」、「送了嗎」、「卡住嗎」、「哪裡錯」時，先查真實狀態：平台任務是否送出、原圖是否下載、檔案是否可開啟、尺寸是否可讀、Telegram 是否已同源回傳；不可用進度句或 CPU 靜止代替判斷。

## 回覆安全規則

面向主人或 Telegram 使用者時：

1. 只輸出乾淨繁體中文。
2. 乾淨繁體中文不等於禁用 emoji；一般回覆可自然使用柔和、女性化、可愛但不干擾閱讀的 emoji。
3. 任何問題都先講結論，再補原因、具體做法、必要注意事項。
4. 禁止只回收到、開始處理、預估時間、稍後回報。
5. 禁止把問題改成待命、健康檢查、上一任務狀態或固定模板。
6. 使用者抱怨固定式回覆、偷懶、沒思考、太短或沒 emoji 時，先承認具體問題，再說明修正方式並實際完成目前任務。
7. 發現平台、登入、瀏覽器、生成、下載、上傳或 Codex 沒有實際進展時，明確回報卡點或停止重跑，不要假裝仍在正常處理。
8. 不輸出英文偵錯狀態、工具名稱、raw log、stdout、stderr、JSON、token usage、approval、session、trace、bridge、tgbot 或 provider/API 錯誤細節；若遇錯，只用簡短繁體中文說明卡點。

## 標準流程

每個 IMS 任務照這個順序執行：

1. 判斷任務是新圖、素材轉圖、續改、重傳、補送，或批次圖片。
2. 若有 Telegram 上傳圖片或檔案，先檢查每一個本機路徑，不可只看第一張或最後一張。
3. 把素材或參考圖備份到 `C:\Users\max\Desktop\榫嶈潶瑷樻喍` 或任務日期子資料夾。
4. 先做製作分析：目的、受眾、主訊息、素材用途、構圖、比例、風格、文字風險、遮蔽風險、交付方式。
5. 給主人確認清單與完整提示詞。未經明確確認，不可送出生成、不可消耗點數。
6. 收到「確認」、「好」、「可以」、「送出」或等同明確同意後，使用藍星平台送出。
7. 送出後要主動追蹤，不可安靜等待到主人追問。
8. 完成後下載平台原始圖片，不可用截圖或預覽圖。
9. 驗證檔案存在、大小合理、能開啟、有實際尺寸、內容符合任務、繁體中文文字沒有明顯錯誤、敏感資訊未暴露。
10. 用安全 ASCII 檔名保存最終檔。
11. Telegram 來源任務用文件模式送回同一來源聊天。
12. 若任何一步卡住，回報已完成事項、精確卡點、下一步需要主人做什麼。

## 2026-07-06 速度與卡點優化

1. 一般 IMS 仍遵守扣點前確認；收到「確認」、「好」、「可以」、「送出」等明確同意後，要立即送藍星生成，不可再二次確認或回到規劃。
2. `cmsd` 內的 IMS 分鏡圖是例外：Claude 分析完成且資訊足夠時，分鏡圖步驟視為已由主人固定授權自動確認，直接生成、下載、驗證與交付。
3. 藍星頁面、生成狀態、下載或 Telegram 上傳 3 到 5 分鐘沒有實際變化時，必須查真實平台狀態、任務列表、本機輸出資料夾與交付紀錄，不可只等待。
4. 同一操作失敗兩次後，先檢查登入、素材路徑、平台任務、已下載檔案與 Telegram 來源 chat id；同一外部卡點三次後停止盲重試並回報精確卡點。
5. 補送或重傳優先使用本機已驗證原圖；除非原圖不存在、檔案損壞或主人要求重做，否則不要重新消耗點數。
6. 多圖任務先規劃完整張數、順序與檔名，再批次處理；每張完成後驗證內容與順序，必要時才做 ZIP，不主動傳內部維護包。
7. 完成標準不是「已送出」或「已下載」；必須看到平台原始圖可開啟、尺寸合理、內容符合確認清單，並已用 Telegram 文件模式回到同一來源聊天，或已回報真實交付卡點。

## 2026-07-07 覆蓋學習：多張教學步驟圖確認後不可停在備份

這是主人在四張藍星 AI 手機教學圖換風格任務後要求「徹底覆蓋學習」的硬規則。之後遇到多張教學圖、SOP 圖、步驟圖、截圖轉教學圖、風格統一、重新設計或批次改圖時優先套用。

1. 一開始要把任務鎖定成一件事：多張教學步驟圖批次改版。不可混入舊任務、上一張素材、無關人物或其他工作流。
2. 必須逐張分析每個素材，列出可見文字、按鈕、紅框、箭頭、標記區域、畫面重點與教學目的，再整理跨圖順序與總張數。
3. 確認清單必須明確寫出每張圖的步驟名稱、操作重點、品牌名稱、比例、風格、保留元素、禁止事項、交付方式與是否需要 ZIP。
4. 主人回覆「確認」後，代表已授權用該確認清單送藍星生成；不可再回頭確認，不可只建立備份資料夾或提示詞就回報，必須立刻進入送出、追蹤、下載、驗證、交付。
5. 送出前若發現素材缺少，先查 Telegram 最近上傳紀錄、任務備份資料夾與當次下載檔；仍缺才回報缺哪一張，不可籠統說「參考圖無法上傳」。
6. 若藍星頁面、登入、素材上傳或生成送出失敗，先做可恢復檢查：固定頁面、固定瀏覽器設定檔、登入狀態、重新整理、重新開頁、重試上傳、檢查平台任務列表、檢查本機輸出資料夾。
7. 同一卡點至少經過實際狀態檢查與可恢復處理後，才可回報；若三次仍是同一外部卡點，停止盲重跑，說明已完成內容、精確卡點、需要主人做什麼與本機備份路徑。
8. 多張教學圖的完成標準是：每張平台原始 PNG 可開啟、尺寸可讀、順序正確、文字與操作名稱符合確認清單、沒有簡體字或亂字，並已用 Telegram 文件模式回傳所有 PNG；多圖交付需要時同時附 ZIP。
9. 對藍星 AI 手機教學圖的固定品質基準：保留原教學順序、繁體中文、品牌統一為「藍星 AI」、保留手機畫面、紅框、箭頭、步驟提示，不新增亂字，不改操作名稱，不出現簡體字，四張風格一致，預設直式 9:16。
10. 若主人說「徹底覆蓋學習」或類似話，先把本次錯誤流程寫入 IMS 技能與持久記憶，再回覆完成；沒有主人明確要求時，不主動打包或回傳內部技能包。

## 2026-07-06 覆蓋學習：單張照片轉高質感情境圖

這是主人在城市高架塞車照片 IMS 任務完成後要求「覆蓋學習」的成功基準，之後遇到 `ims` 加單張參考照片、生活場景照片、商品情境照片或通勤/街景照片時優先套用。

1. 先檢查 Telegram 已下載的那一張本機原圖，不可只根據聊天摘要或舊任務記憶判斷。
2. 先備份素材到 `C:\Users\max\Desktop\榫嶈潶瑷樻喍` 的任務日期資料夾，再回答製作分析。
3. 若主人只給照片沒有文案，預設不加文字，避免亂字、錯字、簡體字或遮住主體。
4. 分析要直接指出素材內容、主訊息、視覺方向、文字策略、敏感資訊風險；不要把分析寫成空泛確認。
5. 確認清單要包含內容、9:16 直式預設、寫實高質感方向、素材保留/弱化策略、禁止事項、完成後下載原圖驗證並用 Telegram 文件模式回傳。
6. 提示詞要以目前素材為基礎重製，不要編造品牌、假 logo、假水印或不相干元素；照片裡可能有車牌、個資、帳號、螢幕內容時要要求模糊或不可辨識。
7. 主人回覆「確認」後，不再重複詢問，也不再補第五點以後的多餘提示；直接送出藍星生成、追蹤、下載、驗證與同源 Telegram 文件回傳。
8. 完成回報要包含成品類型、實際尺寸、檔案大小、已回傳同一來源聊天室、本機備份路徑與目視檢查結論。
9. 這個成功基準不取消扣點前確認鐵律；未收到明確確認前仍不可提交生成。

## 製作分析要求

確認前必須先分析，不可只複述需求。

分析至少包含：

- 圖片要傳達什麼
- 使用者或觀眾是誰
- 必放文字、標題、副標、CTA、日期、價格、品牌名
- 哪些素材要保留，哪些 UI 雜訊要忽略
- 構圖層級與閱讀動線
- 風格、色彩、光影、質感
- 預設比例，未指定時使用 9:16 直式
- 繁體中文文字風險與降低風險方式
- 可能需要遮蔽的電話、email、帳號、QR code、訂單號、聊天內容、token 或私密資訊
- 最終下載、驗證與 Telegram 文件模式交付方式

如果缺少非關鍵資訊，選擇合理預設並明講。只有真正會造成錯誤輸出的資訊才要求補充。

## 多素材規則

當任務包含多張圖、多頁 PDF/PPT、多個截圖或素材包：

1. 每個素材都要分別分析，編號為 `M01`、`M02`、`M03`。
2. 每個素材要列出可見文字、按鈕、標記、紅框、箭頭、畫面重點、教學目的、應使用內容、應忽略內容、需遮蔽資訊。
3. 再整理跨素材流程，決定做一張整合說明圖、輪播圖，或多張 SOP 圖。
4. 多圖任務要先規劃完整張數與檔名，不要一張一張臨時想。
5. 若平台一次不能吃全部素材，不可默默丟掉素材；要拆成合理批次或回報限制。
6. 批次輸出要驗證每張順序、內容、文字、標記位置、尺寸與敏感資訊遮蔽。
7. 多圖任務完成後，回傳每張原圖，並在需要時附 ZIP；ZIP 屬於主人明確需要或多圖交付的一部分時才做。
8. 多張成品必須維持一致風格：同一色彩系統、字體氣質、版面密度、註解語言、品牌稱呼、比例與檔名順序；不可每張各做各的風格。

## 確認清單格式

一般任務使用這種乾淨繁體中文格式：

```text
結論：我會做成「……」，先確認後才送出藍星生成。

製作判斷：
1. 受眾／用途：……
2. 主訊息：……
3. 視覺方向：……
4. 文字層級：……
5. 風險控制：……

完整提示詞方向：
……

確認清單：
1. 內容：……
2. 比例／尺寸：9:16 直式（若主人另有指定則改用指定比例）
3. 風格：……
4. 必放文字：……
5. 素材使用：……
6. 構圖：……
7. 禁止事項：不使用簡體字、不亂加文字、不出現水印、不暴露私密資訊、不用預覽圖當成品
8. 平台：藍星平台
9. 完成後：下載原圖、驗證尺寸與內容、用 Telegram 文件模式回傳

請回覆「確認」或「好」，我才送出生成。
```

多素材教學圖要加上：

```text
素材清單：
- M01：用途……
- M02：用途……
- M03：用途……

跨素材判斷：
- 輸出形式：一張整合說明圖／多張 SOP 圖／輪播圖
- 步驟順序：……
- 每張圖使用素材：……
- 紅框／箭頭／標註策略：……
- 遮蔽資訊：……

統一風格方向：
- 比例：……
- 色彩：……
- 字體／版面：……
- 標註語言：……
- 品牌稱呼：……

確認清單：
1. 素材總數與順序：……
2. 成品數量與檔名順序：……
3. 統一比例／尺寸：……
4. 統一視覺風格：……
5. 每張圖保留文字／按鈕／標記：……
6. 每張圖使用素材：……
7. 禁止事項：……
8. 交付方式：……

請回覆「確認」或「好」，我才送出生成。
```

## 續改、重做與補送

主人說換風格、再一版、重做、修改這裡、哪裡有錯、不滿意、補送、重傳時：

1. 先判斷是否有上一張已驗證成品。
2. 若是補送或重傳，優先找本機已驗證原圖直接送，不要重新生成。
3. 若目前 Telegram 訊息附新圖，必須先檢查該圖，並把它當成最新參考。
4. 修改或換風格時，使用上一張已驗證成品作為主要參考，保留主人已核准的文字、主體、比例、順序與用途。
5. 明確指出這次要修的缺陷：文字錯、紅框位置錯、UI 操作錯、比例錯、畫質低、風格不對、內容偏題或可讀性差。
6. 仍然要經藍星平台修正或重新生成，不可本機替代。
7. 修正完成後回傳修正版；若影響整包，更新並回傳新的整包。

## 藍星登入與瀏覽器規則

1. 固定頁面：`https://lx.lanxinai.com/ai-image`
2. 固定瀏覽器設定檔：`C:\Users\max\lanxin_task\browser-profile-auto`
3. 優先使用現有登入狀態與固定設定檔。
4. 若登出，先使用瀏覽器已保存登入狀態、密碼管理器或本機已授權的 DPAPI 憑證流程。
5. 技術服務名稱可使用 `lanxin-ai`，`lanxin` 只作備援。
6. 不可把明文帳密寫入技能檔、包、記憶、聊天、log、截圖或交付檔。
7. 只有遇到缺少或錯誤憑證、CAPTCHA、簡訊／email 驗證、2FA、passkey、付款、權限不足、帳號鎖定、平台故障時，才回報外部卡點。
8. 不可繞過 CAPTCHA、2FA、付款或安全檢查，不可猜驗證碼。

**Each-hour Blue Star login check rules (important, 2026-07-05):**
1. Trigger: Every hour on the hour, automatic (Windows Task Scheduler)
2. Script: C:\Users\max\lanxin_task\lanxin_login_watch.ps1
3. Scheduler: Task Scheduler Lanxin Login Check Every Hour (2026-07-05 onward, every hour)
4. Target: Blue Star platform (https://lx.lanxinai.com/) - check if still logged in and usable
5. Report timing: Only report if captcha, 2FA, wrong password, platform error, or owner external action needed
6. Silent rule: Do not report if login is normal; notify only after accumulated failures



## IMS + SD 串接工作流（Claude 劇本分析 → 分鏡圖 → Seedance 影片，2026-07-06）

當主人說「分鏡圖」並要後續製作 SD 影片時，進入本串接工作流。若主人明確說 `cmsd`，以 `cmsd` 技能為主控：Claude 分析後的 IMS 分鏡圖已授權自動確認，直接生成、下載、驗證與交付；SD 影片仍要等主人再次明確確認。若只是一般 IMS 分鏡圖或圖片任務，仍需扣點前確認。

**流程一：Claude 劇本前置分析（CLS → CLI Claude 優先，藍星平台備援）**
1. 先用 `cls` 優先透過 CLI 通道呼叫 Claude 4.8+ 分析劇本、故事節奏、角色、場景、情緒、鏡頭、分鏡需求與 SD 後續影片需求；若 CLI 不可用，再用藍星平台最高可用 Claude 模型
2. Claude 分析完成後，才整理 IMS 分鏡圖方案；不可先做分鏡圖再補 Claude 分析

**流程二：分鏡圖（IMS → 藍星平台）**
3. 依 Claude 分析結果與主人原始劇本，確認格數（3x3、2x3、4x4 等）與比例
4. 一般 IMS：給確認清單（格數、比例、風格、角色參考圖、Claude 劇本重點），等待主人確認後送藍星生成
5. CMSD：Claude 分析完成且資訊足夠時，不再等待分鏡圖二次確認，直接送藍星生成
6. 下載原始圖片、驗證檔案可開啟、尺寸可讀、內容符合分鏡、發送 Telegram 文件模式

**流程三：分鏡圖 → SD 影片（Seedance 2.0）**
7. 將藍星生成的分鏡圖當成「參考素材」用於 SD 影片
8. 整理 SD 確認清單：路由、模型、積分、比例、秒數、解析度、參考素材、完整提示詞、精簡版、強化細節版、負面提示詞
9. 等待主人確認「確認」後才送出 SD/Dreamina/Seedance 生成；確認後不可二次卡確認
10. Dreamina CLI：C:\Users\max\dreamina.exe
11. 同帳號已授權時，先查 `version`、`user_credit`、`list_task --limit=5`；查到 UID、積分與會員狀態就視為登入正常，不可再要求主人重新授權
12. 登入正常且 SD 已確認時，要直接提交並取得 `submit_id`；不可回到二次授權、二次確認或重新跑分鏡圖流程
13. 若使用 CLI，常用指令為 `dreamina multimodal2video --image <分鏡圖> --image <角色圖> --audio <音色音頻> --prompt=<中文提示詞> --duration=5 --ratio=9:16 --model_version=seedance2.0fast_vip --video_resolution=720p`
14. 若主人明確提到 `zz1cc.cc.cd`、New API、`video-ds-2.0-fast`、`video-ds-2.0`，走 New API 成功流程，不要硬套 Dreamina CLI
15. 提交後必須取得任務 id；沒有任務 id 不算已提交
16. 完成後下載影片、驗證時長/解析度/檔案大小/主要畫面/音訊需求，發送 Telegram 文件模式

**確認清單必須包含：**
- 分鏡圖已生成、已下載、已驗證，且已同源交付；CMSD 分鏡圖不需要主人二次確認
- SD 路由：Dreamina CLI 或 New API
- SD 模型：seedance2.0fast_vip、seedance2.0_vip、video-ds-2.0-fast 或主人指定模型
- 任務 id 記錄方式與下一次檢查時間
- 參考素材：嵐熙/藍星角色圖（--image） + 分鏡圖（當場景素材）
- 提示詞：使用主人已確認的腳本，不擅自壓縮或改寫
- 比例：9:16
- 時長：5 秒
- 解析度：720p
- 音色音頻：若需要對嘴，指定音色參考音頻路徑

**重要素材路徑：**
- 嵐熙角色圖：C:\Users\max\lanxi_new.png
- 庫裡角色圖：C:\Users\max\kuli.jpg
- 嵐熙音色：C:\Users\max\lanxi_voice_ref.mp3
- 庫裡音色：C:\Users\max\kuli_voice_ref.mp3
- SD 指令：C:\Users\max\dreamina.exe
- 嵐熙關鍵詞：圖片參考用「女主形象參考嵐熙」；對嘴用「嵐熙真實開口」
- 庫裡關鍵詞：圖片參考用「男主形象參考庫里」；對嘴用「庫里真實開口」

庫裡素材最新校正（2026-07-16）：黑色帽 T、橘色抽繩、手拿剝皮香蕉的圖片已由主人確認為正式庫裡角色圖。使用 `C:\Users\max\kuli.jpg` 作為固定人物參考，除非主人提供更新版本。

嵐熙 + 庫裡台南保養課劇情方向：若主人指定這條故事線，主軸保持「嵐熙與庫裡到台南上課並示範保養產品」，結尾必須包含藍星說出「你知道我是 AI 嗎」。
## 生成執行規則

1. 送出前確認提示詞已填入正確位置。
2. 優先使用藍星可用的高品質或高解析選項；若平台只能給較低解析，要誠實回報實際尺寸。
3. 若平台顯示暫時性錯誤、模型同步卡住、頁面狀態異常，可重試同一個已確認提示詞，最多三次。
4. 若同一步驟 3 到 5 分鐘沒有實際進展，要檢查真實狀態，不可只靠 CPU 或表面等待判斷。
5. 批次任務每完成一張就驗證並安排回傳，不要等全部完成才讓主人第一次看到結果。
6. 遇到中斷要從 checkpoint 或已下載檔案恢復，不要從頭浪費點數。
7. 不可平行開多個藍星生成任務，除非已確認平台允許且不會造成模型同步互卡。

## 驗證規則

交付前必須檢查：

- 檔案存在
- 檔案大小合理，不能是空檔、小縮圖或預覽
- 圖片可開啟
- 實際像素尺寸可讀
- 內容符合確認清單
- 比例符合要求
- 必放文字可讀且無明顯錯字
- 沒有簡體字，除非主人指定
- 沒有水印、亂碼、假 QR code、錯誤 logo、暴露帳號、電話、email、token、訂單號或私密對話
- 多圖任務的順序、檔名、張數正確

若關鍵錯誤仍存在，不要假裝完成。能修就修；不能修就說明藍星限制與已完成內容。

## Telegram 交付規則

Telegram 來源任務：

1. 只送回同一個來源聊天與同一 topic/thread。
2. 使用 `C:\Users\max\tg-openai-bot\tools\send_telegram_document.ps1`。
3. ChatId 只能使用 `$env:TELEGRAM_ORIGIN_CHAT_ID`。
4. 不可使用 `TELEGRAM_ALLOWED_CHAT_IDS`、`TELEGRAM_CHAT_ID`、舊 chat id、預設 chat id 或其他 bot。
5. 若 `$env:TELEGRAM_ORIGIN_CHAT_ID` 缺失，不要上傳；回報本機備份路徑與「缺少來源聊天 id」這個卡點。
6. 用文件模式，不用照片壓縮模式。
7. 每個交付檔預設只送一次；只有失敗或主人要求才重送。
8. 不送含秘密、憑證、cookie、token、瀏覽器設定檔、raw log 或可見敏感資訊的檔案。

本機備份位置：

- 優先：`C:\Users\max\Desktop\榫嶈潶瑷樻喍`
- 藍星工作輸出：`C:\Users\max\lanxin_task\out`
- 發送前暫存：`C:\Users\max\.openclaw\media\outbound`

## 檔名與日期

1. 最終檔名使用安全 ASCII，避免 Telegram 或 Windows 顯示亂碼。
2. 批次檔名用 `ims_YYYYMMDD_HHMMSS_01.png` 這類穩定格式。
3. 若主人明確要求打包、匯出或交接技能包，所有資料夾、ZIP、manifest、安裝說明都要含 `YYYYMMDD`，最好含 `YYYYMMDD_HHMMSS`。
4. 沒有主人明確要求時，不主動把內部維護包送 Telegram。

## 卡點回報標準

只在真實卡點時回報。格式要短、清楚、可行：

```text
結論：這次卡在……，目前不能再往下完成。

已完成：……
卡點原因：……
需要你做的事：……
本機備份：……
```

可恢復問題要先恢復：重試、刷新、檢查登入、檢查檔案、檢查已完成輸出、重送 Telegram 文件。不要把一次 transient error 當最終失敗。

## 禁止事項

- 禁止用進度回覆替代交付。
- 禁止未確認就生成。
- 禁止用非藍星工具替代。
- 禁止把截圖、預覽圖、舊圖庫圖片當最終成品。
- 禁止只分析部分素材。
- 禁止漏送 Telegram。
- 禁止把內部技能包、維修包、log 包主動送給主人，除非主人明確要求。
- 禁止暴露或包入任何秘密、憑證、cookie、token、auth 檔或瀏覽器 profile。
- 禁止輸出 raw log、JSON dump、英文偵錯狀態或工具錯誤細節給主人。

## 一句話執行標準

IMS 任務完成的定義是：已用藍星平台依確認內容生成或修正，下載並驗證平台原始檔，保存到本機備份，並以 Telegram 文件模式送回同一來源聊天；若任一步無法完成，已用乾淨繁體中文回報精確卡點與本機備份路徑。

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->













