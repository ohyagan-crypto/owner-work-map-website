---
name: codex-zuotu-lanxin
description: Codex 專用做圖技能。當使用者要求做圖、生圖、生成圖片、產圖、做海報、產海報、海報設計、圖片設計、商品圖、行銷圖、社群圖、廣告圖、文案轉圖、PPT轉海報、PDF轉海報、Lanxin AI、蘭心AI、聚合平台做圖時啟用。包含：登入/已登入檢查、聚合平台功能巡檢、確認清單、等待使用者確認、提交生成、自動檢查狀態、下載原始圖片、驗證檔案、回傳 Telegram 文件模式。不得包含或保存帳號密碼、cookie、token、API key。
---
## Named Workflow Completion Gate

- Owner-named workflows are never quick status replies. Identify the exact deliverable first, then continue until the file, URL, or platform state is actually complete.
- Do not report completion at `started`, `queued`, `submitted`, `generated`, `playing`, `downloaded`, `exported`, or local-path-only state. Verify the next observable state: job id/status when applicable, output file exists, file format/size/readability/duration/page count/dimensions/language as relevant, and public URL or Telegram delivery when required.
- For Telegram-origin tasks, every final deliverable must be sent back to the same originating chat/thread by document mode whenever possible. A local path is only a backup if Telegram delivery is blocked.
- If a requested output is missing after another output was already delivered, treat it as recovery for the same workflow. Inspect the job record, artifact folder, platform page, downloads, validation result, and Telegram delivery state before replying.
- For audio/video workflows, playback is only a status check. Download/export the actual file, convert only when needed by the requested format, validate with a media tool when available, then deliver.
- After the same step fails twice, inspect real local/platform state instead of blind retrying. After three same blockers, report the concrete blocker and local backup path if any.

# Codex 做圖技能：Lanxin / 聚合平台

## 對主人顯示名稱

- 2026-07-05 主人修正：「蘭心以後都叫藍星」。
- 對主人回覆、網站文字、教學文字、狀態說明、完成回報時，一律稱為「藍星」或「藍星平台」。
- `Lanxin` / `lanxin` 只保留在網址、API、服務名稱、檔名、程式代號、credential service 或既有自動化相容性需要的地方。

## 必讀文件

1. `references/workflow.md`
2. `references/login-and-platform-check.md`
3. `references/prompt-confirmation.md`
4. `references/task-monitor-download.md`
5. `references/telegram-delivery.md`
6. `references/safety-no-secrets.md`

## 平台

- 平台名稱：Lanxin AI / 蘭心 AI / 聚合平台
- 平台網址：https://lx.lanxinai.com/

## 核心規則

- 使用者只要提到做圖、生圖、產圖、做海報、產海報、圖片設計、文案轉圖、修圖、改圖、換風格、科技一點、再做一次、重做、下一版、變體、封面、縮圖、Banner、SOP 教學圖，就啟用本技能。
- 所有圖片相關延續任務都必須回到 Lanxin / 聚合平台提交或修正；不得用本機腳本、Canvas、PPT、PS、ImageMagick、Node/System.Drawing、HTML/SVG、截圖、預覽圖、內建 imagegen 或其他工具替代。
- 先給確認清單，不可直接提交。
- 等使用者明確確認後才提交。
- 登入可使用已登入瀏覽器；若未登入，請使用者在本機輸入帳密與驗證碼。
- 不保存、不輸出、不打包帳密、cookie、token、API key。
- 生成後要自動檢查狀態，直到完成或遇到明確卡點。
- 完成後下載原始圖片，不用截圖/預覽圖代替。
- 驗證檔案有效後，用 Telegram 文件模式回傳。
- 若使用者說沒收到，重傳同一個已驗證檔案，不要重做。
- 如果沒有當次聚合平台提交、平台原圖下載、檔案驗證與 Telegram 文件模式回傳，不能宣稱做圖任務完成；只能回報明確平台或交付卡點。

<!-- TGBOT_DAILY_SELF_UPGRADE_START -->
## TGBOT Daily Self-Upgrade Overlay

- Last updated: 2026-07-16 00:00 daily learning job
- Source: TGBOT conversation histories + 22:00 owner daily summary when available
- Scope: TGBOT 65則/1對話；TGBOT 63則/3對話；TGBOT 84則/1對話

Apply these corrections before the skill-specific workflow:
- 所有 Telegram 來源任務都必須核對同源回傳：輸出檔存在、格式可讀、Telegram document/file mode 送達成功後才算完成。
- 所有短訊息、抱怨、狀態追問都禁止固定式回覆；先判斷最新意圖，再查本機狀態、任務狀態或平台狀態後回答。
- 命名工作流一律視為高優先級；不能用開始、排隊、播放、下載中、已生成代替最終交付。
- NBS 音訊任務：按播放只代表可預覽，不是完成；必須用下載/匯出取得 MP3，驗證檔案大小與時長，再回傳 Telegram。
- NBS 多輸出任務：PPTX、MP4、MP3 要逐項核對，不可只傳其中一個就結案。
- TGBOT 狀態檢查要同時看 getMe、Python PID、heartbeat、request status、最近錯誤摘要；不能只用記憶回答。
- Bot 回覆清洗只能移除 raw log/tool/debug 行，不能把正常中文結論整段攔截成固定錯誤訊息。
- LINE 官方每日學習要讀取當日對話，更新客服回覆方向，並檢查 webhook/relay 正常；禁止退回固定式客服句。
- 每日自我升級要產生 dated memory、技能修正覆蓋區與三個 bot 的 learning index；明確穩定規則才寫回 SKILL.md，避免盲目改壞技能。
- 多素材任務要先逐一分析每個檔案，再輸出確認清單；不得只看第一個或最後一個素材。
<!-- TGBOT_DAILY_SELF_UPGRADE_END -->














