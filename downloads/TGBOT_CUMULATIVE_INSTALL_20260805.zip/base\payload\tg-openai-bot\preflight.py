import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, Optional


PROJECT_DIR = Path(__file__).resolve().parent
ENV_PATH = PROJECT_DIR / ".env"


def load_env() -> Dict[str, str]:
    values: Dict[str, str] = {}
    if not ENV_PATH.exists():
        return values

    for raw_line in ENV_PATH.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


ENV = load_env()
for env_key, env_value in ENV.items():
    os.environ.setdefault(env_key, env_value)

TELEGRAM_BOT_TOKEN = ENV.get("TELEGRAM_BOT_TOKEN", os.getenv("TELEGRAM_BOT_TOKEN", ""))
TELEGRAM_API_BASE = ENV.get("TELEGRAM_API_BASE", os.getenv("TELEGRAM_API_BASE", "https://api.telegram.org")).rstrip("/")
OPENAI_API_KEY = ENV.get("OPENAI_API_KEY", os.getenv("OPENAI_API_KEY", ""))
OPENAI_BASE_URL = ENV.get("OPENAI_BASE_URL", os.getenv("OPENAI_BASE_URL", "https://lanxinai.com/v1")).rstrip("/")
OPENAI_MODEL = ENV.get("OPENAI_MODEL", os.getenv("OPENAI_MODEL", "gpt-5.5"))
OPENAI_REASONING_EFFORT = ENV.get("OPENAI_REASONING_EFFORT", os.getenv("OPENAI_REASONING_EFFORT", "low"))
OPENAI_STORE = ENV.get("OPENAI_STORE", os.getenv("OPENAI_STORE", "false")).lower() in {"1", "true", "yes", "y"}


def redact(value: str) -> str:
    if TELEGRAM_BOT_TOKEN:
        value = value.replace(TELEGRAM_BOT_TOKEN, "[TELEGRAM_BOT_TOKEN]")
    if OPENAI_API_KEY:
        value = value.replace(OPENAI_API_KEY, "[OPENAI_API_KEY]")
    return value


def mask(value: str) -> str:
    if not value:
        return "endpoint/Codex auth"
    if len(value) <= 12:
        return "***"
    return f"{value[:6]}...{value[-6:]}"


def http_json(url: str, payload: Optional[Dict] = None, headers: Optional[Dict] = None, timeout: int = 45) -> Dict:
    data = None
    request_headers = headers or {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        request_headers = {"Content-Type": "application/json", **request_headers}

    request = urllib.request.Request(url, data=data, headers=request_headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        body = redact(error.read().decode("utf-8", errors="replace"))
        raise RuntimeError(f"HTTP {error.code}: {body}") from error
    except Exception as error:
        raise RuntimeError(redact(str(error))) from error


def parse_response_text(response: Dict) -> str:
    direct = response.get("output_text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()

    chunks = []
    for item in response.get("output", []) or []:
        for content in item.get("content", []) or []:
            text = content.get("text")
            if isinstance(text, str) and text.strip():
                chunks.append(text.strip())
    return "\n".join(chunks)


def parse_chat_text(response: Dict) -> str:
    choices = response.get("choices", []) or []
    if choices:
        message = choices[0].get("message", {}) or {}
        content = message.get("content")
        if isinstance(content, str) and content.strip():
            return content.strip()
    return ""


def check_env() -> int:
    print("== .env ==")
    if not ENV_PATH.exists():
        print(f"FAIL: missing {ENV_PATH}")
        print("Run setup_env.ps1 or START_BOT.cmd and enter your tokens.")
        return 1

    missing = []
    for key, value in {
        "TELEGRAM_BOT_TOKEN": TELEGRAM_BOT_TOKEN,
        "OPENAI_API_KEY": OPENAI_API_KEY,
        "OPENAI_BASE_URL": OPENAI_BASE_URL,
        "OPENAI_MODEL": OPENAI_MODEL,
    }.items():
        if not value:
            missing.append(key)

    if missing:
        print(f"FAIL: missing {', '.join(missing)}")
        return 1

    if "replace" in TELEGRAM_BOT_TOKEN.lower() or TELEGRAM_BOT_TOKEN.startswith("123456789:"):
        print("FAIL: TELEGRAM_BOT_TOKEN is still a placeholder.")
        return 1
    if "replace" in OPENAI_API_KEY.lower() or OPENAI_API_KEY.startswith("你的"):
        print("FAIL: OPENAI_API_KEY is still a placeholder.")
        return 1
    if not re.match(r"^\d+:[A-Za-z0-9_-]{30,}$", TELEGRAM_BOT_TOKEN):
        print("FAIL: TELEGRAM_BOT_TOKEN format looks wrong. It should look like 123456789:AA...")
        return 1
    api_key_lower = OPENAI_API_KEY.lower()
    if "model_provider" in api_key_lower or "base_url" in api_key_lower or "opencode" in api_key_lower:
        print("FAIL: OPENAI_API_KEY contains config text, not an API key.")
        return 1
    if not OPENAI_BASE_URL.startswith(("http://", "https://")):
        print("FAIL: OPENAI_BASE_URL must start with http:// or https://")
        return 1
    if OPENAI_BASE_URL.rstrip("/") == "https://lanxinai.com":
        print("FAIL: OPENAI_BASE_URL is missing /v1. Use https://lanxinai.com/v1")
        return 1

    print(f"TELEGRAM_BOT_TOKEN={mask(TELEGRAM_BOT_TOKEN)}")
    print(f"OPENAI_API_KEY={mask(OPENAI_API_KEY)}")
    print(f"OPENAI_BASE_URL={OPENAI_BASE_URL}")
    print(f"OPENAI_MODEL={OPENAI_MODEL}")
    print(f"OPENAI_REASONING_EFFORT={OPENAI_REASONING_EFFORT}")
    print(f"OPENAI_STORE={str(OPENAI_STORE).lower()}")
    print(f"TELEGRAM_API_BASE={TELEGRAM_API_BASE}")
    if ENV.get("HTTPS_PROXY") or ENV.get("HTTP_PROXY"):
        print("Proxy: configured")
    print("OK")
    return 0


def check_telegram() -> int:
    print("\n== Telegram ==")
    try:
        result = http_json(f"{TELEGRAM_API_BASE}/bot{TELEGRAM_BOT_TOKEN}/getMe", timeout=30)
    except Exception as error:
        print(f"FAIL: {redact(str(error))}")
        print("Usually this means the Telegram token is wrong, revoked, or copied with extra spaces.")
        print("If the request times out or cannot connect, set HTTPS_PROXY in .env, for example HTTPS_PROXY=http://127.0.0.1:7890")
        return 1

    if not result.get("ok"):
        print(f"FAIL: {redact(json.dumps(result, ensure_ascii=False))}")
        return 1

    bot = result["result"]
    print(f"OK: @{bot.get('username')} id={bot.get('id')}")

    try:
        webhook = http_json(f"{TELEGRAM_API_BASE}/bot{TELEGRAM_BOT_TOKEN}/getWebhookInfo", timeout=30)
        info = webhook.get("result", {}) if webhook.get("ok") else {}
        webhook_url = info.get("url") or ""
        pending = info.get("pending_update_count", 0)
        if webhook_url:
            print("Webhook: configured. START_BOT.cmd will clear it before polling.")
        else:
            print("Webhook: none")
        print(f"Pending updates: {pending}")
    except Exception as error:
        print(f"Webhook check warning: {redact(str(error))}")

    return 0


def check_openai() -> int:
    print("\n== OpenAI-compatible API ==")
    response_payload = {
        "model": OPENAI_MODEL,
        "store": OPENAI_STORE,
        "reasoning": {"effort": OPENAI_REASONING_EFFORT},
        "input": "只回覆 OK 兩個字。",
        "max_output_tokens": 32,
    }
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"} if OPENAI_API_KEY else {}

    attempts = [
        (
            "responses/full",
            f"{OPENAI_BASE_URL}/responses",
            response_payload,
            parse_response_text,
        ),
        (
            "responses/no-reasoning",
            f"{OPENAI_BASE_URL}/responses",
            {key: value for key, value in response_payload.items() if key != "reasoning"},
            parse_response_text,
        ),
        (
            "responses/minimal",
            f"{OPENAI_BASE_URL}/responses",
            {key: value for key, value in response_payload.items() if key not in {"reasoning", "store"}},
            parse_response_text,
        ),
        (
            "responses/string-input",
            f"{OPENAI_BASE_URL}/responses",
            {
                "model": OPENAI_MODEL,
                "input": "只回覆 OK 兩個字。",
                "max_output_tokens": 32,
            },
            parse_response_text,
        ),
        (
            "chat-completions/fallback",
            f"{OPENAI_BASE_URL}/chat/completions",
            {
                "model": OPENAI_MODEL,
                "messages": [
                    {"role": "system", "content": "你是 Telegram bot 助手。用繁體中文回答，簡潔、直接。"},
                    {"role": "user", "content": "只回覆 OK 兩個字。"},
                ],
                "max_tokens": 32,
            },
            parse_chat_text,
        ),
    ]

    last_error = None
    for label, url, payload, parser in attempts:
        try:
            result = http_json(url, payload=payload, headers=headers, timeout=90)
            text = parser(result)
            print(f"OK: {label} replied {text or '<empty>'}")
            return 0
        except Exception as error:
            last_error = error
            print(f"TRY FAILED: {label}: {redact(str(error))}")

    print(f"FAIL: all API attempts failed. Last error: {redact(str(last_error))}")
    print("If this is 404, check OPENAI_BASE_URL. It should usually be https://lanxinai.com/v1")
    print("If this is model-related, try OPENAI_MODEL=gpt-5.4 or gpt-5.4-mini.")
    return 1


def main() -> int:
    print(f"Python: {sys.version.split()[0]}")
    for check in [check_env, check_telegram, check_openai]:
        code = check()
        if code:
            return code
    print("\nREADY: start simple_bot.py and keep the window open.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
