# Lanxin Image Workflow

- All image/poster/design generation tasks must use Lanxin AI / 聚合平台: `https://lx.lanxinai.com/`.
- Do not replace Lanxin with local scripts, Canvas, Photoshop, ImageMagick, PPT, or other generators.
- 2026-06-27 owner update: for 做圖、改圖、修圖、圖片變體、海報 and other image-output tasks, do not send a confirmation checklist and do not wait for a second confirmation by default. Internally verify platform, task type, materials, aspect ratio, style, text language, missing info, final prompt, and login/quota/waiting notes, then submit directly.
- Only ask before submitting if the owner explicitly requests a checklist/review, says not to submit yet, or one blocking detail makes the task impossible to execute.
- After generation, download the original/high-resolution output, verify the file, then send it to Telegram in document mode.
- If platform fails due to upstream access denied, quota, login, captcha, payment, timeout, or permission issue, report the blocker clearly and do not secretly use another tool.
