﻿$ErrorActionPreference='Stop'
$skills=Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'payload\.codex\skills'
Get-ChildItem -LiteralPath $skills -Directory | Where-Object {$_.Name -match '_20\d{6}'} | Remove-Item -Recurse -Force
Write-Host 'Removed dated duplicate skill folders.'
