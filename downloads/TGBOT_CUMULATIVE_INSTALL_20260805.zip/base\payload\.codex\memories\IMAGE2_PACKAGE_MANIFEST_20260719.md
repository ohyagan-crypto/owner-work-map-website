﻿# 套件清單｜20260719

## 技能
- `skills/image2-external-api-poster-workflow/SKILL.md`：外部 API image2 海報工作流、觸發詞、確認、生成、驗收、交付與安全規則。
- `skills/image2-external-api-poster-workflow/references/successful-run-20260719.md`：剪映 SVIP 成功案例與可重用提示詞方向。

## 教學文件
- `INSTALL_FOR_OTHER_CODEX.md`：完整安裝、學習、測試與卡點處理。
- `FORWARD_TO_RECEIVER_TGBOT.txt`：可直接轉發給其他 Codex／OpenClaw／TGBOT 的指令。
- `MEMORY_AND_BEHAVIOR_SUMMARY.md`：主人偏好、成功流程與不可洩漏內容。
- `PACKAGE_MANIFEST.md`：本清單。

## 明確未包含
- API key、token、密碼、cookie、瀏覽器 profile、auth 檔。
- 原始 Telegram 對話、raw log、完整 API 回應與含敏感資料的截圖。
- 其他無關技能、舊任務素材與歷史 M 編號。

## 日期
建立日期：2026-07-19

- memories/image2_external_api_success_flow_20260719.memory.md：可匯入接收端的成功流程記憶。
- skills/image2-external-api-poster-workflow/scripts/generate_image2_external_template.js：不含金鑰的外部 API 生成與 PNG 驗證範本。
