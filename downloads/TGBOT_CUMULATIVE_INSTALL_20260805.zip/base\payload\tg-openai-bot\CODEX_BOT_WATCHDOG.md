# Codex Telegram Bot Watchdog

This folder now has a self-healing watchdog for `codex_bot.py`.

## What It Does

- Starts `codex_bot.py` if it is not running.
- Checks Telegram `getMe`.
- Checks the Codex CLI is available.
- Checks `codex_bot_heartbeat.json` so a stuck bot can be restarted.
- Does not stop long-running Codex tasks just because they exceed a fixed duration; the bot refreshes heartbeat while Codex is still running.
- Restarts stale duplicate or dead bot processes.
- Runs once every hour through Windows Task Scheduler.
- Runs when the Windows user logs in.

## Files

- `watch_codex_bot.ps1`: health check and restart logic.
- `install_codex_bot_watchdog.ps1`: installs scheduled tasks.
- `INSTALL_CODEX_BOT_WATCHDOG.cmd`: double-click installer.
- `codex_bot_watchdog.log`: watchdog history.
- `codex_bot_heartbeat.json`: bot heartbeat state.

## Scheduled Tasks

- `Codex Telegram Bot Watchdog Startup`
- `Codex Telegram Bot Watchdog Hourly`

The startup task is registered for user logon. Running before any user logs in requires installing a Windows service or a highest-privilege startup task from an elevated Administrator shell.

## Manual Commands

```powershell
cd C:\Users\max\tg-openai-bot
.\watch_codex_bot.ps1
.\install_codex_bot_watchdog.ps1
```

## Telegram Reply Safety

- Telegram replies must stay in clean Traditional Chinese.
- Do not expose `brining`, `Web Fetch`, `Memory Search`, tool status, raw logs, JSON dumps, token usage, bridge/session/trace/tgbot text, or English internal status messages.
- Direct chats should send an initial received/estimate message, then a substantive result, file, URL, or clear blocker in the same task flow.
- If Codex or the bot hits an internal error, report only a short user-facing blocker; never paste stdout, stderr, stack traces, or watchdog logs into Telegram.

## Long Tasks

Set `CODEX_TIMEOUT_SECONDS=0` in `.env` to let Codex run until the task completes, the user sends `stop` / `停止` / `取消` / `中止`, or Codex reports a real blocker/error.
