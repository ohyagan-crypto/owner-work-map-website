﻿$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvPath = Join-Path $ProjectDir ".env"

try {
    [System.Net.ServicePointManager]::SecurityProtocol = `
        [System.Net.ServicePointManager]::SecurityProtocol -bor `
        [System.Net.SecurityProtocolType]::Tls12
}
catch {
}

function Read-DotEnv {
    param([string] $Path)

    $Values = @{}
    if (-not (Test-Path $Path)) {
        return $Values
    }

    foreach ($RawLine in Get-Content -Path $Path -Encoding UTF8) {
        $Line = $RawLine.Trim().Trim([char]0xFEFF)
        if ([string]::IsNullOrWhiteSpace($Line) -or $Line.StartsWith("#") -or -not $Line.Contains("=")) {
            continue
        }

        $EqualsIndex = $Line.IndexOf("=")
        $Key = $Line.Substring(0, $EqualsIndex).Trim()
        $Value = $Line.Substring($EqualsIndex + 1).Trim().Trim('"').Trim("'")
        $Values[$Key] = $Value
    }

    return $Values
}

function Redact {
    param([string] $Value)

    if ($script:TelegramToken) {
        $Value = $Value.Replace($script:TelegramToken, "[TELEGRAM_BOT_TOKEN]")
    }
    return $Value
}

function Get-HttpErrorText {
    param($ErrorRecord)

    try {
        $Response = $ErrorRecord.Exception.Response
        if ($null -ne $Response) {
            $Stream = $Response.GetResponseStream()
            if ($null -ne $Stream) {
                $Reader = New-Object System.IO.StreamReader($Stream)
                return $Reader.ReadToEnd()
            }
        }
    }
    catch {
    }

    return $ErrorRecord.Exception.Message
}

function Invoke-Telegram {
    param(
        [string] $Method,
        [hashtable] $Payload = $null,
        [int] $TimeoutSec = 30
    )

    $Params = @{
        Uri = "$script:TelegramApiBase/bot$script:TelegramToken/$Method"
        Method = "Post"
        TimeoutSec = $TimeoutSec
    }

    if (-not [string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
        $Params.Proxy = $script:ProxyUrl
    }

    if ($null -ne $Payload) {
        $Params.ContentType = "application/json; charset=utf-8"
        $JsonBody = $Payload | ConvertTo-Json -Depth 20 -Compress
        $Params.Body = [System.Text.Encoding]::UTF8.GetBytes($JsonBody)
    }

    try {
        $Result = Invoke-RestMethod @Params
    }
    catch {
        throw "Telegram request failed: $(Redact (Get-HttpErrorText $_))"
    }

    if ($Result.ok -ne $true) {
        throw "Telegram returned ok=false: $(Redact ($Result | ConvertTo-Json -Depth 20 -Compress))"
    }

    return $Result.result
}

Set-Location $ProjectDir

$Env = Read-DotEnv $EnvPath
$script:TelegramToken = $Env["TELEGRAM_BOT_TOKEN"]
$script:TelegramApiBase = $Env["TELEGRAM_API_BASE"]
$script:ProxyUrl = $Env["HTTPS_PROXY"]

if ([string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
    $script:ProxyUrl = $Env["HTTP_PROXY"]
}
if ([string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTPS_PROXY", "Process")
}
if ([string]::IsNullOrWhiteSpace($script:ProxyUrl)) {
    $script:ProxyUrl = [Environment]::GetEnvironmentVariable("HTTP_PROXY", "Process")
}
if ([string]::IsNullOrWhiteSpace($script:TelegramApiBase)) {
    $script:TelegramApiBase = "https://api.telegram.org"
}
$script:TelegramApiBase = $script:TelegramApiBase.TrimEnd("/")

if ([string]::IsNullOrWhiteSpace($script:TelegramToken)) {
    throw "Missing TELEGRAM_BOT_TOKEN in .env"
}

Write-Host "Checking Telegram bot..."
$Bot = Invoke-Telegram -Method "getMe"
Write-Host "Bot: @$($Bot.username) id=$($Bot.id)"
Write-Host "Clearing webhook without dropping pending messages..."
[void](Invoke-Telegram -Method "deleteWebhook" -Payload @{
    drop_pending_updates = $false
} -TimeoutSec 30)
Write-Host "Waiting for the /ping message you just sent to @$($Bot.username)..."

$Updates = Invoke-Telegram -Method "getUpdates" -Payload @{
    timeout = 25
} -TimeoutSec 35

if ($null -eq $Updates -or $Updates.Count -eq 0) {
    Write-Host "No update received."
    Write-Host "This means Telegram did not deliver a pending message to this token, or another bot process consumed it."
    exit 1
}

$Last = $Updates | Select-Object -Last 1
$Message = $Last.message
if ($null -eq $Message) {
    $Message = $Last.edited_message
}
if ($null -eq $Message -or $null -eq $Message.chat) {
    Write-Host "Latest update has no message/chat. Send /ping again and rerun this test."
    exit 1
}

$ChatId = [long]$Message.chat.id
$Text = [string]$Message.text
Write-Host "Latest text: $Text"
if (-not $Text.StartsWith("/ping")) {
    Write-Host "Latest text is not /ping."
    Write-Host "Close running bot windows, send /ping to @$($Bot.username), then rerun this test."
    exit 1
}
Write-Host "Replying to chat_id=$ChatId..."

[void](Invoke-Telegram -Method "sendMessage" -Payload @{
    chat_id = $ChatId
    text = "pong"
})

[void](Invoke-Telegram -Method "getUpdates" -Payload @{
    offset = ([long]$Last.update_id + 1)
    timeout = 0
})

Write-Host "Sent pong. If Telegram received it, token/network/sendMessage are working."
