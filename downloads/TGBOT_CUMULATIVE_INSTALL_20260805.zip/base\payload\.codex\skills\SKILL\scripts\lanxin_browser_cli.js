#!/usr/bin/env node
/**
 * Lanxin / aggregation-platform browser CLI helper.
 *
 * Purpose:
 * - Drive a user-provided browser/platform flow.
 * - Submit a confirmed prompt unchanged.
 * - Check every 3 minutes until an original image can be downloaded.
 * - Verify the downloaded file is a real image.
 * - Return the verified local file path so the caller can send it through Telegram/document mode.
 *
 * Security:
 * - Do not hardcode credentials.
 * - Prefer an already logged-in browser profile or user-provided credentials at runtime.
 * - Stop for CAPTCHA/2FA/payment/quota/permission blocks.
 *
 * Usage example:
 *   node scripts/lanxin_browser_cli.js --url https://lx.lanxinai.com/ --prompt prompt.txt --out out.png --poll-ms 180000
 *
 * Delivery note:
 *   This helper does not send Telegram messages by itself. After it prints a verified output path,
 *   the assistant must use the host/provider file-send capability in document mode. If a normal
 *   media preview does not reach the user, resend the same verified file as a document before regenerating.
 */
const fs = require('fs');
const path = require('path');

function arg(name, fallback = null) {
  const prefix = `--${name}=`;
  const direct = process.argv.find((item) => item.startsWith(prefix));
  if (direct) return direct.slice(prefix.length);
  const index = process.argv.indexOf(`--${name}`);
  if (index >= 0 && process.argv[index + 1]) return process.argv[index + 1];
  return fallback;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function verifyImage(filePath) {
  if (!fs.existsSync(filePath)) throw new Error(`Missing output: ${filePath}`);
  const stat = fs.statSync(filePath);
  if (stat.size < 4096) throw new Error(`Output too small: ${stat.size} bytes`);
  const header = fs.readFileSync(filePath, { start: 0, end: 15 });
  const isPng = header[0] === 0x89 && header.slice(1, 4).toString('ascii') === 'PNG';
  const isJpeg = header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff;
  const isWebp = header.slice(0, 4).toString('ascii') === 'RIFF' && header.slice(8, 12).toString('ascii') === 'WEBP';
  if (!isPng && !isJpeg && !isWebp) throw new Error('Output is not PNG/JPEG/WEBP');
  return { filePath, bytes: stat.size, type: isPng ? 'png' : isJpeg ? 'jpeg' : 'webp' };
}

async function main() {
  const url = arg('url');
  const promptPath = arg('prompt');
  const outPath = path.resolve(arg('out', `lanxin_output_${Date.now()}.png`));
  const pollMs = Number(arg('poll-ms', '180000'));
  const maxChecks = Number(arg('max-checks', '20'));

  if (!url) throw new Error('Missing --url');
  if (!promptPath) throw new Error('Missing --prompt');
  const prompt = fs.readFileSync(promptPath, 'utf8').trim();
  if (!prompt) throw new Error('Prompt file is empty');

  let chromium;
  try {
    ({ chromium } = require('playwright'));
  } catch (error) {
    throw new Error('Install Playwright first: npm i playwright');
  }

  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage({ acceptDownloads: true });
  await page.goto(url, { waitUntil: 'domcontentloaded' });

  console.log('Opened platform. Complete login manually if required, then press Enter here.');
  await new Promise((resolve) => process.stdin.once('data', resolve));

  const textareas = page.locator('textarea');
  if (await textareas.count()) {
    await textareas.first().fill(prompt);
  } else {
    const editable = page.locator('[contenteditable="true"]').first();
    await editable.fill(prompt);
  }

  const generateButton = page.getByRole('button', { name: /生成|提交|開始|Create|Generate/i }).first();
  await generateButton.click();

  for (let check = 1; check <= maxChecks; check += 1) {
    console.log(`Checking result ${check}/${maxChecks}`);
    const downloadButton = page.getByRole('button', { name: /下載|Download|保存|Save/i }).first();
    if (await downloadButton.count()) {
      const downloadPromise = page.waitForEvent('download', { timeout: 15000 }).catch(() => null);
      await downloadButton.click().catch(() => null);
      const download = await downloadPromise;
      if (download) {
        await download.saveAs(outPath);
        console.log(JSON.stringify(verifyImage(outPath)));
        await browser.close();
        return;
      }
    }

    const dataUrl = await page.evaluate(() => {
      const images = Array.from(document.images).map((img) => img.currentSrc || img.src).filter(Boolean);
      return images.find((src) => src.startsWith('data:image/')) || null;
    });
    if (dataUrl) {
      const match = dataUrl.match(/^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i);
      if (match) {
        fs.writeFileSync(outPath, Buffer.from(match[2], 'base64'));
        console.log(JSON.stringify(verifyImage(outPath)));
        await browser.close();
        return;
      }
    }

    await sleep(pollMs);
  }

  await browser.close();
  throw new Error('No downloadable verified image found before max checks');
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
