# NBS Confirmation Checklist Required

Created: 2026-06-29

Owner rule:

For all future NBS / NotebookLM tasks, Codex must provide a confirmation checklist first and wait for explicit owner confirmation before adding sources to NotebookLM, starting generation, submitting a Studio output, exporting, downloading, or triggering any irreversible action.

This applies to:

- NotebookLM presentations / decks.
- NotebookLM video summaries.
- NotebookLM audio summaries.
- Complete NBS packages that include presentation, video summary, and audio summary.
- NBS tasks based on websites, YouTube links, files, images, posters, or pasted text.

The NBS confirmation checklist must include the practical submission scope:

- Source material to be added.
- Requested outputs: presentation, video summary, audio summary, or complete NBS package.
- Language, defaulting to Traditional Chinese unless the owner specifies otherwise.
- NotebookLM source method: website, YouTube as website source, file upload, image/poster text extraction, or pasted text.
- Presentation requirements when relevant, including at least 15 content slides unless the owner accepts fewer.
- Delivery format: real NotebookLM original PPTX / MP4 / M4A or MP3 after validation.
- Validation rules: no placeholder, no HTML/login page, no corrupted file, no self-made replacement output.
- Estimated waiting/checking plan.
- Cost, quota, subscription, or payment information if the platform shows any cost-related prompt.

Do not start a new NBS generation or submit a NotebookLM Studio output before the owner replies with clear confirmation, unless the owner is continuing an already confirmed NBS task within the same scope.

Existing NBS completion rules still apply: a NBS task is complete only after the real NotebookLM output is generated, downloaded/exported, validated, and sent to Telegram once.
