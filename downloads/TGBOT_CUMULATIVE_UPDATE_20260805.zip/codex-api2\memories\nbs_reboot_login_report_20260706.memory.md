# NBS Reboot Login Report

- Date: 2026-07-06
- For NBS / NotebookLM, Windows logon runs `C:\Users\你的使用者名稱\nbs_task\nbs_autostart.ps1` via scheduled task `NBS NotebookLM AutoStart`.
- The script opens the fixed Chrome profile, checks NotebookLM login state, writes `C:\Users\你的使用者名稱\nbs_task\nbs_startup_status.json` and `C:\Users\你的使用者名稱\nbs_task\nbs_login_status.json`, then reports the result to Telegram only when `C:\Users\你的使用者名稱\nbs_task\nbs_reboot_report_target.json` is enabled.
- The Telegram report target is the exact current origin chat/thread saved for this owner request. Never use allowed-chat, default-chat, previous-chat, or fallback destinations for this reboot login report.
- If Telegram reporting fails, keep local status files updated and report the concrete blocker with the local status path when asked.
