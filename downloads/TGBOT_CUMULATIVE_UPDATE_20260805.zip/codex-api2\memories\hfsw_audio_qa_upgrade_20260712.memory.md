# HFSW Audio QA Upgrade - 2026-07-12

Owner approved upgrading HFSW after the Liu Bang/Zhang Fei problems: noisy BGM, subtitles not aligned, and sections that sounded like no audio.

Apply this as the latest HFSW completion standard.

## Core Upgrade

1. Keep voice, BGM, subtitle timing, platform images, and final mix traceable in each HFSW task folder.
2. BGM fixes are mix-only. Do not change approved accent, narrator, speed, subtitle timing, or visual timing unless the owner explicitly requests it.
3. For HFSW audio complaints, checking `has audio stream` is not enough. Must check silence/dropouts, BGM from 0s, loop continuity, phone-speaker audibility, and whether BGM is noisy.
4. For long videos, inspect opening, every 10 minutes, known problem points, middle, and final minute.
5. For subtitles, extract frames and check bottom Kai-style captions are readable, not cropped, not doubled, and not appearing before the voice.
6. If captions are burned in and wrong, cover/rebuild/re-burn them. Do not claim external subtitle timing fixes burned-in text.
7. If aggregation platform / Blue Star images are expected, keep a platform-image inventory. Local fallback images do not count as final unless the owner explicitly accepts them.
8. HFSW must run until the final MP4 validates and same-origin TG3 document delivery succeeds, or a real blocker is reported.

## New Local Tools

HFSW skill updated:

`C:\Users\你的使用者名稱\.codex-bot3\skills\hfsw\SKILL.md`

QA script:

`C:\Users\你的使用者名稱\.codex-bot3\skills\hfsw\tools\hfsw_media_qa.ps1`

Manifest template:

`C:\Users\你的使用者名稱\.codex-bot3\skills\hfsw\templates\mix_manifest_template.md`

Use the QA script for repeatable checks when `ffprobe` and `ffmpeg` are available. The tool creates probe output, silence detection output, and extracted frames. Manual listening/visual judgment is still required before delivery.

## Important Override

`口音-1`, `口音-2`, `人聲-2`, `voice 1`, and `voice 2` are accent preset selectors, not volume or dB changes. Only change volume when the owner explicitly says volume, louder, quieter, dB, or `-2dB`.

## Expected Final Report

For future completed HFSW deliverables, report:

- final MP4 delivered by same-origin Telegram document mode,
- duration and ratio,
- audio/BGM check,
- subtitle frame check,
- platform-image count when applicable,
- local backup path.
