# HFSW Revert Accent And Audible BGM Correction - 2026-07-11

Owner correction: after several Zhang Fei HFSW BGM fixes, the owner said the accent had changed and the BGM was still not audible.

Apply this rule for future HFSW historical videos:

1. When the owner says "改回去" about the voice/accent, preserve the exact approved voice/accent from the owner-provided or approved reference video. Do not re-TTS or substitute another voice just because the BGM is being fixed.
2. For Zhang Fei, the reference in this correction is:
   `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260710_221819.mp4`
3. BGM repair must be a mix-only operation unless the owner explicitly asks to change the narration. Keep the video, subtitle, and approved voice intact.
4. The old historical BGM bed was too quiet; it existed technically but was effectively inaudible. Future BGM must be checked as a separate bed and in the final mix.
5. Use BGM that remains audible on phone speakers:
   - historical epic string / choir / warm pad bed,
   - no discrete SFX when the owner complained SFX is noisy,
   - avoid low-frequency-only rumble,
   - emphasize midrange presence so it is not mistaken for silence.
6. Voice remains lead, but BGM should be clearly present. In the 2026-07-11 correction, the BGM bed after processing measured about -18.8 LUFS before mixing, while the final mixed output remained voice-forward at about -13.2 LUFS.
7. Validate final MP4 duration, dimensions, AAC audio, subtitle frame, and same-origin TG3 document delivery.

Corrected output:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260711_zhang_fei_revert_voice_add_bgm\zhang_fei_hfsw_revert_accent_historical_epic_bgm_v10_audible_20260711.mp4`
