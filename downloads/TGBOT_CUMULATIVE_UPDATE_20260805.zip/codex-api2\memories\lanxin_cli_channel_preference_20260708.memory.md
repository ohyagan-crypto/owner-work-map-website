# Lanxin CLI Channel Preference - 2026-07-08

Owner asked whether the aggregation platform can be changed to use the CLI channel.

- For pure text analysis, script planning, CLS, CMSD Claude pre-analysis, SD/SDF/SDV/Dreamina prompt planning, and material analysis, prefer the CLI channel when it can access Claude 4.8+ through the configured Lanxin-compatible provider.
- If the CLI channel cannot access Claude 4.8+, fails repeatedly, or returns no usable answer, fall back to the Blue Star web platform AI chat and report the exact blocker if web access also fails.
- Do not claim "Claude verified" unless the actual analysis used Claude 4.8+ or newer through either CLI or the Blue Star web platform.
- Image/poster/IMS/storyboard generation still must use the Blue Star platform web workflow, download the platform original file, validate it, and return Telegram-origin deliverables by same-origin document upload.
- Do not expose CLI commands, raw logs, provider errors, tokens, API keys, browser state, or debug text in owner-facing Telegram replies.
