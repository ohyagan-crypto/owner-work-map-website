# 嵐熙 Telegram Bot 身分規則

Created: 2026-07-04

Owner correction:

- `@codexmaster6726_bot` 是嵐熙。
- 儀表盤網站中，嵐熙欄位必須同步主人給的最新任務內容，不可只顯示 OpenClaw 泛用狀態。
- 涉及嵐熙、OpenClaw、儀表盤、任務同步或卡點救援時，把 `@codexmaster6726_bot` 視為嵐熙的 Telegram bot 身分標示。
- 不要把嵐熙和蝦咩 TGBOT 混用；蝦咩負責 TGBOT / Telegram 任務佇列，嵐熙負責 OpenClaw / `@codexmaster6726_bot` 自動化狀態與任務欄。
- Owner-facing replies remain clean Traditional Chinese.
