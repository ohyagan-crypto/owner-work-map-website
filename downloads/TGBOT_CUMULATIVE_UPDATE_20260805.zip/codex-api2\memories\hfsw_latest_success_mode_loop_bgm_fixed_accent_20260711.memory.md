# HFSW Latest Success Mode - Fixed Accent + Loop BGM From Start - 2026-07-11

Owner approval: "很好，這次成功方式記好工作流，再看哪裡可以升級" after the Zhang Fei HFSW version that restored the replied-video accent and looped BGM from the beginning.

Approved output:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260711_hfsw_revert_to_replied_accent\zhang_fei_hfsw_replied_accent_loop_bgm_from_start_v2_20260711.mp4`

Verified:

- Duration: 300 seconds.
- Video: 720x1280 vertical 9:16, H.264.
- Audio: AAC stereo, 48000 Hz.
- Captions: bottom Kai-style Traditional Chinese captions.
- Delivery: returned through TG3 document mode in the originating Telegram conversation.

Latest locked HFSW rules:

1. The approved accent is fixed by default. Do not change narrator, accent, speed, pitch, timing, or re-TTS unless the owner explicitly asks to change the voice.
2. If the owner replies to a prior video and says to use "this version" for accent, inspect and use the replied video as the accent/source reference.
3. BGM work is mix-only. Preserve narration, subtitle timing, visual timing, and existing approved voice.
4. BGM must start at 0 seconds and loop continuously through the full video. No silent intro, no mid-video gaps, no early fade-out.
5. BGM must sit behind the voice. Use ducking/sidechain-style volume control so speech stays clearly in front on phone speakers.
6. Use the owner-provided BGM when supplied. If no BGM is supplied, use soft original pirate-adventure / heroic orchestral / historical-epic music, not copyrighted original recordings or exact melodies.
7. Do not add SFX by default. Avoid metal hits, whooshes, impact booms, harsh transitions, heavy percussion, and low-frequency rumble unless the owner explicitly requests effects.
8. Keep the subtitle baseline: Kai-style / DFKai-SB, bottom centered, large white Traditional Chinese text, thick black outline, subtle shadow, short chunks synced to narration.
9. For full HFSW production, keep the established order: Claude 4.8 Opus script first -> matching images -> Hyperframes composition -> voice/BGM mix -> bottom captions -> MP4 export -> validation -> same-origin Telegram document delivery.
10. Completion requires validation of duration, 9:16 dimensions, readable captions, AAC audio, no wrong old materials, BGM audible from the start, and TG3 same-origin delivery.

Upgrade candidates for future HFSW:

1. Add an audio QA step that probes voice/BGM loudness separately and rejects exports where BGM is absent, too loud, too low, or silent at the beginning.
2. Add a first-10-seconds check to confirm BGM starts immediately at 0 seconds.
3. Add a loop-boundary check to avoid audible BGM gaps when the source music repeats.
4. Store approved voice source, BGM source, and final mix settings in each task folder as a small non-secret manifest.
5. Add a "mix-only repair" script so BGM fixes never touch narration, captions, or visual timing.
6. For new HFSW projects, generate 10 images for 300 seconds by default, one image per 30-second segment.
7. Add frame extraction validation around 0s, 30s, 60s, and final 10s to confirm image cadence and bottom subtitles.
