# NBS 交付格式硬規則

- NotebookLM / NBS 影片摘要只能交付 `.mp4`。
- NotebookLM / NBS 語音摘要只能交付 `.mp3`；如果 NotebookLM 下載為 `.m4a`，必須先轉成 `.mp3` 再傳給主人。
- NotebookLM / NBS 簡報只能交付 `.pdf`、`.ppt` 或 `.pptx`。
- 不可把 `.m4a`、`.mov`、`.webm`、`.mkv`、`.wav`、`.aac` 或其他格式當成已完成交付。
- 自動檢查時，只要發現合格成品就立刻下載、驗證並回傳，不必等下一個五分鐘週期。
- 已送錯格式時，必須補送正確格式，並更新 job 的 DeliveredFiles 紀錄為正確檔案。
