# Guan Yu Hyperframes Claude-First Workflow - 2026-07-10

Owner correction: for brand-new Guan Yu style long-form videos, do not treat old Telegram photos or previous task assets as materials unless the owner explicitly says to reuse them.

Use this optimized sequence:

1. If no current materials are provided, treat the task as a zero-material workflow. Do not invent or list M01/M02/M03 materials, do not analyze old uploaded photos, and do not include a material list.
2. Use the aggregation platform Claude 4.8 Opus first to produce the full narrative copy, scene plan, voiceover script, caption structure, image prompt list, and Hyperframes timing plan.
3. Generate corresponding new images from the approved Claude copy and scene plan. Images must match the script rather than being generic atmosphere shots.
4. Use Blue Star / IMS for image generation when image credits are needed. Do not spend credits before owner confirmation unless the active workflow explicitly allows it.
5. Put generated images into a Hyperframes project. Hyperframes is the composition and animation source of truth.
6. Build a 9:16 video with a coherent visual system, scene transitions, bottom captions, and image motion.
7. Generate natural voiceover MP3 from the approved script. The voiceover must actually explain the theme and match the target duration.
8. Mix voiceover with BGM and sound effects. Voice must remain clear and dominant.
9. Export MP4, validate duration, dimensions, audio, subtitles, and visual content.
10. For Telegram-origin tasks, deliver the final MP4 only through the same originating bot/chat by document mode.

Quality standard:
- Script first, image second, video third.
- Content must be theme-specific, not generic narration.
- Images must correspond to each script segment.
- Captions stay at the bottom.
- Do not mix unrelated materials, OpenClaw, modern classroom assets, skincare products, or old task materials into Guan Yu videos unless the owner explicitly asks.
