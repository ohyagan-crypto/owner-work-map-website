# Explicit Image Tool Routing - 2026-07-20

Owner correction: when the owner explicitly names the image tool, obey that tool exactly.

- `ComfyUI`, `comfy`, or `com` means use only ComfyUI for that image/poster task.
- `image2`, `image`, `image2 API`, or `gpt-image-2` means use only the image2 route for that image/poster task.
- Do not automatically switch tools, make comparison versions, or override the route because another tool seems better.
- If the chosen tool is likely weak for Traditional Chinese text, layout, or style, warn briefly before confirmation, but keep the route unchanged unless the owner changes it.
- This rule applies across TG1, TG2, TG3, IMS, poster, tutorial image, and revision tasks.
