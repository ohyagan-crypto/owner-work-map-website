# HFSW Run Until Good - 2026-07-12

Owner correction from TG3: `hfsw` must keep working until the final video is actually good.

Reusable rule:

- If Blue Star / aggregation platform has already produced partial images, inspect the real image folder and platform/cache state, keep valid platform images, and continue from the missing scene numbers.
- Do not stop at a fallback-rendered MP4 when the owner expects platform images.
- Local fallback images are allowed only as temporary placeholders, not as final HFSW deliverables.
- When platform images are added after a fallback draft, force-rerender video segments before final muxing. Remuxing alone is not enough because old segment files may still contain fallback visuals.
- Validate late-video frames after rerendering, especially scenes after the newly generated range.
- Completion requires validated MP4 plus same-origin Telegram document delivery through the correct bot.

Liu Bang recovery result:

- The first delivered 1-hour 16:9 draft used fallback visuals for later scenes.
- Owner noticed the aggregation platform had generated images and asked to continue.
- Correct recovery was to keep existing platform images, generate missing scenes 42-60 on Blue Star, force-rerender all 60 segments, validate the final MP4, then deliver through TG3.
