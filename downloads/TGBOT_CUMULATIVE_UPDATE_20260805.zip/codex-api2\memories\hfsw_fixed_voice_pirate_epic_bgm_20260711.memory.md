# HFSW Fixed Voice And Pirate-Epic BGM Rule - 2026-07-11

Owner correction:

- "bgm太吵"
- "以後hfsw口音都固定不要更動 除非我要求"
- "你知道神鬼奇航主題曲嗎 用這個當bgm"

Apply this rule for future HFSW work:

1. The approved HFSW voice/accent is locked by default. Do not re-TTS, swap voice, change accent, change speed, or replace narration unless the owner explicitly asks to change the voice/accent.
2. BGM repair is mix-only. Keep the approved voice, video, and subtitles intact; only replace or rebalance music.
3. If the owner references a copyrighted soundtrack such as the Pirates of the Caribbean theme, do not directly use or recreate the protected recording or exact melody unless the owner supplies licensed audio. Use an original "pirate adventure / heroic orchestral / maritime epic" BGM direction instead.
4. For Zhang Fei HFSW, use the owner-approved reference voice from:
   `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260710_221819.mp4`
   or the clean extracted locked voice:
   `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_clean_voice_reference_short_loud_kai.wav`
5. BGM should be present but not loud: voice remains the lead. Avoid noisy SFX, metal hits, whooshes, low-frequency-only rumble, or busy percussion when the owner complains that BGM is noisy.
6. Use midrange orchestral support: restrained strings, warm brass, choir/pad, light marching rhythm. Duck BGM under narration.
7. Validate final MP4 duration, dimensions, AAC audio, readable Kai-style bottom subtitles, and same-origin TG3 document delivery.

Latest corrected output:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260711_hfsw_bgm_pirate_style\zhang_fei_hfsw_fixed_accent_pirate_epic_bgm_soft_20260711.mp4`
