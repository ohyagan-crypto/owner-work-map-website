# HFSW Epic BGM Correction - 2026-07-11

Owner reported the prior Zhang Fei HFSW BGM was mismatched, noisy, and too distracting.

Use this correction for future HFSW, especially Zhang Fei / Guan Yu / Three Kingdoms historical story videos:

- Do not use dense low-frequency rumble, stacked whooshes, harsh metallic clusters, or busy synthetic arpeggios as the main BGM.
- Choose the BGM by story context, not by simply making effects louder.
- For Three Kingdoms historical storytelling, default to a cleaner epic bed:
  - slow low strings / bowed bass foundation,
  - restrained brass-like swells,
  - subtle choir/pad warmth,
  - sparse war drums on section changes and important beats,
  - very limited transition accents.
- Voice remains the lead layer. BGM should support scale, tension, and historical weight without masking speech.
- SFX should be sparse and purposeful; if it makes the result noisy, remove or reduce it.
- Verify final MP4 for duration, 9:16 dimensions, AAC audio, readable Kai-style bottom subtitles, and Telegram same-origin delivery.

Corrected Zhang Fei deliverable:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_epic_bgm_v6_20260711.mp4`

Implementation note:

- The corrected BGM was rebuilt as a separate clean epic/cinematic music bed, then mixed with the clean approved voice stem and remuxed onto the approved captioned video.
- Mix direction: narration in front, epic BGM audible but controlled, no noisy low-frequency clutter.
