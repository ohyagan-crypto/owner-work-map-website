# MEMORY.md 關鍵字索引
# 快速檢索MEMORY.md中的重要段落

## 快速跳轉
| 關鍵字 | 位置 | 摘要 |
|--------|------|------|
| Codex最高原則 | MEMORY.md #【Codex最高原則】 | 核心規則：即時回報、刪除噪音、卡住停損 |
| Dreamina CLI | MEMORY.md #【Dreamina核心指令集】 | dreamina.exe路徑、禁止命令、sd/sdf簡寫 |
| 嵐熙主動權 | MEMORY.md #【嵐熙主動權規則】 | 石頭人沒特別說就不主動用嵐熙 |
| 作業系統規則 | MEMORY.md #【作業系統規則】 | Codex默認執行，龍蝦只當橋樑 |
| 提交確認紀律 | MEMORY.md #【提交前確認流程】 | 先給清單，等確認，再執行 |
| 記憶自主優化 | MEMORY.md #【記憶自主優化規則】 | 說一次就記住，主動補充進化 |
| 純素材模式 | MEMORY.md #【Dreamina純素材模式】 | 無提示詞，成功率高 |
| 每日備份 | MEMORY.md #【每日備份】 | 桌面\龍蝦記憶，backup_memory.ps1 |
| 角色設定 | MEMORY.md #【角色設定】 | 嵐熙/庫里/小蝦圖片和音頻路徑 |
| 簽到系統 | MEMORY.md #【藍星車隊簽到系統v3】 | URL、PIN 6726、功能說明 |
| NotebookLM | MEMORY.md #【NotebookLM簡報規範】 | 最少15張，下載路徑 |

## HEARTBEAT.md 關鍵索引
| 關鍵字 | 位置 | 摘要 |
|--------|------|------|
| 記憶複習 | HEARTBEAT.md #1.記憶複習 | 每小時一次，發現遺漏立刻補寫 |
| 每日23:00 | HEARTBEAT.md #⏰每日23:00 | 保存記憶+複習MEMORY+持續優化+備份 |
| 積分查詢 | HEARTBEAT.md #3.積分查詢 | 每6-8小時查一次 |

