# Dreamina CLI Fixed Login Reuse Policy - 2026-07-09

Owner instruction: keep Dreamina CLI logged in and reuse the same account/session by default.

Operational rule:
- Do not run `dreamina logout` or `dreamina relogin` unless the owner explicitly asks to switch accounts or clear the current account.
- Do not start a fresh OAuth/login flow just because a task begins. First verify the existing local login state with `C:\Users\你的使用者名稱\dreamina.exe user_credit` and `C:\Users\你的使用者名稱\dreamina.exe list_task --limit=5`.
- If both checks work, treat the current local session as valid and continue the SD/SDF/Dreamina task without asking the owner to authorize again.
- If a command fails once, inspect the real CLI state, job records, and logs before asking for authorization. Do not use old Device Flow URLs or expired codes.
- Ask the owner to authorize again only when the platform clearly requires OAuth again, CAPTCHA, 2FA/passkey/SMS/email approval, account risk verification, a permission change, or the owner explicitly asks to change accounts.
- Current local account verified on 2026-07-09: user_id `[REDACTED_NUMBER]`, vip_level `standard`, total_credit `857`. This account can query credit and tasks, but CLI generation permission may still require a higher membership or platform-side CLI permission.
- If the owner wants the former high-permission account, perform one explicit account switch/login, then preserve and reuse that new account under this same policy.

Completion rule:
- A Dreamina CLI route is considered usable only when `user_credit` and `list_task --limit=5` both succeed, and generation permission is not rejected by the platform.
- If the account lacks CLI generation permission, report that as an account permission blocker, not as a login failure.
