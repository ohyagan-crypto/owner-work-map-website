# NBS Auto Check Traditional Chinese Delivery - 2026-07-07

Owner correction:

1. NBS deliverables must be returned automatically after completion. The automatic check mechanism was too weak and must be strengthened.
2. NBS presentation, video summary, and audio summary must all be Traditional Chinese versions by default.

Updated reusable rule:

- For every NBS / NotebookLM task, completion requires: real NotebookLM output generated, downloaded or exported from the same notebook, staged under the task artifact folder, renamed with clean ASCII filename, validated, checked for Traditional Chinese requirements, and delivered to the same originating Telegram conversation by document/file mode.
- A local path, downloaded file, generated card, or submitted job is not completion until Telegram delivery succeeds or a real delivery blocker is reported.
- After submitting a NotebookLM Studio generation, create or update a job record under `C:\Users\RECEIVER\nbs_task\jobs` with output type, source summary, language, next check time, validation state, delivery state, artifact folder, and delivered files.
- NBS auto-check must inspect real state: NotebookLM card status, browser state, Downloads folder, artifact folder, file validity, Traditional Chinese language requirement, and Telegram delivery result.
- If output is ready, the next action is download/export, validate, stage, and return to Telegram. Do not wait for the owner to ask "好了沒" or "回傳".
- If the same step fails three times, stop blind retries and report the concrete blocker with the best local backup path.
- Default language is `中文（繁體）` for presentation, video summary, and audio summary unless the owner explicitly specifies another language in the current request.
- Presentation validation must inspect PPTX structure and slide text for Traditional Chinese. Do not deliver a Simplified Chinese, English, placeholder, or corrupted deck.
- Video and audio summary validation must verify playable media and that the generated version is Traditional Chinese when NotebookLM exposes language, captions, title, transcript, or readable text. Wrong-language media is not deliverable.
- Confirmation checklists for future NBS tasks must include a line for `語言：中文（繁體）` and `完成後自動檢查並回傳 Telegram 原來源對話`.
