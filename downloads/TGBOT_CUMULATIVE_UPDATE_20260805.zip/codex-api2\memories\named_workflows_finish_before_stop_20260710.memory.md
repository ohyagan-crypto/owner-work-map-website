# Named Workflows Finish Before Stop - 2026-07-10

Owner correction: all named workflows must continue until genuinely complete, not only NBS.

Applies to: `nbs`, NotebookLM, `sd`, `sdf`, `sdv`, Dreamina, Seedance, `cmsd`, `cmdsw`, `ims`, `hfsw`, `wbs`, `acs`, `acs2`, `ans`, `nms`, `speech`, `transcribe`, `pdf`, Lanxin/Blue Star generation, website/deploy tasks, Telegram delivery tasks, and any owner follow-up saying a file is missing or was not returned.

Completion rule:

1. Identify the exact current deliverable and source materials from the newest owner instruction.
2. Execute the workflow through real platform submission or local generation when required.
3. Record job id/status when a platform job exists.
4. Wait or actively poll until generation/export/download is complete, unless a real external blocker remains.
5. Validate final files: existence, format, readability/playability, page count/duration/dimensions/language/content as relevant.
6. For Telegram-origin work, deliver every final requested file back to the same originating chat/thread by document/file mode whenever possible.
7. Only report complete after delivery succeeds or after a concrete delivery blocker is known with the local backup path.

Forbidden completion states:

- started
- queued
- submitted
- generated
- playing
- visible card
- downloaded but unvalidated
- exported but undelivered
- local path only
- partial delivery
- Telegram send attempt without success verification

If a workflow stalls:

- Inspect real local/platform state before replying: job record, task folder, artifact folder, browser/platform page, download folder, validation result, delivery state.
- Latest owner correction on 2026-07-12: for recoverable workflow failures, do not stop after one failed attempt. Rebuild, resubmit, regenerate, redownload, revalidate, or redeliver as appropriate until the workflow is genuinely complete.
- Minimum retry threshold: if the failure is recoverable and does not require owner/external action, attempt at least five real recovery runs before reporting blocked.
- Each retry must change or inspect something concrete: check platform state, clear stale output, use the correct profile/account, rerun the generation, rebuild the artifact, redownload the file, or redeliver by Telegram document mode. Do not count blind repeated clicks with no state inspection as valid attempts.
- Report earlier only for real external blockers that cannot be solved by retrying: missing material, missing/wrong credentials, CAPTCHA, SMS/email/2FA/passkey, payment/credit confirmation, account security lock, platform-wide outage, unavailable origin chat id, or a safety restriction.
- After five failed recoverable attempts, report the exact blocker, completed steps, attempt count, local backup path if any, and the external action needed.

Owner-facing replies should be concise Traditional Chinese with a concrete result, delivered filenames/URL/path, verification performed, or the real blocker. Do not send a generic standby reply.
