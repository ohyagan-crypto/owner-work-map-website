# Media Tasks Confirmation Checklist Required

Created: 2026-06-29

Owner rule:

For any future image or video related task, Codex must provide a confirmation checklist before creating, generating, submitting, exporting, uploading, or spending credits/quota.

This applies to:

- Image generation, poster generation, visual design, product images, social media images, and revisions.
- SD/Dreamina/AI short video generation, image-to-video, text-to-video, and reference-based video generation.
- Video editing, CapCut/Jianying automation, reference-video replication, exports, uploads, or publishing.

The checklist must be practical and include relevant items such as prompt/copy, materials, style, dimensions/aspect ratio, duration, platform/model, cost or credit usage, estimated TWD price when cost is involved, and the exact action to be submitted.

Wait for the owner's explicit confirmation before any credit-consuming, irreversible, or externally submitted action. If the owner is clearly continuing an already confirmed task, continue within that confirmed scope only.
