# HFSW Success Mode - Fixed Voice + Soft Pirate-Epic BGM - 2026-07-11

Owner approval: "這次可以 記好成功方式" after reviewing the TG3 returned Zhang Fei HFSW video.

Inspected reference video:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_115648.mp4`

Validation observed before saving this memory:

- Duration: 300 seconds.
- Size: about 14.9 MB.
- Video: H.264, 720x1280, 30 fps, 9:16 vertical.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.2 dB, peak near 0 dB.
- Visual sample: Zhang Fei / Three Kingdoms historical-epic imagery, no old classroom/skincare/OpenClaw material mixed in.
- Captions: large Traditional Chinese bottom captions, white text, dark outline/shadow, readable on phone-style vertical video.

Approved HFSW success mode from this version:

1. Voice/accent is locked by default.
   - Do not re-TTS, change accent, change speaking speed, or swap the narrator unless the owner explicitly asks to change the voice.
   - BGM fixes are mix-only. Keep the approved voice, subtitles, and video timing intact.

2. Subtitle style is locked by default.
   - Use Kai-style / DFKai-SB when available.
   - Large Traditional Chinese captions near the bottom, centered.
   - White fill, thick black outline, subtle dark shadow.
   - Short phrase chunks synced to narration.
   - No top title banner, no tiny captions, no double subtitles.

3. BGM direction approved in this version.
   - Use a soft original "pirate adventure / heroic orchestral / maritime epic" direction inspired by the owner's reference, not the copyrighted original recording or exact melody.
   - The music should feel epic and adventurous, but softer than the noisy earlier attempts.
   - Use restrained strings, warm brass, light marching rhythm, and broad orchestral support.
   - Keep BGM ducked under narration: audible, but never louder than the voice.

4. Sound effects are off by default for this mode.
   - Do not add noisy SFX, metal hits, whooshes, impact booms, harsh transitions, or low-frequency rumble.
   - Only add SFX if the owner explicitly asks for them after this approval.

5. HFSW production flow remains:
   - Claude 4.8 Opus script first.
   - Generate matching images from the script.
   - Hyperframes composition, motion, captions, and final video.
   - Export MP4, validate duration/dimensions/audio/subtitles.
   - For Telegram-origin tasks, return the final MP4 through the same originating TG bot/chat by document mode.

This memory overrides earlier HFSW BGM attempts that were described as noisy, too low, low-frequency rumble, or not matching the history-epic mood.
