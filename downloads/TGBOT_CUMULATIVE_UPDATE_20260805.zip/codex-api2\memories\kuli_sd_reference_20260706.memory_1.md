# 庫裡 SD 角色參考更新

## 2026-07-06 Correction

The image described in this memory is the black hoodie / orange drawstrings / peeled banana image.
Per the owner's latest AGENTS.md correction, this image must not be used as the correct Kuli generation reference for cmsd, SD, SDF, SDV, Dreamina, or image/video tasks.
If this is the only Kuli image available, stop before generation and ask the owner for the corrected Kuli character image.

Owner provided the latest Telegram photo on 2026-07-06 and labeled it: 「這是庫裡」.

## Latest reference image

- Source upload: `C:\Users\RECEIVER\tg-openai-bot\telegram_uploads\telegram_photo_20260706_120225.jpg`
- Backed-up material: `C:\Users\RECEIVER\Desktop\榫嶈潶瑷樻喍\sd_materials_20260706\curry_reference_20260706_120225.jpg`
- Image size: `896 x 1196`

## Stable visual traits for SD prompts

- Male character named 庫裡.
- Front-facing half-body portrait, clean light studio background.
- Short black hair with shaved sides, longer top swept to one side.
- Clean youthful Taiwanese/Chinese male look, soft smile, no glasses.
- Current outfit in this reference: black hoodie with orange drawstrings and orange sleeve details.
- Wearing a wristband/smart band on one wrist and a silver watch on the other.
- Holding a peeled banana with both hands in the reference image.

## Prompt usage notes

- Use this image as the latest face/identity reference when the owner asks for 庫裡 in SD/Dreamina video tasks.
- Treat hoodie, watch, wristband, and banana as changeable scene props unless the owner asks to preserve this exact look.
- Negative constraints when identity matters: no glasses, no sunglasses, no extra face changes, no cartoon/Q-version unless explicitly requested.
- Existing memory says 庫裡 and 嵐熙 audio should not be used together in the same generation if that workflow would trigger failure; use only one character audio unless the owner explicitly approves another test.
