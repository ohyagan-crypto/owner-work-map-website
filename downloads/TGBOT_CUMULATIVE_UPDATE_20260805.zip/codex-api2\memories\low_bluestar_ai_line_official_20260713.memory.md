# LOW 藍星 AI LINE 官方客服接手 - 2026-07-13

Owner confirmed login success for the second LINE Official account and assigned 「藍星AI官方客服」 to Codex.

## Target Account

- Workflow: `low`
- LINE Official account: `藍星AI官方客服`
- Basic ID: `@977wywdw`
- Use case: Blue Star / 藍星 AI official customer service.
- This account is separate from MoreFun / 魔方. Never reuse or overwrite MoreFun relay, secrets, prompt, webhook, tunnel, scheduled task, or status files for this account.

## Local Isolation

- Browser profile: `C:\Users\你的使用者名稱\line_official_second\chrome-profile`
- Relay script: `C:\Users\你的使用者名稱\line-bluestar-ai-relay.js`
- CLI helper: `C:\Users\你的使用者名稱\line-bluestar-ai-official-cli.ps1`
- Secrets file: `C:\Users\你的使用者名稱\line-bluestar-ai-relay.secrets.json`
- Prompt file: `C:\Users\你的使用者名稱\.openclaw\workspace\line_cs\bluestar_ai_customer_prompt.txt`
- Log/status folder: `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\line-bluestar-ai`
- Local relay port: `3001`

## Current State

- LINE Official Account Manager login verified.
- Account visible and manageable.
- Messaging API status was `未使用`.
- Enabling Messaging API requires LINE Developers developer info: developer name and email.
- Developer email is not visible/pre-filled locally; do not guess it.

## Completion Gate

This setup is not complete until all are true:

1. LINE Developers developer info is completed for the logged-in account.
2. Messaging API is enabled for `藍星AI官方客服`.
3. Channel secret and Channel access token are saved only in the separate secrets file.
4. Independent relay starts on port `3001`.
5. Independent public webhook is created and set on the target Messaging API channel.
6. LINE webhook test passes.
7. Hourly monitor/repair is created for this account without affecting MoreFun.
8. Owner-facing report includes only clean Traditional Chinese, non-secret status.

## Customer Reply Style

- Clean Traditional Chinese.
- Short, practical, friendly.
- Directly guide common actions: default browser, add to home screen, new chat, refresh model, login, payment/plan issue triage.
- Never request passwords, verification codes, tokens, API keys, cookies, full card data, or other secrets.
