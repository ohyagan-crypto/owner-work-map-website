# Lanxin All Image-Related Hard Lock

Created: 2026-07-01 after the owner corrected another accidental local image/style revision.

## Highest Rule

All image-related tasks must use Lanxin AI / 聚合平台 only: `https://lx.lanxinai.com/`.

This includes:

- 做圖、生圖、生成圖片、產圖、圖片生成
- 做海報、產海報、海報設計、圖片設計、製作圖片
- 修圖、改圖、換風格、科技一點、再做一次、重做、改版、變體、下一版
- 封面、縮圖、Banner、商品圖、人物圖、行銷圖、社群圖、廣告圖
- 文案轉圖、PPT 轉海報、PDF 轉海報
- SOP / teaching / tutorial / explainer image sets

## Forbidden Substitutes

Do not use local `imagegen`, built-in image generation, local scripts, Canvas, PPT, Photoshop, ImageMagick, Node/System.Drawing, HTML/SVG composition, screenshots, crops, previews, old gallery items, or any other website/API/tool as a substitute.

If Lanxin / 聚合平台 is unavailable, fails, has no quota, blocks login, requires CAPTCHA/2FA/payment/permission, cannot upload materials, cannot generate, or cannot download the original image, report the exact platform blocker in clean Traditional Chinese. Do not create a local replacement and do not claim completion.

## Completion Standard

An image task is complete only when all four checks pass:

1. The current task was submitted/generated through Lanxin / 聚合平台.
2. The platform original was downloaded.
3. The file was validated for existence, dimensions, readability, and task match.
4. The verified original was returned to the originating Telegram chat by document/file mode, or a real Telegram delivery blocker was reported with the local backup path.

If any check is missing, the result is not complete.
