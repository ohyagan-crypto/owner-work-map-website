# HFSW Audio Deep Check - Noisy BGM, Subtitle Sync, Dropouts - 2026-07-12

Owner correction: the owner reported `背景音很雜`, `字幕對上`, `無音頻`, and asked to thoroughly check.

Inspected owner-provided/replied video:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Observed:

- Duration: 300 seconds.
- Video: 720x1280, H.264, 30 fps.
- Audio: AAC stereo, 48 kHz. The file has an audio stream, so it is not globally mute.
- Overall audio level: mean around -16.7 dB, peak near 0 dB.
- Detected low-audio/silent gaps:
  - around 84.25-85.18s
  - around 174.28-175.20s
  - around 264.15-265.18s
  - stricter threshold also catches shorter gaps near 88s, 177s, and 270s.
- Captions are burned into the video at the bottom in Kai-style white text with black outline.

Also inspected recent Liu Bang target:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260712_liu_bang_hfsw_audio_subtitle_repair\liu_bang_hfsw_1h_16x9_voice1_audio_subtitle_repaired_wrapped_tg_20260712.mp4`

Observed:

- Duration: 3600 seconds.
- Video: 1280x720, 16:9.
- Audio: AAC stereo, 48 kHz.
- No >0.7s complete silent gap was detected at -35 dB in the latest checked file.
- Overall audio mean is around -23.2 dB, which can feel weak or nearly absent on phone speakers even though the audio stream exists.

Rules for future HFSW:

1. Do not answer based only on "audio stream exists." Check silence/dropouts and practical phone-audibility.
2. For owner complaints about noisy BGM or no audio, check both the current uploaded/replied video and the latest delivered target video if the conversation context names a target such as Liu Bang.
3. If a reference video contains noisy BGM or repeated low-audio gaps, use it as an accent reference only, not as a clean BGM bed.
4. Burned subtitles cannot be shifted like external subtitles. If alignment is wrong, rebuild/cover/re-burn the subtitle layer.
5. Long HFSW validation must include early/middle/late audio checks, frame extraction for subtitle readability, and silence detection at known issue boundaries.
6. Phone playback standard: BGM should not be low-frequency noise, narration must remain clearly audible, and no segment should feel empty unless it is an intentional pause with background bed.
