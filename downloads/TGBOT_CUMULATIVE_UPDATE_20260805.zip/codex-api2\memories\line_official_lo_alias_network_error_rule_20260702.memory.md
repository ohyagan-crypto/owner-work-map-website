# LINE Official Alias And Network Error Rule

Created: 2026-07-02

## Owner Alias

- When the owner says `lo`, interpret it as LINE Official / LINE 官方帳號 / MoreFun LINE 官方客服.
- Do not confuse `lo` with other platforms, bots, or generic login wording when the surrounding task is customer service or LINE automation.

## MoreFun LINE Customer Rule

For MoreFun LINE customer service:

- If a customer sends the red error screenshot showing `無網路連線` / `無網際網路連線`, or asks about Steam / MoreFun system having no internet connection, answer with the Steam downgrade link.
- Fixed customer reply:

```text
這是 Steam 版本不匹配，先退回 Steam 上個版本匹配系統。

降版下載：
https://cache.rkugame.cn/d/yidong/Steam/steam1779486452.7z

下載後解壓縮安裝，先用舊版 Steam。等後續更新完成後，再改用新版 Steam。
```

## Implementation Notes

- The active `line_cs` prompt and the 6-hour LINE customer watchdog known-good config should both contain this rule.
- The inspected Telegram photo for this rule was `C:\Users\你的使用者名稱\tg-openai-bot\telegram_uploads\telegram_photo_20260702_092442.jpg`; visible red text: `無網路連線`.
- Do not store customer private data, credentials, LINE tokens, cookies, API keys, raw logs, or full private keys in this memory.
