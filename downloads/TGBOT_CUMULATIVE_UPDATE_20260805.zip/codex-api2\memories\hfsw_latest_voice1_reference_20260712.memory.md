# HFSW Latest Voice 1 Reference - 2026-07-12

Owner correction from TG3:

`這個口音命名口音-1`

`用這個口音去做劉邦視頻`

Latest voice/accent reference:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

SHA256:

`42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`

Inspection summary:

- Duration: 300 seconds.
- Video: 720x1280, H.264, 30 fps.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.
- Visual style: historical-storytelling video with large bottom Kai-style Traditional Chinese captions.

Rules:

1. `口音-1`, `口音1`, `口音編號1`, and `voice 1` now refer to this 20260712_134206 reference.
2. Do not interpret `口音-1` as lowering volume or -1 dB. It is a voice/accent number.
3. If another existing reference file has the same SHA256, it is the same voice reference, but new work should record the 20260712_134206 path when this Telegram upload is the newest owner instruction.
4. For Liu Bang HFSW and future HFSW outputs using this voice reference, preserve the Kai-style bottom subtitles and use continuous BGM from 0 seconds so there are no audible gaps during narration pauses.
5. Completion still requires MP4 validation and same-origin TG3 document delivery.
