# HFSW Current Correct Accent / Voice 1 - 2026-07-12

Owner correction: "把這個口音變成是口音-1" with the current TG3 uploaded/replied video.

Exact inspected video:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_131534.mp4`

Same-content prior copy:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_131018.mp4`

SHA256 for both copies:

`42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`

Inspection summary:

- Duration: 300 seconds.
- Size: 15,137,784 bytes.
- Video: H.264, 720x1280, 30 fps.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.

Behavior rule:

1. This is the official `口音-1` / `口音編號1` / `voice 1` reference for HFSW/Zhang Fei.
2. When the owner says "this accent", "this version accent", "change back to this accent", `口音-1`, `口音1`, or uses voice/accent wording in this immediate HFSW context, use this file as the accent source/reference.
3. Do not substitute older HFSW accent references unless the owner explicitly asks for another numbered accent or uploads another new reference.
4. Keep accepted HFSW defaults with this accent: Kai-style bottom captions, voice forward, BGM from 0 seconds and looped through the full video, no noisy SFX by default.
5. Accent changes should not alter speech speed, subtitle timing, image timing, or BGM unless specifically requested.
6. Do not treat `口音-1` as lowering the volume. It is an accent preset number.
