# 蘭心對主人顯示名稱規則

Created: 2026-07-05

Owner rule:

- 之後主人說「蘭心」「Lanxin」「lanxin」「Lanxin AI」時，理解為同一個平台與流程。
- 對主人回覆、網站文字、教學文字、狀態說明、完成回報時，一律稱為「藍星」。
- 只有在技術路徑、網址、服務名稱、程式代號、credential service、API endpoint、檔名或既有工具設定需要保持相容時，才保留 `lanxin` / `Lanxin`。
- 不要在一般主人可見回覆中再稱呼「蘭心」；若需避免混淆，可寫「藍星平台」。
- 平台網址仍是 `https://lx.lanxinai.com/`，不要因顯示名稱改成藍星而更動網址或內部登入設定。
