# HFSW Replied-Video Accent Restore + Loop BGM Rule - 2026-07-11

Owner correction: "口音改回這個版本" with the replied video:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_131041.mp4`

Applied output:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260711_hfsw_revert_to_replied_accent\zhang_fei_hfsw_replied_accent_loop_bgm_from_start_v2_20260711.mp4`

Rule for future Zhang Fei / HFSW fixes:

1. When the owner says to restore or change the accent to "this version" and provides/replies with a video, inspect that exact video first and use its audio as the accent reference/source.
2. Do not re-TTS, change speed, or substitute another narrator when the task is an accent restore.
3. If a prior BGM was approved and the owner asks it to loop, make the BGM start at 0 seconds and loop through the full video duration.
4. Mix cleanly: use the replied-video narration source plus the approved BGM bed only. Do not accidentally include the previous wrong audio track from the current video.
5. Keep voice dominant. Duck the BGM under narration and avoid SFX unless explicitly requested.
6. Preserve existing video timing, visuals, and bottom Kai-style subtitles unless the owner explicitly asks to change them.
7. Validate duration, 9:16 dimensions, AAC audio, readable subtitles, and same-origin TG3 document delivery before reporting complete.

This correction extends the fixed-voice HFSW success mode: BGM repair and looping are mix-only operations, while the accent follows the owner-provided replied video.
