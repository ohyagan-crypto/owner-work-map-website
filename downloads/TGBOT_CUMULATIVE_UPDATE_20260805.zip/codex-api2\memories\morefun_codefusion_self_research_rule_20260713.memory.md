# MoreFun CodeFusion Self-Research Rule - 2026-07-13

Owner correction from TG1:

- Screenshot example: game dialog for `Yakuza: Like a Dragon` says a problem occurred and points to `support.codefusion.technology`.
- Treat this as a third-party game / CodeFusion official protection-program error, not a MoreFun or magic-system outage.
- Future MoreFun / LINE客服 replies for this issue should tell the customer to follow the dialog's official link, error code, or game name and search online themselves.
- Do not provide long troubleshooting, do not promise a fix, and do not escalate it as a MoreFun system fault.
- Suggested customer-facing reply:
  `這是遊戲本身跳出的官方錯誤，不是魔方系統問題。請依照視窗上的官方連結或錯誤碼自行上網查詢處理方式；這類第三方遊戲錯誤我們這邊無法逐一代查。`
