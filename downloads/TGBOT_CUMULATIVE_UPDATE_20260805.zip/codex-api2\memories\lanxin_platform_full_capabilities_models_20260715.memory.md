# 藍星平台完整功能與模型共同記憶

更新日期：2026-07-15

- 核心頁面：AI聊天、AI繪圖、AI視頻、媒體庫。
- 聊天模型：gpt-5.6、gpt-5.6-luna、gpt-5.6-sol、claude-opus-4-8、claude-opus-4-7、claude-opus-4-6、gemini-3.5-flash、gemini-3.5-flash-thinking、gemini-3.1-pro。
- 智能模式：極速=gemini-3.5-flash；均衡=gpt-5.6-luna；高級=gpt-5.6。
- 繪圖模型：gpt-image-2、gemini-3.1-flash-image、gemini-3-pro-image、gemini-3.1-flash-lite-image。
- 視頻模型：Seedance2.0/video-ds-2.0、Seedance2.0-fast/video-ds-2.0-fast。
- 聊天功能：歷史對話、文件與圖片上傳、網頁搜索、深度研究、建立圖片、Word、PPT、近期文件、拍照、相冊、停止生成、下載生成物。
- 文件格式：PDF、DOC、DOCX、PPT、PPTX、XLS、XLSX、TXT、MD、CSV、JSON、ZIP。
- 繪圖：多參考圖；1:1、16:9、9:16、4:3、3:4；1K、2K、4K；可下載及存媒體庫。
- 視頻：自動、文生、單圖圖生、首尾幀、2～20 張多幀、圖片/視頻/音頻全能參考；目前固定 15 秒；五種畫幅；可下載及存媒體庫。
- 媒體庫：分類、搜索、最新/收藏/名稱排序、收藏、開啟、下載、刪除。
- 商務功能：餘額、訂閱、訂單、推薦碼、邀請鏈接、兩級團隊與返利。
- 目前限制：語音辨識後台未安裝；充值支付未啟用；沒有新訂閱套餐可購買。
- 執行前須重新讀取即時模型狀態，因後台可變更模型與功能。
- 圖片與視頻任務仍須遵守確認、提交、完成、下載、驗證、Telegram 同源交付閉環。
