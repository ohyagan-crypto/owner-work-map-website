# HFSW Audio And Subtitle Alignment Repair - 2026-07-12

Owner correction: the owner reported that a HFSW video had subtitles not aligned and silence in the middle.

Inspected input:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Observed issue:

- Video was 300 seconds, 720x1280, AAC stereo.
- Subtitle text was already burned into the video, not an external subtitle stream.
- Audio had near-silent gaps around 84.25-85.18s, 174.28-175.20s, and 264.15-265.18s.

Repair rules for future HFSW:

1. For any owner complaint about HFSW audio, subtitle timing, missing voice, or silent middle sections, inspect the exact video with ffprobe, silencedetect, and extracted frames before answering.
2. Do not report "audio exists" as completion. Check for silent gaps, especially around scene boundaries.
3. If subtitles are burned into the source video, do not pretend an external subtitle edit is enough. Cover or replace the old subtitle area and burn a clean subtitle layer.
4. Subtitle starts around known silent boundaries must be delayed until after audio resumes. Do not show the next subtitle while the audio is still silent.
5. If the owner wants no silent gaps and voice cannot be reconstructed, add a continuous low-volume BGM bed from 0 seconds through the end so there is no full audio dropout, while keeping the voice dominant.
6. Validate the final MP4 with duration, dimensions, AAC audio, silencedetect, and frame extraction near every repaired boundary.
7. For Telegram-origin tasks, return the corrected MP4 through the same originating TG bot/chat by document mode.

Corrected output:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260712_hfsw_audio_subtitle_repair\zhang_fei_hfsw_voice1_subtitle_audio_fixed_v3_20260712.mp4`
