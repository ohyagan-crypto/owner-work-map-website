# HFSW Accent 1 Current Reference - 2026-07-12

Owner instruction from TG3: "把這個口音變成是口音-1".

Exact inspected video:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_131534.mp4`

Same-content prior copy:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_131018.mp4`

Verification:

- SHA256: `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`
- Duration: 300 seconds.
- Size: 15,137,784 bytes.
- Video: H.264, 720x1280, 30 fps.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.

Rule:

1. This video is now the official HFSW `口音-1` / `口音編號1` / `voice 1` reference.
2. When the owner says `口音-1`, `口音1`, `這個口音`, `改回這個口音`, or `voice 1` in the current HFSW/Zhang Fei context, use this video's accent/voice identity.
3. Do not treat `口音-1` as lowering volume by 1 dB. It is an accent preset number.
4. Only change volume when the owner explicitly says `音量`, `降低音量`, `降分貝`, `-1dB`, or another clear volume command.
5. Keep accepted HFSW defaults with this accent unless changed by the owner: Kai-style bottom captions, voice forward, BGM from 0 seconds and looped through the full video, no noisy SFX by default.
6. Accent changes should not alter speech speed, subtitle timing, image timing, or BGM unless specifically requested.
