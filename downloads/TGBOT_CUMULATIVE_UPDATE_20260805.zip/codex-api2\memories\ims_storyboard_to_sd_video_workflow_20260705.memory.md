# IMS Storyboard To SD Video Workflow

Date: 2026-07-05

Owner preference:

- In future video workflows, the owner may first use `ims` to create storyboard images.
- Updated owner correction on 2026-07-05: Claude/CLS script analysis must become step 1. Run Claude on the script/story first, then use that analysis to create IMS storyboard images, then use the finished storyboard images as SD/Dreamina video reference materials.
- Treat those finished storyboard images as story/reference materials for SD/Dreamina video generation, not as ordinary decorative images.
- When the owner provides IMS-made storyboard images for SD video, inspect every storyboard image individually before preparing the SD confirmation checklist.
- For each storyboard image, identify: story beat, visible characters, action, setting, mood, camera direction, text/marks if any, and what should be preserved or ignored in the video.
- Use the storyboard images as reference materials when preparing SD/Dreamina prompts, scene segmentation, motion design, character continuity, and material upload planning.
- Before any SD/Dreamina submission, still provide a confirmation checklist and wait for explicit owner confirmation.

Checklist requirements for this combined workflow:

- Source materials: list every storyboard image and its role.
- Story sequence: summarize the scene order and whether it should become one 10-15 second clip or multiple clips.
- Video plan: duration, aspect ratio, model, billing mode, motion/camera, audio/dialogue needs, and any character references.
- Prompt: include the exact prompt planned for submission; do not alter an owner-confirmed prompt without asking.
- Credits and cost: show current credits, estimated credit cost, RMB price, estimated TWD price, and estimated remaining credits.
- Safety: no credit-consuming generation until the owner replies with an explicit Chinese confirmation phrase meaning confirm, okay, can proceed, or submit.

Operational sequence:

1. Run the required Claude 4.8+ / CLS pre-analysis first on the script/story before making storyboard images. Analyze story beats, scene order, characters, emotions, camera direction, material needs, SD video needs, and prompt structure.
2. Use the Claude analysis to prepare the IMS storyboard image stage: return the IMS confirmation checklist, wait for confirmation, generate through Blue Star, download originals, verify, and return via same-origin Telegram document mode.
3. For the SD video stage, use the finished storyboard images as reference materials and inspect every storyboard image individually.
4. Return the SD confirmation checklist with storyboard mapping and pricing details.
5. Submit the SD/Dreamina job only after explicit owner confirmation, then monitor, download the original MP4, verify, and return via same-origin Telegram document mode.
