# 安全排除報告

建立日期：2026-07-11

## 已排除

- Telegram bot token
- API key
- 密碼
- cookie
- OAuth / auth 檔
- 瀏覽器 profile
- Chrome / Edge / Doubao 使用者資料
- `appsettings.Local.json`
- `.env`
- raw logs
- 任務輸出原始紀錄

## 包內保留

- 技能 `SKILL.md`
- 記憶 `.memory.md`
- 可移植參考腳本
- 安裝教學
- 工作流詳細文件
- 接收端可轉發訊息

## 接收端注意

接收端需要自行配置自己的 Telegram、藍星登入狀態、Chrome profile 與 API 權限。不要把任何秘密資料寫入技能、記憶、交接文件或聊天訊息。
