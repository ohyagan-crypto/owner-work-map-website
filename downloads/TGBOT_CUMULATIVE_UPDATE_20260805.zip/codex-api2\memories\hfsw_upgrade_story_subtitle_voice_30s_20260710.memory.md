# HFSW Upgrade: Story Subtitle, Voice, 30s Scene Cadence - 2026-07-10

Owner approval: the Zhang Fei HFSW version with expressive male storyteller voice, louder voice-forward mix, and story subtitle reference is approved as the default HFSW style.

Use for future `hfsw` unless the owner says otherwise:

1. Voice
   - Use the approved expressive Yunjian-style male storyteller voice.
   - Must have clear rise-and-fall, stronger pauses, emphasis, and dramatic storytelling cadence.
   - Narration must be theme-specific and easy to understand, not generic and not stiff reading.
   - Voice must sit clearly in front of BGM and SFX. Use the louder final Zhang Fei baseline as default; keep limiting to avoid clipping.

2. Subtitle
   - Use the approved story subtitle style from the reference image/video.
   - Font default: 標楷體 / DFKai-SB when available.
   - Large Traditional Chinese captions near the bottom, centered.
   - White fill, thick black outline, subtle black shadow.
   - Short phrase chunks matched to narration.
   - No tiny captions, no top title banner, no doubled burned-in captions.

3. Scene cadence
   - For HFSW long videos, change image/scene every 30 seconds by default.
   - A 300-second video should use about 10 visual scenes/images unless the owner specifies another length.
   - Each image must correspond to the exact narration segment for that 30-second block.
   - Do not keep one image for 40-45 seconds by default anymore.

4. HFSW workflow upgrade
   - Script first: use aggregation platform Claude 4.8 Opus to create the full theme-specific script, scene plan, captions, image prompts, BGM/SFX plan, and Hyperframes timing plan.
   - Image second: generate images from the 30-second scene plan, not generic atmosphere images.
   - Hyperframes third: build the final 9:16 composition, image motion, transitions, voiceover, BGM/SFX, and subtitles.
   - Validate final MP4 duration, dimensions, audio clarity, caption readability, scene cadence, and same-origin Telegram delivery.

5. Upgrade checks before delivery
   - Voice is clear on phone speakers.
   - BGM/SFX do not cover narration.
   - Subtitles are readable, in 標楷體 style, bottom-centered, white with thick black outline/shadow.
   - Scene changes are about every 30 seconds.
   - The video uses a coherent visual style and does not mix unrelated old materials.

