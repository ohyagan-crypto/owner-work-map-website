# HFSW Owner Voice Means Actual Owner Voice Accent - 2026-07-13

Owner correction from TG3:

`我是要用我的語音做口音`

Exact video inspected:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Verification:

- File exists.
- Size: 15,137,784 bytes.
- Duration: 300 seconds.
- Video: H.264, 720x1280, 30 fps.
- Audio: AAC, 48 kHz, stereo.
- Mean audio level: about -16.7 dB.
- SHA256: `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`
- Detected low-audio gaps around 84.25s, 174.28s, and 264.15s.

Rules:

1. `我的語音`, `我的口音`, `主人語音`, `主人口音`, `主人本人口音`, `口述口音`, `用我的語音做口音`, and `用我的口音做口述口音` all mean this exact video is the owner's personal narration accent reference.
2. This is not a request for a generic Chinese male TTS voice. It means preserve the owner's voice identity direction: cadence, rhythm, pauses, phrasing, pronunciation tendency, and speaking feel.
3. When the production route supports voice cloning or voice reference input, use this file as the source/reference.
4. If true voice cloning is unavailable, do not claim exact cloning. State or record that only the closest available storyteller fallback was used.
5. Do not use this video as clean BGM or final-quality narration audio. It contains low-audio gaps and production audio.
6. Any future HFSW final claiming to use the owner's voice/accent must include a manifest entry showing the actual voice route used, and must pass audio dropout, subtitle sync, clean BGM, and TG3 same-origin delivery gates.

