# 安裝說明

## Codex 安裝位置

一般放到：

- 技能：`C:\Users\RECEIVER\.codex\skills\codex-zuotu-lanxin\`
- 記憶：`C:\Users\RECEIVER\.codex\memories\lanxin_zuotu_rules_no_secrets.memory.md`

若是其他機器，放到該機器對應的 Codex skills/memories 目錄。

## PowerShell 複製範例

```powershell
$src = "解壓後資料夾"
Copy-Item -Recurse -Force "$src\.codex\skills\codex-zuotu-lanxin" "C:\Users\RECEIVER\.codex\skills\codex-zuotu-lanxin"
Copy-Item -Force "$src\.codex\memories\lanxin_zuotu_rules_no_secrets.memory.md" "C:\Users\RECEIVER\.codex\memories\lanxin_zuotu_rules_no_secrets.memory.md"
```

## 安裝後測試

問 Codex：

「以後做圖要怎麼做？如果聚合平台失敗可以用本機補做嗎？」

正確回答應包含：

- 只能使用 Lanxin/聚合平台。
- 不可用本機或其他工具補做。
- 先確認再提交。
- 快速輪詢，不傳操作廢話。
- 成功下載原圖並 Telegram 文件模式回傳。
