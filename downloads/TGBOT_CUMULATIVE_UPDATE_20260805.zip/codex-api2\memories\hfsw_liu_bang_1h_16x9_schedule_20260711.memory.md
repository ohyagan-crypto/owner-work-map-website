# HFSW Liu Bang 1H 16:9 Scheduled Override - 2026-07-11

Owner correction from TG3: the scheduled Liu Bang HFSW one-hour video at `2026-07-12 01:00` must be `16:9`, not the earlier vertical ratio.

Updated scheduled files:

- `C:\Users\你的使用者名稱\tg-openai-bot-3\scheduled_reports\hfsw-liu-bang-0100-spec.md`
- `C:\Users\你的使用者名稱\tg-openai-bot-3\scheduled_reports\run-hfsw-liu-bang-0100.ps1`

Rules for this scheduled task:

1. Topic: Liu Bang / 劉邦.
2. Duration: 1 hour / 3600 seconds.
3. Ratio: horizontal 16:9.
4. Target size: prefer 1920x1080; 1280x720 is acceptable if resources require it.
5. Image cadence: 1 image per minute, 60 images / 60 sections.
6. Reference video for voice/accent/subtitle/BGM source:
   `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_133100.mp4`
7. The reference video is vertical, but this task must not inherit the vertical ratio. Use it only for HFSW voice number 2, Kai-style bottom captions, and BGM source.
8. Generate horizontal 16:9 Liu Bang / early Han historical images. Do not generate vertical 9:16 images for this task.
9. Build Hyperframes as a 16:9 horizontal composition, not a final crop from 9:16.
10. Validate horizontal 16:9, duration about 3600 seconds, AAC audio, BGM from 0 seconds through the full video, readable bottom captions, about 60 visual sections, and TG3 same-origin document delivery.
