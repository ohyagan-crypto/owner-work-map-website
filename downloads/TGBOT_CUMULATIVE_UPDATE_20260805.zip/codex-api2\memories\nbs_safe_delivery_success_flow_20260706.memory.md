# NBS Safe Delivery Success Flow - 2026-07-06

Owner correction:

- After a complete NBS task, if Telegram displays garbled filenames, do not resend the same garbled files.
- For video summary delivery, send only a validated `.mp4`.
- For audio summary delivery, send only a validated `.mp3`.
- Use clean ASCII filenames for Telegram-facing NBS media files to prevent mojibake or unreadable display names.
- Do not send duplicate presentation files when the owner only asks to fix video/audio delivery.

Reusable success flow:

1. Keep the real NotebookLM output as the source of truth.
2. Validate each NotebookLM output before delivery.
3. Stage Telegram-facing copies with safe ASCII names under the task backup folder.
4. For video summary, ensure the final owner-facing file is `.mp4`; if the source name is garbled, copy or rename to a safe ASCII filename before sending.
5. For audio summary, convert or stage the verified audio as `.mp3`, then revalidate it before sending.
6. Send only the requested corrected deliverables to the same originating Telegram chat.
7. In the final reply, list the clean delivered filenames and backup folder, without raw logs or tool details.

Filename rule:

- Use descriptive ASCII names with date, for example `NBS_video_summary_YYYYMMDD.mp4` and `NBS_audio_summary_YYYYMMDD.mp3`.
- Never send NBS files to Telegram with mojibake, corrupted Chinese, raw NotebookLM random names, or names that may render unreadably.
- If a filename may be unsafe, rename or copy it first; do not ask the owner to tolerate garbled filenames.

