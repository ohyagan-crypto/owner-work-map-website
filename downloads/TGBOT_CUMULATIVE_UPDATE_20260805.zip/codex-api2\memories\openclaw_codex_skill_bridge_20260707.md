# OpenClaw / Codex Skill Bridge - 2026-07-07

Owner correction: when the owner says OpenClaw seems to forget skills, cannot understand screenshots, or cannot understand image materials, OpenClaw must not answer from memory only. It must inspect the local skill bridge and the actual attached materials.

## Skill Source

- Codex skill manuals mirrored for OpenClaw:
  `C:\Users\你的使用者名稱\.openclaw\workspace\codex_shared_memory\skills`
- Skill index:
  `C:\Users\你的使用者名稱\.openclaw\workspace\codex_shared_memory\skills\CODEX_SKILLS_INDEX.md`
- Codex memory mirror:
  `C:\Users\你的使用者名稱\.openclaw\workspace\codex_shared_memory\memories`
- Codex shared memory index:
  `C:\Users\你的使用者名稱\.openclaw\workspace\codex_shared_memory\CODEX_SHARED_MEMORY_INDEX.md`

## Required Behavior

1. If the owner mentions a skill alias or workflow, first search `CODEX_SKILLS_INDEX.md`, then read the matching `SKILL.md` before answering.
2. Do not claim the skill is unknown until the local skill bridge has been checked.
3. If the owner sends one or more screenshots or image materials, analyze every image individually before planning:
   - visible content and layout
   - visible text, buttons, marked areas, and UI state
   - what the image is likely meant to teach, reproduce, edit, or compare
   - missing or risky information
4. For multi-image tasks, do not only analyze the first or last image. Summarize the cross-image workflow after individual analysis.
5. Keep owner-facing replies in clean Traditional Chinese. Use light emoji only when it does not reduce clarity.
6. Never expose passwords, API keys, tokens, cookies, browser profiles, auth files, raw logs, or internal debug dumps.

## Common Skill Triggers

- `nbs`, `NotebookLM`, `簡報`, `語音摘要`, `影片摘要`: read the nbs skill.
- `sd`, `sdf`, `sdv`, `Dreamina`, `即夢`, `Seedance`, `生成影片`: read the Dreamina / SD video skills.
- `做圖`, `生圖`, `海報`, `Lanxin`, `藍星`, `聚合平台`: read the Lanxin image workflow / 做圖 skills.
- `acs`, `nms`, `剪映`, `數字人`: read the matching video automation skills.
- `截圖`, `圖片素材`, `教學圖`, `SOP 圖`: read screenshot, teaching-step-images, and video-frame-analysis as relevant.
- `TGBOT`, `Telegram`, `回傳`, `固定回覆`: read telegram-bot-manager and operator-principles.

## Completion Standard

After using a skill, answer with the concrete result, path/URL/file when relevant, verification performed, and the real blocker only if completion is impossible.

