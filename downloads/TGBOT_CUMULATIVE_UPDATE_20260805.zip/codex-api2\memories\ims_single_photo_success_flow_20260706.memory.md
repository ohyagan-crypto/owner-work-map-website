# IMS Single Photo Success Flow

Created: 2026-07-06 after the owner said "覆蓋學習" following a successful IMS city commute image task.

## Override Rule

For future IMS tasks where the owner sends one reference photo and asks to generate a refined image/poster:

1. Inspect the exact Telegram-downloaded local image before answering.
2. Back up the source image under `C:\Users\你的使用者名稱\Desktop\榫嶈潶瑷樻喍` or a dated task subfolder.
3. Give a concise but real production analysis before the checklist: visible content, intended message, visual direction, text strategy, and privacy/sensitive-data risk.
4. If no copy is requested, default to no text to avoid hallucinated words, wrong characters, Simplified Chinese, or text covering the subject.
5. Default to 9:16 vertical when the owner does not specify another ratio.
6. Use Blue Star/Lanxin only for image generation; do not use local drawing, screenshots, previews, galleries, or other image tools.
7. After the owner replies "確認", "好", "可以", or an equivalent confirmation, submit directly without repeating unnecessary warnings or asking for another confirmation.
8. Download the platform original, verify that it opens, has real dimensions, matches the prompt/checklist, has no visible watermark, no hallucinated text, and no exposed sensitive details.
9. Return the finished image to the same originating Telegram chat by document/file mode. Local path is only a backup unless Telegram origin chat id is missing.
10. Completion report should state the concrete result, real pixel dimensions, approximate file size when useful, Telegram delivery status, local backup path, and visual verification.

## Quality Baseline From The Successful Task

- Source: in-car view of sunny elevated-road traffic.
- Output: 9:16 realistic high-quality urban commute image.
- Verified result: `2160 x 3840`, about `6.9 MB`, original PNG returned by Telegram document mode.
- Content checks that worked: preserved in-car viewpoint, elevated road, traffic, blue sky; reduced noise; blurred/unreadable plates; no added text; no watermark.

This memory overrides weaker IMS single-photo behavior that stops at analysis, asks repeated confirmations after the owner already confirmed, or reports completion before original-file verification and same-origin Telegram delivery.
