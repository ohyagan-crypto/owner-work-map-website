# Codex / OpenClaw 共用記憶橋接規則

建立日期：2026-06-22

主人要求：Codex 要跟 OpenClaw 共用記憶。

## 共用入口

- Codex 記憶資料夾：`C:\Users\你的使用者名稱\.codex\memories\`
- Codex 技能資料夾：`C:\Users\你的使用者名稱\.codex\skills\`
- Codex 學習索引：`C:\Users\你的使用者名稱\tg-openai-bot\codex_learning_index.json`
- OpenClaw 即時主記憶：`C:\Users\你的使用者名稱\.openclaw\workspace\MEMORY.md`
- OpenClaw 每日記憶資料夾：`C:\Users\你的使用者名稱\.openclaw\workspace\memory\`
- Codex 端 OpenClaw 去敏副本：`C:\Users\你的使用者名稱\.codex\memories\openclaw_import\raw_memory_sanitized\`
- 同步腳本：`C:\Users\你的使用者名稱\tg-openai-bot\sync_openclaw_codex_memory.ps1`

## 執行規則

- 之後遇到主人提到 OpenClaw、舊記憶、之前學過、技能包、工作流、回覆規則、NBS、Dreamina、圖片生成、Telegram 行為或藍星科技邏輯時，先讀本檔與 `openclaw_imported.memory.md`。
- 若任務需要最新 OpenClaw 記憶，不只看匯入快照；要讀 `C:\Users\你的使用者名稱\.openclaw\workspace\MEMORY.md` 與 `C:\Users\你的使用者名稱\.openclaw\workspace\memory\` 內相關日期或索引檔。
- 若 OpenClaw 端需要 Codex 記憶，使用 `C:\Users\你的使用者名稱\tg-openai-bot\codex_learning_index.json`、`C:\Users\你的使用者名稱\.codex\memories\` 與 `C:\Users\你的使用者名稱\.codex\skills\` 作為入口。
- 新增永久偏好、規則或重要工作流時，優先寫入 Codex 記憶一份，並同步補到 OpenClaw `MEMORY.md` 或當日 `memory\YYYY-MM-DD.md`；若當下無法同步，要明確回報主人。
- 共用記憶只同步規則、偏好、工作流與索引，不同步密碼、API key、bot token、cookie、瀏覽器登入資料、OAuth 檔、raw log 或任何敏感驗證資料。
- Telegram 對主人直接回覆必須保持乾淨繁體中文：第一條只做「已收到 + 預估時間」，第二條必須給實質結果、檔案或明確卡點；不得只停在收到、思考中或預估時間。
- Telegram 不得外露 bridge/session/trace/tgbot、Web Fetch、Memory Search、工具狀態、tool card、raw log、JSON dump、token usage、英文內部狀態或錯誤堆疊；需要說明問題時，改寫成簡短乾淨繁中。
- 除非主人明確要求，不使用 `openclaw` CLI；Codex 仍優先使用本機 Codex 工具與已安裝技能。

## 安全邊界

- OpenClaw 原始工作區可能包含歷史任務檔、下載檔、登入狀態或工具資料；不要把整個工作區硬連結到 Codex。
- 目前採用「即時路徑入口 + 去敏同步副本」方式共用，避免破壞兩邊環境，也避免誤傳敏感資料。

