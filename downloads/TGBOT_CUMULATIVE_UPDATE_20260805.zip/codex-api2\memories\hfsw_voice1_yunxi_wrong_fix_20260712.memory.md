# HFSW Voice 1 Yunxi Wrong-Voice Fix - 2026-07-12

Owner correction from TG3: after the Liu Bang HFSW video was delivered, the owner said the accent had not changed.

Actual inspected issue:

- The current voice-1 reference video was correctly identified as:
  `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`
- The faulty Liu Bang render manifest claimed `voice 1`, but the narration was generated with:
  `zh-CN-YunxiNeural`, rate `+22%`, pitch `+6Hz`
- This is not acceptable as applying the owner's requested voice-1 accent.

Correction:

1. Do not label `zh-CN-YunxiNeural` as HFSW voice-1 for Liu Bang or future HFSW work.
2. When true voice cloning from the reference video is not locally available, do not pretend cloning happened.
3. For the current local fallback, use the stronger storyteller route:
   `zh-CN-YunjianNeural`, rate `+3%`, pitch `-3Hz`
   and record that this is the local closest storyteller fallback, not a real cloned voice.
4. Use the 20260712_134206 video as the newest voice-1 reference path in manifests.
5. Validate the actual TTS voice in the manifest before reporting that the accent was changed.
6. Keep Kai-style bottom subtitles, 16:9 Liu Bang visuals, BGM from 0 seconds, and same-origin TG3 document delivery.

Corrected delivered file:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260712_hfsw_liu_bang_voice1_yunjian_fixed\liu_bang_hfsw_1h_16x9_voice1_yunjian_accent_fixed_loud_tg_20260712.mp4`

Delivery:

- Sent through TG3 same-origin document mode.
- Duration: 3600 seconds.
- Size: under Telegram upload limit.
- Video: 1280x720, 16:9.
- Audio: AAC stereo, boosted from the previous too-low mix.
