# Kuli Confirmed Character Asset - 2026-07-07

## Latest Owner Confirmation

On 2026-07-07, the owner uploaded a Telegram photo and explicitly identified it as the Kuli character appearance.

This is the latest confirmed Kuli visual identity reference. Use this memory as the active Kuli identity source for future CMSD, IMS storyboard, SD, SDF, SDV, Dreamina, Seedance, and image/video generation tasks unless the owner provides a newer replacement.

## Active Reference Image

- Source upload: `C:\Users\你的使用者名稱\tg-openai-bot\telegram_uploads\telegram_photo_20260707_144215.jpg`
- Backup file name: `kuli_reference_20260707_144215.jpg`
- Backup folder: `C:\Users\你的使用者名稱\Desktop\<lobster-memory-folder>\character_refs_20260707`
- Image size: `896 x 1196`

## Stable Visual Traits

- Character name: Kuli.
- Male Taiwanese/Chinese appearance, clean youthful face, soft friendly smile.
- Front-facing half-body portrait on a light studio background.
- Short black hair with shaved sides and longer top swept to one side.
- No glasses and no sunglasses.
- Current reference outfit: black hoodie with orange drawstrings and orange sleeve details.
- Visible accessories: dark wristband or smart band on one wrist, silver watch on the other.
- Visible prop: peeled banana held with both hands.

## Prompt Usage Notes

- Use the face and identity from this image as the primary Kuli reference.
- Treat the hoodie, orange details, watch, wristband, and banana as changeable styling or props unless the owner asks to preserve this exact look.
- If a future task asks for a different Kuli look, keep the same face identity and adapt costume, scene, pose, and props to the script.
- Negative constraints when identity matters: no glasses, no sunglasses, no major face change, no extra characters unless requested, no cartoon/Q-version unless requested.

## 2026-07-07 Post-Video Likeness Optimization

After the Tainan AI skincare SD video succeeded, the owner said Kuli's generated appearance was not close enough.

For future Kuli CMSD / IMS / SD / SDF / SDV / Dreamina / Seedance / image-video tasks:

- Treat Kuli likeness as a required confirmation item before credit-consuming generation.
- Do not rely only on a storyboard panel or small face crop for Kuli identity.
- Prefer a separate high-quality Kuli face/reference image as an uploaded reference material.
- If the only available material is a storyboard image and no separate Kuli reference is present, report the likeness risk and ask for the corrected Kuli reference before submitting.
- Add a confirmation checklist line: `庫裡形象一致性：已使用獨立人物參考 / 尚缺正確人物參考`.
- Prompt Kuli with stable identity traits: Taiwanese/Chinese male, clean youthful face, short black hair with shaved sides, longer top swept to one side, friendly soft smile, no glasses, no sunglasses.
- Negative prompt: no random generic male, no aged face, no glasses, no sunglasses, no distorted face, no cartoon/Q-version unless requested, no extra unrelated male presenter.

## Conflict Resolution

Older 2026-07-06 memories warned not to use the black hoodie / orange drawstrings / peeled banana image unless the owner explicitly re-confirmed it. The owner has now explicitly re-confirmed it on 2026-07-07, so this 2026-07-07 memory overrides that older warning for Kuli identity usage.
