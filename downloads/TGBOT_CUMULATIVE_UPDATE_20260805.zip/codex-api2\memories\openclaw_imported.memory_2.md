# OpenClaw Imported Memory

- OpenClaw memory has been imported for Codex/TG bot use.
- Shared-memory bridge file: `C:\Users\RECEIVER\.codex\memories\openclaw_codex_shared_memory_bridge_20260622.memory.md`.
- Live OpenClaw main memory: `C:\Users\RECEIVER\.openclaw\workspace\MEMORY.md`.
- Live OpenClaw daily memory folder: `C:\Users\RECEIVER\.openclaw\workspace\memory\`.
- Sanitized source files are under `C:\Users\RECEIVER\.codex\memories\openclaw_import\raw_memory_sanitized`.
- Index file: `C:\Users\RECEIVER\.codex\memories\openclaw_import\OPENCLAW_MEMORY_INDEX.md`.
- When the operator asks about older OpenClaw preferences, workflows, products, NotebookLM/NBS, Dreamina, Telegram behavior, image generation, or Blue Star reply logic, inspect the bridge file and the live OpenClaw memory first; use the imported sanitized files as a fallback snapshot.
- Do not expose raw logs, API keys, bot tokens, auth files, browser cookies, or internal progress text to Telegram.
- The operator prefers Traditional Chinese. In this Telegram context, address the operator as `主人` when natural; externally use `藍星科技` for company identity.
- The operator wants Codex/TG bot to use Lanxin `gpt-5.5` by default, not OpenClaw.

## Imported File Index

# OpenClaw Memory Import Index

Imported from `C:\Users\RECEIVER\.openclaw\workspace\memory` and `C:\Users\RECEIVER\.openclaw\workspace\MEMORY.md`.
Secrets matching API key, token, password, and Telegram bot token patterns were redacted during copy.

## Files
- $rel (18349 bytes)
- $rel (5228 bytes)
- $rel (10553 bytes)
- $rel (15478 bytes)
- $rel (2778 bytes)
- $rel (1007 bytes)
- $rel (5787 bytes)
- $rel (8719 bytes)
- $rel (3354 bytes)
- $rel (2220 bytes)
- $rel (6113 bytes)
- $rel (1230 bytes)
- $rel (1289 bytes)
- $rel (6072 bytes)
- $rel (3613 bytes)
- $rel (6842 bytes)
- $rel (951 bytes)
- $rel (4780 bytes)
- $rel (3336 bytes)
- $rel (3619 bytes)
- $rel (1604 bytes)
- $rel (892 bytes)
- $rel (560 bytes)
- $rel (666 bytes)
- $rel (29829 bytes)
- $rel (519 bytes)

