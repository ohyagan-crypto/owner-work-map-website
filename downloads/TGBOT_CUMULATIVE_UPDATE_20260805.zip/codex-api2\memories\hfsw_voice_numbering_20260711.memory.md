# HFSW Voice Numbering Correction - 2026-07-11

## 2026-07-12 Latest Override

Owner instruction: `把這個口音變成是口音-1`.

`口音-1` / `口音編號1` / `voice 1` now means:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_131534.mp4`

This file was inspected:

- Duration: 300 seconds.
- Video: H.264, 720x1280, 30 fps.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.
- SHA256: `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`

`口音-1` is an accent preset number, not a volume instruction. Only lower volume when the owner explicitly says volume/dB.

Owner correction from TG3:

- `不是降分貝，是這個口音編號，口音編號2，上一個是口音編號1`.
- The earlier interpretation of `人聲-2` as lowering narration by 2 dB was wrong.
- The previous approved accent is now `口音編號1`.
- The current replied video is `口音編號2`.

Reference for `口音編號2`:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_133100.mp4`

Inspected baseline:

- Duration: 300 seconds
- Video: 720x1280 vertical, 30 fps
- Audio: AAC stereo, 48000 Hz
- Visuals: Zhang Fei historical story video with bottom Kai-style Traditional Chinese captions
- Use this file as the voice/accent reference, not as a volume-change instruction.

Rules:

1. `口音編號1` means the previous approved HFSW accent before this correction.
2. `口音編號2` means the voice/accent style in `telegram_replied_video_20260711_133100.mp4`.
3. Do not interpret `人聲-2`, `口音2`, `聲音2`, `voice 2`, or similar wording as lowering volume or dB unless the owner explicitly says `降分貝`, `降低音量`, `音量-2`, or `-2dB`.
4. When applying `口音編號2`, preserve the selected accent/voice identity, speech rhythm, subtitle timing, BGM loop from 0 seconds, and visual timing unless the owner separately asks to change them.
5. The previous `voice_minus2` output was a misunderstanding and is not the HFSW baseline.
6. Future HFSW voice presets should be stored as numbered accent presets, not as volume operations.
