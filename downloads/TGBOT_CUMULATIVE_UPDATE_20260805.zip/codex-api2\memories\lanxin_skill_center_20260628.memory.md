# Lanxin AI Skill Center - 2026-06-28

User asked Codex to learn the Lanxin AI / aggregation platform skill center and explain how to use it.

Verified platform page:

- Platform: Lanxin AI / 聚合平台
- URL: https://lx.lanxinai.com/ai-skills
- Checked date: 2026-06-28
- Login: authorized local encrypted credential was used; no credential is stored here.
- Visible account state after login: skills center accessible.

Current skill center status:

- Available skills: 224
- Real tools: 23
- Need configuration: 0
- Skill templates visible: 6
- Tool types:
  - Prompt skills: 199
  - Document skills: 13
  - Image skills: 7
  - Video skills: 3
  - Chat skills: 2

Category counts:

- Writing: 10
- Reading: 8
- Business: 20
- Analysis: 18
- Career/workplace: 11
- Documents: 10
- Creation: 17
- Efficiency: 16
- Research: 6
- Planning: 19
- Marketing: 18
- Sales: 17
- Customer service: 13
- Code: 14
- Learning: 12
- Operations: 14
- Automation: 1

Template packs:

- Sales growth pack: customer persona, ICP, discovery questions, objection handling, opportunity risk, next follow-up.
- Customer success pack: customer replies, ticket escalation, NPS feedback, renewal retention, churn interviews, negative review recovery.
- Marketing content pack: ad ideas, SEO briefs, social content calendar, community scripts, landing page teardown, brand voice.
- Product operations pack: requirement clarification, user stories, launch checks, campaign retrospectives, project risks, SOP.
- Data analysis pack: KPI attribution, metric dictionary, experiment retrospective, survey insights, data quality, dashboard storytelling.
- Document delivery pack: source reading, summaries, PPT, Word, PDF, Markdown.

Important high-value skills:

- Image/poster: AI image generation, poster design, product photography image prompt, character image prompt, comic storyboard image prompt, interior design image prompt.
- Video: Dreamina video, Dreamina shot prompt, Dreamina reference-image video.
- Documents: PPT, Word, PDF, Markdown, PPT rewrite, document-to-PPT, data package PDF brief, Excel template.
- Marketing: social copy pack, Xiaohongshu note, SEO article, brand voice, landing page copy, ad variants, marketing calendar, live commerce script, community operations.
- Sales: e-commerce detail page, sales email, objection handling, proposal generation, sales call script, payment collection script, CRM follow-up, enterprise account plan, renewal retention, RFP response, ICP, price objection.
- Customer service: customer reply, FAQ knowledge base, complaint handling, customer health scoring, ticket triage, review reply, refund policy, onboarding email, NPS mining, churn interview, support escalation.
- Analysis: data analysis, data insight report, spreadsheet formulas, budget explanation, table-to-report, cashflow forecast, KPI dashboard, A/B testing, funnel analysis, SQL result interpretation.
- Code: SQL assistant, code explanation/debugging, regex, log analysis, API docs, test cases, bug report, SQL performance, code review checklist, threat modeling, API troubleshooting, frontend UX review.
- Efficiency/operations: meeting minutes, weekly/monthly report, prompt engineering, inbox sorting, project status, decision memo, knowledge base organizer, SOP, launch checklist, runbook, incident communication.
- Planning/learning/research: project plan, travel plan, OKR, risk register, decision matrix, course plan, study plan, quiz generation, research question breakdown.

How owner can invoke:

- "去藍星技能中心用海報設計做一張課程海報"
- "用 AI圖片生成，參考這張圖做商品圖"
- "用即夢視頻做 10 秒影片"
- "用 PPT大綱 / Word文檔 / PDF報告 生成文件"
- "用長文總結讀這份文件"
- "用社媒文案包寫小紅書、抖音、朋友圈文案"
- "用銷售異議處理整理客戶反對意見"
- "用客服回覆處理這段客訴"
- "用數據分析看這張表"
- "用 SQL助手改這段 SQL"

Operational rule:

- For any paid/generation task, before submission show a confirmation checklist including platform, skill name, task type, source material, prompt, output format, credits/cost if visible, and wait for explicit confirmation.
- For image jobs, use Lanxin image workflow rules: confirm first, submit unchanged prompt after confirmation, monitor until complete, download original output, verify file, deliver as file/document.

Local extraction artifacts from this run:

- C:/Users/max/lanxin_research/skill_center_20260628_current/skills_parsed.json
- C:/Users/max/lanxin_research/skill_center_20260628_current/skills_summary.md
- C:/Users/max/lanxin_research/skill_center_20260628_current/skill_center_loaded.png
