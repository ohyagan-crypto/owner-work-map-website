# 剪映技能補充說明

主交接包為了 Telegram 可穩定傳送，暫時不含大型 `jianying-editor-skill` 完整資料夾。

若接收端需要剪映/ACS 深度自動化，請再安裝第二份「剪映技能補充包」。
如果只需要一般 Telegram 回覆規則、NBS、圖片、ANS/NMS、ACS2 流程記憶與大多數技能，先安裝主包即可。
