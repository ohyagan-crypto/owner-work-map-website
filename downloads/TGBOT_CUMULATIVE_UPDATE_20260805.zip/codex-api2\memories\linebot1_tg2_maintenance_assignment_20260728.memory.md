# LINEBOT1 由 TG2 協助修正 - 2026-07-28

- 主人指定：以後 LINEBOT1 的檢查、除錯與修正由 TG2 協助處理。
- `LINEBOT1` 固定指 BSMFTEK 的隔離服務：
  - 儲存根目錄：`E:\linebot\LBOT-1`
  - Relay：`C:\Users\max\line-bsmftek-relay.js`
  - CLI：`C:\Users\max\line-bsmftek-official-cli.ps1`
  - 監控：`C:\Users\max\line-bsmftek-hourly-monitor.ps1`
  - 本機服務：`http://127.0.0.1:3002`
  - 狀態檔：`E:\linebot\LBOT-1\latest-status.json`
  - 排程：`BSMFTEK LINE Official Hourly Monitor`
- 後續收到 LINEBOT1 修復要求時，先核對最新訊息與實際狀態，再依序檢查程序、健康端點、狀態檔、公開 Webhook／測試、排程最近結果及相關功能測試。
- 修正以最小必要範圍為準；不得混用或改動 MoreFun、藍星 AI 或其他 LINE Bot 的 Relay、Token、Secret、Webhook、連接埠、排程、狀態檔與使用者資料。
- 除非主人當次明確要求，不變更 LINEBOT1 既有模型、供應商、服務等級或推理設定。
- 完成標準：修改已套用、語法／測試通過、LINEBOT1 程序正常、健康端點正常，並依任務需要驗證 Webhook 或實際功能；只回報乾淨繁體中文結果，不輸出機密或原始偵錯資料。
- 2026-07-28 建立本記憶時只做責任綁定與現況核對，沒有修改 LINEBOT1 執行程式。當下 `3002/health` 回應正常。
