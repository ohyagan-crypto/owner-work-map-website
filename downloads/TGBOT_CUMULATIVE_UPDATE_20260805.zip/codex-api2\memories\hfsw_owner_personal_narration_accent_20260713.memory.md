# HFSW Owner Personal Narration Accent - 2026-07-13

Owner instruction from TG3:

`要以我的口音做口述口音`

Exact video inspected before saving:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Verification:

- File exists.
- Size: 15,137,784 bytes.
- Duration: 300 seconds.
- Video: H.264, 720x1280, 30 fps.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.
- SHA256: `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`
- Detected low-audio gaps around 84.25s, 174.28s, and 264.15s at the HFSW QA threshold.

Rules:

1. `我的口音`, `主人口音`, `主人本人口音`, `口述口音`, `用我的口音做口述`, and similar HFSW wording mean this exact inspected video should be used as the owner's personal narration accent reference.
2. This owner personal narration accent is the same inspected source currently used for `口音-1` / `中國口音`, unless the owner later uploads a newer personal voice sample and explicitly replaces it.
3. Use this file as a voice/accent reference or voice-cloning reference when the production tool supports it.
4. If true voice cloning is not available in the current local/tool route, do not claim exact cloning. State or record that the closest available storyteller fallback is being used while preserving the owner's requested accent direction.
5. Do not use the mixed audio from this reference video as clean BGM or final-quality narration audio. It contains low-audio gaps and background/production audio; it is a reference, not a clean BGM bed.
6. Future HFSW outputs using the owner's personal narration accent must still keep the normal HFSW gates: Claude-first script, platform images when required, Hyperframes composition, Kai-style bottom subtitles, clean BGM from 0 seconds, audio dropout check, subtitle sync check, and same-origin TG3 document delivery.

