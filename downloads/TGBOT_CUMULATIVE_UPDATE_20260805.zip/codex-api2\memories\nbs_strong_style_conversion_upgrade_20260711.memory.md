# NBS Strong Style And Conversion Upgrade - 2026-07-11

Owner instruction: upgrade NBS into a stronger style workflow.

Apply to every future `nbs` / NotebookLM task:

1. Add a `風格強度分級` to the confirmation checklist: `低`, `中`, `高`, or `極強`.
2. Choose a concrete visual direction when useful: hard industrial, black-tech launch, command center, laboratory teardown, pitch deck, product demo, sales roadshow, or short-video viral style.
3. Add conversion logic for sales, course, product, onboarding, or recruitment materials:
   - what the audience sees
   - what the presenter says
   - what the assistant/co-host does
   - how the page pushes trust, signup, inquiry, purchase, cooperation, or the next action
4. Add camera/script direction for visual tasks:
   - wide shot, medium shot, close-up, product close-up, hand operation, UI over-the-shoulder
   - product operation, sound capture, transition point, reveal, compare, recap
5. For pitch/recruitment/sales tasks, include opportunity, reason to cooperate, partner profile, action command, and follow-up handoff when supported by sources.
6. MP4 and MP3 must inherit the same style intensity as PPTX. Do not let video/audio become flat summaries when the task asks for stronger style.
7. Validation must include style strength:
   - does the output match the approved intensity
   - does each page/section have a purpose
   - is there a material-derived visual system
   - is there a next action where useful
   - are unsupported claims avoided

Hard limit:

- Strong style cannot invent specifications, price, lifespan, certification, medical/clinical claims, sales data, official endorsements, quotas, deadlines, or guaranteed results.
- If the source is thin, make the style strong but keep factual claims conservative.

Skill updated:

- `C:\Users\你的使用者名稱\.codex\skills\nbs\SKILL.md`
- Section: `2026-07-11 Strong Style NBS Upgrade`
