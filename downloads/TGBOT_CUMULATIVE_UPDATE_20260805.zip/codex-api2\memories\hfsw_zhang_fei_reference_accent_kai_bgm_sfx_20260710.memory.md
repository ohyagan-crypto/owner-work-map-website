# HFSW Zhang Fei Reference Accent Kai BGM/SFX Success Mode - 2026-07-10

Owner approved the Zhang Fei HFSW reference-video style and asked to remember it.

Source video inspected before remix:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260710_221819.mp4`

Full-length remixed deliverable:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_bgm_sfx_20260710_2218.mp4`

Use this success mode for future `hfsw` work unless the owner changes it:

1. Voice/accent: use the Zhang Fei reference-video short-form storytelling accent, faster and more emphatic than slow narration, with harder articulation and clear rise-and-fall.
2. Subtitles: keep large bottom Traditional Chinese captions, Kai-style font, white fill, thick black outline/shadow, short phrase chunks, readable on mobile.
3. BGM: add low cinematic historical/epic background music by default.
4. SFX: add battle/transition/emphasis sound effects at scene changes, emotional turns, key reveals, and battle beats.
5. Mix rule: narration must stay clearly in front; BGM and SFX are support layers only. Use limiting/compression to avoid clipping.
6. 2026-07-10 correction: BGM/SFX must be actually audible on phone playback, not merely present in the project. If the owner says the BGM/effects cannot be heard, remix from separated narration/BGM/SFX stems, raise BGM and transition/effect layers enough to be recognizable, and verify the final MP4 audio level before delivery.
7. Current audible remix baseline:
   `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_bgm_sfx_stronger_20260710_2320.mp4`
   Validation: 300 seconds, 720x1280, AAC stereo audio, final mean volume about -13.6 dB and max about -0.9 dB.
8. Verification: inspect the actual reference/source video first, verify MP4 duration, 9:16 dimensions, audio presence, subtitle readability, audible BGM/SFX, and Telegram same-origin document delivery.

## 2026-07-10 correction: avoid low-frequency-only BGM/SFX

Owner reported the `stronger_20260710_2320` version still sounded like low-frequency noise and did not have recognizable BGM/SFX.

New corrected deliverable:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_bgm_sfx_clear_mid_20260710_2350.mp4`

Rules added for future HFSW:

- Do not make the BGM/SFX layer only sub-bass or low cinematic rumble.
- BGM must include phone-audible mid-frequency musical content, such as strings, arpeggio, brass-like tones, or melody movement.
- SFX must include recognizable mid/high-frequency cues, such as drum click, metal strike, whoosh, cymbal/noise tail, or transition hit.
- Keep narration in front, but verify the BGM/SFX stem is audible enough before mixing; the corrected stem baseline after gain was about -19.8 dB mean and 0 dB max before limiter.
- Final delivery must be checked for duration, dimensions, AAC audio, subtitle frame readability, and same-origin TG3 document upload.

## 2026-07-10 correction: replace noisy BGM

Owner reported the `clear_mid_20260710_2350` version was still noisy. The successful direction is not "more BGM" or "more SFX"; it is a cleaner background bed.

New corrected deliverable:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_clean_bgm_v2_20260710.mp4`

Rules added for future HFSW:

- If the owner says BGM is noisy, stop strengthening the same BGM/SFX layer; replace it with a different, cleaner BGM.
- Prefer clean mid-frequency musical bed, soft historical/cinematic mood, and reduced low-end rumble.
- Avoid dense impacts, harsh metallic clusters, noisy whoosh layers, or stacked low-frequency drones unless the owner explicitly asks.
- It is acceptable to reduce SFX heavily or omit aggressive SFX when it makes the full video cleaner.
- Keep the approved short-video storytelling accent and Kai-style bottom subtitles unchanged while changing only the music layer.
- Use a clean voice stem plus a separate filtered BGM bed when possible, then remux onto the approved captioned video.
- Delivery validation remains: 300 seconds, 9:16, AAC stereo audio, subtitle frame readable, and TG3 same-origin document upload.

## 2026-07-10 correction:彻底改 BGM/SFX must be clearly audible

Owner reported the clean BGM v2 version still sounded like there was no BGM/SFX. The correction is to stop reusing the old background bed and rebuild the entire BGM/SFX layer from a clean voice stem.

New corrected deliverable:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_bgm_sfx_thorough_v4_clean_loud_20260710.mp4`

Rules added for future HFSW:

- Use the approved voice/subtitle video as the visual base, but replace the entire audio bed when the owner says BGM/SFX are not audible.
- Build or choose an independent BGM/SFX stem first, then verify that stem has audible mid-frequency content before mixing.
- BGM should include recognizable melodic or rhythmic content, not only atmosphere.
- SFX should include clear scene-change cues, drum hits, metal/weapon accents, or transition marks, but avoid noisy stacked whooshes.
- Mix target for this correction: final audio mean volume around `-13 dB`, 300 seconds, AAC stereo, while keeping narration intelligible.
- Do not report completion just because a BGM/SFX layer exists in the file; the layer must be strong enough to be heard on phone playback.
