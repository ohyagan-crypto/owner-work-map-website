# 庫裡正式角色形象確認 - 2026-07-16

- 主人於 2026-07-16 明確指定本次 Telegram 上傳照片為正式「庫裡」形象。
- 正式固定路徑：`C:\Users\你的使用者名稱\kuli.jpg`
- 原始任務圖片：`C:\Users\你的使用者名稱\tg-openai-bot\telegram_uploads\mmexport1778855036138_1.jpg`
- TG123 安全備份：`E:\COOCMEMORY\20260716_kuli_character_asset\kuli_confirmed_20260716.jpg`
- 圖片特徵：短黑髮、黑色帽 T、橘色抽繩、手持剝皮香蕉、白色棚拍背景。
- 適用工作流：`cmsd`、`cmde`、IMS 分鏡、SD、SDF、SDV、Dreamina、Seedance，以及所有嵐熙＋庫裡圖片或影片任務。
- 此規則覆蓋先前把香蕉圖視為錯版或禁用素材的舊規則；不得再因這張圖的服裝或香蕉道具阻擋任務。
- 若主人日後提供新的庫裡角色圖並明確指定替換，才更新固定參考圖。
