# Lanxin 平台多素材參考上傳偏好

Created: 2026-06-29

User preference:

- When using the Lanxin / 聚合平台 video workflow, upload all user-provided materials as reference assets when available.
- Future inputs such as character images, character audio files, and story material images should not be treated as text-only context.
- Prefer combining prompt + reference images + audio + scene/story materials in the same platform submission when the platform supports it.
- If a referenced material is missing, ask the user for the missing asset instead of silently omitting it.
