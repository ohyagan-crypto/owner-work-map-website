# Codex / OpenClaw 技能交接安裝說明

## 結論

這份 ZIP 是 codex_all_skills_plus_ims_v7_20260708_130240。接收端解壓後，請先讀本檔，再複製 .codex\skills 與 .codex\memories，最後重新啟動 Codex、OpenClaw 或 Telegram bot。

## 安裝路徑

```text
.codex\skills\   -> C:\Users\你的使用者名稱\.codex\skills\
.codex\memories\ -> C:\Users\你的使用者名稱\.codex\memories\
```

## IMS v7

本包已額外加入 .codex\skills\ims_v7_20260708\。接收端要並存測試就安裝此資料夾；要取代 ims 則先備份原本 ims 再覆蓋。

## 回覆規則

正式回覆只用乾淨繁體中文。可以自然使用柔和、女性化、可愛但不干擾閱讀的 emoji。不要只回「收到、處理中、稍後回報」，必須給結果、檔案、網址、路徑、驗證或明確卡點。

## 安全規則

不要保存或輸出密碼、token、API key、cookie、瀏覽器 profile、credential store、auth file、raw log、JSON dump 或任何可見秘密。Telegram 來源任務如果產生檔案，必須回傳同一個來源聊天與同一 topic/thread。
