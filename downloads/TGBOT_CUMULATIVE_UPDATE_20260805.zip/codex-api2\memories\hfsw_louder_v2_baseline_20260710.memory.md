# HFSW Louder V2 Baseline - 2026-07-10

Owner requested the Zhang Fei HFSW video volume to be made louder again after the prior louder version.

Latest accepted delivery:
`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw\hf_20260710\export\zhang_fei_hfsw_20260710_revoice_expressive_yunjian_louder_v2_tg.mp4`

Use this as the default HFSW voice and loudness reference unless the owner says it is too loud.

Rules:
1. Keep the expressive Yunjian-style male storyteller voice.
2. Preserve clear rises and falls, stronger pauses, emphasis, and dramatic storytelling cadence.
3. Narration must sit clearly in front of BGM and sound effects.
4. BGM and SFX must be lower than narration and must not cover speech.
5. The louder v2 delivery was boosted about +7 dB from the previous louder delivery, with limiting to prevent clipping.
6. Target phone-speaker clarity first.
7. Bottom captions remain required and must match the spoken content.
