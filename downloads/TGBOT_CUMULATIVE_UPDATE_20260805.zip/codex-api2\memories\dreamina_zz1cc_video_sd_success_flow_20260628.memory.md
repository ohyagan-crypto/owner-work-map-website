# Dreamina ZZ1CC Video SD Success Flow

Created: 2026-06-28

Purpose: Preserve the working `video sd` / Dreamina-style video generation flow that succeeded through the New API interface at `https://zz1cc.cc.cd`.

## Trigger

Use this memory when the owner asks for:

- `video sd`
- SD/SDF/SDV/Dreamina-style video generation
- 即夢影片 generation through the zz1cc/New API interface
- Repeating the successful mother-reference 10-second video flow

## Confirm Before Submitting

Before any credit-consuming video submission, show a confirmation checklist and wait for explicit owner confirmation.

The checklist must include:

- Platform/interface: `zz1cc.cc.cd` New API when this route is used.
- Model.
- Duration.
- Requested size/aspect ratio.
- Prompt path or exact prompt.
- Reference image/audio/materials.
- Current credits.
- Estimated credit cost.
- RMB price.
- Estimated TWD price.
- Estimated remaining credits.
- Expected submit endpoint and delivery method.

## Known Working API Flow

- Submit: `POST https://zz1cc.cc.cd/v1/videos`
- Query: `GET https://zz1cc.cc.cd/v1/videos/<task_id>`
- Download: `GET https://zz1cc.cc.cd/v1/videos/<task_id>/content`
- Auth header: `Authorization=[REDACTED_SECRET] <API key>`
- Body: multipart form.
- Working fields: `model`, `seconds`, `size`, `prompt=<prompt file`, `input_reference=@<reference image>`.

Do not save, print, or expose raw API keys.

## Known Models And Pricing

- `video-ds-2.0-fast`: 65 credits per generation, RMB 3.9 per generation, estimate TWD in confirmation checklist.
- `video-ds-2.0`: 83 credits per generation, RMB 4.9 per generation, estimate TWD in confirmation checklist.

Use live or most recently checked CNY/TWD exchange rate for TWD. If rate lookup fails, show a clearly marked approximate TWD value and continue.

## Successful Reference Run

- Date: 2026-06-28
- Task id: `task_CGlk8PESKII05SaHNATQEPrIdGj2QyPb`
- Model: `video-ds-2.0-fast`
- Requested duration: 10 seconds
- Requested size: `720x1280`
- Prompt file: `C:\Users\你的使用者名稱\dreamina_10s_prompt.txt`
- Reference image: `C:\Users\你的使用者名稱\dreamina_work\mother_hug.jpg`
- Job file: `C:\Users\你的使用者名稱\zz1cc_video_job.json`
- Submit script: `C:\Users\你的使用者名稱\zz1cc_submit_10s_video.ps1`
- Query/download script: `C:\Users\你的使用者名稱\zz1cc_query_video.ps1`
- Observed output: about 10.1 seconds, with audio, actual `1280x720` landscape output.
- Delivery: returned to the original Telegram chat as a document, with local backup retained.

## Failure Lessons

- Dreamina CLI attempts with interface model names `seedance2.0` and `seedance2.0fast` silently failed and returned no task id.
- If a submission produces no task id and credits do not change, treat it as not submitted.
- For this interface, prefer direct New API endpoint submission over Dreamina CLI when the owner references `zz1cc.cc.cd`.

## Output Rule

For completed jobs, report briefly in Traditional Chinese:

- Task id.
- Model.
- Actual cost in credits, RMB, and estimated TWD.
- Actual duration and dimensions if verified.
- Telegram delivery status.
- Local backup path if relevant.
