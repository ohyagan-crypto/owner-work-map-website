# HFSW Default Success Baseline - Accent 1 and 1.3x Speed - 2026-07-15

The owner approved the latest Codex HFSW accelerated version and requested this success method as the new default.

## Official Defaults

1. Default accent: `Accent 1 / Chinese accent`.
2. Accent reference: `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`.
3. Default speed: overall `1.3x`.
4. Speed changes must stay synchronized across visuals, narration, BGM, and subtitle timing.
5. Default captions: large bottom Traditional Chinese Kai-style captions, white fill, thick black outline, short phrase chunks.
6. Default mix: voice forward, clean BGM from 0 seconds through the full runtime, and no noisy SFX.

## Duration Rule

- For an exact final duration, prepare about `target duration x 1.3` source content before the speed pass so the final output remains near the requested duration.
- When accelerating an existing finished video, the runtime may shorten normally.

## Verified References

- Accent reference: 300 seconds, 720x1280, H.264, AAC 48 kHz stereo.
- Its mixed audio has low-audio gaps around 84s, 174s, and 264s. Use it only for accent and cadence, never as clean BGM or final narration.
- Approved output: `E:\COOCMEMORY\20260715_hfsw_codex_speed_1_3x\codex_hfsw_9x16_accent1_bgm_speed_1.3x_compact_20260715.mp4`.
- Approved output: about 230.92 seconds, 1080x1920, H.264, AAC 48 kHz stereo.

## Priority

- Unless the owner explicitly requests another accent or speed, future HFSW tasks default to `Accent 1 + 1.3x`.
- BGM, subtitle, or visual repairs must not silently change the approved accent or speed.
- If the owner explicitly asks for the owner's personal voice, use the saved 105-second Telegram owner voice reference instead.
- Delivery still requires subtitle sync, dropout detection, BGM continuity, platform-image validation when expected, and TG3 same-origin document delivery.
