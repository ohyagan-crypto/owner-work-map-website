# IMS Material-First Continuation Rule

Owner correction set on 2026-06-30.

For future IMS image/poster continuation tasks such as "換個風格再一張", "重新做一次 ims", "改這張素材圖", "單參考圖", or any style-change/revision/remix where Telegram includes a recently uploaded image:

1. Inspect the exact current uploaded image path before answering or generating.
2. Save the current material/reference image under `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\` or a dated task subfolder there.
3. Re-analyze the current material image directly: visible content, useful subject/UI details, text, composition, color/style, and what should or should not be preserved.
4. Do not rely only on prior chat summaries, remembered prompts, or the previous generated output when a current material image exists.
5. If the owner asks for a single reference image, upload/use only the current intended reference image unless they explicitly request multiple references.
6. Continue normal IMS after analysis: confirmation checklist, exact prompt, wait for explicit confirmation, submit through Lanxin only, download original output, validate it, and return the finished file to the originating Telegram chat as a document.

This rule was added because the owner corrected a previous "change style another one" flow: the right behavior is to save and re-analyze the material image first, then run IMS.
