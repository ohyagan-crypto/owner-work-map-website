# OpenClaw IMS Priority Repair - 2026-07-07

The owner reported that OpenClaw forgot the `ims` skill.

Repair intent:

- Treat `ims` as a mandatory image/poster workflow, not as ordinary chat.
- OpenClaw must read `C:\Users\你的使用者名稱\.openclaw\workspace\codex_shared_memory\skills\ims\SKILL.md` before handling IMS requests.
- The canonical Codex IMS skill remains `C:\Users\你的使用者名稱\.codex\skills\ims\SKILL.md`.
- If stale IMS summaries conflict with the full IMS skill, the full skill wins.
- Keep LINE customer-service memory isolated; do not inject internal IMS owner skills into `line_cs.sqlite`.

Operational IMS baseline:

- Use only 藍星平台 / Lanxin for final image generation.
- Analyze materials first.
- Ask confirmation before consuming credits unless a controlling workflow has already authorized the IMS step.
- Download and verify the original output.
- For Telegram-origin tasks, return final files to the same originating chat by document/file mode when possible.
