# NBS No Missing Outputs Delivery Gate - 2026-07-07

Owner correction:

- A recent NBS task delivered the presentation PPTX and video MP4 but missed the already-generated MP3 audio summary.
- The owner explicitly complained that NBS often misses data/files and that the generated audio had been ready for about 10 minutes without being returned.

Reusable rule:

- For every NBS / NotebookLM task, first derive the expected deliverable list from the owner's latest confirmed request.
- Expected deliverables must be tracked independently:
  - Presentation: validated `.pptx`.
  - Video summary: validated `.mp4`.
  - Audio or voice summary: validated `.mp3` unless another audio format was explicitly requested.
- Completion requires every expected deliverable to satisfy all three gates: file exists in the correct artifact folder, validation passed, and Telegram document delivery succeeded to the same origin chat when Telegram origin is available.
- A generated NotebookLM card, playback, `OutputStatus=completed`, local path, download, export, or partial Telegram delivery is not enough.
- For audio summaries, pressing play or seeing duration only proves the card exists. The actual file must be downloaded from the same NotebookLM notebook, converted to MP3 when needed, validated with a media tool when available, then sent by Telegram document mode.
- Before final reply, compare `RequestedOutputs` with `DeliveredFiles`. If any requested output is missing, do recovery before answering complete.
- If the owner reports `少了 MP3`, `少了語音`, `已經生成但沒給我`, or similar, treat it as same-workflow recovery. Inspect the job record, NotebookLM page, Downloads folder, artifact folder, validation results, and Telegram delivery state before replying.
- Final NBS completion replies must list every delivered filename. If the list does not match the requested outputs, do not call the task complete.

Do not include secrets, raw logs, tokens, cookies, browser profiles, or credential stores in NBS packages or replies.
