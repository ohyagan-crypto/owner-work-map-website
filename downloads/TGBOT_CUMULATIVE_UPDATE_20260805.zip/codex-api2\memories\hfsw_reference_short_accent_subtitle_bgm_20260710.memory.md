# HFSW Reference Short Accent, Subtitle, BGM/SFX Baseline - 2026-07-10

Owner-approved reference video:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260710_214010.mp4`

Use this as the latest HFSW short-video style baseline unless the owner says otherwise.

What the owner approved:

1. Voice/accent
   - Short-video explanatory storytelling cadence.
   - Faster, harder articulation than the earlier slow narration.
   - Clear emotion, stronger emphasis, and more obvious rise-and-fall.
   - Keep the narration easy to understand; do not make BGM or effects cover speech.

2. Subtitle style
   - Use the same short-video storytelling subtitle direction.
   - Large, readable visual emphasis.
   - Bottom subtitles must stay clear on mobile.
   - Use the owner-approved HFSW subtitle style when building new Hyperframes videos: Traditional Chinese, large readable captions, white fill, thick black outline/shadow, short phrase chunks, bottom-centered. If the reference uses a top keyword/title, it may be used only when it supports the story and does not replace bottom subtitles.

3. BGM/SFX upgrade
   - Future HFSW videos should include BGM and sound effects by default.
   - BGM should be low and cinematic/epic under narration.
   - SFX should mark scene changes, key reveals, battle beats, emotional turns, or title moments.
   - Voice remains the loudest layer. Use limiter/compression to avoid clipping.

4. Completion standard
   - Inspect the actual reference video/audio before copying its style.
   - For new deliverables, export MP4, verify duration/dimensions/audio/subtitles, and return by TG3 same-origin document mode for TG3 tasks.

Current remixed deliverable with added BGM/SFX:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_hfsw_success_audio_bgm\hfsw_reference_accent_subtitle_bgm_sfx_loud_20260710.mp4`

