# 嵐熙與庫裡 SD 角色素材包 - 2026-07-06

## 2026-07-06 Kuli Asset Correction

`C:\Users\RECEIVER\kuli.jpg` exists, but visual inspection confirmed it is the black hoodie / orange drawstrings / peeled banana image.
Per the owner's latest AGENTS.md correction, this image must not be used as the correct Kuli generation reference.
For any cmsd, SD, SDF, SDV, Dreamina, or image/video generation involving Kuli, ask for the corrected Kuli character image if this is the only available Kuli image.

Owner provided a Telegram material package on 2026-07-06 and said these should be used as SD materials.

## Verified Package

- Source ZIP: `C:\Users\RECEIVER\tg-openai-bot\telegram_uploads\lanxi_kuli_assets_20260706.zip`
- Local backup folder: `C:\Users\RECEIVER\Desktop\榫嶈潶瑷樻喍\sd_materials_20260706\lanxi_kuli_assets_20260706`
- Backup ZIP: `C:\Users\RECEIVER\Desktop\榫嶈潶瑷樻喍\sd_materials_20260706\lanxi_kuli_assets_20260706\lanxi_kuli_assets_20260706.zip`
- Verified contents: 6 files.
- The package files match the active files under `C:\Users\RECEIVER` by SHA256 hash.

## 嵐熙 Active Materials

- Image: `C:\Users\RECEIVER\lanxi_new.png`
- Backup image: `C:\Users\RECEIVER\Desktop\榫嶈潶瑷樻喍\sd_materials_20260706\lanxi_kuli_assets_20260706\lanxi_new.png`
- Image size: `937 x 1678`
- Voice reference: `C:\Users\RECEIVER\lanxi_voice_ref.mp3`
- Dialogue audio: `C:\Users\RECEIVER\lanxi_dialogue.mp3`

Stable visual traits for prompts:

- Young adult woman named 嵐熙.
- Refined, cool, elegant beauty; calm and composed expression.
- Long black wavy side-parted hair, falling mostly over one shoulder.
- Fair skin, slim tall body proportions, delicate bright facial features.
- Current reference outfit: white fitted short-sleeve crop top, black high-waisted shorts with side tie details.
- Accessories visible in the reference: small drop earrings and a delicate necklace.

Prompt usage notes:

- Use `lanxi_new.png` as the latest face, body, hairstyle, and identity reference for SD/Dreamina/cmsd tasks involving 嵐熙.
- Treat outfit, earrings, necklace, barefoot pose, and indoor wall background as changeable unless the owner asks to preserve this exact look.
- Negative constraints when identity matters: no glasses, no sunglasses, no short hair, no childish appearance, no extra characters, no cartoon/Q-version unless explicitly requested.

## 庫裡 Active Materials

- Image: `C:\Users\RECEIVER\kuli.jpg`
- Backup image: `C:\Users\RECEIVER\Desktop\榫嶈潶瑷樻喍\sd_materials_20260706\lanxi_kuli_assets_20260706\kuli.jpg`
- Image size: `896 x 1196`
- Voice reference: `C:\Users\RECEIVER\kuli_voice_ref.mp3`
- Dialogue audio: `C:\Users\RECEIVER\kuli_dialogue.mp3`

Stable visual traits for prompts:

- Male character named 庫裡.
- Clean youthful Taiwanese/Chinese male look, front-facing half-body portrait.
- Short black hair with shaved sides and a longer top swept to one side.
- Friendly soft smile, no glasses.
- Current reference outfit: black hoodie with orange drawstrings and orange sleeve details.
- Props visible in the reference: peeled banana held with both hands, wristband/smart band, silver watch.

Prompt usage notes:

- Use `kuli.jpg` as the latest face and identity reference for SD/Dreamina/cmsd tasks involving 庫裡.
- Treat hoodie, watch, wristband, and banana as changeable props unless the owner asks to preserve this exact look.
- Negative constraints when identity matters: no glasses, no sunglasses, no major face change, no extra characters, no cartoon/Q-version unless explicitly requested.

## Audio Use

- `*_voice_ref.mp3` files are tone/voice identity references.
- `*_dialogue.mp3` files are spoken dialogue examples.
- For SD/Dreamina video generation, confirm whether the provider supports one or multiple audio references before submission.
- If a workflow is known to fail with multiple character audio references in one generation, use one character audio per generation unless the owner explicitly approves a test.
