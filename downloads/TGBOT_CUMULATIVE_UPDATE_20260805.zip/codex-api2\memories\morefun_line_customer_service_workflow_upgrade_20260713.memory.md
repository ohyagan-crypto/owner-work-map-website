# MoreFun LINE 客服工作流整理與升級 - 2026-07-13

## 目前工作流

1. 客戶訊息進入 MoreFun LINE 官方 relay。
2. 回覆助理只輸出乾淨繁體中文客服話術，不暴露工具、log、token、webhook、內部流程。
3. 先判斷最新訊息類型，再回最短可執行答案；已知問題直接給解法，資訊不足才請客戶補截圖。
4. 主要分類與口徑：
   - 下載／更新：引導回覆選單自助提領；必要時給鑽石、鉑金／至尊下載資訊。
   - Steam 無網路／紅色錯誤：給 Steam 降版連結；若客戶說仍不行，判斷為降版未成功，請重做回滾。
   - CodeFusion／遊戲官方錯誤：判斷為第三方遊戲或官方保護程式問題，請客戶依官方錯誤碼、官方連結或遊戲名稱自行查詢。
   - 無法共享／不能共享：直接說這款若無法共享，就只能自行購買正版或換玩其他可共享遊戲。
   - Ubi / EA / 暴雪：目前不支援，不索取平台帳密。
   - 劍星代刷／提供帳密：不能協助，不要收帳密。
   - 單一遊戲 AppID 或編號：請到鑽石系統內用反饋功能，不要判斷成全系統故障。
   - 問候／在嗎：自然回「人在」，請客戶直接傳問題或畫面，不直接轉人工。
5. 每小時健康檢查：
   - `MoreFun LINE Official Hourly Repair`：檢查本機 relay、公開 webhook、LINE webhook test；可恢復時自動重啟、重設 webhook、重測。
   - `LINE Customer Hourly Monitor`：檢查本機 relay 與 tunnel 健康。
   - `LINE Customer 6H Watchdog`：每 6 小時做較長週期監看。
6. 每日學習：
   - `MoreFun LINE Daily Customer Learning 0000` 每天整理客服對話分類、重複回覆、錯誤紀錄，更新 `C:\Users\你的使用者名稱\.openclaw\workspace\line_cs\morefun_customer_prompt.txt`。

## 已補升級

- `MoreFun LINE Official Hourly Repair` 從單次修復改成最多 5 次真實嘗試；每次會檢查 relay、webhook URL、LINE webhook test，仍失敗才留下 blocker。
- 回覆狀態時必須看實際 `latest-status.json`，不能只說排程存在。

## 下一批建議升級

1. 增加「高風險需主人決定」佇列：退款、補償、私鑰找回、金流爭議、封號、帳號借用、法律風險、客戶辱罵或威脅，一律不自動承諾。
2. 增加「送達驗證」統計：每日學習不只看 assistant reply，也要統計 reply_sent、push_sent、reply_failed、push_failed，列出失敗率。
3. 增加「客戶追問未解」追蹤：同一客戶 24 小時內同類問題重複 3 次，標成需要人工介入或主人確認。
4. 增加「圖片錯誤分類」：Steam 紅色無網路、CodeFusion、Chrome/下載錯誤、Windows 防毒警告、入庫錯誤、遊戲官方彈窗，要各自有第一句判斷。
5. 增加「口徑測試集」：每天用 10 條代表性問題測試 prompt，確認不會把無法共享、CodeFusion、Steam 無網路混成同一類。
6. 整理舊停用排程：`LINE Customer Hourly Inbox Check` 目前停用且 LastTaskResult 舊失敗，應標註為舊版，不要被健康檢查誤判成問題。
7. 路徑編碼防呆：所有 MoreFun LINE 報告固定寫入 `C:\Users\你的使用者名稱\Desktop\龍蝦記憶`，不得再產生亂碼資料夾。

## 回報標準

回報 MoreFun / LINE 狀態時要包含：

- LINE relay 是否健康。
- webhook 是否存在。
- LINE webhook test 是否通過。
- 最近一次排程時間與結果。
- 若有客戶回覆問題，要說明分類、採用口徑、是否需要主人決定。

不得輸出 raw log、JSON dump、token、Channel secret、webhook secret、完整客戶個資或內部 debug。
