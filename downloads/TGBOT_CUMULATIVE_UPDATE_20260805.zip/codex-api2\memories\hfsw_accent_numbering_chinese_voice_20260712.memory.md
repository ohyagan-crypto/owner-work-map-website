# HFSW Accent Numbering Override - 2026-07-12

Owner latest TG3 correction:

`中國口音命名-1`

`上一版本口音-2`

This overrides the earlier confusing HFSW voice numbering for current and future HFSW work.

## Accent -1

Name:

- `口音-1`
- `口音1`
- `voice 1`
- `中國口音`

Reference file inspected for this correction:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260712_134206.mp4`

Inspection:

- File exists.
- Size: 15,137,784 bytes.
- Duration: 300 seconds.
- Video: H.264, 720x1280, 30 fps, vertical.
- Audio: AAC, 48 kHz, stereo.
- Audio level: mean volume about -16.7 dB, max near 0 dB.
- SHA256: `42BFC7EF551C45155BFCFD104016FE2BA8789E3DEF6B59A3DD71AF88DE34B823`

Rule:

- Treat this exact video as the current HFSW `口音-1` reference.
- `口音-1` means the Chinese-accent voice identity/style, not volume -1 dB.

## Accent -2

Name:

- `口音-2`
- `口音2`
- `voice 2`
- `上一版本口音`

Reference:

- `口音-2` means the previous HFSW accent version before the latest Chinese-accent override.
- If a concrete source is needed, use the latest prior HFSW delivered/versioned voice record first:
  `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260712_hfsw_liu_bang_voice1_yunjian_fixed\liu_bang_hfsw_1h_16x9_voice1_yunjian_accent_fixed_loud_tg_20260712.mp4`
- Older historical reference for the previous numbered accent remains:
  `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_133100.mp4`

Rule:

- Treat `口音-2` as the previous-version accent, not a volume reduction.
- Do not interpret `口音-1` or `口音-2` as dB, loudness, pitch, or speed instructions unless the owner explicitly mentions volume, dB, loud, quiet, pitch, or speed.

## HFSW Application

For future HFSW tasks:

1. Default to the owner's latest requested numbered accent when specified.
2. If the owner says `中國口音`, use `口音-1`.
3. If the owner says `上一版本口音`, use `口音-2`.
4. Keep Kai-style bottom subtitles, BGM from 0 seconds, and continuous BGM loop unless separately changed.
5. If true voice cloning is unavailable, state that a closest local voice fallback is being used and do not claim exact cloning.
