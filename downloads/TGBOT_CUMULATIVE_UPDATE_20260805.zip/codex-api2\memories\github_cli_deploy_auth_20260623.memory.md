# GitHub CLI Deploy Auth

Created: 2026-06-23

For GitHub Pages deployment on this Windows host:

- Official GitHub CLI is installed at `C:\Program Files\GitHub CLI\gh.exe`.
- PortableGit is installed at `C:\Users\你的使用者名稱\PortableGit\`.
- npm `gh` shims were disabled because they pointed to a broken npm package and blocked real GitHub CLI usage.
- Put `C:\Program Files\GitHub CLI;C:\Users\你的使用者名稱\PortableGit\cmd;C:\Users\你的使用者名稱\PortableGit\bin;C:\Users\你的使用者名稱\PortableGit\mingw64\bin` first in PATH before deploy commands.
- Before public deployment, run `C:\Users\你的使用者名稱\.openclaw\workspace\tools\ensure-github-cli-auth.ps1`.
- The helper sends a Telegram authorization button with the GitHub device-login link, then opens the local browser as fallback and waits for `gh auth status`. Ask the owner only if GitHub requires account selection, password, 2FA, or consent outside the Telegram link.
- Reboot should not require reauthorization once `gh auth status` succeeds; GitHub CLI stores auth in Windows credential storage or `%APPDATA%\GitHub CLI\hosts.yml`.
- Important fallback: Windows Credential Manager already has a usable Git credential for `https://github.com/ohyagan-crypto/freeway-charging-stations.git`. Updating that repo can use plain `git push` without `gh auth`. Only `gh` is needed for new repo creation or Pages API operations.
- Avoid routine `git credential fill` and `git push --dry-run` on this host; both can hang. Use `git ls-remote` as the quick check and attempt the real `git push` when deploying.
- New no-computer setup: `send-github-token-setup.ps1` sends a Telegram link to create a fine-grained deploy token. If the owner replies `github_pat TOKEN`, store it with `set-github-deploy-token.ps1`; future deploy pushes can use `git-push-with-github-token.ps1`.
