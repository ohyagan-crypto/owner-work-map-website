# 交接包清單

建立時間：2026-06-19 21:22:39

內容：
- 本機非系統技能資料夾
- 本機 .codex\memories 記憶檔
- C:\AGENTS.md 操作偏好與最高規則
- 中文安裝說明
- 給接收端 Telegram 的轉發文字

安全排除：
- 未包含 appsettings.Local.json
- 未包含 Telegram bot token
- 未包含 API key
- 未包含瀏覽器 profile、cookie、登入資料
- 未包含 raw logs