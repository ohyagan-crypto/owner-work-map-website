# NBS No Missing Deliverables Gate - 2026-07-07

Owner correction after an NBS task delivered the presentation and video but initially missed the MP3 audio summary:

- NBS must not miss requested outputs, under-create files, or forget Telegram delivery.
- The requested output list is the delivery contract. `presentation_pptx`, `video_summary_mp4`, and `audio_summary_mp3` each require a real final file when requested.
- A NBS workflow is complete only when every requested output is generated in the same NotebookLM notebook, downloaded or exported to the artifact folder, renamed safely when needed, validated, and delivered to the same Telegram origin chat by document mode.
- Do not rely on `OutputStatus=completed`, a visible NotebookLM card, playback, a local path, or a previous send attempt as proof of completion.
- Before final reply, compare `RequestedOutputs` against `DeliveredFiles` and the actual artifact folder. If any requested output is missing, continue recovery and keep `DeliveryStatus` as partial or missing.
- For full NBS, final delivery must include PPTX, MP4, and MP3. For partial NBS, final delivery must include exactly every type the owner requested.
- Missing-file complaints such as `少了 MP3`, `少了語音`, `少了檔案`, `少做`, `少傳`, `漏傳`, `怎麼少資料`, or `已生成但沒給我` are active recovery tasks for the same job record and notebook.
- Final replies must list delivered filenames by type so a count mismatch is visible before reporting done.
- If Telegram origin delivery is available, a local path is only a backup. Completion requires Telegram document upload success.

Reusable NBS final checklist:

1. Read the current job record.
2. Expand `RequestedOutputs` into required final extensions.
3. Confirm each final file exists in `ArtifactFolder`.
4. Validate each final file: PPTX structure/page count, MP4 playable duration/video/audio, MP3 playable duration/format.
5. Confirm every required file is in `DeliveredFiles`.
6. Confirm `DeliveryStatus=delivered_all` only after all required files are delivered.
7. Final reply lists every delivered filename and the backup folder.
