# HFSW No-SFX Historical Epic BGM Correction - 2026-07-11

Owner reported the Zhang Fei HFSW sound effects were too noisy and asked to delete them, then replace the music with historical epic BGM.

Use this correction for future HFSW historical videos:

- If the owner says sound effects are noisy, remove the SFX layer completely instead of reducing or strengthening it.
- Do not use whooshes, metal strikes, impact hits, harsh transition sounds, noisy low-frequency rumbles, or stacked battle accents unless explicitly requested again.
- For Three Kingdoms / historical epic storytelling, use a cleaner BGM-only bed:
  - slow low strings,
  - restrained orchestral swells,
  - subtle choir or warm pad,
  - sparse historical melodic line,
  - no discrete SFX events.
- Keep the approved Zhang Fei short-video storytelling accent and Kai-style bottom subtitles unchanged.
- Mix rule: narration remains the lead layer; BGM should be audible and historical, but not busy or sharp.
- Use sidechain ducking or equivalent mixing so the BGM supports the story without masking speech.

Corrected deliverable:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw_bgm_sfx\zhang_fei_hfsw_reference_accent_kai_historical_epic_bgm_no_sfx_v7b_20260711.mp4`

Validation:

- Duration: 300 seconds.
- Size: 720x1280.
- Audio: AAC stereo.
- Subtitles: Kai-style bottom subtitles still readable.
- Delivery: returned through TG3 same-origin document mode.
