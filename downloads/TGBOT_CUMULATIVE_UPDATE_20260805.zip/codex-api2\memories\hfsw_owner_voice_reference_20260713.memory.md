# HFSW Owner Voice Reference - 2026-07-13

Owner provided a Telegram voice recording for future HFSW accent reference.

## Reference Files

- Original TG3 voice: `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_voice_20260713_143544.ogg`
- Backup OGG: `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\hfsw_owner_voice_reference_20260713_143544\owner_hfsw_voice_reference_20260713_143544.ogg`
- Converted WAV: `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\hfsw_owner_voice_reference_20260713_143544\owner_hfsw_voice_reference_20260713_143544.wav`

## Media Inspection

- Format: OGG / Opus
- Duration: about 105.4 seconds
- Audio: mono, 48 kHz
- SHA256: `9D6FE481C788F1086A764CC63C826F40E39F13B64AB72FBD5B78D4190C6483E7`

## Use Rule

Use this voice as an HFSW owner voice/accent reference when the owner asks to use their own voice, owner voice, this TG voice, or a newly recorded owner voice for HFSW.

This reference is suitable for accent, rhythm, pause, and speaking-style guidance. Do not use it as clean BGM.

If exact voice cloning is unavailable, say clearly that the closest available HFSW voice preset will be tuned toward this reference instead of claiming exact cloning.

## Transcript Summary

The owner read the historical-story sample beginning with:

`各位好，今天我們來講一段歷史故事。`

The reading style contains natural conversational pauses, a history-storytelling cadence, and ordinary spoken phrasing. When converting to HFSW, preserve the cadence and storytelling rhythm, but clean up ASR mistakes in text such as `亂誓`, `魔略`, `世人`, and `陰碰運` back to the intended Traditional Chinese script.

## 2026-07-13 20:49 Override

The owner later corrected the reference with:

`這才是我的口音`

The primary owner voice/accent reference is now:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_voice_20260713_204932.ogg`

Backup:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.ogg`

WAV:

`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.wav`

Use the 20:49 voice first for `我的口音`, `我的語音`, `主人口音`, `主人語音`, `主人本人口音`, and `口述口音`.

Do not silently assign or change `口音-1` / `口音-2` numbering unless the owner explicitly says this sample should become a numbered preset.
