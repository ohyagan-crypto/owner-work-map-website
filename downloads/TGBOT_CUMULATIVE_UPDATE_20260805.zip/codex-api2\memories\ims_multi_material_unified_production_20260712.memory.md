# IMS Multi-Material Unified Production - 2026-07-12

Owner setting:

- For multi-material IMS work, collect and analyze every provided material first.
- Do not give separate one-off replies per image when the owner is building one batch.
- Produce one unified confirmation checklist before Blue Star generation.
- Put the unified confirmation checklist at the end of the pre-generation reply so the owner reads the analysis first. Required order: conclusion, material inventory, per-material analysis, cross-material judgment, shared style/prompt direction, then final confirmation checklist.
- The checklist must state the shared style system, unified ratio/size, total output count, filename/order plan, and per-output material usage.
- For multiple final images, keep one coherent visual system across all outputs: same palette family, typography style, layout density, border/radius treatment, icon/annotation language, brand wording, ratio, and export naming.
- For tutorial/SOP images, preserve the original operation meaning, visible key text, red boxes/arrows/callouts, and step order.
- Exclude unrelated older uploads explicitly instead of mixing them into the active IMS task.
- After owner confirmation, complete the full batch: Blue Star generation, original PNG download, validation, and same-origin Telegram document delivery for every final file.
- Recoverable failures must be retried after real-state inspection, up to at least five attempts before reporting a blocker, unless the blocker is external.
