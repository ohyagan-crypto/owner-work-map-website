# 庫裡角色修正 - 2026-07-06

## 2026-07-16 Owner Override

- The owner explicitly reconfirmed the black hoodie / orange drawstrings / peeled banana portrait as the official Kuli identity reference.
- Active image: `C:\Users\你的使用者名稱\kuli.jpg`.
- Use it for CMSD, IMS storyboard, SD, SDF, SDV, Dreamina, Seedance, and related image/video generation until the owner provides a newer replacement.
- This dated override supersedes the older restriction below.

Owner correction: "庫裡角色不同".

Effective immediately:

- The black-hoodie/banana male image previously saved as `C:\Users\你的使用者名稱\kuli.jpg` must not be treated as the confirmed fixed identity for 庫裡.
- Do not use that image in cmsd, SD, Dreamina, Seedance, IMS storyboard, or character prompt workflows as 庫裡 unless the owner explicitly re-confirms it.
- The existing 庫裡 audio files may remain stored as audio assets, but they do not confirm the image identity.
- For any new task involving 庫裡, ask for or locate the owner-confirmed correct 庫裡 reference image before generation.
- 嵐熙 material is not changed by this correction.
