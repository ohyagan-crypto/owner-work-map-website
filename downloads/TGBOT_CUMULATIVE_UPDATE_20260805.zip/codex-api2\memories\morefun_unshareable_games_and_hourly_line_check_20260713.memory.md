# MoreFun 無法共享遊戲與 LINE 官方每小時檢查 - 2026-07-13

Owner correction from TG1:

- MoreFun / 魔方客服遇到「無法共享」的遊戲時，直接請客戶自己購買正版或換玩其他可以共享的遊戲。
- 不要把無法共享的遊戲誤判成 MoreFun 系統故障。
- 不提供繞過共享限制、借帳號、破解、非授權共享等做法。

## 客服固定方向

```text
這款如果無法共享，就只能自己購買正版，或先換玩其他可以共享的遊戲。
```

## LINE 官方健康檢查

- LINE 官方 / MoreFun 通道必須每小時檢查是否正常運作。
- 主要排程：`MoreFun LINE Official Hourly Repair`
- 檢查重點：本機 relay、公開 webhook、LINE webhook test。
- 若可恢復，排程應自動重啟 relay、重新取得 webhook、重新設定 webhook。
- 不要只看排程存在；回報狀態時要看實際健康檢查結果或 status file。

## Safety

- 不要在回覆、記憶或報告中暴露 LINE token、Channel secret、webhook secret、cookie、raw log、客戶私密資料。
