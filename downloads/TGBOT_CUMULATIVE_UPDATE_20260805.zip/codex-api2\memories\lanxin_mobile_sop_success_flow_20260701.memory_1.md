# Lanxin Mobile SOP Success Flow

Created: 2026-07-01 after the owner praised the completed Lanxin / Blue Star AI mobile SOP image workflow.

## Core Rule

For future Lanxin / Blue Star AI mobile teaching image tasks, reuse the completed SOP flow as the quality and delivery baseline. The praised 4-image set is only an example, not a fixed count. Future sets may be 3, 4, 5, 8, 10, 12, or more images depending on the owner's materials and the real teaching workflow. This applies to tasks about opening the platform in a mobile browser, adding it to the home screen, starting a new chat, refreshing the model, or explaining the mobile usage flow to customers.

## Variable Count Rule

When the owner provides multiple screenshots, references, or step materials:

1. Read and inspect every provided material image before planning or answering.
2. Do not assume the set is four images just because the praised reference set had four.
3. Decide the required image count from the complete workflow after all materials are reviewed.
4. If there are 10 or more materials, still analyze all of them individually; do not summarize only the first, last, or most obvious screenshots.
5. After all materials are read, provide one consolidated final confirmation checklist before generation/submission. Do not send scattered partial checklists unless there is a real blocker.
6. The final confirmation checklist must include total planned image count, per-image purpose, source material usage, output ratio/size, text language, red-box/arrow targets, validation method, Telegram document delivery, ZIP package plan, and any missing information or blocker.

## Successful Reference Flow, Not Fixed Count

The praised reference set used four vertical SOP images:

1. Use the default browser to open the platform link.
2. In the mobile browser menu, tap `加到主畫面`.
3. In Blue Star AI / Lanxin, tap `新對話`.
4. If the model or page state is abnormal, tap `刷新模型`.

## What Worked

- Analyze every provided material image individually before planning the set.
- State each image's visible text, red-box target, teaching purpose, and its position in the complete workflow.
- Build the complete storyboard first instead of generating isolated frames.
- Decide the final number of images from the complete material review, not from a fixed template.
- Give the owner one final confirmation checklist after all materials have been read.
- Use vertical 9:16 phone teaching images with one main action per image.
- Keep visible Traditional Chinese short and readable.
- Use clear red boxes or arrows to mark the exact UI target.
- Keep the UI screenshot-like and practical, not decorative or poster-like.
- Save files under `C:\Users\RECEIVER\Desktop\龍蝦記憶\<task-folder>\`.
- Download original PNG outputs from Lanxin / 聚合平台.
- Validate file count, order, dimensions, text readability, and red highlight placement before delivery.
- For Telegram-origin tasks, return each PNG as a Telegram document and also return a ZIP for the full set.

## Recovery Pattern That Worked

If the platform completes only part of the set:

1. Return the completed valid images and a clearly named partial ZIP only when continued generation is blocked.
2. Report exactly which image numbers failed and why in clean Traditional Chinese.
3. Preserve the same storyboard, filenames, and task folder.
4. When the owner asks to retry remaining images, generate only the missing image numbers instead of restarting the whole set unless the existing outputs are invalid.
5. After missing images are completed, rebuild the full ZIP containing the latest complete set.
6. Return the newly completed images and the refreshed full ZIP to the same originating Telegram chat.

## Filename Pattern

Use safe numbered ASCII filenames:

- `lanxin-sop-01-open-default-browser.png`
- `lanxin-sop-02-add-to-home-screen.png`
- `lanxin-sop-03-new-chat.png`
- `lanxin-sop-04-refresh-model.png`
- `lanxin-mobile-sop-complete-4-images-YYYYMMDD.zip`
- For variable-size sets, include the real count in the ZIP name, for example `lanxin-mobile-sop-complete-10-images-YYYYMMDD.zip`.

## Quality Baseline

The owner praised the result after all four PNG files and the complete ZIP were returned. Keep this as the future baseline:

- no partial final delivery when recovery is still possible;
- no need to ask the owner to resend the same materials after a platform retry;
- no generic status replies when the owner asks why something is stuck;
- final reply must say exactly what was completed, what was returned, and the local backup folder when useful.

## 2026-07-01 Optimization After Owner Praise

The owner explicitly asked to thoroughly fix the slow, stuck, and failed parts from the previous mobile SOP image workflow, and to support frequent future style changes and corrections.

Apply these improvements:

1. When the owner asks to change style, modify a detail, fix an error, or generate another version from a delivered SOP image, continue from the latest verified Lanxin output instead of starting from memory.
2. Use the prior delivered PNG/JPG as the primary Lanxin reference image. If the owner uploads a new screenshot, inspect it first and use it as an additional reference only when it clarifies the requested change.
3. Preserve the approved teaching workflow, step order, required Traditional Chinese text, red-box target, phone ratio, and product identity unless the owner explicitly asks to change them.
4. For style changes, keep the same instructional content but change the visual direction clearly, such as AI tech, premium clean, business tutorial, cute friendly, cyber neon, or minimalist product UI.
5. For corrections, identify the exact defect before generation: wrong text, unclear highlight, wrong button, bad order, unreadable type, wrong screenshot context, weak style, or output not matching the material.
6. Pre-create the task folder and safe numbered filenames before submission so download, validation, ZIP packaging, and Telegram document delivery are faster.
7. If the platform is stale or the model list is abnormal, use the mobile/menu action `刷新模型` once, then re-check page state before submitting. Do not keep refreshing blindly.
8. If generation stalls, use the fast recovery pattern: first check whether the task actually started, then check completion, then retry only the missing or defective image numbers when safe.
9. For multi-image corrections, rebuild the full ZIP after the corrected frame is validated, and return both corrected individual images and the refreshed ZIP.
10. Completion still requires Telegram document delivery to the originating chat, not only a local path.

## Safety

Do not store or return passwords, tokens, cookies, browser profiles, credential stores, raw logs, or screenshots/files containing visible secrets. If a platform login check is needed, use the existing authorized Lanxin login automation rules and report only the clean result or a real external blocker.
