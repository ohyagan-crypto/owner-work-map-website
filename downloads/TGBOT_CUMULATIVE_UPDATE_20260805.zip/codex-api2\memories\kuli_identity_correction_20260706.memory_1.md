# 庫裡角色修正 - 2026-07-06

Owner correction: "庫裡角色不同".

Effective immediately:

- The black-hoodie/banana male image previously saved as `C:\Users\RECEIVER\kuli.jpg` must not be treated as the confirmed fixed identity for 庫裡.
- Do not use that image in cmsd, SD, Dreamina, Seedance, IMS storyboard, or character prompt workflows as 庫裡 unless the owner explicitly re-confirms it.
- The existing 庫裡 audio files may remain stored as audio assets, but they do not confirm the image identity.
- For any new task involving 庫裡, ask for or locate the owner-confirmed correct 庫裡 reference image before generation.
- 嵐熙 material is not changed by this correction.
