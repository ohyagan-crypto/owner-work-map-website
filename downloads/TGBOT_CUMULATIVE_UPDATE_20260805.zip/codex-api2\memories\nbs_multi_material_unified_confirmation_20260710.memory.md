# NBS Multi-Material Unified Confirmation Rule - 2026-07-10

Owner correction:

- For NBS tasks with multiple materials, analyze all current-task materials together before giving a confirmation checklist.
- Do not analyze only the first, latest, or most obvious upload.
- Assign stable material IDs such as M01, M02, M03, then make one combined cross-material judgment: topic, order, output type, sensitive-data handling, language, and per-output usage.
- The confirmation checklist must be unified, not one checklist per material.
- If the owner replies `確認` to that unified checklist, immediately execute the NBS workflow. Do not ask for confirmation again.
- For Telegram-origin NBS, completion still requires NotebookLM generation, download/export, validation, and same-origin Telegram document delivery for every requested file.
