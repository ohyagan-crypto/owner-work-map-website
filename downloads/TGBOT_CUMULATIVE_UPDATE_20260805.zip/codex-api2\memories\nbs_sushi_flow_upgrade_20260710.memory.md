# NBS 壽司點餐機流程升級記憶

建立日期：2026-07-10

主人確認這次 NBS 流程正確，要求之後繼續保持，並詢問可升級部分。

## 已驗證成功流程

- 對圖片素材先做實際視覺分析，不沿用舊素材。
- 先提出多個方向，等主人回覆方向編號後才送 NotebookLM。
- NBS 使用固定 Chrome 環境：`C:\Program Files\Google\Chrome\Application\chrome.exe`、`C:\Users\Administrator\AppData\Local\Google\Chrome NBS User Data`、`Profile 1`、CDP `http://127.0.0.1:9444`。
- NotebookLM 成品必須來自同一個筆記本，不可本機自製替代。
- 語音摘要若下載為 M4A，要轉成 MP3，使用 `ffprobe` 驗證音訊長度與音軌後再回傳。
- 簡報若下載為 PDF，也可交付，但必須確認是有效 PDF、不是 HTML 或登入頁，並檢查頁數至少 15 頁。
- 影片摘要若一般下載失敗，可從 NotebookLM 播放器取得影片來源，以已登入 Chrome 的 cookies 搭配續傳下載，完成後用 `ffprobe` 驗證 MP4 有影像軌、音軌與正確時長。
- 大檔回傳 Telegram 若一般上傳逾時，可改用 `curl --ssl-no-revoke` 回傳，成功後才寫入去重紀錄。
- 任何壞檔、HTML、登入頁、占位檔都要移到 `invalid-downloads`，不可誤傳。
- 三件成品都傳完後，要更新 job JSON、標記 `delivered_all`，再封存到 `jobs\archive`，避免重複檢查或重複傳檔。

## 下一步升級方向

- 把上述下載、驗證、續傳與 Telegram 回傳流程做成同一支可重用腳本。
- 增加自動判斷：PPTX 優先，若 NotebookLM 只給 PDF，則驗證 PDF 頁數後交付。
- 增加影片下載自救：一般下載、播放來源、cookies 續傳依序嘗試，失敗才回報卡點。
- 增加交付前總檢查表：來源、語言、成品數量、格式、頁數或時長、Telegram message id、job 封存狀態。
