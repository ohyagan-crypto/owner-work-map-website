# NBS Rich Presentation Style Matrix - 2026-07-10

Owner correction: NBS presentation style prompts should be more richly designed and material-derived.

For future NBS tasks with PPTX output, the assistant must not stop at generic style words such as "clean", "professional", or "simple". It must infer a complete design system from the materials and include it in the confirmation checklist and NotebookLM presentation prompt.

Required extra style layers:

- `素材氣質`: operational SOP, customer onboarding, product training, issue diagnosis, sales education, creator planning, executive briefing, course handout, or story/case-study.
- `品牌語感`: Blue Star tech service, warm customer support, premium professional, calm internal training, lively social/creator, or evidence-first diagnostic.
- `視覺層級`: cover impact, section divider style, step-page rhythm, reminder/caution pages, summary/checklist pages, final CTA page.
- `版面節奏`: full screenshot focus, split screenshot plus instruction, comparison table, timeline, checklist, FAQ, mistake/fix, decision tree, or handoff prompt page.
- `圖像與標註規則`: preserve useful red frames, arrows, numbered markers, button names, visible UI states, and source order; simplify cluttered screenshots; never recreate sensitive UI details inaccurately.
- `色彩系統`: primary color, accent color, warning color, neutral background, contrast rule, and no readability-reducing decorative background.
- `字體與可讀性`: mobile-readable Traditional Chinese, short titles, no dense paragraph walls, consistent heading/body/callout sizes, and no tiny instruction text.
- `教學互動感`: add "你要做什麼", "畫面應該看到什麼", "完成判斷", "常見錯誤", and "下一步" where useful.
- `可信度保護`: separate source facts from inferred guidance; do not invent products, links, accounts, prices, claims, platform abilities, or customer promises.
- `交付用途`: specify customer self-study, customer-service forwarding, class teaching, internal training, sales explanation, or production handoff.

Style selection should combine one base visual style plus one functional layer:

- Tutorial SOP: `清爽商務` + mobile step cards + red callout preservation + completion checklist.
- Blue Star / AI platform onboarding: `科技藍綠` or clean Blue Star tech + friendly customer-service wording + UI-state callouts.
- Sensitive credential/token tutorial: clean SOP + privacy warning pages + masked examples + strict no-secret rule.
- Product or skincare demo: premium product training + before/after logic + benefits table + no unsupported medical claims.
- Error/diagnosis material: evidence-first report + issue/cause/fix table + exact blocker and next action.
- SD/storyboard planning: creator production deck + timeline table + character/material mapping + final prompt handoff.
- Course or class material: premium education + module flow + practice checklist + speaker notes.

Quality gate: a successful NBS deck must feel like a deliberately designed teaching or briefing deck, not a screenshot dump, OCR dump, or generic NotebookLM outline.

