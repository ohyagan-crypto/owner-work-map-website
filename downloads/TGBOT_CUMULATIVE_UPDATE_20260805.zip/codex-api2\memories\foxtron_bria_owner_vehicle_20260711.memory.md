# Owner Vehicle Memory - Foxtron Bria

Date: 2026-07-11

Owner vehicle:
- Foxtron Bria Elegant entry model.
- Battery basis: 57.7 kWh LFP.
- Published range basis from prior spec lookup: NEDC 516 km for Elegant.
- Home charging note: owner clarified home charging is 220V / 20A slow charging.

Future Q&A rule:
- When the owner asks how much range remains, how many "points" remain, or how long until full, use Bria Elegant as the default vehicle.
- Default home charging assumption: 220V x 20A = 4.4 kW gross, about 4.0 kW usable after charging loss.
- Do not mention 110V/20A unless the owner specifically asks about 110V or another charger.
- Use approximate charging loss of 10% unless the owner provides a real charger/app reading.
- Estimate range per battery percent from 516 km / 100 = about 5.16 km per 1%.
- Estimate energy per battery percent from 57.7 kWh / 100 = about 0.577 kWh per 1%.
- For 220V/20A, approximate charging gain is about 6.9% battery per hour, or about 35 km NEDC per hour.
- Full 0-100% charging estimate:
  - 220V/20A: about 14.5-16 hours.
- Real-world range may be lower than NEDC. Mention this briefly when giving practical driving estimates.
