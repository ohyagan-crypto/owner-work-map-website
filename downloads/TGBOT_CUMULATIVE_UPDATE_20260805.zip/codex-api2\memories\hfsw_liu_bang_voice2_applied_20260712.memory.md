# HFSW Liu Bang Voice 2 Applied - 2026-07-12

Owner instruction from TG3: `口音換成另一個我要你記好的`.

Current task context:
- Workflow: `hfsw`
- Topic: Liu Bang / 劉邦
- Format: 16:9 horizontal
- Duration: 1 hour / 3600 seconds
- Visual cadence: 60 sections, 1 image per minute

Applied voice/accent reference:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_133100.mp4`

This is the previously saved `口音編號2` reference. It must be treated as an accent/voice preset, not as a volume or dB operation.

Corrected output:

`C:\Users\你的使用者名稱\Desktop\榫嶈潶瑷樻喍\20260712_hfsw_liu_bang_1h_16x9\hf_20260712\export\liu_bang_hfsw_1h_16x9_voice2_20260712.mp4`

Validation before TG3 delivery:
- Duration: 3600 seconds.
- Video: 1280x720, horizontal 16:9.
- Audio: AAC stereo.
- Subtitles: bottom Kai-style captions visible in verification frame.
- BGM source updated to the `20260711_133100` reference and looped from 0 seconds.
- Same-origin TG3 document delivery succeeded.

Rule:
When the owner asks to use "另一個記好的口音", "口音2", "口音編號2", or references this `20260711_133100` video, use this voice/accent preset while preserving HFSW visual timing, Kai-style bottom captions, and BGM loop rules unless the owner explicitly asks to change them.
