# Lanxi Character Reference - 2026-07-06

Created after the owner uploaded a new reference image and said: "這是嵐熙".

Use this as the latest SD / cmsd character reference for 嵐熙 unless the owner provides a newer image.

## Active Reference Files

- Latest fixed SD image path: `C:\Users\你的使用者名稱\lanxi_new.png`
- Original uploaded JPG backup: `C:\Users\你的使用者名稱\Desktop\榫嶈潶瑷樻喍\character_refs_20260706\lanxi_reference_20260706_120329.jpg`
- Previous reference backup: `C:\Users\你的使用者名稱\Desktop\榫嶈潶瑷樻喍\character_refs_20260706\lanxi_new_previous_backup_20260706.png`
- Voice reference remains: `C:\Users\你的使用者名稱\lanxi_voice_ref.mp3`

## Fixed Identity Traits

- Young adult woman, refined and cool, clean elegant beauty.
- Long black wavy hair, side-parted, falling mostly over one shoulder.
- Fair skin, slim tall body proportions, delicate facial features.
- Soft but confident expression; calm, composed, slightly cool temperament.
- Visible accessories in this reference: small drop earrings and a delicate necklace.

## Reference Outfit In Uploaded Image

- White fitted short-sleeve crop top.
- High-waisted black shorts with side tie details.
- Barefoot full-body standing pose against a clean neutral indoor wall.

## Prompt Guidance

- For identity consistency, prioritize face shape, long black wavy side-parted hair, refined facial features, slim tall figure, cool elegant temperament.
- Outfit can change by scene unless the owner asks to preserve this exact white crop top and black shorts.
- Negative constraints when relevant: no glasses, no sunglasses, no extra characters, do not change to short hair, do not make her childish, do not over-cartoonize unless explicitly requested.
