# MoreFun LINE 每小時檢查與每日學習規則 - 2026-07-09

主人要求：每個小時檢查 MoreFun 的 LINE 官方是否正常運作，異常時自動修復；每天晚上 12 點整理當天所有對客戶的回答，萃取成功說法、失敗原因、過度固定或不自然的回覆，更新後續客服規則。

落地方式：

- 每小時排程：`MoreFun LINE Official Hourly Repair`
- 每日 00:00 排程：`MoreFun LINE Daily Customer Learning 0000`
- 健康檢查腳本：`C:\Users\你的使用者名稱\.openclaw\tools\morefun-line-hourly-repair.ps1`
- 每日學習腳本：`C:\Users\你的使用者名稱\.openclaw\tools\morefun-line-daily-learning.ps1`
- 客服規則檔：`C:\Users\你的使用者名稱\.openclaw\workspace\line_cs\morefun_customer_prompt.txt`
- 本機報告資料夾：`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\morefun_line_daily_learning`

原則：不記錄密碼、token、私鑰、驗證碼、付款資訊或任何敏感資料；不保存原始客戶對話全文作為公開報告，只整理類型、成功模式、修正方向。回覆客戶要短、直接、自然，像真人客服。客戶問下載或最新版本時直接給下載資訊；Steam 無網路連線錯誤優先走 Steam 降版規則；「在嗎、有人嗎、客服在嗎」不是人工客服升級。
