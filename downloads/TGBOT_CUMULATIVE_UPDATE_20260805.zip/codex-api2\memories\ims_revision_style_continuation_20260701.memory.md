# IMS Revision And Style Continuation Rule

Created: 2026-07-01 after the owner praised the successful AI-tech Lanxin mobile SOP image delivery and asked to optimize the previously slow/stuck parts.

## Core Rule

For future IMS / Lanxin image tasks, when the owner says any of the following, treat it as a continuation of the latest relevant deliverable:

- 換個風格
- 改一下 / 修改哪裡
- 哪裡有誤
- 風格不滿意
- 再一版 / 重做 / 再做一次
- 用剛剛那張改
- 延續成品

Do not start from memory only. First locate the latest verified output and use it as a reference image in Lanxin / 聚合平台 whenever possible.

## Required Workflow

1. Inspect any newly uploaded Telegram photo first.
2. Locate the latest relevant verified deliverable under:
   - `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\`
   - `C:\Users\你的使用者名稱\Desktop\榫嶈潶瑷樺枍\`
   - `C:\Users\你的使用者名稱\lanxin_task\out\`
3. Copy the current reference material and prior output into the task/date folder before generating.
4. Re-analyze the reference image: visible text, UI target, composition, style, what must be preserved, and what must change.
5. For style changes, preserve the approved content and change only the visual direction unless the owner says otherwise.
6. For corrections, name the exact defect before generating: wrong word, wrong button, red box target, unreadable text, wrong order, low quality, or unrelated image.
7. Submit the revision through Lanxin / 聚合平台 only. Do not use local imagegen, Canvas, PPT, Photoshop, screenshot editing, HTML/SVG, or other substitutes.
8. Download the platform original, validate it, and return it to the originating Telegram chat by document mode.
9. If it is part of a multi-image set, rebuild and return the refreshed ZIP after correction.

## Speed And Stuck-Point Fixes

- Prepare the task folder and safe ASCII filenames before platform submission.
- Reuse the prior prompt, ratio, style constraints, and approved text instead of rewriting everything from scratch.
- Use `刷新模型` once only when the platform model/page state is stale or abnormal, then re-check before submitting.
- If generation partially succeeds, keep valid frames and retry only missing or defective frames.
- If the same platform step fails twice, or no meaningful progress appears for 3-5 minutes, report the exact blocker in clean Traditional Chinese with what has already been prepared.
- Do not leave the owner with only "processing" or "later" when a concrete file, path, or blocker can be reported.

## 2026-07-01 Successful Baseline

The praised baseline was an AI-tech style Lanxin mobile SOP set returned as original PNG files plus a ZIP. Future Blue Star AI / Lanxin tutorial revisions should preserve:

- vertical phone tutorial ratio;
- one action per frame;
- short readable Traditional Chinese;
- clear red box or arrow target;
- platform/product identity;
- original PNG download and validation;
- Telegram document delivery plus ZIP for multi-image sets.

Never send secrets, credentials, tokens, cookies, raw logs, browser profiles, or screenshots containing visible secrets.
