# HFSW True Owner Voice Accent - 2026-07-13 20:49:32

Owner correction from TG3:

`這才是我的口音`

Exact inspected Telegram voice:

`C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_voice_20260713_204932.ogg`

Backup/reference files:

- OGG: `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.ogg`
- WAV: `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\hfsw_owner_true_voice_accent_20260713_204932\owner_true_hfsw_voice_accent_20260713_204932.wav`

Inspection:

- File exists.
- Size: 2,170,938 bytes.
- Duration: 105.4 seconds.
- Format: OGG / Opus.
- Audio: 48 kHz, mono.
- Mean volume: about -21.1 dB.
- Max volume: about -1.7 dB.
- SHA256: `9D6FE481C788F1086A764CC63C826F40E39F13B64AB72FBD5B78D4190C6483E7`.
- Transcript starts with: `各位好，今天我們來講一段歷史故事。`

Behavior rules:

1. This Telegram voice is now the primary owner personal narration accent reference for HFSW.
2. `我的口音`, `我的語音`, `主人口音`, `主人語音`, `主人本人口音`, `口述口音`, `用我的語音做口音`, and `用我的口音做口述口音` should point to this OGG/WAV reference first.
3. This overrides the earlier 300-second replied-video source as the priority owner voice/accent source. Keep the older video only as a secondary historical/subtitle/visual reference unless the owner explicitly asks for that video's accent.
4. This sample is suitable for cadence, rhythm, pause pattern, storytelling feel, and pronunciation tendency.
5. Do not use this voice recording as BGM or final mixed background audio.
6. If true voice cloning or voice reference input is available, use this file as the source/reference and record it in the HFSW mix manifest.
7. If true voice cloning is unavailable, do not claim exact cloning. Record the closest available storyteller fallback and say it is tuned toward this owner voice reference.
8. Future HFSW outputs using the owner's personal voice must still pass normal HFSW gates: platform images when required, Hyperframes composition, Kai-style bottom subtitles, clean BGM from 0 seconds, audio dropout check, subtitle sync check, final MP4 validation, and TG3 same-origin delivery.

Numbering note:

- This file is the owner's true voice reference.
- Do not silently assign or change `口音-1` / `口音-2` numbering unless the owner explicitly says which number this sample should become.
