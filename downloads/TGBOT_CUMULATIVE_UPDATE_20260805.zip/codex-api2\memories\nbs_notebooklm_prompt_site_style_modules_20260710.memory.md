# NBS NotebookLM Prompt Site Style Modules - 2026-07-10

Owner asked to research `https://ohyagan-crypto.github.io/notebooklm-prompt-site/` and add its style prompts to the NBS workflow.

Website-derived rule:

- NBS presentation prompts should be built as modules, not a single vague style line.
- Required modules: slide count, presentation minutes, speaker role, presentation context, target audience, speaker tone/persona, core CTA, purpose type, outline framework, visual style, speaker notes, output format, and anti-generic quality rule.
- Purpose options to infer from materials: proposal persuasion, course teaching, sales conversion, result report, brand introduction, investor/fundraising pitch, or custom.
- Outline options to infer from materials: problem-solution-result, story narrative, pyramid principle, course module, business plan, compare-and-decide, or custom.
- Visual style options to infer from materials:
  - `清爽商務`: light/white background, deep blue titles, clean charts; SOP, onboarding, reports.
  - `高級黑金`: dark background, gold lines, premium tone; brand, investor, luxury, executive pitch.
  - `科技藍綠`: dark tech, cyan/blue-green accents, data visuals; AI, automation, software, platform, crypto.
  - `溫暖編輯`: off-white/brown editorial layout; story, culture, community, customer-service guides.
  - `強烈網紅`: big titles, high contrast, short lines; short-video planning, creator/IP, social sales.
  - `極簡留白`: large whitespace, thin lines, few key words; consulting, premium education, executive summary.
- Output format for NotebookLM presentation prompt: every slide should include slide title, key points, suggested visual/chart/layout, speaker notes when useful, final summary, and CTA/next action.
- Anti-generic gate: avoid empty slogans; every slide must have a clear message, visual suggestion, and ready-to-place copy.

NBS confirmation checklist must include a fully filled `簡報風格提示詞` section with:

```text
簡報風格提示詞：
- 預計頁數 / 報告時間：
- 簡報角色：
- 發表場景：
- 目標受眾：
- 講者語氣與人設：
- 核心 CTA：
- 簡報目的 / 類型：
- 大綱架構：
- 視覺風格：
- 頁面輸出格式：
- Speaker Notes：
- 素材保留重點：
- 敏感資訊處理：
- 禁止加入內容：
```

Do not ask the owner to fill these fields when source materials already reveal enough context. Infer them and present them for confirmation.
