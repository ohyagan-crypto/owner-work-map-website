# NBS Presentation Style Prompt Upgrade - 2026-07-10

Owner correction: the NBS flow is acceptable, but PPTX presentation prompts must be richer and more design-directed.

For future NBS tasks that include `PPTX` or `簡報`, add a dedicated `簡報風格提示詞` section to the confirmation checklist and to the NotebookLM presentation prompt.

Required upgrades:

- Define the deck audience and usage context: customer onboarding, tutorial SOP, internal training, sales briefing, course handout, executive summary, or product education.
- Define visual direction: clean tech brand, premium education, warm customer-service guide, operational SOP, product training, or executive briefing.
- Require a clear slide architecture: cover, agenda, section dividers, step-by-step teaching slides, key reminders, common mistakes, privacy/safety notes, recap, and next actions.
- Make layout requirements explicit: one main idea per slide, concise title, 3 to 5 bullets maximum when possible, strong hierarchy, enough white space, no dense paragraph walls.
- Ask for teaching devices when useful: numbered steps, flow charts, checklist pages, do/don't tables, before/after comparisons, decision trees, timelines, and callout boxes.
- Require consistent visual system: readable mobile-friendly type, high contrast, restrained brand colors, consistent accent color, and no cluttered decorative background.
- For multi-material tutorial decks, preserve source order and make the whole deck feel like one unified SOP instead of separate image explanations.
- Keep source-faithfulness: do not invent brands, product claims, prices, accounts, screenshots, or unsupported operational steps.
- Mask or genericize sensitive information: API tokens, credentials, private IDs, phone numbers, QR codes, cookies, and account secrets.

Preferred confirmation checklist wording:

```text
簡報風格提示詞：
- 受眾：
- 使用場景：
- 視覺方向：
- 頁面結構：
- 版面規則：
- 教學元件：
- 敏感資訊處理：
- 不可加入：
```

When generating NBS decks, quality is not only page count and language. The PPTX must read like a usable, polished presentation with teaching structure and visual direction.

## 2026-07-10 Owner Correction: Material-Derived Style Prompts

The assistant must analyze the provided materials and decide the needed presentation style prompts independently. Do not ask the owner to provide the style prompt when the source materials already reveal the audience, usage context, visual tone, and teaching goal.

For every NBS task that includes a presentation:

- First inspect all current materials as M01, M02, M03, etc.
- Identify the material category: tutorial SOP screenshots, customer onboarding, restaurant/order flow, product demo, platform error diagnosis, course material, sales/product education, or executive/internal report.
- Infer the deck style from the material, not from a fixed generic template.
- Add a completed `簡報風格提示詞` section to the confirmation checklist. It must not be blank.
- The style prompt must include audience, usage scenario, visual direction, page structure, layout density, teaching components, privacy handling, and forbidden additions.
- For multi-material decks, define one shared style system across the whole deck: palette, typography feel, annotation language, step labels, icon/callout style, layout density, and slide order.
- If source screenshots contain red frames, arrows, numbered markers, QR codes, tokens, usernames, buttons, or UI states, decide what to preserve, simplify, blur, or describe textually.
- For BotFather / Telegram bot tutorial materials, default to a clean onboarding SOP style: Blue Star brand, mobile-first teaching, step-by-step cards, red callouts kept as instructional cues, API tokens masked, no invented bot credentials.
- For restaurant LINE ordering materials, default to a practical customer instruction deck: storefront/ordering context, QR code privacy handling, simple scan-order-pay flow, and no guessed QR destination.
- For SD/storyboard materials, default to a production planning deck: timeline, scene table, role setup, product shot logic, risk notes, and final prompt handoff.

Owner-facing rule: when the owner says the style prompt should be stronger, reply with the concrete style analysis and updated prompt rules, not with a vague agreement.
