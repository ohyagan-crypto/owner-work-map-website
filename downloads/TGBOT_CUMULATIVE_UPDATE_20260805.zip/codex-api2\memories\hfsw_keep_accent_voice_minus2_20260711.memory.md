# HFSW Keep This Accent And Voice -2 - 2026-07-11

SUPERSEDED CORRECTION:

The owner clarified on 2026-07-11 that `人聲-2` was not a dB or volume instruction. It means `口音編號2`.

Use `C:\Users\你的使用者名稱\.codex-bot3\memories\hfsw_voice_numbering_20260711.memory.md` instead of this file for current HFSW behavior.

Current rule:

- `口音編號1` = previous approved HFSW accent.
- `口音編號2` = `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_133100.mp4`.
- Do not lower volume unless the owner explicitly says `降分貝`, `降低音量`, `音量-2`, or `-2dB`.

The older rules below were based on the mistaken dB interpretation and must not be used as the active baseline.

Owner instruction from TG3:

- Replied video: `C:\Users\你的使用者名稱\tg-openai-bot-3\telegram_uploads\telegram_replied_video_20260711_133100.mp4`
- Instruction: `這版口音也保留 人聲-2`

Rule:

1. This replied video is an approved HFSW accent reference.
2. Preserve this accent, speech speed, subtitle timing, visual timing, and BGM loop unless the owner explicitly asks to change them.
3. `人聲-2` means lower the dominant voice/narration about 2 dB with mix-only processing, not re-TTS and not changing the narrator.
4. If stems are available, reduce only the narration stem by 2 dB and keep BGM unchanged.
5. If only the final mixed video is available, use center-vocal attenuation or the closest non-destructive mix method, then validate that BGM still starts at 0 seconds and loops through the whole video.
6. Completed output for this instruction:
   `C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260711_hfsw_voice_minus2\zhang_fei_hfsw_keep_this_accent_voice_minus2_20260711.mp4`

Validation baseline:

- Duration: 300 seconds
- Size: 720x1280
- Audio: AAC stereo
- Visuals: Zhang Fei historical story video, bottom Kai-style Traditional Chinese captions
- Processing intent: preserve accepted accent and reduce voice prominence by about 2 dB
