# Imagegen Only Owner Preference - Superseded

Active from 2026-06-16.

- Superseded on 2026-06-24 and reinforced on 2026-07-01.
- This old preference must not be used for current routing.
- Current rule: all image-related work must use Lanxin AI / 聚合平台 only, including image generation, poster generation, image edits, style changes, revisions, variants, teaching images, covers, thumbnails, banners, product images, visual design, and "make it again" continuation tasks.
- Do not use local `imagegen`, built-in image generation, local scripts, Canvas, PPT, PS, ImageMagick, browser screenshots, crops, previews, HTML/SVG composition, or any other substitute workflow for image deliverables.
- If the request is incomplete and no image prompt or edit target is available, ask briefly for the exact image content instead of generating from assumptions.
- Save verified Lanxin platform originals under `C:\Users\RECEIVER\Desktop\龍蝦記憶` or `C:\Users\RECEIVER\lanxin_task\out`, then return them to Telegram by document mode.
- Keep Telegram-facing replies concise, clean Traditional Chinese, and avoid raw logs or technical wrappers.
