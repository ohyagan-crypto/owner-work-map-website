# IMS Lanxin Delivery Preference - 2026-06-26

When handling IMS / Lanxin AI image or poster jobs for the owner:

- Use Lanxin AI / 聚合平台 only for image generation.
- If generation appears stuck or the page is stale, refresh the Lanxin page and retry the same confirmed prompt only after the user has confirmed retry.
- Never use old gallery images, blank images, screenshots, crops, or compressed previews as final delivery.
- Download and verify the original image file before delivery.
- Validate that the file exists, opens, is non-empty, and has real image dimensions.
- Report the true output dimensions honestly. Do not claim 8K if Lanxin returns a lower original size such as 2160x3840.
- Save verified outputs under `C:\Users\你的使用者名稱\lanxin_task\out\` when possible.
- For Telegram delivery, use document/file mode and prefer a short ASCII filename to avoid garbled filenames, for example `ai-tech-poster-YYYYMMDD.png`.
- If the owner says the filename is garbled or the image was not received, do not regenerate first. Re-check the existing verified file, rename/copy it to a safe ASCII filename if needed, and resend it as a document.
- Only regenerate if the verified local original is missing, invalid, corrupt, or the owner explicitly asks for a new generation.
