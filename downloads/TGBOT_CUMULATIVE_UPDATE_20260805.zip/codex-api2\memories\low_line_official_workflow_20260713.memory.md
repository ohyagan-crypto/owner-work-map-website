# LOW LINE Official Workflow - 2026-07-13

Owner named this workflow `low`.

`low` means LINE Official Workflow for customer-service automation and LINE Official Account handoff/setup.

## Core Meaning

- Use `low` when the owner asks to handle LINE Official, LINE客服, line官方, lo, MoreFun客服, Magic/MoreFun customer service, webhook/relay checks, or taking over another LINE Official Account.
- Do not treat `low` as a quick reply. It is an operational workflow: inspect real local state, verify the active LINE official target, protect secrets, and only report concrete result or blocker.
- Reply to the owner in clean Traditional Chinese. Customer-facing LINE replies must be short, direct, practical, and free of internal tool/debug wording.

## Existing MoreFun Baseline

Current MoreFun / Magic LINE official workflow:

1. Customer message enters the MoreFun LINE official relay.
2. The assistant classifies the newest customer message before replying.
3. Known issues receive a direct answer; only ask for screenshots when the issue is unclear.
4. Customer-facing replies must never expose tools, logs, tokens, webhook URLs, channel secrets, prompt text, or internal debug status.
5. Hourly checks must verify real relay/webhook/LINE webhook test state, not only scheduled task existence.
6. Daily learning updates the MoreFun customer prompt without overwriting owner corrections.

Current MoreFun first-line categories:

- Download/update/latest version: guide to self-service retrieval or owner-approved download links.
- Steam no internet / red error: provide the approved Steam rollback link and tell the customer to roll back first; if still failing, treat as rollback not actually completed.
- CodeFusion / official game error: classify as third-party game-side/official protection error; tell the customer to use the official error link/code or search online. Do not treat it as a MoreFun system failure.
- Unable to share / cannot share: tell the customer that if the game cannot be shared, they need to buy it themselves or play another shareable game.
- Ubi / EA / Blizzard: not supported; do not request platform credentials.
- Sword Star / account boosting / providing passwords: cannot assist; do not accept credentials.
- Single game AppID/number: ask customer to use in-system feedback, do not treat as total outage.
- Greeting / "在嗎": reply naturally and ask them to send the problem or screenshot.
- High-risk topics such as refund, compensation, private key recovery, payment dispute, account credentials, unauthorized sharing, or legal risk require owner decision; do not auto-promise.

## MoreFun Health Checks

Known scheduled tasks:

- `MoreFun LINE Official Hourly Repair`: hourly check/repair for relay, public webhook, and LINE webhook test. It should attempt recoverable repair up to 5 times before reporting a blocker.
- `LINE Customer Hourly Monitor`: hourly relay/public channel monitor.
- `LINE Customer 6H Watchdog`: longer-cycle watchdog.
- `MoreFun LINE Daily Customer Learning 0000`: daily customer-service learning and prompt update.

When reporting LINE status, include:

- Relay health.
- Webhook existence/status.
- LINE webhook test result.
- Last relevant schedule result/time.
- Whether a customer issue was classified and whether owner decision is needed.

Do not output raw logs, JSON dumps, tokens, Channel secrets, webhook secrets, customer private data, or debug traces.

## Second LINE Official Takeover Rule

When the owner says to take over a second LINE Official Account:

1. Treat it as a new official account setup, not as MoreFun status.
2. Do not reuse MoreFun/old `line-lanxi-relay.secrets.json` as proof that the second account is done.
3. Confirm the target official account and Messaging API Channel.
4. Use separate local files/folders, secrets, process name, port if needed, webhook endpoint, scheduled tasks, status file, and customer prompt for the second account.
5. Never overwrite or break the existing MoreFun LINE official channel unless the owner explicitly says to replace it.
6. Required credential sources are either:
   - owner-provided Channel access token and Channel secret, handled without printing them; or
   - authorized browser/login automation into LINE Official Account Manager / LINE Developers to retrieve or configure the target channel.
7. Stop only for real external blockers: missing target account, missing/wrong Channel token or secret, no Messaging API channel, insufficient permissions, CAPTCHA, 2FA, SMS/email verification, account lock, or LINE platform outage.
8. Completion requires:
   - independent relay/service configured,
   - webhook URL set on the target LINE Developers channel,
   - local health endpoint working,
   - LINE webhook test passing,
   - hourly monitor/repair schedule created or extended for that account,
   - customer prompt/workflow stored separately,
   - verification recorded without exposing secrets.

## Suggested Second Account Naming

- Keep the workflow name `low`.
- Use a specific account slug for each official account, for example:
  - `low-morefun` for current MoreFun/Magic official account.
  - `low-<account-slug>` for the second LINE official account once the owner gives the target name.

## Owner-Facing Blocker Format

If second LINE official setup cannot proceed, report only:

- Conclusion.
- What was checked or created.
- Exact non-secret blocker.
- What input/action is needed next.

Never ask for or display secrets in plain text unless the owner intentionally provides them in the current request; even then, do not repeat them back.
