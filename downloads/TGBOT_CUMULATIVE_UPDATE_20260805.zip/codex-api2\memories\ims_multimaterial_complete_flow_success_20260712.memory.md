# IMS Multi-Material Complete Flow Success - 2026-07-12

Owner confirmed the correct multi-material IMS flow after the Blue Star AI 4-step SOP image task.

Reusable flow:
1. Treat the current image batch as one unified IMS task, not separate replies.
2. Inventory all current-task materials in order and exclude unrelated older uploads.
3. Analyze each material, then make one cross-material judgment.
4. Put the final confirmation checklist at the end, after analysis and shared style direction.
5. After owner confirmation, do not ask again. Generate the complete batch through Blue Star.
6. Use the correct bot/channel identity. TG1 IMS uses the TG1 second aggregation profile when configured; do not use TG2/TG3 original aggregation profile.
7. Keep one coherent visual system across all outputs: same palette, typography, layout density, card/radius treatment, annotation language, brand wording, ratio, and filename order.
8. Download platform original PNG files, validate file existence, dimensions, order, and visual readability.
9. Deliver every final PNG to the same Telegram origin by document mode before reporting complete.

Successful example:
- Task: Blue Star AI 4-step mobile SOP style-change batch
- Source order: default browser, add to home screen, new chat, refresh model
- Output style: premium white tech background, blue-purple gradient, glassmorphism teaching cards, clear red boxes/arrows
- Output count: 4 PNG
- Completion required: all 4 generated, visually checked, and delivered by TG1 document mode.
