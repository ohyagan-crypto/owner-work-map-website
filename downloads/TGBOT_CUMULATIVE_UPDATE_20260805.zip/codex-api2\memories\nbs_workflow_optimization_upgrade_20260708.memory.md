# NBS Workflow Optimization Upgrade - 2026-07-08

## 目的

把 `nbs / NotebookLM` 流程從「有生成」升級成「可追蹤、可驗證、可完整交付」。

## 核心原則

1. 先鎖定標題與交付範圍，再開始任何生成或下載。
2. 生成、下載、驗證、Telegram 回傳四段分離，不能互相取代。
3. `PPTX`、`MP4`、`MP3` 必須獨立追蹤，任何一項缺件都不算完成。
4. 只有同一來源 Telegram、同一任務資料夾、同一 NotebookLM 來源鏈路，才算同一份交付。
5. `播放成功`、`看到卡片`、`已提交`、`local path` 都不是完成。

## 十點升級版

### 1. 任務定義前置鎖死

- 一開始就固定 `標題`、`RequestedOutputs`、`來源`、`交付 Telegram 對話`。
- 如果有多份成品，標題是唯一主鍵之一，不能做完才補。
- 所有後續檔名、工作紀錄、回傳內容都要帶標題或日期，避免混案。

### 2. 先建工作紀錄，再碰 NotebookLM

- 先建立 job record，再開 NotebookLM。
- 最少要寫入：`ChatId`、`NotebookHint`、`SourceSummary`、`RequestedOutputs`、`Language`、`BrowserProfile`、`ArtifactFolder`。
- 沒有工作紀錄，不進入生成。

### 3. 來源先驗證，再加入同一筆 Notebook

- 先確認來源類型：網頁、YouTube、檔案、圖片、純文字。
- 來源不清楚就先停，不邊做邊猜。
- 加入來源後，先確認 NotebookLM 真的看得到來源名稱或數量，再生成。

### 4. 輸出拆成三條獨立流水線

- `presentation_pptx`
- `video_summary_mp4`
- `audio_summary_mp3`

每一條都要有自己的：

- `generated`
- `downloaded`
- `validated`
- `delivered`

### 5. 生成後立即進下載與格式驗證

- 生成完成不等於完成。
- `PPTX` 要驗證為真 `.pptx`，可開，且頁數合理。
- `MP4` 要驗證可播放、格式正確、時長合理。
- `MP3` 要驗證真的是 `.mp3`，不是只停在播放器畫面。

### 6. 缺件優先補，不重新開新案

- 如果已經有一項完成，另一項缺失，視為同一工作流的補件。
- 先查 job record、NotebookLM 頁面、artifact folder、Downloads、Telegram delivery state。
- 只有在現有輸出無法修復時，才考慮重新生成。

### 7. Telegram 交付獨立成最後一關

- 只有驗證過的檔案才能回傳。
- 優先使用文件模式回傳原檔。
- `sent` 不是完成，只有 `delivery success` 且 `DeliveredFiles` 完整才算完成。

### 8. 失敗處理改成雙檢查、三停損

- 同一步失敗第 2 次，先查真實狀態，不要盲重試。
- 同一 blocker 第 3 次，直接回報具體卡點。
- 不把 CPU 靜止、畫面不動、播放器存在當作完成依據。

### 9. 命名規則固定化

- 建議檔名：
  - `NBS_presentation_YYYYMMDD.pptx`
  - `NBS_video_summary_YYYYMMDD.mp4`
  - `NBS_audio_summary_YYYYMMDD.mp3`
- Telegram-facing 檔名優先 ASCII，避免亂碼或顯示不清。
- 同日多份時加上 `HHMMSS` 或標題縮寫。

### 10. 最後回報必須同時交代標題、檔名、狀態

- 回報格式固定包含：
  - 標題
  - 已交付檔名
  - 還缺哪一項
  - 若未完成，真實 blocker 是什麼
- 如果交付數量少於預期，不可寫成完成。

## 硬門檻

完成 `nbs` 的條件必須同時滿足：

- NotebookLM 已生成對應內容。
- 檔案已從同一 NotebookLM 匯出或下載。
- 檔案已放入正確 task artifact folder。
- 格式、大小、頁數、時長、可讀性已驗證。
- 已回傳到同一 origin Telegram，且文件模式送達成功。
- 工作紀錄已更新 `OutputStatus`、`ValidationStatus`、`DeliveryStatus`、`DeliveredFiles`、`LastCheckSummary`。

## 失敗判定

- 任何一項缺件，整案都只能算 `partial`。
- `OutputStatus=completed` 不能單獨代表完成。
- 看到 NotebookLM 卡片、按播放、下載中、送出中，都不是最終交付。

