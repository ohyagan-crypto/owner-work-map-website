# 安裝與學習說明：幣安 Coin／台股 IMS／抖音陪跑／回覆方式

這是一個給其他 Codex 或 OpenClaw 一次學會的教學交接包。請接收端不要只解壓備份，要照下面順序讀完並安裝。

## 這包教什麼

1. `幣安coin`：Binance／OKX 熱門迷因幣、土狗幣、查詢 coin、Ave.ai 合約研究、風險判斷、必要時做 IMS 圖卡。
2. `台股IMS`：台股每日研究、官方資料與美股連動判斷、台股圖卡、非投資建議回覆規則。
3. `抖音陪跑`：每日 17:00 抖音帳號陪跑、短影音腳本、對標主題、每日不重複規則、台灣老闆 IP 定位。
4. `回覆方式`：乾淨繁體中文、主人稱呼、進度回報、檔案回傳、卡點處理、不可露出內部日誌或密碼金鑰。

## 安裝路徑

如果你是 Windows，請把本包的 `.codex\skills` 複製到：

`C:\Users\你的使用者名稱\.codex\skills\`

把本包的 `.codex\memories` 複製到：

`C:\Users\你的使用者名稱\.codex\memories\`

若你的環境是 OpenClaw 或 Linux，請放到該環境的 Codex home 下面，例如：

`~/.codex/skills/`

`~/.codex/memories/`

## 安裝原則

1. 只新增，不要粗暴覆蓋原本重要技能與記憶。
2. 如果同名技能已存在，先備份舊版，再比較內容。
3. 不要複製任何密碼、金鑰、cookie、登入資料、瀏覽器 profile。
4. 安裝後重啟 Codex、OpenClaw 或 Telegram bot，讓技能重新載入。
5. 重啟後用測試句確認技能是否會觸發。

## 接收端必讀檔案順序

1. `instructions/RECEIVER_SYSTEM_PROMPT.md`
2. `instructions/MEMORY_AND_BEHAVIOR_SUMMARY.md`
3. `.codex/skills/shamie-owner-reply-style/SKILL.md`
4. `.codex/skills/binance-coin-research/SKILL.md`
5. `.codex/skills/taiwan-stock-ims/SKILL.md`
6. `.codex/skills/douyin-peipao/SKILL.md`
7. `instructions/TOPIC_TRIGGER_INDEX.md`
8. `instructions/SAFETY_AND_SECRET_EXCLUSION.md`
9. `templates/` 內的三份輸出模板

## 觸發詞

### 幣安 Coin

- 幣安coin
- 幣安 coin
- Binance coin
- 查詢coin
- 查詢 coin
- 查coin
- 查詢call in
- 分析幣、研究幣、幫我看這個幣
- 幣名、合約地址、Ave.ai 連結、交易對地址

### 台股 IMS

- 台股ims
- 台股 IMS
- 台股研究
- 台股圖卡
- 幫我看台股
- 台股代號或產業研究

### 抖音陪跑

- 抖音陪跑
- 抖音日報
- 今天抖音腳本
- 找對標
- 幫我寫抖音短影音
- 抖音帳號陪跑

## 接收端工作標準

1. 主人下任務後，不要只回收到。
2. 可以做就直接做。
3. 需要外部最新資料時，要先查證。
4. 完成後要給成果、檔案、路徑、連結、或明確卡點。
5. 文件或圖片成果要回傳 Telegram 一次。
6. 遇到登入、驗證、付款、權限、2FA、安全提示，要停下回報。
7. 台股與幣圈都不能說保證獲利，必須標示研究與風險。

## 測試句

安裝重啟後，請測試：

1. `幣安coin`
2. `查詢coin PEPE`
3. `台股ims`
4. `今天台股怎麼看`
5. `抖音陪跑`
6. `找三個抖音對標，不要跟昨天重複`
7. `在嗎`
8. `好了沒`

## 測試通過標準

接收端要能回答：

1. 這三個技能各自做什麼。
2. 哪些記憶要先讀。
3. 什麼情況要查資料。
4. 什麼情況要停下問主人。
5. 怎樣回覆主人不會出現內部狀態與亂碼。
6. 產出成果後要如何回傳 Telegram。

## 最終驗收清單

- 已複製 skills。
- 已複製 memories。
- 已讀安裝說明。
- 已重啟 Codex／OpenClaw／Telegram bot。
- 已用測試句驗證。
- 回覆主人時使用乾淨繁體中文。
- 不會洩漏密碼、金鑰、cookie、token、登入資料。
- 不會把「收到」當成最終答案。
- 會在完成後回傳檔案或明確卡點。