# HFSW 工作流 - 2026-07-10

Owner naming: `hfsw` means the Hyperframes story video workflow.

Use `hfsw` when the owner asks for:
- `hfsw`
- `HFSW`
- Hyperframes story video workflow
- 關羽成功方式的同類長影片
- 先文案、再做圖、再 Hyperframes 合成的影片流程

Core rule:
`hfsw` is not SD / Seedance direct video generation. It is a script-first, image-second, Hyperframes-final video workflow.

Standard sequence:
1. Treat the task as a fresh workflow unless the owner explicitly says to reuse existing materials.
2. If no current materials are provided, do not invent or list M01/M02/M03. Start as a zero-material workflow.
3. First use the aggregation platform Claude 4.8 Opus to produce the complete video plan:
   - theme-specific narrative copy
   - natural voiceover script
   - scene segmentation
   - bottom caption structure
   - image prompt list for every scene
   - Hyperframes timing plan
   - suggested BGM and sound effects
4. Generate corresponding images from the Claude script and scene plan. Each image must match its own script segment, not generic atmosphere.
5. Use Blue Star / IMS for image generation when image credits are needed. Wait for owner confirmation before spending credits unless the active workflow explicitly allows automatic submission.
6. Put the generated images into a Hyperframes project. Hyperframes is the composition and animation source of truth.
7. Build the video in 9:16 by default unless the owner specifies otherwise. Use coherent style, scene motion, transitions, bottom captions, and image movement.
8. Generate natural voiceover MP3 from the approved script. The voiceover must actually explain the selected theme and match the target duration.
9. Mix voiceover with BGM and sound effects. Voice must remain clear and dominant.
10. Export MP4, then validate duration, dimensions, audio, subtitles, and visual content.
11. For Telegram-origin tasks, deliver the final MP4 only through the same originating bot/chat by document mode.

Quality standard:
- Script first, image second, Hyperframes third.
- Content must be specific to the requested theme.
- Do not use generic narration.
- Do not mix unrelated old materials into a new task.
- Captions stay at the bottom.
- Subtitle visual default after the 2026-07-10 Zhang Fei reference update: use large centered Traditional Chinese captions near the bottom, white fill, thick black outline, subtle black shadow, short phrase chunks, no top title banner, and no tiny captions. This matches the owner's reference image style: historical-storytelling subtitles that stay readable on phone screens.
- Voiceover should sound like a natural speaker or storyteller, not stiff reading.
- Voiceover default after the Zhang Fei approved version: use the more expressive male voice style from `zhang_fei_hfsw_20260710_revoice_expressive_yunjian_louder_tg.mp4`. It should have clear rises and falls, stronger pauses and emphasis, and a storytelling cadence. Use the louder 2026-07-10 remix level by default: human voice clearly forward, BGM/effects lowered enough that speech is easy to understand on phone speakers.
- Final completion requires MP4 export, validation, and same-origin Telegram delivery when available.

If the owner says to make a new Guan Yu style video with no materials:
- Do not analyze old classroom, skincare, OpenClaw, or character images.
- Start directly with Claude 4.8 Opus planning.
- Generate new matching images.
- Build and render in Hyperframes.

2026-07-10 latest owner-approved upgrade:
- Future `hfsw` videos should use the approved Zhang Fei final voice style by default: expressive Yunjian-style male storyteller, stronger rise-and-fall, clearer pauses and emphasis, voice-forward mix, BGM/SFX lowered under narration.
- Future `hfsw` subtitles should use the approved story subtitle style by default: 標楷體 / DFKai-SB when available, large Traditional Chinese captions near the bottom, centered, white fill, thick black outline, subtle black shadow, short phrase chunks, no tiny captions, no top title banner, no doubled burned-in captions.
- Future long-form `hfsw` scene cadence should change image/scene every 30 seconds by default. For a 300-second video, plan about 10 images/scenes instead of 7 images at 40-45 seconds each.
- Claude 4.8 Opus planning must output 30-second segments, each with narration, subtitle chunks, image prompt, BGM/SFX cue, and Hyperframes motion plan.
- Validate final output for duration, dimensions, audio clarity, subtitle readability, 30-second scene cadence, and same-origin Telegram document delivery.
