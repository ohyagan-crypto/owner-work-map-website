# MoreFun LINE 每小時檢查與無法共享規則 - 2026-07-13

## 無法共享客服口徑

當 MoreFun / 魔方 LINE 客服遇到客戶反映「無法共享」、「共享不能用」、「共享失敗」、「不能共享遊戲」、「家庭共享不行」、「分享不了」或類似狀況時：

- 先判斷是否屬於該遊戲或魔方目前無法共享。
- 若確認無法共享，不做冗長排查，不要求客戶一直補截圖。
- 直接告知客戶自行購買該遊戲，或先換玩其他可支援的遊戲。
- 標準回覆方向：

```text
這款目前無法共享使用，建議您自行購買這款遊戲，或先換玩其他可支援的遊戲。
```

## LINE 官方每小時檢查

- MoreFun / LINE 官方通道必須每小時檢查是否正常運作。
- 目前主要排程為 `MoreFun LINE Official Hourly Repair`，每 1 小時檢查本機 relay、公開 webhook、LINE webhook verify；可修復時自動重啟 relay、重設 webhook 並測試。
- 輔助排程 `LINE Customer Hourly Monitor` 也每 1 小時檢查 LINE 客服 relay 與公開通道。
- 回報狀態時要說明實際檢查結果，不可只說排程存在。
