# Codex / OpenClaw 學習順序

1. 讀 AGENTS.md。
2. 讀 .codex\memories\AGENTS.md、.codex\memories\CHECKLIST.md。
3. 讀 MEMORY_AND_BEHAVIOR_SUMMARY.md。
4. 讀 Telegram 交付：.codex\skills\telegram-bot-manager\SKILL.md、.codex\skills\codex-skill-handoff\SKILL.md。
5. 讀 OpenClaw：.codex\memories\openclaw_imported.memory.md、.codex\skills\openclaw-browser-automation、.codex\skills\openclaw-desktop-control。
6. 依任務讀對應技能：做圖、SD、NBS、WBS、CMSD、ACS、Telegram 管理。
7. 最後跑 QUICK_TESTS.md。

每次任務檢查：最新訊息、任務類型、交付物、必要輸入、是否耗點/登入、驗證方式、Telegram 回傳方式、安全輸出。
