# Imagegen Poster Auto Skill Memory - Disabled

- Legacy Codex built-in `imagegen` / `imagegen-poster-telegram` routing is disabled.
- For any future image-related request, including 做圖、做海報、生成圖片、海報、封面、縮圖、Banner、商品圖、人物圖、修圖、改圖、圖片變體, use Lanxin AI / 聚合平台 only: https://lx.lanxinai.com/ .
- Do not switch to built-in imagegen, local scripts, Canvas, PPT, PS, ImageMagick, browser screenshots, crops, previews, or other substitute workflows.
- Always prepare a confirmation checklist first, wait for the owner’s explicit confirmation, then submit to Lanxin.
- After completion, download and validate the original platform image, then deliver by Telegram document mode.
- Keep owner-facing messages clean Traditional Chinese; never expose raw logs, JSON, tool status, internal English status, tokens, sessions, traces, or approval commands.
