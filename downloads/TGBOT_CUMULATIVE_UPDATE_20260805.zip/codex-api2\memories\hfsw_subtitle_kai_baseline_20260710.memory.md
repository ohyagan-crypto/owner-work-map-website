# HFSW Subtitle Kai Baseline - 2026-07-10

Owner requested the approved Zhang Fei HFSW story subtitle style to be changed to 標楷體.

Latest delivered reference:
`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw\hf_20260710\export\zhang_fei_hfsw_20260710_story_subtitle_kai_tg.mp4`

Use this as the current default subtitle style for future `hfsw` historical-storytelling videos unless the owner asks otherwise:

1. Font: 標楷體 / DFKai-SB.
2. Large Traditional Chinese captions near the bottom, centered.
3. White fill, thick black outline, subtle black shadow.
4. Short phrase chunks matched to the narration.
5. No top title banner and no tiny captions.
6. Do not overlay on a video that already has burned captions; start from the clean voice/BGM base when changing subtitle style.
7. Validate by extracting frames and checking that captions are readable, bottom-positioned, and not doubled.

