# Lanxin Two-Hour Login Check Rule

Created: 2026-07-02

Owner rule:

- 聚合平台 / Lanxin / 藍星 AI refers to `https://lx.lanxinai.com/`, and routine login checks should use `https://lx.lanxinai.com/ai-image`.
- This is a background login-maintenance rule, separate from image generation polling or task-progress polling.
- The platform login state must be checked every 2 hours to verify that the account remains logged in and usable.
- On this Windows machine, use the fixed browser profile `C:\Users\你的使用者名稱\lanxin_task\browser-profile-auto` for routine checks.
- The Windows scheduled task is named `Lanxin Login Check Every 2 Hours` and runs `C:\Users\你的使用者名稱\lanxin_task\lanxin_login_watch.ps1`.
- Before reporting a platform check as blocked, inspect the scheduled task, status files, browser state, and current login page, then repair recoverable issues when safe.
- Do not treat a transient script error, encoding issue, stale browser profile lock, or one failed attempt as the final result.
- Report a blocker only for real external blockers: CAPTCHA, SMS/email code, 2FA, passkey/biometric approval, wrong credential, platform outage, account security lock, or other owner-required action.
- Never expose or transfer passwords, API keys, tokens, cookies, browser profiles, credential stores, raw logs, or screenshots containing secrets.

