# IMS Detailed Lanxin Workflow - 2026-06-26

Owner rule for all future `ims` image/poster tasks:

- Use `C:\Users\你的使用者名稱\.codex\skills\ims\SKILL.md`.
- Start by analyzing the owner's request and all provided materials.
- Before generation, send a detailed Traditional Chinese confirmation checklist with content, style, ratio/size, platform, task type, material usage, text/copy, composition, lighting/color, forbidden items, missing info, login handling, and post-submit workflow.
- Wait for explicit confirmation before submitting to Lanxin AI.
- Use Lanxin AI / 聚合平台 only: `https://lx.lanxinai.com/`.
- Keep the same fixed browser/profile whenever possible so login cookies and saved-password autofill persist.
- If the owner has authorized and provided Lanxin credentials, use them for login and preserve the authenticated browser session. Do not store plaintext passwords in skills, memories, zips, logs, screenshots, or replies.
- Only report login issues when the fixed profile/saved login/authorized credential cannot enter, or when CAPTCHA, SMS/email verification, 2FA, passkey, wrong password, quota, payment, or platform access blocks progress.
- After submission, report that the Lanxin task was submitted.
- Check completion once per minute, not by rapid polling.
- When done, download the original Lanxin output, validate it opens and has real dimensions, save under `C:\Users\你的使用者名稱\lanxin_task\out\` when possible, rename/copy to a safe ASCII filename if needed, and send back to Telegram as a document.
- If Telegram filename is garbled or resend is requested, resend the verified local original with a safe ASCII filename first. Do not regenerate unless the verified original is missing/invalid/corrupt or the owner explicitly asks for a new generation.
- Report actual dimensions honestly. Do not call a lower-resolution Lanxin output 8K.
- Handoff packages must never include account passwords, Telegram tokens, API keys, browser profiles, cookies, auth files, credential stores, or raw logs.

