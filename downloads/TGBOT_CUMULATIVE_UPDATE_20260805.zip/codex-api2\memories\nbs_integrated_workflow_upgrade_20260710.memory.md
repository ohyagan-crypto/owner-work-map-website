# NBS Integrated Workflow Upgrade - 2026-07-10

Owner correction: upgrade the whole `nbs` workflow together, not only the presentation style prompt.

Future NBS tasks must use one integrated flow:

1. Identify requested outputs. Default `nbs` means PPTX + MP4 + MP3 unless the owner explicitly limits the deliverables.
2. Inventory every current-task source first. Assign M01, M02, M03, etc.; include images, captions, files, URLs, text, PDFs, audio, and video.
3. Produce one unified source diagnosis before the confirmation checklist:
   - material category and topic
   - intended audience and use case
   - source order and cross-source story
   - sensitive data and privacy risks
   - NotebookLM add method
   - what PPTX, MP4, and MP3 should each emphasize
4. Confirmation checklist must include:
   - `來源清單`
   - `素材統一分析`
   - `成品清單`
   - `語言`
   - `簡報風格提示詞`
   - `影片摘要提示方向`
   - `語音摘要提示方向`
   - `NotebookLM 筆記本`
   - `驗證方式`
   - `自動檢查計畫`
   - `交付方式`
   - `可能卡點`
5. PPTX prompt must use the NotebookLM prompt-site modules: slide count/minutes, speaker role, audience, scenario, tone/persona, CTA, purpose type, outline framework, visual style, slide output format, speaker notes, source cues, sensitive-data masking, and forbidden additions.
6. MP4 prompt must request Traditional Chinese, Taiwan wording, source-faithful summary flow, material-specific visual emphasis, and no unsupported inventions.
7. MP3 prompt must request Traditional Chinese, Taiwan wording, natural host/teacher briefing voice, practical takeaways, clear sections, and no reading of raw secrets or private identifiers.
8. After confirmation, add all approved sources to the same NotebookLM notebook, verify source count/names, generate requested cards, create/update the job record, actively poll real card/download/artifact state, download/export, validate, and deliver each final file to the exact Telegram origin by document mode.
9. Completion requires every requested output in `DeliveredFiles`, each file validated, and same-origin Telegram delivery completed. Playback, visible cards, downloads without validation, local paths, or partial delivery are not completion.

This memory complements the main skill at `C:\Users\你的使用者名稱\.codex\skills\nbs\SKILL.md`.
