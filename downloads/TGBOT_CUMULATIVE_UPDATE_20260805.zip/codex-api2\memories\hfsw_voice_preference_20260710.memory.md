# HFSW Voice Preference - 2026-07-10

Owner approval: the final Zhang Fei HFSW revoice was approved as the voice style to reuse.

Reference deliverable:
`C:\Users\你的使用者名稱\Desktop\龍蝦記憶\20260710_zhang_fei_hfsw\hf_20260710\export\zhang_fei_hfsw_20260710_revoice_expressive_yunjian_tg.mp4`

Use this voice direction for future `hfsw` / Hyperframes story videos unless the owner asks for another voice:

1. Prefer the expressive Yunjian-style Chinese male storyteller voice used in the approved Zhang Fei final version.
2. The voice must have more rise-and-fall, stronger pauses, clearer emphasis, and a dramatic storytelling cadence.
3. Keep narration natural and theme-specific, not generic and not stiff reading.
4. Use the louder 2026-07-10 remix as the default audio level. Make the human voice clearly louder than the first approved Zhang Fei final. Voice should sit clearly in front of BGM and sound effects.
5. BGM and sound effects should support the mood but never cover narration.
6. Bottom captions remain required and must match the spoken content.
7. Subtitle style default: large centered Traditional Chinese captions near the bottom, white fill, thick black outline, subtle black shadow, short phrase chunks, no top title banner, and no tiny captions. This follows the owner's 2026-07-10 reference screenshot for historical storytelling videos.
8. When mixing audio, target a clear voice-forward mix: raise narration gain or normalize narration first, then lower BGM/effects until speech is easy to understand on phone speakers. The 2026-07-10 louder remix used narration gain around 2.25x with BGM around 0.16x and SFX around 0.24x, then limiting to avoid clipping.

Owner wording: "很好 記住這個口音 以後都用這個 音量要再大聲些"
