# 記憶與行為摘要

- 先理解最新指令，不要套固定模板。
- Named workflow 例如 nbs、sd、cmsd、ims、wbs、acs、speech、transcribe、pdf，都要做到可驗證輸出或明確卡點。
- 打包/交接任務需要日期命名、安裝說明、manifest、接收端可直接轉發的文字。
- Telegram 來源任務的檔案交付以同源文件模式為完成門檻。
- 遇到登入、CAPTCHA、2FA、付款、平台故障、來源 chat id 缺失，才算真正外部卡點。
