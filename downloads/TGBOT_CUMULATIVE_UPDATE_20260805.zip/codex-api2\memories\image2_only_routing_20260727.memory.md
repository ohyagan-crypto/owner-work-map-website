# IMAGE2-only image routing - 2026-07-27

Owner's latest rule overrides older image memories:
- Every built-in image, poster, cover, tutorial image, product image, and image revision uses mcdesign-image2.
- Use only IMAGE2_PROVIDER_N API channels, in configured order.
- IMS workflow is removed and must not be triggered.
- Do not use Lanxin browser generation, imagegen, or another image provider for image generation.
- Preserve paid-action confirmation and same-origin delivery rules.