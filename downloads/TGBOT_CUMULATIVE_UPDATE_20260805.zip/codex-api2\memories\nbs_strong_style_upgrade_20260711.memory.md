# NBS Strong Style Upgrade - 2026-07-11

Owner correction: NBS workflow must support a stronger style version and apply it across the whole package, not only PPTX.

For future NBS tasks:

- Add `風格強度分級` to every PPTX confirmation checklist: `低 / 中 / 高 / 極強`.
- Infer style intensity from sources and task purpose. Do not ask the owner to choose when the materials are enough.
- Strong visual directions may include `硬核工業`, `黑科技發布會`, `戰情室`, `實驗室拆解`, `招商路演`, and `短影音爆款感`.
- For sales, onboarding, product, course, recruitment, or agent pitch materials, each relevant slide should explain:
  - `觀眾看到什麼`
  - `主播說什麼`
  - `助播做什麼`
  - `這頁如何推動成交`
- If the task is not sales-oriented, translate the same logic into how each page helps the learner complete the task.
- When materials involve video, tutorial operation, product demo, course, scenes, or short-video planning, add `鏡頭腳本提示`:
  - wide/medium/close-up/product close-up/hand operation/UI over-the-shoulder
  - tap, swipe, menu open, copy/paste, product texture, product operation, result confirmation
  - narration, operation sound, product sound, classroom ambience, transition point
- For course signup, agent recruitment, brand pitch, product sales, or cooperation materials, add pitch pages when supported:
  - opportunity, problem, solution, credibility, cooperation path, authorized scarcity, CTA, follow-up flow.
- MP4 and MP3 must follow the same intensity as PPTX:
  - MP4: stronger hook, section rhythm, transition, final CTA.
  - MP3: host-like narration with conclusion, structure, key reminders, and clear closing.
- Validation must include style quality, not only format:
  - intensity matches checklist
  - each slide has a purpose
  - deck has a source-derived visual system
  - teaching/sales pages have next steps
  - no unsupported claims or invented data
- If a high/extreme style deck is too bland and NotebookLM can revise in the same notebook, revise/regenerate before delivery.
- Strong style never permits fabricated specs, price, lifespan, certification, sales numbers, official partnerships, user counts, medical claims, or platform abilities.

Add these fields to `簡報風格提示詞` when relevant:

```text
- 風格強度分級：
- 視覺攻擊性方向：
- 成交/教學推進邏輯：
- 主播/助播分工：
- 鏡頭腳本提示：
- 招商/轉換頁規劃：
- MP4/MP3 同步節奏：
- 強烈但不造假限制：
```
