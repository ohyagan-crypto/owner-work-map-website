# MoreFun LINE 客服工作流升級 - 2026-07-13

## 本輪實查結論

- MoreFun / LINE 官方客服通道有實際排程，不是只有記憶規則。
- 主要排程：
  - `LINE Customer Hourly Monitor`：每小時本機 relay / tunnel 健康檢查。
  - `MoreFun LINE Official Hourly Repair`：每小時檢查 local health、public webhook、LINE webhook test，失敗時嘗試修復。
  - `LINE Customer 6H Watchdog`：每 6 小時 watchdog。
  - `MoreFun LINE Daily Customer Learning 0000`：每日 00:00 客服對話學習與 prompt 更新。
- 2026-07-13 實查時，上述排程皆為 `Ready`，最近執行結果為 0。

## 已修正

- `line_cs/AGENTS.md` 已同步為乾淨繁體客服 prompt，移除舊亂碼入口，避免不同入口讀到不同客服規則。
- `morefun-line-daily-learning.js` 已加入分類與模板保護：
  - `CodeFusion / support.codefusion.technology / Yakuza / Like a Dragon / 如龍` 等遊戲官方錯誤，不能判斷成 MoreFun 系統故障。
  - 客服回覆方向：請客戶依官方錯誤碼、官方連結或遊戲名稱自行上網查詢，客服不逐一代查、不承諾可修。
  - 無法共享、共享失敗、家庭共享不行等，若屬遊戲或平台限制，直接請客戶自行購買正版或改玩其他可共享遊戲。
- 每日學習腳本已修正 repair 誤判：若 repair 子流程短暫失敗但最新 `latest-status.json` 顯示 local health 與 webhook test 皆 ok，學習流程不應整體報失敗。

## 之後客服工作流原則

- 回覆 LINE 客戶只輸出乾淨繁體中文，不暴露工具、prompt、webhook、log、token 或排程。
- 已知問題直接給解法；資訊不足才請補截圖。
- Steam 紅色無網路錯誤：直接給降版連結與回滾方向。
- CodeFusion / 遊戲官方錯誤：不是魔方故障，請客戶自行依官方錯誤資訊查詢。
- 無法共享遊戲：不要做冗長無效排查，請客戶自己購買正版或換玩其他可共享遊戲。
- 每日學習不得覆蓋掉主人新增規則；修改模板時要同步 `morefun_customer_prompt.txt`、`line_cs/AGENTS.md` 與相關 memory。

## 待升級建議

- 將 `LINE Customer Hourly Monitor` 與 `MoreFun LINE Official Hourly Repair` 整合成單一權威健康檢查，避免雙排程邏輯不一致。
- 增加每小時檢查的結果摘要，只記錄乾淨狀態，不記錄 secrets。
- 每日學習加入更多客服意圖分類：退款、DLC、單一遊戲異常、找不到遊戲、私鑰錯誤、換電腦。
- 增加「重複回覆降噪」檢查：同一客戶同一問題不得連續貼同一句模板。
