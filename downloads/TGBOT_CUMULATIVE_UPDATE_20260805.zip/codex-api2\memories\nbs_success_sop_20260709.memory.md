# NBS 成功 SOP 記憶 2026-07-09

主人要求記住這次成功的 NBS 流程，之後遇到 `nbs`、NotebookLM 簡報、影片摘要、語音摘要或完整 NBS 套件時，優先依照本 SOP 執行。

## 成功案例證據

- 任務資料夾：`C:\Users\Administrator\MiniNewBridge4\tasks\nbs_20260709_lanxing_ai_mobile_guide`
- 成品資料夾：`C:\Users\Administrator\MiniNewBridge4\nbs-downloads\nbs_20260709_lanxing_ai_mobile_guide`
- NotebookLM 筆記本：`https://notebooklm.google.com/notebook/2817c5f6-ceaa-4816-8e92-4da842bc59e2`
- 來源：4 張 Telegram 圖片，整理成 `source.md` 後加入 NotebookLM。
- 語言：所有 NotebookLM 生成前都確認為 `中文（繁體）`。
- 交付結果：
  - `Bluestar_AI_Mobile_Quickstart.pptx`，15 頁，已驗證並送出。
  - `NBS_audio_summary_20260709.mp3`，約 18 分 03 秒，M4A 轉 MP3 後驗證並送出。
  - `NBS_video_summary_20260709.mp4`，約 5 分 39 秒，MP4 驗證後送出。
- `job.json` 最終狀態必須是 `deliveryStatus=delivered_all`，三項 `outputStatus` 都是 `delivered`。

## 固定執行 SOP

1. 收到 NBS 任務時，先確認主人指定的輸出：完整 NBS 預設為簡報 PPTX、影片摘要 MP4、語音摘要 MP3 三項。
2. 若來源是多張圖片，必須逐張理解並合併整理，不可只看其中一張；把可讀內容、畫面順序、操作流程與重點整理成一份 NotebookLM 來源文件。
3. 使用固定 NBS Chrome：`C:\Program Files\Google\Chrome\Application\chrome.exe`、`C:\Users\Administrator\AppData\Local\Google\Chrome NBS User Data`、`Profile 1`、控制端口 `http://127.0.0.1:9444`，帳號為 `[NBS_GOOGLE_ACCOUNT]`。
4. 在 NotebookLM 建立或沿用同一個筆記本，把整理後的來源加入同一個筆記本。
5. 生成簡報、影片摘要、語音摘要前，都必須確認或設定語言為 `中文（繁體）`；無法確認語言時要停止回報，不可產生英文成品。
6. 簡報完成後，從 NotebookLM 原生下載 PowerPoint，不可用自製 PPT 或截圖替代；驗證至少 15 頁、PPTX 可作為 ZIP 開啟、內含 `ppt/slides/slide*.xml`，並抽查繁體中文內容。
7. 語音摘要完成後，從同一個 NotebookLM 卡片下載原始音訊；如果是 M4A，先轉成 MP3，再用 `ffprobe` 驗證可播放、時長正常，最後只交付 MP3。
8. 影片摘要完成後，從同一個 NotebookLM 卡片的 `更多` 選單下載；若一般下載事件沒有被捕捉，使用 Chrome CDP `Browser.setDownloadBehavior` 並監聽下載進度，完成後改成乾淨 ASCII 檔名 `NBS_video_summary_YYYYMMDD.mp4`。
9. 影片必須用 `ffprobe` 驗證為可播放 MP4，且有 video/audio stream；必要時確認解析度、時長、編碼，例如本次成功檔案是 h264/aac、1280x720、約 338.872 秒。
10. 任何成品只要完成並驗證通過，就立刻用 Telegram 文件模式回傳一次，不要等整包全部完成才一起送。
11. 每送出一項成品後，更新 `job.json` 的 `downloadedFiles`、`deliveredFiles`、`outputStatus` 與 Telegram 訊息編號。
12. 完整 NBS 最終回覆前，必須再次核對三件事：檔案存在、驗證通過、Telegram 已送出。三項都完成後才可設為 `deliveryStatus=delivered_all`。
13. 最終回覆必須列出已交付的 PPTX、MP3、MP4 檔名與核心驗證結果；如果少一項，不可說完成，要繼續補送缺少項。

## 成功關鍵

- 不把播放、顯示已就緒、下載中、只有本機路徑當成完成。
- 下載失敗時先檢查任務資料夾與系統下載資料夾，再改用同一 NotebookLM 卡片的下載來源修復。
- 影片與語音都必須是 NotebookLM 原生輸出或同一輸出的下載修復，不可用本機自製替代。
- 檔名面向 Telegram 優先使用乾淨 ASCII，避免中文檔名或特殊字造成傳送問題。
- 交付只傳一次；若補送缺失檔案，要只補送缺的那一項。

