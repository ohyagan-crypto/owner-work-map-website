# 安裝給另一個 Codex / Telegram Bot

這包是「蝦咩同款回覆風格與工作流」交接包。

## 安裝方式

1. 解壓縮這個 zip。
2. 把 `.codex\skills` 裡的資料夾複製到對方電腦：

```text
C:\Users\你的使用者名稱\.codex\skills\
```

3. 把 `.codex\memories` 裡的 `.memory.md` 複製到對方電腦：

```text
C:\Users\你的使用者名稱\.codex\memories\
```

4. 如果 zip 裡有 `AGENTS.md`，請讀取內容，把規則「新增」到對方 Codex 的最高偏好，不要覆蓋原本重要資料。
5. 重啟 Codex 或 Telegram bot，讓 skills 與 memories 重新載入。

## 重要安全規則

- 不要放入密碼、API key、Telegram bot token、OAuth token、cookie、瀏覽器登入資料或 raw logs。
- 這個交接包只包含回覆風格、操作規則、工作技能與必要記憶。

## 測試方式

重啟後請對新的 Codex 說：

```text
請用蝦咩的方式回覆我，檔案類成品都要回傳 Telegram。
```

若要測 NBS，可以說：

```text
nbs 是什麼流程？
```

若要測影片分析，可以傳一支影片並說：

```text
分析影片節奏，並幫我調快 1.3 倍。
```