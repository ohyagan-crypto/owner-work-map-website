# NBS 詳細完整工作流安裝指南

建立日期：2026-07-10

這是一包給另一個 Codex、OpenClaw 或 Telegram bot 學習 NBS / NotebookLM 工作流的完整教學包。接收端不要只複製檔案，必須讀完本指南、主技能與記憶摘要後再回覆主人已學會。

## 安裝位置

請解壓縮本包，將 `.codex\skills\` 內的資料夾複製到接收端：

```text
C:\Users\你的使用者名稱\.codex\skills\
```

將 `.codex\memories\` 內的記憶檔複製到：

```text
C:\Users\你的使用者名稱\.codex\memories\
```

複製完成後，必須重啟 Codex、OpenClaw 或 Telegram bot，讓技能索引重新載入。

## 必讀順序

1. 讀本檔。
2. 讀 `NBS_COMPLETE_WORKFLOW.md`。
3. 讀 `MEMORY_AND_BEHAVIOR_SUMMARY.md`。
4. 讀 `.codex\skills\nbs\SKILL.md`，這是唯一主 NBS 技能。
5. 視需要讀輔助技能：`notebooklm-source-builder`、`notebooklm-presentation-prompt`、`nbs-media-summary-pack`、`nbps`、`nbvs`。

## 觸發詞

收到以下任一需求時，啟動 NBS 工作流：

- `nbs`
- `NotebookLM`
- `簡報`
- `影片摘要`
- `語音摘要`
- `完整 NBS`
- 把網站、YouTube、文件、圖片、海報、文字做成 NotebookLM 成品
- 主人問 NBS 成品好了沒、少了 MP3、少了影片、少了簡報、怎麼還沒回傳

`nbps` 代表只做語音摘要，`nbvs` 代表只做影片摘要，但實際流程仍走統一 `nbs` 技能。

## 固定瀏覽器與帳號

接收端要依本機實際環境調整；在主人這台電腦的成功設定是：

```text
Chrome: C:\Program Files\Google\Chrome\Application\chrome.exe
使用者資料：C:\Users\Administrator\AppData\Local\Google\Chrome NBS User Data
Profile：Profile 1
控制端口：http://127.0.0.1:9444
NotebookLM：https://notebooklm.google.com/
```

不得使用臨時瀏覽器、無痕模式或新 profile 取代已登入環境。遇到登入、選帳號、密碼、CAPTCHA、2FA、付款、權限或安全提示，要立刻停止並回報主人。

## 核心原則

- 所有 NBS 成品必須是真實 NotebookLM 同一筆記本輸出，不可本機自製替代。
- 生成完成不等於完成；下載、驗證、Telegram 回傳都完成才算完成。
- 預設語言是中文（繁體）。無法確認語言就不要提交生成。
- 完整 NBS 預設三件成品：簡報、影片摘要、語音摘要。
- 簡報交付格式只能是 PDF、PPT 或 PPTX；影片只能 MP4；語音只能 MP3。
- 任何成品驗證通過後要立刻回傳 Telegram，不要等整包都完成才一次傳。
- 回覆主人只用乾淨繁體中文，不貼 raw log、JSON、工具狀態、token、cookie、密碼或英文錯誤堆疊。

## 測試句

安裝重啟後，請測試：

```text
nbs 把這份資料做成完整 NBS
```

```text
nbps 只做語音摘要
```

```text
nbvs 只做影片摘要
```

```text
NBS 少了 MP3，幫我補回傳
```

接收端正確反應應該是：先讀 `nbs` 技能，確認輸出範圍、來源加入方式、中文（繁體）語言、驗證標準與 Telegram 回傳方式；若還未確認提交，先給主人確認清單。

