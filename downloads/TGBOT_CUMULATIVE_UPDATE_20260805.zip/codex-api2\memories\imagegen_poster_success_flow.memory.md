# Imagegen Poster Success Flow

- 2026-06-10 confirmed successful flow for poster/image output:
  1. Use built-in Codex `imagegen` / `image_gen` tool, not alternate CLI tools, for poster/image generation.
  2. Generated images save under `C:\Users\Administrator\.codex\generated_images\<session>\ig_*.png`.
  3. After generation, locate the newest generated image path and visually inspect it with `view_image` when possible.
  4. Send the final image back to Telegram exactly once using the local Telegram bot token/chat state from `appsettings.Local.json` and `telegram-state.json`, preferably as `sendDocument` to preserve quality.
  5. Keep user-facing Telegram/Codex messages in clean Traditional Chinese only. Do not expose English bridge status, raw JSON, raw logs, token values, or technical stack traces.
  6. For poster requests, start by telling the owner what is being done and estimated time, then generate, verify, send the image once, and report completion briefly.

- Successful example path pattern:
  `C:\Users\Administrator\.codex\generated_images\019eaf33-c63b-7543-9474-b6a168413f3e\ig_*.png`

- Successful Telegram delivery method:
  Use Telegram Bot API `sendDocument` with caption in Traditional Chinese, deriving `chat_id` from `C:\Users\Administrator\AppData\Roaming\Incursa\CodexTelegram\telegram-state.json`.