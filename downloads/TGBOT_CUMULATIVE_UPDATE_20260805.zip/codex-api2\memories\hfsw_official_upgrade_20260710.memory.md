# HFSW 官方升級記憶 - 2026-07-10

主人已確認 `hfsw` 要升級並打包。之後 `hfsw` 固定代表：

1. 無素材任務直接從零起案，不列 M01 / M02，不沿用舊照片。
2. 先到聚合平台用 Claude 4.8 Opus 產出完整文案、10 段分鏡、口述稿、字幕短句、圖片提示詞、音效提示、Hyperframes 時間軸。
3. 依每段文案生成對應圖片，長片預設 300 秒、10 張圖、每 30 秒換圖。
4. 最後進 Hyperframes 合成影片，加入圖片動態、真人口述、BGM、音效、底部字幕。
5. 口音預設沿用張飛通過版：抑揚頓挫明顯的男聲說書口音，停頓與重音清楚。
6. 音量預設人聲更大、更靠前；BGM 和音效壓低，不能蓋過人聲，並加限制避免爆音。
7. 字幕預設標楷體 / DFKai-SB，大字白色、粗黑邊、微黑影、底部置中、短句分段。
8. 完成標準：MP4 匯出、長度/尺寸/音訊/字幕/30 秒換圖節奏驗證通過，Telegram 同源文件模式回傳成功。
9. 這套流程不是 SD / Seedance 直接影片生成，也不是只換聲音；核心是「文案對題、圖片對段、Hyperframes 合成、口述清楚、字幕可讀」。

打包要求：

- 每次打包技能或記憶，檔名與資料夾都要包含日期時間。
- 包內必須有 `INSTALL_FOR_OTHER_CODEX.md`、`FORWARD_TO_RECEIVER_TGBOT.txt`、`PACKAGE_MANIFEST.md`、`MEMORY_AND_BEHAVIOR_SUMMARY.md`。
- 不可包含密碼、token、cookie、API key、瀏覽器 profile、raw log 或任何秘密。
