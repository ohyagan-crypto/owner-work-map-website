# Package Manifest 20260803

套件：TGBOT 功能選單更新包 20260803

## 內容

- APPLY_MENU_UPDATE_20260803.ps1：檢查五掛鉤、測試、備份、覆蓋及驗證。
- ROLLBACK_MENU_UPDATE_20260803.ps1：還原最近一次更新前備份。
- telegram_studio_menu.py：目前 18 個主入口與完整工作室／生活功能選單模組。
- telegram_studio_menu_test.py：7 項共用選單與生活功能測試。
- enable_fast_service_tier_20260803.ps1：把 Codex 設為唯一頂層 service_tier = "fast"，不改模型、provider、reasoning。
- VERSION_20260803.json：版本、入口數、最低 Python 與保留設定契約。
- INSTALL_FOR_OTHER_CODEX_20260803.md：增量更新、觸發、測試、阻塞與復原指南。
- FORWARD_TO_RECEIVER_TGBOT_20260803.txt：可直接轉交接收端 TGBOT 的更新指令。
- MEMORY_AND_BEHAVIOR_SUMMARY_20260803.md：主人偏好、觸發邊界、回覆與安全規則。
- SHA256SUMS_20260803.txt：封裝前各檔案雜湊。

## 適用範圍

僅適用已具備 telegram_studio_menu 五個掛鉤的藍星相容 TGBOT。未完成接線者必須使用全新安裝包。

## 排除項目

本包不含 .env、API key、Bot Token、cookie、chat_id、密碼、auth、瀏覽器 profile、raw log、對話紀錄、模型/provider/reasoning 私有設定及任何憑證。

## 完成定義

接收端必須完成備份、編譯、7 項測試、service tier 驗證、TGBOT 重啟、getMe／單一 PID／heartbeat 檢查及 18 個入口實測，才可回覆更新成功。
