# TGBOT 功能選單更新指南 20260803

## 用途

本更新包只供已經接好 telegram_studio_menu 五個掛鉤的藍星相容 TGBOT 使用。它更新目前 18 個主入口、生活服務、待辦、記帳、學習卡、蝦教室互跳、提醒與分類進度路由，不重新改寫主程式，也不改模型、provider、reasoning、Token 或聊天授權。

沒有舊選單接線時，請改用「TGBOT 功能選單全新安裝包 20260803」。

## 更新方式

解壓後在 PowerShell 執行：

    powershell -ExecutionPolicy Bypass -File ".\APPLY_MENU_UPDATE_20260803.ps1" -BotDirectory "C:\Users\你的使用者名稱\tg-openai-bot"

主程式檔名需指定時：

    powershell -ExecutionPolicy Bypass -File ".\APPLY_MENU_UPDATE_20260803.ps1" -BotDirectory "C:\Users\你的使用者名稱\tg-openai-bot-4" -BotScript "codex_bot_4.py"

更新器會先確認匯入、持久鍵盤、訊息路由、命令同步、提醒掃描五個掛鉤，先執行編譯與 7 項測試，再備份舊選單模組並覆蓋。失敗會自動復原。

更新器也會把接收端 Codex 正規化為唯一一列頂層 service_tier = "fast"；原模型、provider 與 reasoning 保持不變。完成後必須重啟 TGBOT。

自動新手教學：

https://ohyagan-crypto.github.io/owner-work-map-website/#all-skills

## 主要功能與觸發詞

- /start、/menu、功能選單：顯示 18 個主入口。
- 蝦咩工作室：任務、技能、排程、素材、會議、美食、鐵路、遊戲、追蹤、蝦教室、帳戶與設定。
- 生活服務、今日生活、統一待辦、記帳、藍星學習卡：執行該聊天室隔離的生活功能。
- 製作簡報：普通簡報入口；只有明確 NBS／NotebookLM 才走 NBS。
- 製作圖片、製作影片、上傳檔案：維持原 Bot 的專用工作流，不把進度混在一起。

## 對主人回覆規則

使用乾淨繁體中文，先給結論。不能顯示 raw log、工具文字、Token、cookie、密碼、聊天 ID 或內部 debug。不能用模糊的「處理中」結案；檔案成品要回傳同一 Telegram 聊天室／topic，實際失敗要說明具體卡點。

## 更新後測試

1. 重啟指定 TGBOT。
2. getMe 成功，只有一個 Python PID，heartbeat 新鮮且無近期啟動錯誤。
3. 輸入「功能選單」，核對 18 個入口。
4. 進入生活服務，核對蝦教室快捷鈕；進入蝦教室，核對生活服務快捷鈕。
5. 新增一筆待辦及一筆支出，再查看今日生活。
6. 按製作簡報，確認沒有誤走 NBS。

## 復原

    powershell -ExecutionPolicy Bypass -File ".\ROLLBACK_MENU_UPDATE_20260803.ps1" -BotDirectory "C:\Users\你的使用者名稱\tg-openai-bot"

也可用 -BackupPath 指定更新器輸出的備份檔。

## 停止條件

遇到缺少五個掛鉤、Python 不存在、測試失敗、檔案無權限、Telegram 409 polling 衝突時停止並回報。不要停用 watchdog、不要換模型、不要拿另一個 Bot 的健康狀態當成更新成功。

## 完成清單

- [ ] 舊選單模組已備份。
- [ ] Python 編譯及 7 項測試成功。
- [ ] service_tier = "fast" 只有一列頂層設定。
- [ ] 模型、provider、reasoning 未修改。
- [ ] 指定 TGBOT 已重啟且健康。
- [ ] 18 個入口、生活功能與普通簡報路由實測通過。
