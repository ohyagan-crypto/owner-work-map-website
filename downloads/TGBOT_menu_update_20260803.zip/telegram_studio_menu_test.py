import unittest
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from zoneinfo import ZoneInfo

import telegram_studio_menu as studio


class TelegramStudioMenuTests(unittest.TestCase):
    def setUp(self):
        studio._pending.clear()
        self.state_folder = TemporaryDirectory()
        self.original_state_path = studio.STUDIO_STATE_PATH
        studio.STUDIO_STATE_PATH = Path(self.state_folder.name) / "state.json"

    def tearDown(self):
        studio.STUDIO_STATE_PATH = self.original_state_path
        self.state_folder.cleanup()

    def test_main_menu_and_all_sections_are_reachable(self):
        sent = []

        def telegram(method, payload, timeout=60):
            sent.append((method, payload))
            return {}

        def target(chat_id):
            return {"chat_id": chat_id, "message_thread_id": 9}

        self.assertTrue(studio.handle_studio_menu_message(123, "功能選單", "TG1", telegram, target))
        keyboard = sent[-1][1]["reply_markup"]["keyboard"]
        self.assertTrue(sent[-1][1]["reply_markup"]["is_persistent"])
        flattened = [button["text"] for row in keyboard for button in row]
        self.assertEqual(flattened[:-1], [
            "🆕 新對話", "📑 製作簡報", "🎨 製作圖片", "🎬 製作影片",
            "🧰 蝦咩工作室", "⚙️ 個人設定", "📱 開啟生活服務", "🏠 今日生活",
            "✅ 統一待辦", "🎓 藍星學習卡", "🗓️ 8月課程報名", "🧾 記帳",
            "📎 上傳檔案", "➕ 新增提醒", "⏰ 查看提醒", "📊 Token 統計",
            "🛎️ 藍星AI客服", "💳 續訂與續期",
        ])
        self.assertEqual(flattened[-1], "⌄ 收合選單")

        self.assertTrue(studio.handle_studio_menu_message(123, "功能表在哪", "TG1", telegram, target))
        self.assertIn("keyboard", sent[-1][1]["reply_markup"])

        self.assertTrue(studio.handle_studio_menu_message(123, "tg bot沒有出現功能表", "TG1", telegram, target))
        self.assertIn("keyboard", sent[-1][1]["reply_markup"])

        self.assertTrue(studio.handle_studio_menu_message(123, "🧰 蝦咩工作室", "TG1", telegram, target))
        workspace_buttons = [button["text"] for row in sent[-1][1]["reply_markup"]["keyboard"] for button in row]
        for expected in ["📋 蝦任務", "🧩 蝦技能", "⏰ 蝦排程", "🚆 蝦鐵路", "🧑‍🏫 蝦教室"]:
            self.assertIn(expected, workspace_buttons)

        self.assertTrue(studio.handle_studio_menu_message(123, "🎨 製作圖片", "TG1", telegram, target))
        image2_buttons = [button["text"] for row in sent[-1][1]["reply_markup"]["keyboard"] for button in row]
        self.assertIn("✍️ 純文字", image2_buttons)
        self.assertIn("📎 上傳參考圖", image2_buttons)
        self.assertIn("☰ 功能選單", image2_buttons)
        self.assertTrue(studio.handle_studio_menu_message(123, "📎 上傳參考圖", "TG1", telegram, target))
        self.assertIn("多張圖片素材", sent[-1][1]["text"])
        self.assertTrue(studio.handle_studio_menu_message(123, "✍️ 純文字", "TG1", telegram, target))
        self.assertIn("必放文字與禁止內容", sent[-1][1]["text"])

        persistent_main = studio.studio_main_reply_keyboard()
        self.assertTrue(persistent_main["is_persistent"])
        self.assertFalse(persistent_main["one_time_keyboard"])

        self.assertTrue(studio.handle_studio_menu_message(123, "⌄ 收合選單", "TG1", telegram, target))
        self.assertTrue(sent[-1][1]["reply_markup"]["remove_keyboard"])
        self.assertIsNone(studio.persistent_menu_reply_keyboard("TG1", 123, target(123)))
        self.assertTrue(studio.handle_studio_menu_message(123, "功能選單", "TG1", telegram, target))
        self.assertIsNotNone(studio.persistent_menu_reply_keyboard("TG1", 123, target(123)))

        self.assertTrue(studio.handle_studio_menu_message(123, "📊 Token 統計", "TG2", telegram, target))
        self.assertIn("不會用估算數字代替", sent[-1][1]["text"])

        for section in studio.SECTION_MENUS:
            self.assertTrue(studio.handle_studio_menu_message(123, section, "TG1", telegram, target), section)

    def test_games_use_verified_https_urls(self):
        sent = []
        telegram = lambda method, payload, timeout=60: sent.append((method, payload)) or {}
        target = lambda chat_id: {"chat_id": chat_id}
        self.assertTrue(studio.handle_studio_menu_message(123, "蝦遊藝", "TG4", telegram, target))
        buttons = sent[-1][1]["reply_markup"]["inline_keyboard"]
        self.assertEqual(len(buttons), 4)
        self.assertTrue(all(row[0]["url"].startswith("https://") for row in buttons))

    def test_every_lbot_parity_menu_button_has_a_real_route(self):
        sent = []
        telegram = lambda method, payload, timeout=60: sent.append((method, payload)) or {}
        target = lambda chat_id: {"chat_id": chat_id}
        handled_here = [
            "📑 製作簡報", "🎨 製作圖片", "🎬 製作影片", "🧰 蝦咩工作室",
            "📱 開啟生活服務", "🏠 今日生活", "✅ 統一待辦", "🎓 藍星學習卡",
            "🗓️ 8月課程報名", "🧾 記帳", "📎 上傳檔案", "➕ 新增提醒",
            "⏰ 查看提醒", "⚙️ 個人設定",
            "📊 Token 統計", "🛎️ 藍星AI客服", "💳 續訂與續期",
        ]
        for button in handled_here:
            before = len(sent)
            self.assertTrue(studio.handle_studio_menu_message(123, button, "TG2", telegram, target), button)
            self.assertGreater(len(sent), before, button)

        # The bot process handles this one so it can clear that bot's own history and running task state.
        self.assertFalse(studio.handle_studio_menu_message(123, "🆕 新對話", "TG2", telegram, target))
        support_markup = next(payload["reply_markup"] for _, payload in sent if "藍星AI官方 LINE 客服" in payload["text"])
        self.assertEqual(support_markup["inline_keyboard"][0][0]["url"], "https://lin.ee/FmJ2Ytq")

    def test_life_service_todo_and_ledger_routes_are_operational(self):
        sent = []
        telegram = lambda method, payload, timeout=60: sent.append((method, payload)) or {}
        target = lambda chat_id: {"chat_id": chat_id}

        self.assertTrue(studio.handle_studio_menu_message(123, "📱 開啟生活服務", "TG4", telegram, target))
        life_buttons = [button["text"] for row in sent[-1][1]["reply_markup"]["keyboard"] for button in row]
        self.assertIn("🧑‍🏫 蝦教室", life_buttons)

        self.assertTrue(studio.handle_studio_menu_message(123, "➕ 新增待辦", "TG4", telegram, target))
        self.assertTrue(studio.handle_studio_menu_message(123, "整理月報｜8/5 18:00", "TG4", telegram, target))
        self.assertIn("已新增待辦", sent[-1][1]["text"])
        self.assertTrue(studio.handle_studio_menu_message(123, "📋 查看待辦", "TG4", telegram, target))
        self.assertIn("整理月報", sent[-1][1]["text"])

        self.assertTrue(studio.handle_studio_menu_message(123, "➖ 記支出", "TG4", telegram, target))
        self.assertTrue(studio.handle_studio_menu_message(123, "120｜餐飲｜午餐", "TG4", telegram, target))
        self.assertIn("NT$120", sent[-1][1]["text"])
        self.assertTrue(studio.handle_studio_menu_message(123, "📊 收支統計", "TG4", telegram, target))
        self.assertIn("支出：NT$120", sent[-1][1]["text"])

        self.assertTrue(studio.handle_studio_menu_message(123, "🏠 今日生活", "TG4", telegram, target))
        self.assertIn("未完成待辦：1 項", sent[-1][1]["text"])
        self.assertIn("今日支出：NT$120", sent[-1][1]["text"])

    def test_syncs_readable_traditional_chinese_bot_commands(self):
        calls = []
        telegram = lambda method, payload, timeout=60: calls.append((method, payload)) or True
        studio.sync_bot_commands(telegram)
        self.assertEqual([method for method, _ in calls], ["setMyCommands", "setMyCommands"])
        self.assertNotIn("?", "".join(item["description"] for item in calls[0][1]["commands"]))
        self.assertEqual(calls[1][1]["language_code"], "zh")

        sent = []
        sender = lambda method, payload, timeout=60: sent.append((method, payload)) or {}
        target = lambda chat_id: {"chat_id": chat_id}
        self.assertTrue(studio.handle_studio_menu_message(123, "/status", "TG2", sender, target))
        self.assertIn("目前在線", sent[-1][1]["text"])

    def test_rail_parser_and_sale_reminder(self):
        stations = [
            {"id": "1000", "name": "臺北", "normalized": "台北"},
            {"id": "3300", "name": "臺中", "normalized": "台中"},
        ]
        now = datetime(2026, 7, 27, 12, 0, tzinfo=ZoneInfo("Asia/Taipei"))
        parsed = studio.parse_rail_request("台北到台中 明天早上 8 點", "TRA", station_rows=stations, now=now)
        self.assertTrue(parsed["ok"])
        self.assertEqual(parsed["date"], "2026-07-28")
        self.assertEqual((parsed["start"], parsed["end"]), (480, 720))
        sale = studio.sale_reminder("2026-08-30 台北到台中", "TRA", now=now)
        self.assertTrue(sale["ok"])
        self.assertEqual(sale["sale_date"], "2026-08-02")
        self.assertEqual(sale["remind_at"], "2026-08-01T21:00:00+08:00")

    def test_persists_workspace_state_per_bot_chat_and_thread(self):
        sent = []
        telegram = lambda method, payload, timeout=60: sent.append((method, payload)) or {}
        target = lambda chat_id: {"chat_id": chat_id, "message_thread_id": 7}
        with TemporaryDirectory() as folder:
            original = studio.STUDIO_STATE_PATH
            studio.STUDIO_STATE_PATH = Path(folder) / "state.json"
            try:
                self.assertTrue(studio.handle_studio_menu_message(123, "建立任務", "TG1", telegram, target))
                self.assertFalse(studio.handle_studio_menu_message(123, "整理月報並輸出 Excel", "TG1", telegram, target))
                tg1 = studio._workspace_state("TG1", 123, target(123))
                tg2 = studio._workspace_state("TG2", 123, target(123))
                self.assertEqual(tg1["tasks"][0]["title"], "整理月報並輸出 Excel")
                self.assertEqual(tg2["tasks"], [])
                self.assertEqual(studio.normalize_market_symbol("2330"), "2330.TW")
                self.assertEqual(studio.normalize_market_symbol("比特幣"), "BTC-USD")
            finally:
                studio.STUDIO_STATE_PATH = original


if __name__ == "__main__":
    unittest.main()
