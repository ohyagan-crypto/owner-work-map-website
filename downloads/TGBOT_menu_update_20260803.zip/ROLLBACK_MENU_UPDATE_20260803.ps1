﻿param(
    [Parameter(Mandatory = $true)]
    [string] $BotDirectory,
    [string] $BackupPath = ''
)

try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch {}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$ErrorActionPreference = 'Stop'
$botDir = [System.IO.Path]::GetFullPath($BotDirectory)
$targetModule = Join-Path (Split-Path -Parent $botDir) 'telegram_studio_menu.py'
if (-not $BackupPath) {
    $BackupPath = Get-ChildItem -LiteralPath (Split-Path -Parent $targetModule) -File -Filter 'telegram_studio_menu.py.before_menu_update_*.bak' | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $BackupPath -or -not (Test-Path -LiteralPath $BackupPath -PathType Leaf)) {
    throw '找不到可復原的選單備份。'
}
[System.IO.File]::Copy([System.IO.Path]::GetFullPath($BackupPath), $targetModule, $true)
$python = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } elseif (Get-Command python -ErrorAction SilentlyContinue) { 'python' } else { throw '找不到 Python。' }
& $python -m py_compile $targetModule
if ($LASTEXITCODE -ne 0) { throw '備份已還原，但 Python 編譯失敗；請檢查原始備份。' }
Write-Output "已復原：$targetModule"
Write-Output '請重啟 TGBOT。'
