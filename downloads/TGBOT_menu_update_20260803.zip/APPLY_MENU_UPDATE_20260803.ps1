﻿param(
    [Parameter(Mandatory = $true)]
    [string] $BotDirectory,
    [string] $BotScript = '',
    [string] $CodexConfigPath = ''
)

try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch {}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$ErrorActionPreference = 'Stop'
$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceModule = Join-Path $packageDir 'telegram_studio_menu.py'
$testFile = Join-Path $packageDir 'telegram_studio_menu_test.py'
$botDir = [System.IO.Path]::GetFullPath($BotDirectory)
if (-not (Test-Path -LiteralPath $botDir -PathType Container)) { throw "Bot 目錄不存在：$botDir" }

$scripts = if ($BotScript) {
    @((Join-Path $botDir $BotScript))
} else {
    @(Get-ChildItem -LiteralPath $botDir -File -Filter 'codex_bot*.py' | Select-Object -ExpandProperty FullName)
}
if ($scripts.Count -eq 0) { throw '找不到 codex_bot*.py，無法確認選單接線。' }

$requiredHooks = @(
    'from telegram_studio_menu import',
    'persistent_menu_reply_keyboard(',
    'handle_studio_menu_message(',
    'sync_bot_commands(',
    'poll_due_studio_reminders('
)
foreach ($script in $scripts) {
    if (-not (Test-Path -LiteralPath $script -PathType Leaf)) { throw "主程式不存在：$script" }
    $source = [System.IO.File]::ReadAllText($script)
    $missing = @($requiredHooks | Where-Object { -not $source.Contains($_) })
    if ($missing.Count -gt 0) {
        throw "主程式尚未完成全新安裝，缺少：$($missing -join '、')。請改用全新安裝包。"
    }
}

$python = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } elseif (Get-Command python -ErrorAction SilentlyContinue) { 'python' } else { throw '找不到 Python。' }
& $python -m py_compile $sourceModule $testFile
if ($LASTEXITCODE -ne 0) { throw '更新包內的 Python 檔案編譯失敗。' }
Push-Location $packageDir
try {
    & $python -m unittest 'telegram_studio_menu_test.py'
    if ($LASTEXITCODE -ne 0) { throw '更新包內的功能測試失敗。' }
} finally {
    Pop-Location
}

$targetModule = Join-Path (Split-Path -Parent $botDir) 'telegram_studio_menu.py'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = "$targetModule.before_menu_update_$stamp.bak"
if (Test-Path -LiteralPath $targetModule) {
    [System.IO.File]::Copy($targetModule, $backup, $false)
}

try {
    [System.IO.File]::Copy($sourceModule, $targetModule, $true)
    $compileTargets = @($targetModule) + @($scripts)
    & $python -m py_compile @compileTargets
    if ($LASTEXITCODE -ne 0) { throw '更新後 Python 編譯失敗。' }
} catch {
    if (Test-Path -LiteralPath $backup) { [System.IO.File]::Copy($backup, $targetModule, $true) }
    throw
}

$fastHelper = Join-Path $packageDir 'enable_fast_service_tier_20260803.ps1'
if ($CodexConfigPath) {
    & $fastHelper -ConfigPath $CodexConfigPath
} else {
    & $fastHelper
}

Write-Output "更新完成：$targetModule"
if (Test-Path -LiteralPath $backup) { Write-Output "可復原備份：$backup" }
Write-Output '模型、provider、reasoning 未修改。請重啟 TGBOT 後輸入「功能選單」驗收。'
