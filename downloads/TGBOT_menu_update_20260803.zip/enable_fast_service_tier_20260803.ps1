﻿param(
    [string] $ConfigPath = (Join-Path $env:USERPROFILE '.codex\config.toml')
)

try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch {}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$ErrorActionPreference = 'Stop'
$configFile = [System.IO.Path]::GetFullPath($ConfigPath)
$configDir = Split-Path -Parent $configFile
if (-not (Test-Path -LiteralPath $configDir)) {
    [System.IO.Directory]::CreateDirectory($configDir) | Out-Null
}

$lines = if (Test-Path -LiteralPath $configFile) {
    [System.IO.File]::ReadAllLines($configFile)
} else {
    @()
}

$insideTable = $false
$kept = [System.Collections.Generic.List[string]]::new()
foreach ($line in $lines) {
    if ($line -match '^\s*\[') { $insideTable = $true }
    if (-not $insideTable -and $line -match '^\s*service_tier\s*=') { continue }
    $kept.Add($line)
}

$output = [System.Collections.Generic.List[string]]::new()
$output.Add('service_tier = "fast"')
foreach ($line in $kept) { $output.Add($line) }
[System.IO.File]::WriteAllLines($configFile, $output, [System.Text.UTF8Encoding]::new($false))

$topLevelCount = 0
$insideTable = $false
foreach ($line in [System.IO.File]::ReadAllLines($configFile)) {
    if ($line -match '^\s*\[') { $insideTable = $true }
    if (-not $insideTable -and $line -match '^\s*service_tier\s*=\s*"fast"\s*$') { $topLevelCount += 1 }
}
if ($topLevelCount -ne 1) { throw 'service_tier fast 驗證失敗。' }

Write-Output "已設定 service_tier = fast：$configFile"
Write-Output '模型、provider 與 reasoning 設定均未修改；請重啟 Codex 或 TGBOT。'
