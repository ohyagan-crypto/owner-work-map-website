# Package Manifest 20260803

套件：TGBOT 功能選單全新安裝包 20260803

## 內容

- INSTALL_MENU_20260803.ps1：一鍵安裝入口。
- install_tgbot_menu_20260803.py：相容檢查、五掛鉤接線、備份、語法驗證與失敗復原。
- ROLLBACK_MENU_INSTALL_20260803.ps1：依同次備份時間戳復原主程式；還原原有選單模組，或移除該次新增模組。
- telegram_studio_menu.py：18 個主入口與工作室、生活服務、待辦、記帳、提醒、鐵路、追蹤及教學功能。
- telegram_studio_menu_test.py：7 項共用選單與生活功能測試。
- enable_fast_service_tier_20260803.ps1：把 Codex 設為唯一頂層 service_tier = "fast"，不改模型、provider、reasoning。
- VERSION_20260803.json：版本、入口數、最低 Python 與保留設定契約。
- INSTALL_FOR_OTHER_CODEX_20260803.md：完整安裝、觸發、工作流、測試、阻塞與復原指南。
- FORWARD_TO_RECEIVER_TGBOT_20260803.txt：可直接轉交接收端 TGBOT 的教學訊息。
- MEMORY_AND_BEHAVIOR_SUMMARY_20260803.md：主人偏好、觸發邊界、回覆與安全規則。
- SHA256SUMS_20260803.txt：封裝前各檔案雜湊。

## 排除項目

本包刻意不含 .env、API key、Bot Token、cookie、chat_id、密碼、auth、瀏覽器 profile、raw log、對話紀錄、媒體成品、模型/provider/reasoning 私有設定及任何憑證。

## 完成定義

接收端必須完成備份、編譯、7 項測試、service tier 驗證、TGBOT 重啟、getMe／單一 PID／heartbeat 檢查及 18 個入口實測，才可回覆安裝成功。
