﻿param(
    [Parameter(Mandatory = $true)]
    [string] $BotDirectory,
    [string] $BotScript = '',
    [string] $CodexConfigPath = ''
)

try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch {}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$ErrorActionPreference = 'Stop'
$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$installer = Join-Path $packageDir 'install_tgbot_menu_20260803.py'
$fastHelper = Join-Path $packageDir 'enable_fast_service_tier_20260803.ps1'

$python = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } elseif (Get-Command python -ErrorAction SilentlyContinue) { 'python' } else { throw '找不到 Python。' }
$arguments = @($installer, '--bot-dir', [System.IO.Path]::GetFullPath($BotDirectory))
if ($BotScript) { $arguments += @('--bot-script', $BotScript) }

& $python @arguments
if ($LASTEXITCODE -ne 0) { throw '功能選單安裝失敗；原 Bot 不會被半套更新。' }

if ($CodexConfigPath) {
    & $fastHelper -ConfigPath $CodexConfigPath
} else {
    & $fastHelper
}

Write-Output '全新安裝完成。請重啟這個 TGBOT，然後輸入「功能選單」執行驗收。'
