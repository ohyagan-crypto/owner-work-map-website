# TGBOT 綜合更新包 Manifest 20260803

- 套件名稱：TGBOT 綜合更新包
- 版本：2026.08.03
- 內容：`update/` 增量更新、`install/` 全新安裝、統一指南與完整檔案雜湊
- 選單入口：18 個
- 最低 Python：3.11
- service tier：fast
- onboarding：https://ohyagan-crypto.github.io/owner-work-map-website/#all-skills

兩條路徑都保留原本的模型、provider、reasoning 與接收端設定，不包含任何憑證或私人資料。
