from __future__ import annotations

import argparse
import json
import py_compile
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


IMPORT_LINE = (
    "from telegram_studio_menu import handle_studio_menu_message, "
    "persistent_menu_reply_keyboard, poll_due_studio_reminders, "
    "studio_main_reply_keyboard, sync_bot_commands"
)


def discover_bot_script(bot_dir: Path, requested: str) -> Path:
    if requested:
        candidate = bot_dir / requested
        if not candidate.is_file():
            raise RuntimeError(f"找不到 Bot 主程式：{candidate}")
        return candidate
    preferred = bot_dir / "codex_bot.py"
    if preferred.is_file():
        return preferred
    candidates = sorted(bot_dir.glob("codex_bot*.py"))
    if len(candidates) != 1:
        raise RuntimeError("無法唯一判斷 Bot 主程式，請使用 --bot-script 指定檔名。")
    return candidates[0]


def insert_import(source: str) -> str:
    if IMPORT_LINE in source:
        return source
    if "from pathlib import Path" not in source:
        raise RuntimeError("主程式缺少 pathlib.Path 匯入，無法套用相容接線。")
    block = (
        "\nimport sys\n"
        "sys.path.insert(0, str(Path(__file__).resolve().parent.parent))\n"
        f"{IMPORT_LINE}\n"
    )
    return source.replace("from pathlib import Path\n", "from pathlib import Path\n" + block, 1)


def function_block(source: str, name: str) -> tuple[int, int, str]:
    match = re.search(rf"(?m)^def {re.escape(name)}\([^\n]*\).*?:\s*$", source)
    if not match:
        raise RuntimeError(f"找不到相容函式：{name}")
    next_def = re.search(r"(?m)^def \w+\(", source[match.end():])
    end = match.end() + next_def.start() if next_def else len(source)
    return match.start(), end, source[match.start():end]


def insert_send_hook(source: str) -> str:
    start, end, block = function_block(source, "send_message")
    if "persistent_menu_reply_keyboard(" in block:
        return source
    required = ("telegram_target_payload", "BOT_INSTANCE_NAME", "is_allowed", "payload")
    if any(name not in block and name not in source for name in required):
        raise RuntimeError("send_message 缺少功能選單需要的 payload、授權或 Bot 名稱接點。")
    call = re.search(r"(?m)^(\s*)telegram\(\s*\n\s*[\"']sendMessage[\"'],\s*\n\s*payload,", block)
    if not call:
        raise RuntimeError("send_message 找不到相容的 Telegram sendMessage 呼叫。")
    indent = call.group(1)
    hook = (
        f"{indent}if is_allowed(int(chat_id)):\n"
        f"{indent}    menu_markup = persistent_menu_reply_keyboard(BOT_INSTANCE_NAME, int(chat_id), payload)\n"
        f"{indent}    if menu_markup:\n"
        f"{indent}        payload[\"reply_markup\"] = menu_markup\n"
    )
    position = start + call.start()
    return source[:position] + hook + source[position:]


def insert_message_hook(source: str) -> str:
    if "handle_studio_menu_message(" in source and "owner_command_text" in source:
        return source
    anchor = "    owner_command_text = telegram_owner_command_text(message, text)\n"
    if anchor not in source:
        raise RuntimeError("找不到 owner_command_text 接點，無法安裝選單訊息路由。")
    hook = (
        "\n    if owner_command_text and is_allowed(int(chat_id)) and handle_studio_menu_message(\n"
        "        int(chat_id), owner_command_text, BOT_INSTANCE_NAME, telegram, telegram_target_payload\n"
        "    ):\n"
        "        return\n"
    )
    return source.replace(anchor, anchor + hook, 1)


def insert_startup_hook(source: str) -> str:
    if "sync_bot_commands(" in source and re.search(r"sync_bot_commands\((?:telegram_startup_call|telegram)\)", source):
        return source
    patterns = (
        (r"(?m)^(\s*)bot\s*=\s*telegram_startup_call\([^\n]+\)\s*$", "telegram_startup_call"),
        (r"(?m)^(\s*)bot\s*=\s*telegram\([^\n]+\)\s*$", "telegram"),
    )
    for pattern, caller in patterns:
        match = re.search(pattern, source)
        if match:
            line_end = source.find("\n", match.end())
            line_end = len(source) if line_end < 0 else line_end + 1
            return source[:line_end] + f"{match.group(1)}sync_bot_commands({caller})\n" + source[line_end:]
    raise RuntimeError("找不到 Telegram getMe 啟動接點。")


def insert_reminder_hook(source: str) -> str:
    if "poll_due_studio_reminders(BOT_INSTANCE_NAME" in source:
        return source
    match = re.search(r"(?m)^(\s*)payload\s*=\s*\{[\"']timeout[\"']\s*:\s*50\}\s*$", source)
    if not match:
        raise RuntimeError("找不到 polling payload 接點，無法安裝提醒掃描。")
    indent = match.group(1)
    hook = (
        f"{indent}try:\n"
        f"{indent}    poll_due_studio_reminders(BOT_INSTANCE_NAME, telegram, telegram_target_payload)\n"
        f"{indent}except Exception:\n"
        f"{indent}    logging.exception(\"Telegram studio reminder scan failed\")\n"
    )
    return source[:match.start()] + hook + source[match.start():]


def validate_hooks(source: str) -> None:
    required = (
        IMPORT_LINE,
        "persistent_menu_reply_keyboard(BOT_INSTANCE_NAME",
        "handle_studio_menu_message(",
        "sync_bot_commands(",
        "poll_due_studio_reminders(BOT_INSTANCE_NAME",
    )
    missing = [value for value in required if value not in source]
    if missing:
        raise RuntimeError("安裝後仍缺少接點：" + "、".join(missing))
    compile(source, "<patched_tgbot>", "exec")


def main() -> int:
    parser = argparse.ArgumentParser(description="安裝藍星 TGBOT 共用功能選單")
    parser.add_argument("--bot-dir", required=True)
    parser.add_argument("--bot-script", default="")
    args = parser.parse_args()

    package_dir = Path(__file__).resolve().parent
    bot_dir = Path(args.bot_dir).expanduser().resolve()
    if not bot_dir.is_dir():
        raise RuntimeError(f"Bot 目錄不存在：{bot_dir}")
    bot_script = discover_bot_script(bot_dir, args.bot_script)
    source_module = package_dir / "telegram_studio_menu.py"
    if not source_module.is_file():
        raise RuntimeError("安裝包缺少 telegram_studio_menu.py")
    target_module = bot_dir.parent / "telegram_studio_menu.py"

    original = bot_script.read_text(encoding="utf-8-sig")
    patched = insert_import(original)
    patched = insert_send_hook(patched)
    patched = insert_message_hook(patched)
    patched = insert_startup_hook(patched)
    patched = insert_reminder_hook(patched)
    validate_hooks(patched)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    script_backup = bot_script.with_name(f"{bot_script.name}.before_menu_{stamp}.bak")
    module_backup = target_module.with_name(f"telegram_studio_menu.py.before_menu_{stamp}.bak")
    shutil.copy2(bot_script, script_backup)
    module_preexisted = target_module.exists()
    if module_preexisted:
        shutil.copy2(target_module, module_backup)

    try:
        bot_script.write_text(patched, encoding="utf-8", newline="\n")
        shutil.copy2(source_module, target_module)
        py_compile.compile(str(bot_script), doraise=True)
        py_compile.compile(str(target_module), doraise=True)
        test_result = subprocess.run(
            [sys.executable, "-m", "unittest", "telegram_studio_menu_test.py"],
            cwd=package_dir,
            text=True,
            capture_output=True,
            timeout=120,
        )
        if test_result.returncode != 0:
            raise RuntimeError("選單測試失敗。")
    except Exception:
        shutil.copy2(script_backup, bot_script)
        if module_backup.exists():
            shutil.copy2(module_backup, target_module)
        elif target_module.exists():
            target_module.unlink()
        raise RuntimeError("安裝驗證失敗，已復原原檔。")

    print(json.dumps({
        "ok": True,
        "bot_script": str(bot_script),
        "menu_module": str(target_module),
        "script_backup": str(script_backup),
        "module_backup": str(module_backup) if module_preexisted else None,
        "restart_required": True,
        "model_provider_reasoning_changed": False,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
