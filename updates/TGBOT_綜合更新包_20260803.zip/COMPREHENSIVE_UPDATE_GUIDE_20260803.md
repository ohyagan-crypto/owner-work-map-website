# TGBOT 綜合更新包 20260803

這是今天最新的單一綜合包，包含兩種安全路徑：

- `update/`：已有 `telegram_studio_menu` 五個掛鉤的 TGBOT，使用增量更新與回復工具。
- `install/`：沒有既有選單掛鉤的新 TGBOT，使用全新安裝與回復工具。

## 使用規則

1. 只能辨識並處理目前這個 TGBOT，不可改到其他 Bot、其他 Token 或其他資料夾。
2. 先讀取對應資料夾的 `INSTALL_FOR_OTHER_CODEX_20260803.md`、`PACKAGE_MANIFEST_20260803.md` 與 `VERSION_20260803.json`。
3. 已有五個掛鉤才使用 `update/APPLY_MENU_UPDATE_20260803.ps1`；沒有掛鉤就使用 `install/INSTALL_MENU_20260803.ps1`。
4. 先執行檢查、編譯、測試與備份；任何驗證失敗都停止，不得重啟或覆蓋設定。
5. 保留既有模型、provider、reasoning、service tier、`.env`、Token、登入狀態、排程與對話資料。
6. 只在驗證通過後重啟目前這個 TGBOT，再確認 getMe、單一 PID、heartbeat、18 個選單入口與生活／蝦教室互跳。

## 今日版本

- 版本：`2026.08.03`
- 選單入口：18 個
- Python 最低版本：3.11
- service tier：`fast`
- 保留：model、provider、reasoning
- 新手教學：https://ohyagan-crypto.github.io/owner-work-map-website/#all-skills

## 復原

每條路徑都有同版本的 rollback 工具。只有在更新器明確建立備份後，才可依該資料夾說明執行回復。

本包排除 `.env`、API key、Bot Token、cookie、chat_id、密碼、auth、瀏覽器 profile、raw log、對話紀錄與媒體成品。
