# TGBOT 功能選單全新安裝指南 20260803

## 1. 套件目的

本套件把目前藍星 TGBOT 的共用功能選單安裝到相容的 Telegram Codex Bot。它只加入選單模組與五個必要接點，不替換 Bot Token、模型、provider、reasoning、聊天授權或既有技能。

安裝後提供 18 個主選單入口：新對話、製作簡報、製作圖片、製作影片、蝦咩工作室、個人設定、生活服務、今日生活、統一待辦、藍星學習卡、8 月課程報名、記帳、上傳檔案、新增提醒、查看提醒、Token 統計、藍星 AI 客服、續訂與續期。

## 2. 相容條件

- Windows PowerShell 與 Python 3.11 以上。
- 目標是藍星相容的 polling TGBOT，主程式具備 send_message、telegram_target_payload、telegram_owner_command_text、is_allowed、BOT_INSTANCE_NAME、telegram 與 main。
- Bot 資料夾例如 C:\Users\你的使用者名稱\tg-openai-bot。
- 不含 .env、Token、API key、cookie、帳密、聊天 ID、瀏覽器 profile 或原始紀錄。

若相容接點不足，安裝器會停止且不落下半套修改。不要為了強行安裝而刪除原 Bot 的安全或交付規則。

## 3. 安裝路徑與指令

以 PowerShell 執行：

    powershell -ExecutionPolicy Bypass -File ".\INSTALL_MENU_20260803.ps1" -BotDirectory "C:\Users\你的使用者名稱\tg-openai-bot"

主程式不是 codex_bot.py 時指定檔名：

    powershell -ExecutionPolicy Bypass -File ".\INSTALL_MENU_20260803.ps1" -BotDirectory "C:\Users\你的使用者名稱\tg-openai-bot-4" -BotScript "codex_bot_4.py"

安裝器會：

1. 在記憶體加入匯入、持久鍵盤、訊息路由、命令同步與提醒掃描五個接點。
2. 先完成接點與 Python 語法驗證，再備份並寫入。
3. 把 telegram_studio_menu.py 放到 Bot 資料夾的上一層，供同層多個 TGBOT 共用。
4. 執行功能測試；失敗時自動復原。
5. 將接收端 Codex 設為唯一一列頂層 service_tier = "fast"，不修改模型、provider 或 reasoning。

安裝後必須重啟 Codex 或 TGBOT。自動新手教學入口：

https://ohyagan-crypto.github.io/owner-work-map-website/#all-skills

## 4. 觸發詞與第一個動作

主要觸發詞：/start、/menu、功能選單、選單、蝦咩工作室、製作簡報、製作圖片、生活服務、今日生活、統一待辦、記帳、藍星學習卡。

收到選單觸發詞時，第一個動作是由 handle_studio_menu_message 判斷按鈕功能；命中後直接回覆對應鍵盤或執行本機功能，不能把按鈕文字誤送成舊任務。未命中時才交回原 Bot 的一般 AI 流程。

## 5. 正常工作流

1. 啟動時同步 /start、/menu、/studio、/status、/skills。
2. 授權聊天室的普通回覆都附持久主選單；使用者可收合並用「功能選單」重新展開。
3. 工作室功能依區域開啟，蝦教室與生活服務底部可互相跳轉。
4. 待辦、記帳、教學進度與追蹤資料依 Bot、聊天室及 topic/thread 隔離。
5. 今日生活只彙整該聊天室的待辦與記帳；做圖、影片、檔案與任務進度不得混在同一進度回答。
6. 普通簡報入口只收本輪需求／素材；NBS 或 NotebookLM 必須由明確關鍵字觸發，不可混用。
7. 背景 polling 會檢查到期提醒，不以 CPU 安靜或程序存在代替真實狀態。

## 6. 對主人回覆方式

- 使用乾淨繁體中文，先給結論，再補必要原因與下一步。
- 不顯示 raw log、工具呼叫、Token、cookie、密碼、聊天 ID 或內部 debug。
- 不能用「處理中」當最終答覆；完成要有實際結果，失敗要有具體卡點。
- Telegram 來源若產生成品檔案，必須回傳同一聊天室／同一 topic，優先使用文件模式。
- 做圖確認清單要完整；LINEBOT1 簡報確認可精簡，但內部提交規格仍要完整。

## 7. 完成輸出與禁止事項

完成安裝至少要有：主程式備份、共用選單模組、Python 編譯成功、7 項功能測試通過、Bot 重啟、功能選單實際顯示 18 個入口。

必須停止並回報的卡點：主程式不相容、Python 不存在、檔案無寫入權限、測試失敗、Bot Token／網路問題、Telegram 409 polling 衝突。不得猜 Token、停用原 watchdog、改模型或用另一個 Bot 當驗收結果。

## 8. 立即測試

1. 功能選單：應看到 18 個主入口。
2. 生活服務：應看到今日生活、統一待辦、記帳、學習卡及蝦教室快捷鈕。
3. 新增待辦，下一則輸入「測試待辦｜明天 18:00」，再按查看待辦。
4. 記支出，下一則輸入「120｜餐飲｜午餐」，再按收支統計。
5. 製作簡報：應請使用者提供主題／本輪素材，不應直接進 NBS。
6. NBS 簡報：若接收端已安裝 NBS，應走明確 NBS 工作流。

## 9. 復原

安裝器會產生 .before_menu_YYYYMMDD_HHMMSS.bak。需要復原時：

    powershell -ExecutionPolicy Bypass -File ".\ROLLBACK_MENU_INSTALL_20260803.ps1" -BotDirectory "C:\Users\你的使用者名稱\tg-openai-bot"

復原腳本會使用同一次安裝的時間戳備份：原本有選單模組就還原原模組；原本沒有選單模組就移除該次新增模組，並重新編譯原主程式。

## 10. 安裝完成清單

- [ ] 只處理指定 TGBOT，未碰其他 Bot。
- [ ] 原主程式與既有選單模組已備份。
- [ ] 五個接點齊全且 Python 編譯成功。
- [ ] 7 項功能測試通過。
- [ ] service_tier = "fast" 只有一列頂層設定。
- [ ] 模型、provider、reasoning 未改變。
- [ ] TGBOT 已重啟且 heartbeat／getMe 正常。
- [ ] 18 個入口與生活功能實測成功。
