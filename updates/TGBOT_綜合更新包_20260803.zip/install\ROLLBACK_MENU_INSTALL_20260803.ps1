﻿param(
    [Parameter(Mandatory = $true)]
    [string] $BotDirectory,
    [string] $BotScript = ''
)

try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch {}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$ErrorActionPreference = 'Stop'
$botDir = [System.IO.Path]::GetFullPath($BotDirectory)
if (-not $BotScript) {
    $candidate = Join-Path $botDir 'codex_bot.py'
    if (Test-Path -LiteralPath $candidate) { $BotScript = 'codex_bot.py' } else {
        $BotScript = Get-ChildItem -LiteralPath $botDir -File -Filter 'codex_bot*.py' | Select-Object -First 1 -ExpandProperty Name
    }
}
$scriptPath = Join-Path $botDir $BotScript
$scriptBackup = Get-ChildItem -LiteralPath $botDir -File -Filter "$BotScript.before_menu_*.bak" | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
if (-not $scriptBackup) { throw '找不到主程式安裝前備份。' }
[System.IO.File]::Copy($scriptBackup, $scriptPath, $true)

$modulePath = Join-Path (Split-Path -Parent $botDir) 'telegram_studio_menu.py'
$backupName = [System.IO.Path]::GetFileName($scriptBackup)
if ($backupName -notmatch '\.before_menu_(\d{8}_\d{6})\.bak$') { throw '主程式備份名稱無法識別。' }
$moduleBackup = Join-Path (Split-Path -Parent $botDir) "telegram_studio_menu.py.before_menu_$($Matches[1]).bak"
if (Test-Path -LiteralPath $moduleBackup -PathType Leaf) {
    [System.IO.File]::Copy($moduleBackup, $modulePath, $true)
} elseif (Test-Path -LiteralPath $modulePath -PathType Leaf) {
    Remove-Item -LiteralPath $modulePath -Force
}

$python = if (Get-Command py -ErrorAction SilentlyContinue) { 'py' } elseif (Get-Command python -ErrorAction SilentlyContinue) { 'python' } else { throw '找不到 Python。' }
& $python -m py_compile $scriptPath
if ($LASTEXITCODE -ne 0) { throw '已還原備份，但主程式編譯失敗。' }
Write-Output '已復原全新安裝前的 Bot 主程式；請重啟 TGBOT。'
