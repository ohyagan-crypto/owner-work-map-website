# Package Manifest

- Name: `TGBOT_MENU_UPDATE_HANDOFF_20260728`
- Version: `20260728.1`
- Audience: Codex、COI、OpenClaw、TGBOT
- Source behavior: 已在 TG1、TG2、TG3、TG4 驗證的藍星蝦咩功能選單

## 內容

- `INSTALL_FOR_OTHER_CODEX.md`：接收端安裝與驗收順序。
- `MEMORY_AND_BEHAVIOR_SUMMARY.md`：固定行為、回覆與隔離規則。
- `FORWARD_TO_RECEIVER_TGBOT.txt`：可直接交給另一端的執行指令。
- `SET_FAST_SERVICE_TIER_20260728.ps1`：只設定 FAST，不更換模型與供應商。
- `UPDATE_TGBOT_MENU_20260728.ps1`：安裝技能與共用模組，保留接收端設定。
- `skills/tgbot-lbot-menu-parity/SKILL.md`：觸發詞與完整工作流。
- `skills/tgbot-lbot-menu-parity/assets/telegram_studio_menu_20260728.py`：共用功能選單模組。
- `skills/tgbot-lbot-menu-parity/references/`：選單規格與整合指南。
- `skills/tgbot-lbot-menu-parity/scripts/verify_tgbot_menu_20260728.py`：離線驗證工具。
- `workflows/TGBOT_MENU_UPDATE_20260728.md`：更新、驗證、重啟工作流。

## 排除內容

不得包含 `.env`、密碼、API key、Bot Token、Chat ID、Cookie、登入檔、瀏覽器 Profile、資料庫、原始日誌、使用者對話或 Token 使用明細。
