# TGBOT 藍星蝦咩功能選單更新安裝指南

版本：`20260728.1`

這是給其他 Codex、COI、OpenClaw 與 Telegram Bot 學習並套用的功能選單教學包。接收端必須先讀完本檔，再安裝技能、整合模組、測試與重啟；不能只解壓縮就回報完成。

## 更新內容

- 主選單固定依序提供：新對話、一般問答、製作圖片、製作影片、蝦咩工作室、上傳檔案、新增提醒、查看提醒、個人設定、Token 統計、藍星AI客服、續訂與續期、收合選單。
- `蝦咩工作室` 保留完整第二層功能，按鈕會轉成可執行的任務或資料查詢。
- `製作圖片` 固定顯示 `純文字 / 上傳參考圖`，實際生成只走 IMAGE2 API。
- 功能選單常駐，可收合；輸入 `功能選單`、`功能表在哪` 或 `/menu` 可重新開啟。
- Telegram 原生左側指令同步 UTF-8 繁體中文，不再顯示問號。
- Token 統計只能讀取目前 Bot 的實際紀錄，沒有資料時明確說沒有，不得估算。
- 預設使用 `service_tier = "fast"`，但不得更換接收端既有模型、供應商或推理強度。

## 安裝順序

1. 讀取 `MEMORY_AND_BEHAVIOR_SUMMARY.md`。
2. 讀取 `skills/tgbot-lbot-menu-parity/SKILL.md`。
3. 執行 `SET_FAST_SERVICE_TIER_20260728.ps1`，確認設定檔只有一條 `service_tier = "fast"`。
4. 執行 `UPDATE_TGBOT_MENU_20260728.ps1`。腳本會安裝技能、備份並複製共用選單模組，但不會猜測或覆蓋不同架構的 Bot 主程式。
5. 依 `skills/tgbot-lbot-menu-parity/references/INTEGRATION_GUIDE_20260728.md` 把模組接到目前這個 Bot。
6. 執行驗證腳本，再編譯目前 Bot 主程式。
7. 只重啟目前這一端 Codex／COI／TGBOT，不能影響其他 Bot。
8. 實際測試 `/menu`、`/studio`、`/status`、`製作圖片`、`收合選單`、重新開啟與中文原生指令。

## 建議命令

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\SET_FAST_SERVICE_TIER_20260728.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\UPDATE_TGBOT_MENU_20260728.ps1 -TargetBotRoots "C:\Users\你的使用者名稱\tg-openai-bot"
py -3 .\skills\tgbot-lbot-menu-parity\scripts\verify_tgbot_menu_20260728.py
```

## 完成標準

- 功能選單順序完全一致，常駐與收合狀態可用。
- 製作圖片顯示純文字與上傳參考圖兩個入口。
- 蝦咩工作室各第二層功能可點入，不只是靜態名稱。
- `/start`、`/menu`、`/studio`、`/status`、`/skills` 的繁體中文說明沒有 `?`。
- Token 統計只使用目前 Bot 的實際紀錄。
- 既有模型、供應商、推理強度、Token、`.env`、登入狀態與其他 Bot 都沒有被改動。
- 重啟後從 Telegram 真實聊天室完成一次選單操作驗證。

教學網站：`https://ohyagan-crypto.github.io/owner-work-map-website/#all-skills`

## 安全限制

本包不含密碼、API key、Bot Token、Chat ID、Cookie、瀏覽器 Profile、登入資料、`.env`、原始日誌或使用者訊息。接收端也不得把這些資料加入更新包、命令列或回覆。
