# TGBOT 整合指南

## 1. 匯入共用模組

```python
from telegram_studio_menu import (
    handle_studio_menu_message,
    persistent_menu_reply_keyboard,
    poll_due_studio_reminders,
    studio_main_reply_keyboard,
    sync_bot_commands,
)
```

## 2. 訊息路由

在一般模型回覆之前，用目前訊息的 `chat_id`、文字、Bot 名稱、Telegram API 呼叫函式與 target payload builder 呼叫：

```python
handled = handle_studio_menu_message(
    int(chat_id),
    owner_command_text,
    BOT_INSTANCE_NAME,
    telegram_call,
    target_payload_builder,
)
if handled:
    return
```

`新對話` 故意回傳 `False`，必須由 Bot 既有清除流程真正移除目前聊天室／討論串的歷史、素材與執行狀態。

## 3. 一般回覆保留功能選單

每次送出一般文字時，取得目前聊天室的鍵盤；使用者已收合時會回傳 `None`：

```python
menu_markup = persistent_menu_reply_keyboard(BOT_INSTANCE_NAME, int(chat_id), payload)
if menu_markup:
    send_payload["reply_markup"] = menu_markup
```

不要在圖片確認、錯誤或第二輪任務後遺漏鍵盤。

## 4. 啟動同步原生指令

Bot 確認 Telegram API 可用後執行：

```python
sync_bot_commands(telegram_call)
```

它會同步預設與 `zh` 指令。啟動後再用 `getMyCommands` 驗證兩個 scope 都有五個可讀繁體中文說明。

## 5. 提醒輪詢

若接收端啟用蝦鐵路開賣提醒，在既有安全背景循環呼叫：

```python
poll_due_studio_reminders(BOT_INSTANCE_NAME, telegram_call, target_payload_builder)
```

不要新增會與既有 poller 重複的無限循環。

## 6. 實際資料來源

共用模組中的 Token 路徑是參考映射。接收端要改成目前 Bot 自己的實際 JSONL／資料庫讀取函式，並用 Bot、聊天室、討論串隔離。沒有資料時回覆「目前尚無可讀取紀錄」，不能估算。

## 7. 驗證

```powershell
py -3 -m py_compile .\telegram_studio_menu.py .\codex_bot.py
py -3 <更新包>\skills\tgbot-lbot-menu-parity\scripts\verify_tgbot_menu_20260728.py --module .\telegram_studio_menu.py
```

完成後只重啟目前 Bot，從真實 Telegram 聊天室依序測試：`功能選單`、`製作圖片`、`蝦咩工作室`、`Token 統計`、`收合選單`、`功能選單`、`/status`。
