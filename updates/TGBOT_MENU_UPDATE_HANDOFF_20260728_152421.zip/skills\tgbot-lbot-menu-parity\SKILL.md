---
name: tgbot-lbot-menu-parity
description: 將 TGBOT 功能選單同步為藍星蝦咩客戶版，包含固定順序、常駐／收合、蝦咩工作室第二層、IMAGE2 圖片入口、實際 Token 統計與 UTF-8 Telegram 指令。使用者提到 TGBOT 功能選單、LBOT 同款選單、選單收合、左側問號、製作圖片按鈕、蝦咩工作室或 Token 統計時使用。
---

# TGBOT 藍星蝦咩功能選單同步

## 觸發詞

`TGBOT功能選單`、`LBOT同款選單`、`功能選單常駐`、`選單收合`、`左邊選單問號`、`製作圖片按鈕`、`蝦咩工作室`、`Token統計`、`tgbot-lbot-menu-parity`

## 執行前必讀

1. `references/MENU_SPEC_20260728.md`
2. `references/INTEGRATION_GUIDE_20260728.md`

## 工作流

1. 先辨識目前這一個 Bot 的根目錄、主程式、Telegram 呼叫函式、目標 payload builder、Bot 名稱、實際 Token 紀錄與重啟方式。
2. 備份會修改的檔案；保留 `.env`、Bot Token、Chat ID、模型、供應商、推理強度、登入狀態、排程與其他 Bot。
3. 將 `assets/telegram_studio_menu_20260728.py` 複製為目前 Bot 根目錄的 `telegram_studio_menu.py`。
4. 依整合指南加入四個掛接點：匯入、訊息路由、每次回覆的常駐鍵盤、啟動時 `sync_bot_commands`。需要鐵路開賣提醒時再掛接提醒輪詢。
5. `新對話` 留給 Bot 主程式真正清除該聊天室的歷史、素材與執行狀態；不可由選單模組假裝清除。
6. 將 `service_tier` 設為 `fast`，只保留一條，不能更換模型、供應商或推理強度。
7. 先跑 `scripts/verify_tgbot_menu_20260728.py`，再對共用模組與 Bot 主程式跑 `py_compile`。
8. 只重啟目前 Bot，實際測試 `/menu`、`/studio`、`/status`、`製作圖片`、`Token 統計`、`收合選單` 與重新開啟。
9. 完成回覆必須列出實際 Bot、版本、測試結果與重啟狀態；不能只說已安裝。

## 安全與隔離

- 不要打包或輸出 `.env`、Token、Chat ID、密碼、Cookie、瀏覽器資料、原始日誌或使用者對話。
- 不要自動修改不同架構的主程式；先找到真實掛接點再整合。
- 不要動其他 TG Bot；多 Bot 同步必須是主人當次明確指定。
- 不要偽造訂閱剩餘時間、影片積分或 Token 用量；只能接真實資料來源。
- IMAGE2 的內部提示詞與禁止詞要完整提交，但不顯示給一般使用者。

## 完成門檻

離線驗證、主程式語法檢查、重啟後程序／心跳、Telegram 真實選單操作與 UTF-8 中文指令全部通過，才可回報完成。
