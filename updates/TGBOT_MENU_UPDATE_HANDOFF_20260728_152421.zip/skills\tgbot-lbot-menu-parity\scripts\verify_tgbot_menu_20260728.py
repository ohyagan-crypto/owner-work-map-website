from __future__ import annotations

import argparse
import importlib.util
import tempfile
from pathlib import Path


EXPECTED_MAIN = [
    "🆕 新對話", "💬 一般問答", "🎨 製作圖片", "🎬 製作影片",
    "🧰 蝦咩工作室", "📎 上傳檔案", "➕ 新增提醒", "⏰ 查看提醒",
    "⚙️ 個人設定", "📊 Token 統計", "🛎️ 藍星AI客服", "💳 續訂與續期",
]


def load_module(module_path: Path):
    spec = importlib.util.spec_from_file_location("tgbot_menu_under_test", module_path)
    if not spec or not spec.loader:
        raise RuntimeError(f"無法載入模組：{module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def flattened(markup: dict) -> list[str]:
    return [button["text"] for row in markup["keyboard"] for button in row]


def main() -> int:
    parser = argparse.ArgumentParser()
    default_module = Path(__file__).resolve().parents[1] / "assets" / "telegram_studio_menu_20260728.py"
    parser.add_argument("--module", type=Path, default=default_module)
    args = parser.parse_args()
    module_path = args.module.resolve()
    if not module_path.is_file():
        raise FileNotFoundError(module_path)
    module = load_module(module_path)

    with tempfile.TemporaryDirectory() as folder:
        module.STUDIO_STATE_PATH = Path(folder) / "workspace-state.json"
        module.REMINDER_PATH = Path(folder) / "rail-reminders.json"
        sent = []

        def telegram(method, payload, timeout=60):
            sent.append((method, payload))
            return {}

        def target(chat_id):
            return {"chat_id": chat_id, "message_thread_id": 7}

        assert module.handle_studio_menu_message(123, "功能選單", "TG1", telegram, target)
        main_markup = sent[-1][1]["reply_markup"]
        assert main_markup["is_persistent"] is True
        assert main_markup["one_time_keyboard"] is False
        assert flattened(main_markup) == EXPECTED_MAIN + ["⌄ 收合選單"]

        assert module.handle_studio_menu_message(123, "製作圖片", "TG1", telegram, target)
        image_buttons = flattened(sent[-1][1]["reply_markup"])
        assert "✍️ 純文字" in image_buttons
        assert "📎 上傳參考圖" in image_buttons
        assert "☰ 功能選單" in image_buttons

        assert module.handle_studio_menu_message(123, "蝦咩工作室", "TG1", telegram, target)
        studio_buttons = flattened(sent[-1][1]["reply_markup"])
        for expected in ("📋 蝦任務", "🧩 蝦技能", "🚆 蝦鐵路", "🧑‍🏫 蝦教室"):
            assert expected in studio_buttons

        assert module.handle_studio_menu_message(123, "收合選單", "TG1", telegram, target)
        assert sent[-1][1]["reply_markup"]["remove_keyboard"] is True
        assert module.persistent_menu_reply_keyboard("TG1", 123, target(123)) is None
        assert module.handle_studio_menu_message(123, "功能選單", "TG1", telegram, target)
        assert module.persistent_menu_reply_keyboard("TG1", 123, target(123)) is not None

        calls = []
        module.sync_bot_commands(lambda method, payload, timeout=60: calls.append((method, payload)) or {})
        assert [method for method, _ in calls] == ["setMyCommands", "setMyCommands"]
        assert calls[1][1].get("language_code") == "zh"
        descriptions = "".join(item["description"] for item in calls[0][1]["commands"])
        assert "?" not in descriptions
        assert len(calls[0][1]["commands"]) == 5

    print("TGBOT_MENU_VERIFY_OK 20260728.1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
