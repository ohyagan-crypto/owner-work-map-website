"""Shared Telegram studio menus and deterministic Taiwan rail helpers."""

from __future__ import annotations

import json
import html
import http.cookiejar
import ipaddress
import os
import re
import socket
import threading
import time
import urllib.parse
import urllib.request
from datetime import date, datetime, time as datetime_time, timedelta
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple
from zoneinfo import ZoneInfo


TAIPEI = ZoneInfo("Asia/Taipei")
TDX_BASE = "https://tdx.transportdata.tw/api/basic/v2/Rail"


def _menu_data_root() -> Path:
    configured = str(os.environ.get("TGBOT_MENU_DATA_ROOT") or "").strip()
    if configured:
        return Path(configured).expanduser()
    owner_memory = Path(r"E:\COOCMEMORY")
    if owner_memory.exists():
        return owner_memory / "telegram-studio"
    return Path.home() / ".codex" / "tgbot-menu-data"


MENU_DATA_ROOT = _menu_data_root()
REMINDER_PATH = MENU_DATA_ROOT / "rail-sale-reminders.json"
STUDIO_STATE_PATH = MENU_DATA_ROOT / "workspace-state.json"
THSR_BOOKING_URL = "https://irs.thsrc.com.tw/IMINT/"
TRA_BOOKING_URL = "https://tip.railway.gov.tw/tra-tip-web/tip/tip001/tip123/query"
GAME_URLS = {
    "1945 龍蝦空戰": "https://jennie-claw.youjue.ai/games/1945.html",
    "貪吃蝦": "https://jennie-claw.youjue.ai/games/snake.html",
    "龍蝦 2048": "https://jennie-claw.youjue.ai/games/2048.html",
    "麻將學堂": "https://jennie-claw.youjue.ai/games/mahjong.html",
}
BOT_COMMANDS = [
    {"command": "start", "description": "開始使用藍星蝦咩"},
    {"command": "menu", "description": "開啟功能選單"},
    {"command": "studio", "description": "開啟蝦咩工作室"},
    {"command": "status", "description": "查看目前狀態"},
    {"command": "skills", "description": "查看可用技能"},
]
THSR_STATIONS = [
    {"id": station_id, "name": name, "code": code, "normalized": name.replace("臺", "台").lower()}
    for station_id, name, code in [
        ("0990", "南港", "NanGang"), ("1000", "台北", "TaiPei"), ("1010", "板橋", "BanQiao"),
        ("1020", "桃園", "TaoYuan"), ("1030", "新竹", "XinZhu"), ("1035", "苗栗", "MiaoLi"),
        ("1040", "台中", "TaiZhong"), ("1043", "彰化", "ZhangHua"), ("1047", "雲林", "YunLin"),
        ("1050", "嘉義", "JiaYi"), ("1060", "台南", "TaiNan"), ("1070", "左營", "ZuoYing"),
    ]
]
THSR_TIMETABLE_PAGE = "https://www.thsrc.com.tw/ArticleContent/a3b630bb-1066-4352-a1ef-58c7b4e8ef7c"
TRA_TIMETABLE_PAGE = "https://tip.railway.gov.tw/tra-tip-web/tip/tip001/tip112/gobytime"

MAIN_MENU = [
    ["🆕 新對話", "💬 一般問答"],
    ["🎨 製作圖片", "🎬 製作影片"],
    ["🧰 蝦咩工作室", "📎 上傳檔案"],
    ["➕ 新增提醒", "⏰ 查看提醒"],
    ["⚙️ 個人設定", "📊 Token 統計"],
    ["🛎️ 藍星AI客服", "💳 續訂與續期"],
]

STUDIO_MENU = [
    ["🧰 蝦工作室", "🎨 IMAGE2 做圖"],
    ["📋 蝦任務", "🧩 蝦技能"],
    ["⏰ 蝦排程", "🦞 龍蝦小包包"],
    ["🎙️ 蝦會議", "🍽️ 蝦美饌"],
    ["🚆 蝦鐵路", "🕹️ 蝦遊藝"],
    ["📜 追蹤中心", "🧑‍🏫 蝦教室"],
    ["💳 帳戶與方案", "⚙️ 支援與設定"],
]

IMAGE2_MENU = [
    ["✍️ 純文字", "📎 上傳參考圖"],
    ["↩️ 蝦工作室"],
]

SECTION_MENUS = {
    "蝦任務": (
        "蝦任務｜建立、續做與管理任務",
        [["🆕 建立任務", "📎 加入素材"], ["📋 任務狀態", "▶️ 繼續任務"], ["🕘 任務歷史", "🗑️ 刪除任務"], ["停止目前任務", "↩️ 蝦工作室"]],
    ),
    "蝦技能": (
        "蝦技能｜搜尋並使用目前可執行的技能",
        [["🏪 技能市集", "🧩 已安裝技能"], ["✅ 啟用技能", "🚫 停用技能"], ["⬆️ 技能優先級", "🔎 搜尋技能"], ["📈 投資分析", "✍️ 文案寫作"], ["📊 Excel／文件", "🎞️ 簡報製作"], ["🧳 旅遊規劃", "↩️ 蝦工作室"]],
    ),
    "蝦排程": (
        "蝦排程｜提醒與行程管理",
        [["➕ 新增排程", "⏰ 查看排程"], ["📜 執行紀錄", "⏸️ 暫停排程"], ["▶️ 啟用排程", "❌ 取消排程"], ["📥 匯入行程", "↩️ 蝦工作室"]],
    ),
    "龍蝦小包包": (
        "龍蝦小包包｜管理這個聊天室的素材",
        [["📤 上傳素材", "📂 查看素材"], ["📌 釘選素材", "🗑️ 刪除素材"], ["✅ 使用目前素材", "🧹 清空素材"], ["↩️ 蝦工作室"]],
    ),
    "蝦會議": (
        "蝦會議｜錄音、逐字稿、摘要與正式記錄",
        [["🎙️ 上傳錄音", "📝 產生逐字稿"], ["📌 會議摘要", "✅ 決議／待辦"], ["📂 會議列表", "📄 匯出 Word"], ["🗑️ 刪除會議", "📄 正式會議記錄"], ["↩️ 蝦工作室"]],
    ),
    "蝦美饌": (
        "蝦美饌｜提供位置後搜尋實際店家",
        [["☕ 附近咖啡", "🍜 必比登美食"], ["🔎 餐廳搜尋", "🗺️ 美食行程"], ["↩️ 蝦工作室"]],
    ),
    "蝦鐵路": (
        "蝦鐵路｜官方班次、票價、訂票與開賣提醒",
        [["🚄 高鐵查詢", "🚆 台鐵查詢"], ["🔔 高鐵開賣提醒", "🔔 台鐵開賣提醒"], ["🎫 官方訂票", "↩️ 蝦工作室"]],
    ),
    "追蹤中心": (
        "追蹤中心｜商品比價、降價與投資追蹤",
        [["🛒 商品比價", "📉 降價追蹤"], ["📋 比價紀錄", "✅ 標記已購買"], ["⏹️ 停止商品追蹤", "📈 投資追蹤"], ["➕ 加入投資標的", "✏️ 追蹤備註"], ["⏸️ 暫停追蹤", "🗑️ 移除追蹤"], ["🌅 每日投資摘要", "↩️ 蝦工作室"]],
    ),
    "蝦教室": (
        "蝦教室｜依成果分類選擇教學",
        [["🔎 搜尋教學", "★ 我的最愛"], ["✅ 完成進度", "➕ 收藏教學"], ["✔️ 標記完成", "🚀 新手上手"], ["📊 職場文書", "📣 行銷社群"], ["🏪 開店經營", "💰 投資理財"], ["⏰ 自動化排程", "🎨 創意生活"], ["↩️ 蝦工作室"]],
    ),
    "帳戶與方案": (
        "帳戶與方案｜用量、訂閱、解鎖與企業服務",
        [["💰 蝦飼料／用量", "👑 訂閱方案"], ["🔓 功能解鎖", "🏢 企業／團隊"], ["🎟️ 兌換企業碼", "🔐 我的權限"], ["↩️ 蝦工作室"]],
    ),
    "支援與設定": (
        "支援與設定｜教學、客服、回饋與個人偏好",
        [["🎓 教學引導", "📝 客服中心"], ["💬 提交回饋", "📜 回饋紀錄"], ["⚙️ 蝦設定", "🔔 通知設定"], ["↩️ 蝦工作室"]],
    ),
}

ACTION_PROMPTS = {
    "丟素材": "請直接上傳一張或多張圖片素材；全部傳完後，再輸入做圖需求。我會先整理素材與提示詞，確認後才使用 IMAGE2。📎",
    "上傳參考圖": "請直接上傳一張或多張圖片素材；全部傳完後，再輸入做圖需求。我會先整理素材與提示詞，確認後才使用 IMAGE2。📎",
    "純文字": "請直接輸入畫面、比例、風格、必放文字與禁止內容；我會先整理確認，確認後才使用 IMAGE2。✍️",
    "建立任務": "請直接輸入任務目標、希望的成品格式與期限；需要素材時可一起上傳。📋",
    "加入素材": "請直接上傳圖片、影片、音訊或檔案，再補一句要加入哪個任務與用途。📎",
    "任務狀態": "請輸入 /status 查看執行狀態；要看最近任務可直接說「整理我最近交代的任務」。📋",
    "繼續任務": "請直接說「繼續」並補上要接續的任務內容；近期對話與這個聊天室的素材會一起帶入。▶️",
    "搜尋技能": "請輸入想完成的成果，例如「Excel 合併月報」或「寫 30 秒短影音腳本」；我會從已安裝技能中選最多 3 個最相關的執行。🧩",
    "已安裝技能": "請輸入 /skills 查看目前技能；也可直接說需求，我會自動選用可執行技能。",
    "投資分析": "請輸入股票、ETF、匯率、黃金或加密貨幣標的，以及要比較、追蹤或分析的範圍。📈",
    "文案寫作": "請提供產品、受眾、平台與目標；可指定貼文、廣告、標題、腳本或銷售頁。✍️",
    "Excel／文件": "請上傳 Excel、Word、PDF 或資料檔，再說明要整理、比對、合併、分析或輸出的格式。📊",
    "簡報製作": "請上傳資料或貼上主題，並告訴我簡報頁數、用途與觀眾；完成後會回傳可下載檔案。🎞️",
    "旅遊規劃": "請輸入地點、日期、天數、人數、預算與偏好，我會安排交通、景點、餐飲與緩衝。🧳",
    "新增排程": "請輸入完整日期、時間、事項與通知頻率，例如「每天早上 8 點整理 5 則 AI 新聞」。⏰",
    "匯入行程": "請上傳 .ics、.txt、.csv，或貼上含日期時間的行程，再說明提醒方式。📥",
    "上傳素材": "請直接上傳素材；同一聊天室最近的圖片與檔案會隔離保存，之後可在任務或 IMAGE2 使用。📤",
    "查看素材": "請輸入「列出這個聊天室最近上傳的素材」，我會依實際檔案狀態回答。📂",
    "使用目前素材": "請直接輸入要製作、分析或整理的成果；最近一批素材會一起帶入。✅",
    "清空素材": "請輸入「新對話」以隔離舊任務與舊素材；長期記憶不會因此刪除。🧹",
    "上傳錄音": "請直接上傳會議錄音、音訊檔或文字筆記；可一次接收多個檔案。🎙️",
    "產生逐字稿": "請上傳錄音後輸入「產生逐字稿」，我會按說話順序整理並標示不確定處。📝",
    "會議摘要": "請上傳錄音、逐字稿或筆記，我會整理議題、重點、結論與待釐清事項。📌",
    "決議／待辦": "請上傳會議內容，我會抽出決議、待辦、負責人與期限，缺漏會明確標示。✅",
    "正式會議記錄": "請上傳錄音、逐字稿或筆記，我會輸出含會議資訊、討論、決議與待辦的正式記錄檔。📄",
    "附近咖啡": "請傳送位置或輸入地址／地標，再補充距離、營業時間、插座與安靜度需求。☕",
    "必比登美食": "請傳送位置或輸入城市／地區，我會查找仍在營業的必比登與在地小吃並附來源。🍜",
    "餐廳搜尋": "請輸入位置、料理、預算、人數與時間，我會依實際營業資訊整理選項。🔎",
    "美食行程": "請輸入城市、日期、移動方式與餐數，我會安排可走得完的美食路線。🗺️",
    "商品比價": "請輸入商品名稱、規格、預算與可接受平台，我會查目前價格、差異與購買連結。🛒",
    "降價追蹤": "請提供商品網址或完整型號、目前價格、目標價與希望通知時間。📉",
    "比價紀錄": "請說「整理我最近的比價結果」，我會從這個聊天室的對話與交付內容統整。📋",
    "投資追蹤": "請輸入要查看的台股、ETF、匯率、金價或加密貨幣標的。📈",
    "加入投資標的": "請輸入代碼或名稱與備註，例如「2330.TW 成本 580」，可接著要求盤後摘要或價格提醒。➕",
    "每日投資摘要": "請提供追蹤標的與每天通知時間；摘要最多 5 點，資料僅供整理參考，不構成投資建議。🌅",
}

CLASSROOM_EXAMPLES = {
    "新手上手": "LINE／Telegram 基本操作、永久記憶、IMAGE2 做圖與常用功能",
    "職場文書": "Excel 合併／比對、A4 摘要、Word 履歷、會議記錄與簡報",
    "行銷社群": "賣點文案、爆款標題、Threads、Reels 腳本與分鏡",
    "開店經營": "商品比價、餐飲搜尋、客群分析、促銷與市場調研",
    "投資理財": "存股試算、同產業比較、組合健檢、產業鏈與盤後報告",
    "自動化排程": "行程提醒、晨報、每日產業新知、股市摘要與定期整理",
    "創意生活": "高畫質做圖、照片修復、旅遊規劃與互動小遊戲",
    "我的最愛": "把常用教學名稱告訴我，我會保存到個人記憶",
}

_pending: Dict[Tuple[str, int, int], str] = {}
_station_cache: Dict[str, Tuple[float, List[Dict[str, str]]]] = {}
_reminder_lock = threading.RLock()
_studio_state_lock = threading.RLock()
_last_reminder_poll: Dict[str, float] = {}


def _default_workspace_state(bot_instance: str = "", chat_id: int = 0, thread_id: int = 0) -> Dict:
    return {
        "bot": str(bot_instance),
        "chat_id": int(chat_id),
        "message_thread_id": int(thread_id),
        "tasks": [],
        "skills": {"enabled": [], "priorities": {}},
        "tracking": {"products": [], "instruments": [], "daily_summary": None},
        "classroom": {"favorites": [], "completed": []},
        "feedback": [],
        "settings": {"notifications": True, "language": "繁體中文"},
    }


def _read_workspace_states() -> Dict:
    try:
        payload = json.loads(STUDIO_STATE_PATH.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _write_workspace_states(states: Dict) -> None:
    STUDIO_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = STUDIO_STATE_PATH.with_suffix(f".{time.time_ns()}.tmp")
    temporary.write_text(json.dumps(states, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(STUDIO_STATE_PATH)


def _workspace_state_key(bot_instance: str, chat_id: int, thread_id: int = 0) -> str:
    return f"{bot_instance}:{int(chat_id)}:{int(thread_id)}"


def _workspace_state(bot_instance: str, chat_id: int, target: Dict) -> Dict:
    thread_id = int(target.get("message_thread_id") or 0)
    key = _workspace_state_key(bot_instance, chat_id, thread_id)
    with _studio_state_lock:
        states = _read_workspace_states()
        current = states.get(key)
        if not isinstance(current, dict):
            current = _default_workspace_state(bot_instance, chat_id, thread_id)
            states[key] = current
            _write_workspace_states(states)
        return json.loads(json.dumps(current, ensure_ascii=False))


def _update_workspace_state(bot_instance: str, chat_id: int, target: Dict, updater: Callable[[Dict], None]) -> Dict:
    thread_id = int(target.get("message_thread_id") or 0)
    key = _workspace_state_key(bot_instance, chat_id, thread_id)
    with _studio_state_lock:
        states = _read_workspace_states()
        current = states.get(key)
        if not isinstance(current, dict):
            current = _default_workspace_state(bot_instance, chat_id, thread_id)
        updater(current)
        current["updated_at"] = datetime.now(TAIPEI).isoformat()
        states[key] = current
        _write_workspace_states(states)
        return json.loads(json.dumps(current, ensure_ascii=False))


def _plain(text: str) -> str:
    value = re.sub(r"\s+", " ", str(text or "").strip())
    value = re.sub(r"^[^\w\u4e00-\u9fff/]+\s*", "", value)
    return value.strip()


def _target_key(bot_instance: str, chat_id: int, payload: Dict) -> Tuple[str, int, int]:
    return (str(bot_instance), int(chat_id), int(payload.get("message_thread_id") or 0))


def _reply_keyboard(
    rows: List[List[str]],
    *,
    include_main_menu_button: bool = True,
    include_collapse_button: bool = True,
) -> Dict:
    keyboard = [[{"text": text} for text in row] for row in rows]
    if include_main_menu_button:
        keyboard.append([{"text": "☰ 功能選單"}, {"text": "⌄ 收合選單"}])
    elif include_collapse_button:
        keyboard.append([{"text": "⌄ 收合選單"}])
    return {
        "keyboard": keyboard,
        "resize_keyboard": True,
        "one_time_keyboard": False,
        "is_persistent": True,
        "input_field_placeholder": "選擇功能或直接輸入任務",
    }


def studio_main_reply_keyboard() -> Dict:
    return _reply_keyboard(MAIN_MENU, include_main_menu_button=False)


def studio_workspace_reply_keyboard() -> Dict:
    return _reply_keyboard(STUDIO_MENU)


def persistent_menu_reply_keyboard(bot_instance: str, chat_id: int, target_payload: Dict) -> Optional[Dict]:
    state = _workspace_state(bot_instance, int(chat_id), dict(target_payload or {}))
    if bool((state.get("settings") or {}).get("menu_collapsed")):
        return None
    return studio_main_reply_keyboard()


def _token_usage_path(bot_instance: str) -> Optional[Path]:
    key = re.sub(r"[^A-Z0-9]", "", str(bot_instance or "").upper())
    user_root = Path.home()
    tg1_root = Path(os.environ.get("TGBOT_1_ROOT") or user_root / "tg-openai-bot")
    tg2_root = Path(os.environ.get("TGBOT_2_ROOT") or user_root / "tg-openai-bot-2")
    tg3_root = Path(os.environ.get("TGBOT_3_ROOT") or user_root / "tg-openai-bot-3")
    tg4_root = Path(os.environ.get("TGBOT_4_ROOT") or user_root / "tg-openai-bot-4")
    roots = {
        "TG1": tg1_root,
        "TGBOT": tg1_root,
        "TGBOT1": tg1_root,
        "TG2": tg2_root,
        "TGBOT2": tg2_root,
        "TG3": tg3_root,
        "TGBOT3": tg3_root,
        "TG4": tg4_root,
        "TGBOT4": tg4_root,
    }
    root = roots.get(key)
    return root / "codex_token_usage.jsonl" if root else None


def token_usage_reply(bot_instance: str) -> str:
    usage_path = _token_usage_path(bot_instance)
    if not usage_path or not usage_path.exists():
        return f"{bot_instance} 目前尚無可讀取的 Token 使用紀錄；不會用估算數字代替。"
    records = []
    for line in usage_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        if isinstance(row, dict) and isinstance(row.get("total_tokens"), (int, float)):
            records.append(row)
    if not records:
        return f"{bot_instance} 的 Token 紀錄目前沒有可計算資料；不會用估算數字代替。"
    today = datetime.now(TAIPEI).date().isoformat()
    today_records = [row for row in records if str(row.get("date") or "") == today]
    today_total = sum(int(row.get("total_tokens") or 0) for row in today_records)
    all_total = sum(int(row.get("total_tokens") or 0) for row in records)
    return (
        f"{bot_instance} Token 統計 📊\n"
        f"今日：{today_total:,} tokens｜{len(today_records)} 筆\n"
        f"累計：{all_total:,} tokens｜{len(records)} 筆\n"
        "來源：此 TGBOT 的本機實際使用紀錄；實際帳單仍以藍星後端帳單為準。"
    )


def sync_bot_commands(telegram_call: Callable) -> None:
    telegram_call("setMyCommands", {"commands": BOT_COMMANDS})
    telegram_call("setMyCommands", {"commands": BOT_COMMANDS, "language_code": "zh"})


def _send(
    chat_id: int,
    text: str,
    telegram_call: Callable,
    target_payload_builder: Callable,
    reply_markup: Optional[Dict] = None,
) -> None:
    payload = dict(target_payload_builder(int(chat_id)))
    payload.update({"text": str(text), "disable_web_page_preview": True})
    if reply_markup:
        payload["reply_markup"] = reply_markup
    telegram_call("sendMessage", payload)


def _section_for_text(text: str) -> str:
    plain = _plain(text)
    if plain == "蝦遊藝" or plain.endswith("蝦遊藝"):
        return "蝦遊藝"
    for section in SECTION_MENUS:
        if plain == section or plain.endswith(section):
            return section
    return ""


def _http_json(url: str, timeout: int = 15):
    request = urllib.request.Request(
        url,
        headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/138 Safari/537.36"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        if response.status < 200 or response.status >= 300:
            raise RuntimeError(f"tdx_http_{response.status}")
        return json.loads(response.read().decode("utf-8"))


def normalize_market_symbol(value: str) -> str:
    clean = re.sub(r"\s+", "", str(value or "").upper())
    aliases = {
        "台積電": "2330.TW", "美元匯率": "TWD=X", "美金匯率": "TWD=X", "美元": "TWD=X",
        "金價": "GC=F", "黃金": "GC=F", "比特幣": "BTC-USD", "BTC": "BTC-USD",
    }
    if clean in aliases:
        return aliases[clean]
    if re.fullmatch(r"\d{4,6}", clean):
        return f"{clean}.TW"
    return clean


def query_market_quote(value: str) -> Dict:
    symbol = normalize_market_symbol(value)
    if not symbol or len(symbol) > 40 or not re.fullmatch(r"[A-Z0-9.^=_-]+", symbol):
        return {"ok": False, "error": "symbol_invalid", "symbol": symbol}
    payload = _http_json(
        f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(symbol, safe='')}?range=5d&interval=1d"
    )
    result = ((payload.get("chart") or {}).get("result") or [None])[0] or {}
    meta = result.get("meta") or {}
    try:
        price = float(meta["regularMarketPrice"])
    except Exception:
        return {"ok": False, "error": "quote_missing", "symbol": symbol}
    try:
        previous = float(meta["chartPreviousClose"])
        change_percent = ((price - previous) / previous) * 100 if previous else None
    except Exception:
        previous = None
        change_percent = None
    return {
        "ok": True,
        "symbol": str(meta.get("symbol") or symbol),
        "price": price,
        "previous": previous,
        "change_percent": change_percent,
        "currency": str(meta.get("currency") or ""),
    }


def _market_quote_line(quote: Dict) -> str:
    if not quote.get("ok"):
        return f"{quote.get('symbol') or '未知標的'}｜暫時無法取得報價"
    price = f"{float(quote['price']):,.4f}".rstrip("0").rstrip(".")
    change = quote.get("change_percent")
    change_text = f"｜{float(change):+.2f}%" if isinstance(change, (int, float)) else ""
    return f"{quote['symbol']}｜{price} {quote.get('currency', '')}{change_text}"


def _validate_public_product_url(value: str) -> str:
    target = urllib.parse.urlparse(str(value or ""))
    if target.scheme != "https" or not target.hostname or target.username or target.password or target.port:
        raise ValueError("product_url_invalid")
    if target.hostname == "localhost" or target.hostname.endswith(".local"):
        raise ValueError("product_url_private")
    addresses = socket.getaddrinfo(target.hostname, 443, type=socket.SOCK_STREAM)
    if not addresses:
        raise ValueError("product_url_unresolved")
    for entry in addresses:
        address = ipaddress.ip_address(entry[4][0])
        if not address.is_global:
            raise ValueError("product_url_private")
    return urllib.parse.urlunparse(target)


class _SafeProductRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_public_product_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def query_product_price(value: str) -> Dict:
    url = _validate_public_product_url(value)
    request = urllib.request.Request(url, headers=_browser_headers({"Accept": "text/html,application/xhtml+xml"}))
    opener = urllib.request.build_opener(_SafeProductRedirect())
    with opener.open(request, timeout=15) as response:
        body = response.read(5 * 1024 * 1024).decode("utf-8", errors="replace")
    patterns = [
        r'<meta[^>]+(?:property|name)=["\'](?:product:price:amount|og:price:amount)["\'][^>]+content=["\']([0-9][0-9,.]*)["\']',
        r'<meta[^>]+content=["\']([0-9][0-9,.]*)["\'][^>]+(?:property|name)=["\'](?:product:price:amount|og:price:amount)["\']',
        r'["\']price["\']\s*:\s*["\']?([0-9][0-9,.]*)',
        r'itemprop=["\']price["\'][^>]+content=["\']([0-9][0-9,.]*)["\']',
    ]
    for pattern in patterns:
        match = re.search(pattern, body, re.I)
        if not match:
            continue
        price = float(match.group(1).replace(",", ""))
        if price > 0:
            currency_match = re.search(r'(?:priceCurrency|product:price:currency)["\'\s:=]+([A-Z]{3})', body, re.I)
            return {"ok": True, "url": url, "price": price, "currency": (currency_match.group(1).upper() if currency_match else "TWD")}
    return {"ok": False, "error": "product_price_missing", "url": url}


def _browser_headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/138 Safari/537.36",
        "Accept": "*/*",
        **(extra or {}),
    }


def _http_text(
    url: str,
    *,
    data: Optional[Dict[str, str]] = None,
    headers: Optional[Dict[str, str]] = None,
    opener=None,
    timeout: int = 30,
) -> str:
    encoded = urllib.parse.urlencode(data).encode("utf-8") if data is not None else None
    request = urllib.request.Request(url, data=encoded, headers=_browser_headers(headers), method="POST" if encoded is not None else "GET")
    active_opener = opener or urllib.request.build_opener()
    with active_opener.open(request, timeout=timeout) as response:
        if response.status < 200 or response.status >= 300:
            raise RuntimeError(f"official_rail_http_{response.status}")
        return response.read().decode("utf-8", errors="replace")


def _html_text(value: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", str(value or "")))).strip()


def _tra_stations_from_page(page: str) -> List[Dict[str, str]]:
    source_match = re.search(r"availableTags\s*=\s*\[([\s\S]*?)\]\s*;", page, re.IGNORECASE)
    source = source_match.group(1) if source_match else ""
    return [
        {"id": station_id, "name": name, "code": f"{station_id}-{name}", "normalized": _normalize_station(name)}
        for station_id, name in re.findall(r"['\"](\d+)-([^'\"]+)['\"]", source)
    ]


def _normalize_station(value: str) -> str:
    return re.sub(r"(?:車站|站)$", "", str(value or "").strip().replace("臺", "台")).lower()


def _stations(operator: str, fetch_json: Callable = _http_json) -> List[Dict[str, str]]:
    key = operator.upper()
    cached = _station_cache.get(key)
    if cached and time.time() - cached[0] < 86400:
        return cached[1]
    rows = fetch_json(f"{TDX_BASE}/{key}/Station?%24format=JSON")
    items = [
        {
            "id": str(row.get("StationID") or ""),
            "name": str((row.get("StationName") or {}).get("Zh_tw") or ""),
            "normalized": _normalize_station((row.get("StationName") or {}).get("Zh_tw") or ""),
        }
        for row in rows if isinstance(row, dict)
    ]
    items = [item for item in items if item["id"] and item["normalized"]]
    _station_cache[key] = (time.time(), items)
    return items


def _parse_date(text: str, now: Optional[datetime] = None) -> Optional[date]:
    current = (now or datetime.now(TAIPEI)).astimezone(TAIPEI).date()
    if "後天" in text:
        return current + timedelta(days=2)
    if "明天" in text:
        return current + timedelta(days=1)
    if "今天" in text or "今日" in text:
        return current
    match = re.search(r"(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})(?:日)?", text)
    if match:
        try:
            return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
        except ValueError:
            return None
    match = re.search(r"(?:^|\s)(\d{1,2})[-/.月](\d{1,2})(?:日)?(?:\s|$)", text)
    if not match:
        return None
    try:
        result = date(current.year, int(match.group(1)), int(match.group(2)))
        return result if result >= current else date(current.year + 1, result.month, result.day)
    except ValueError:
        return None


def _time_range(text: str) -> Tuple[int, int, str]:
    if "全天" in text or "全日" in text:
        return 0, 1439, "全天"
    colon = re.search(r"(?:^|\s)([01]?\d|2[0-3])[:：](\d{2})(?:\s|$)", text)
    words = re.search(r"(早上|上午|中午|下午|晚上|晚間)?\s*([01]?\d|2[0-3])\s*點(?:\s*(半|\d{1,2})\s*分?)?", text)
    if colon or words:
        hour = int(colon.group(1) if colon else words.group(2))
        minute = int(colon.group(2)) if colon else (30 if words.group(3) == "半" else int(words.group(3) or 0))
        period = "" if colon else str(words.group(1) or "")
        if period in {"下午", "晚上", "晚間"} and hour < 12:
            hour += 12
        if period == "中午" and hour < 11:
            hour += 12
        start = min(1439, hour * 60 + minute)
        return start, min(1439, start + 240), f"{start // 60:02d}:{start % 60:02d} 起"
    if "下午" in text:
        return 720, 1080, "下午"
    if "晚上" in text or "晚間" in text:
        return 1080, 1439, "晚間"
    if "早上" in text or "上午" in text:
        return 300, 720, "上午"
    return 360, 720, "06:00 起"


def _station_in(segment: str, stations: List[Dict[str, str]], prefer_last: bool) -> Optional[Dict[str, str]]:
    normalized = _normalize_station(segment)
    normalized = re.sub(r"高鐵|台鐵|查詢|班次|時刻", "", normalized).replace("高雄", "左營")
    matches = [item for item in stations if item["normalized"] in normalized]
    if not matches:
        return None
    matches.sort(key=lambda item: len(item["normalized"]), reverse=True)
    if prefer_last:
        matches.sort(key=lambda item: normalized.rfind(item["normalized"]), reverse=True)
    return matches[0]


def parse_rail_request(
    text: str,
    operator: str,
    *,
    station_rows: Optional[List[Dict[str, str]]] = None,
    now: Optional[datetime] = None,
) -> Dict:
    parts = re.split(r"\s*(?:到|至|→|->)\s*", str(text or ""), maxsplit=1)
    if len(parts) != 2:
        return {"ok": False, "error": "route_missing"}
    rows = station_rows if station_rows is not None else _stations(operator)
    origin = _station_in(parts[0], rows, True)
    destination = _station_in(parts[1], rows, False)
    if not origin or not destination or origin["id"] == destination["id"]:
        return {"ok": False, "error": "station_invalid"}
    travel_date = _parse_date(str(text or ""), now)
    if not travel_date:
        return {"ok": False, "error": "date_missing", "origin": origin, "destination": destination}
    start, end, label = _time_range(str(text or ""))
    return {
        "ok": True,
        "operator": operator.upper(),
        "origin": origin,
        "destination": destination,
        "date": travel_date.isoformat(),
        "start": start,
        "end": end,
        "time_label": label,
    }


def _minutes(value: str) -> int:
    match = re.match(r"^(\d{2}):(\d{2})$", str(value or ""))
    return int(match.group(1)) * 60 + int(match.group(2)) if match else -1


def _duration(departure: str, arrival: str) -> str:
    start, end = _minutes(departure), _minutes(arrival)
    if start < 0 or end < 0:
        return ""
    if end < start:
        end += 1440
    value = end - start
    return f"{value // 60}小時{value % 60:02d}分"


def _normal_fare(operator: str, fare_rows: List[Dict]) -> str:
    fares = fare_rows[0].get("Fares") if fare_rows else []
    if operator == "THSR":
        item = next((row for row in fares if row.get("TicketType") == 1 and row.get("FareClass") == 1 and row.get("CabinClass") == 1), None)
        return f"標準座全票 NT${item['Price']}" if item else ""
    item = next((row for row in fares if row.get("TicketType") == "成自"), None)
    return f"自強號全票 NT${item['Price']}" if item else ""


def _official_thsr_query(parsed: Dict) -> Dict:
    payload = {
        "SearchType": "S", "Lang": "TW",
        "StartStation": parsed["origin"]["code"], "EndStation": parsed["destination"]["code"],
        "OutWardSearchDate": parsed["date"].replace("-", "/"), "OutWardSearchTime": f"{parsed['start'] // 60:02d}:{parsed['start'] % 60:02d}",
        "ReturnSearchDate": parsed["date"].replace("-", "/"), "ReturnSearchTime": f"{parsed['start'] // 60:02d}:{parsed['start'] % 60:02d}",
        "DiscountType": "",
    }
    raw = _http_text(
        "https://www.thsrc.com.tw/TimeTable/Search",
        data=payload,
        headers={
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Referer": THSR_TIMETABLE_PAGE,
            "Origin": "https://www.thsrc.com.tw",
            "X-Requested-With": "XMLHttpRequest",
        },
    )
    result = json.loads(raw)
    if not result.get("success"):
        raise RuntimeError("thsr_query_failed")
    items = (((result.get("data") or {}).get("DepartureTable") or {}).get("TrainItem") or [])
    matches = []
    for item in items:
        departure = str(item.get("DepartureTime") or "")
        minute = _minutes(departure)
        if minute < parsed["start"] or minute > parsed["end"]:
            continue
        duration = str(item.get("Duration") or "")
        duration_match = re.match(r"^(\d{2}):(\d{2})$", duration)
        if duration_match:
            duration = f"{int(duration_match.group(1))}小時{duration_match.group(2)}分"
        matches.append({
            "departure": departure,
            "arrival": str(item.get("DestinationTime") or ""),
            "number": str(item.get("TrainNumber") or ""),
            "type": "高鐵",
            "duration": duration,
            "non_reserved": str(item.get("NonReservedCar") or ""),
        })
        if len(matches) >= 8:
            break
    coach = str((((result.get("data") or {}).get("PriceTable") or {}).get("Coach") or [""])[0]).replace("$", "NT$")
    return {"matches": matches, "fare": f"標準座全票 {coach}" if coach else ""}


def _official_tra_context() -> Dict:
    cookie_jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
    page = _http_text(TRA_TIMETABLE_PAGE, opener=opener)
    csrf_match = re.search(r'name="_csrf"\s+value="([^"]+)"', page, re.IGNORECASE)
    stations = _tra_stations_from_page(page)
    if not csrf_match or len(stations) < 100:
        raise RuntimeError("tra_page_parse_failed")
    return {"opener": opener, "csrf": csrf_match.group(1), "stations": stations}


def _official_tra_query(parsed: Dict, context: Dict) -> Dict:
    raw = _http_text(
        "https://tip.railway.gov.tw/tra-tip-web/tip/tip001/tip112/querybytime",
        data={
            "_csrf": context["csrf"],
            "startStation": parsed["origin"]["code"], "endStation": parsed["destination"]["code"],
            "transfer": "ONE", "rideDate": parsed["date"].replace("-", "/"), "startOrEndTime": "true",
            "startTime": f"{parsed['start'] // 60:02d}:{parsed['start'] % 60:02d}",
            "endTime": f"{parsed['end'] // 60:02d}:{parsed['end'] % 60:02d}",
            "trainTypeList": "ALL", "queryClassification": "NORMAL", "query": "查詢",
        },
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Referer": TRA_TIMETABLE_PAGE,
            "Origin": "https://tip.railway.gov.tw",
        },
        opener=context["opener"],
    )
    matches = []
    for row in re.findall(r'<tr\s+class="trip-column">([\s\S]*?)</tr>', raw, re.IGNORECASE):
        train_match = re.search(r'<ul\s+class="train-number">[\s\S]*?<a[^>]*>([\s\S]*?)</a>', row, re.IGNORECASE)
        train_label = _html_text(train_match.group(1) if train_match else "")
        number_match = re.search(r"(\d+)\s*$", train_label)
        times = re.findall(r'<td[^>]*>\s*(\d{2}:\d{2})\s*</td>', row, re.IGNORECASE)
        if not number_match or len(times) < 2:
            continue
        number = number_match.group(1)
        train_type = re.sub(r"\s*\d+\s*$", "", train_label).strip() or "列車"
        duration_match = re.search(r'<td[^>]*>\s*((?:\d+\s*小時\s*)?\d+\s*分)\s*</td>', row, re.IGNORECASE)
        duration = re.sub(r"\s+", "", _html_text(duration_match.group(1) if duration_match else "")) or _duration(times[0], times[1])
        prices = [int(value.replace(",", "")) for value in re.findall(r'<span>\s*\$\s*([\d,]+)\s*</span>', row, re.IGNORECASE)]
        matches.append({
            "departure": times[0], "arrival": times[1], "number": number,
            "type": train_type, "duration": duration, "fare": prices[0] if prices else None,
        })
        if len(matches) >= 8:
            break
    fare_item = next((item for item in matches if item.get("fare")), None)
    return {"matches": matches, "fare": f"自強號全票 NT${fare_item['fare']}" if fare_item else ""}


def query_rail(text: str, operator: str, fetch_json: Callable = _http_json, now: Optional[datetime] = None) -> Dict:
    op = operator.upper()
    if op == "THSR":
        parsed = parse_rail_request(text, op, station_rows=THSR_STATIONS, now=now)
        if not parsed.get("ok"):
            return parsed
        result = _official_thsr_query(parsed)
    else:
        context = _official_tra_context()
        parsed = parse_rail_request(text, op, station_rows=context["stations"], now=now)
        if not parsed.get("ok"):
            return parsed
        result = _official_tra_query(parsed, context)
    operator_name = "高鐵" if op == "THSR" else "台鐵"
    lines = [
        f"{operator_name}｜{parsed['date']} {parsed['origin']['name']} → {parsed['destination']['name']}",
        f"時段：{parsed['time_label']}" + (f"｜{result['fare']}" if result.get("fare") else ""),
        "",
    ]
    if not result["matches"]:
        lines.append("這個時段沒有查到可用班次，請改成「全天」或換一個時間再查。")
    else:
        for index, item in enumerate(result["matches"], 1):
            non_reserved = f"｜自由座 {item['non_reserved']} 車" if item.get("non_reserved") else ""
            lines.append(f"{index}. {item['departure']} → {item['arrival']}｜{item['type']} {item['number']}｜{item['duration']}{non_reserved}")
    source = "台灣高鐵" if op == "THSR" else "台灣鐵路"
    lines.extend(["", f"資料來源：{source}官方網站；剩餘座位與即時異動請使用官方訂票按鈕確認。"])
    return {**parsed, "matches": result["matches"], "fare": result.get("fare", ""), "reply": "\n".join(lines)}


def sale_reminder(text: str, operator: str, now: Optional[datetime] = None) -> Dict:
    current = (now or datetime.now(TAIPEI)).astimezone(TAIPEI)
    travel_date = _parse_date(text, current)
    if not travel_date:
        return {"ok": False, "error": "date_missing"}
    sale_date = travel_date - timedelta(days=28)
    remind_at = datetime.combine(sale_date - timedelta(days=1), datetime_time(21, 0), TAIPEI)
    if remind_at <= current:
        return {"ok": False, "error": "reminder_in_past", "travel_date": travel_date.isoformat(), "sale_date": sale_date.isoformat()}
    return {
        "ok": True,
        "operator": operator.upper(),
        "travel_date": travel_date.isoformat(),
        "sale_date": sale_date.isoformat(),
        "remind_at": remind_at.isoformat(),
    }


def _read_reminders() -> List[Dict]:
    try:
        data = json.loads(REMINDER_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _write_reminders(rows: List[Dict]) -> None:
    REMINDER_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = REMINDER_PATH.with_suffix(f".{time.time_ns()}.tmp")
    temporary.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(REMINDER_PATH)


def _add_sale_reminder(bot_instance: str, chat_id: int, target: Dict, sale: Dict, source_text: str) -> Dict:
    with _reminder_lock:
        rows = _read_reminders()
        record = {
            "id": f"rail-{time.time_ns()}",
            "bot": str(bot_instance),
            "chat_id": int(chat_id),
            "message_thread_id": int(target.get("message_thread_id") or 0),
            "operator": sale["operator"],
            "travel_date": sale["travel_date"],
            "sale_date": sale["sale_date"],
            "remind_at": sale["remind_at"],
            "source_text": str(source_text)[:500],
            "status": "pending",
            "created_at": datetime.now(TAIPEI).isoformat(),
        }
        rows.append(record)
        _write_reminders(rows[-2000:])
        return record


def _list_sale_reminders(bot_instance: str, chat_id: int, target: Dict) -> List[Dict]:
    thread_id = int(target.get("message_thread_id") or 0)
    now = datetime.now(TAIPEI)
    with _reminder_lock:
        return sorted([
            row for row in _read_reminders()
            if row.get("status") == "pending"
            and str(row.get("bot")) == str(bot_instance)
            and int(row.get("chat_id") or 0) == int(chat_id)
            and int(row.get("message_thread_id") or 0) == thread_id
            and datetime.fromisoformat(str(row.get("remind_at"))) > now
        ], key=lambda row: row["remind_at"])


def _cancel_sale_reminder(bot_instance: str, chat_id: int, target: Dict, number: int) -> Optional[Dict]:
    pending = _list_sale_reminders(bot_instance, chat_id, target)
    if number < 1 or number > len(pending):
        return None
    selected_id = pending[number - 1]["id"]
    with _reminder_lock:
        rows = _read_reminders()
        selected = None
        for row in rows:
            if row.get("id") == selected_id:
                row["status"] = "cancelled"
                row["cancelled_at"] = datetime.now(TAIPEI).isoformat()
                selected = row
                break
        _write_reminders(rows)
        return selected


def poll_due_studio_reminders(bot_instance: str, telegram_call: Callable, target_payload_builder: Callable) -> None:
    now_ts = time.time()
    if now_ts - _last_reminder_poll.get(str(bot_instance), 0) < 25:
        return
    _last_reminder_poll[str(bot_instance)] = now_ts
    now = datetime.now(TAIPEI)
    with _reminder_lock:
        rows = _read_reminders()
        due = [
            row for row in rows
            if row.get("status") == "pending"
            and str(row.get("bot")) == str(bot_instance)
            and datetime.fromisoformat(str(row.get("remind_at"))) <= now
        ][:30]
        changed = False
        for row in due:
            payload = dict(target_payload_builder(int(row["chat_id"])))
            if int(row.get("message_thread_id") or 0):
                payload["message_thread_id"] = int(row["message_thread_id"])
            operator_name = "高鐵" if row.get("operator") == "THSR" else "台鐵"
            payload.update({
                "text": f"🔔 {operator_name}開賣提醒\n乘車日：{row['travel_date']}\n預估今天 {row['sale_date']} 開賣，請到官方訂票頁確認；連假或臨時調整以官方公告為準。",
                "disable_web_page_preview": True,
                "reply_markup": {"inline_keyboard": [[{"text": f"開啟{operator_name}官方訂票", "url": THSR_BOOKING_URL if row.get("operator") == "THSR" else TRA_BOOKING_URL}]]},
            })
            try:
                telegram_call("sendMessage", payload)
                row["status"] = "sent"
                row["sent_at"] = now.isoformat()
                changed = True
            except Exception:
                continue
        if changed:
            _write_reminders(rows)

    with _studio_state_lock:
        states = _read_workspace_states()
        due_summaries = []
        due_products = []
        for state_key, state in states.items():
            if str(state.get("bot")) != str(bot_instance):
                continue
            for product in (state.get("tracking") or {}).get("products", []):
                if product.get("status") != "tracking" or not product.get("url") or not product.get("next_check_at"):
                    continue
                try:
                    product_due_at = datetime.fromisoformat(str(product.get("next_check_at"))).astimezone(TAIPEI)
                except Exception:
                    continue
                if product_due_at <= now:
                    due_products.append((state_key, json.loads(json.dumps(state, ensure_ascii=False)), dict(product)))
            summary = ((state.get("tracking") or {}).get("daily_summary") or {})
            if not summary.get("enabled") or not (state.get("settings") or {}).get("notifications", True):
                continue
            try:
                next_at = datetime.fromisoformat(str(summary.get("next_at"))).astimezone(TAIPEI)
            except Exception:
                continue
            if next_at <= now:
                due_summaries.append((state_key, json.loads(json.dumps(state, ensure_ascii=False))))
    for state_key, state in due_summaries[:20]:
        instruments = [row for row in (state.get("tracking") or {}).get("instruments", []) if row.get("status") != "paused"][:10]
        quotes = []
        for item in instruments:
            try:
                quotes.append(query_market_quote(str(item.get("symbol") or "")))
            except Exception:
                quotes.append({"ok": False, "symbol": str(item.get("symbol") or "")})
        payload = dict(target_payload_builder(int(state["chat_id"])))
        if int(state.get("message_thread_id") or 0):
            payload["message_thread_id"] = int(state["message_thread_id"])
        payload.update({
            "text": "\n".join([
                "🌅 每日投資追蹤摘要",
                *([_market_quote_line(quote) for quote in quotes] or ["目前沒有啟用中的追蹤標的。"]),
                "",
                "公開市場報價可能延遲，不構成投資建議。",
            ]),
            "disable_web_page_preview": True,
        })
        try:
            telegram_call("sendMessage", payload)
        except Exception:
            continue
        with _studio_state_lock:
            states = _read_workspace_states()
            current = states.get(state_key)
            if not isinstance(current, dict):
                continue
            summary = ((current.get("tracking") or {}).get("daily_summary") or {})
            next_at = datetime.fromisoformat(str(summary.get("next_at"))).astimezone(TAIPEI)
            while next_at <= now:
                next_at += timedelta(days=1)
            summary["next_at"] = next_at.isoformat()
            summary["last_sent_at"] = now.isoformat()
            states[state_key] = current
            _write_workspace_states(states)
    for state_key, state, product in due_products[:30]:
        try:
            quote = query_product_price(str(product.get("url") or ""))
        except Exception as error:
            quote = {"ok": False, "error": str(error)}
        with _studio_state_lock:
            states = _read_workspace_states()
            current = states.get(state_key)
            if not isinstance(current, dict):
                continue
            current_product = next((row for row in (current.get("tracking") or {}).get("products", []) if row.get("id") == product.get("id")), None)
            if not current_product:
                continue
            next_check = datetime.fromisoformat(str(current_product.get("next_check_at"))).astimezone(TAIPEI)
            while next_check <= now:
                next_check += timedelta(days=1)
            current_product["next_check_at"] = next_check.isoformat()
            current_product["last_checked_at"] = now.isoformat()
            current_product["last_price"] = quote.get("price") if quote.get("ok") else current_product.get("last_price")
            current_product["last_error"] = "" if quote.get("ok") else str(quote.get("error") or "price_check_failed")[:80]
            states[state_key] = current
            _write_workspace_states(states)
        target_price = product.get("target_price")
        target_reached = quote.get("ok") and isinstance(target_price, (int, float)) and float(quote["price"]) <= float(target_price)
        if not target_reached or not (state.get("settings") or {}).get("notifications", True):
            continue
        payload = dict(target_payload_builder(int(state["chat_id"])))
        if int(state.get("message_thread_id") or 0):
            payload["message_thread_id"] = int(state["message_thread_id"])
        payload.update({
            "text": f"📉 商品已達目標價\n{product.get('label')}\n目前價格：{float(quote['price']):,.2f} {quote.get('currency', '')}\n目標價格：{float(target_price):,.2f}\n{product.get('url')}",
            "disable_web_page_preview": True,
        })
        try:
            telegram_call("sendMessage", payload)
        except Exception:
            continue


def handle_studio_menu_message(
    chat_id: int,
    text: str,
    bot_instance: str,
    telegram_call: Callable,
    target_payload_builder: Callable,
) -> bool:
    raw = str(text or "").strip()
    plain = _plain(raw)
    target = dict(target_payload_builder(int(chat_id)))
    key = _target_key(bot_instance, int(chat_id), target)

    if plain in {"收合選單", "隱藏選單", "關閉選單"}:
        _update_workspace_state(
            bot_instance,
            chat_id,
            target,
            lambda value: value["settings"].update({"menu_collapsed": True}),
        )
        _send(
            chat_id,
            "功能選單已收合；需要時輸入「功能選單」即可重新展開。",
            telegram_call,
            target_payload_builder,
            {"remove_keyboard": True},
        )
        return True

    if raw.lower() == "/status":
        _send(
            chat_id,
            f"{bot_instance} 目前在線，功能選單與蝦咩工作室可正常使用。\n\n{token_usage_reply(bot_instance)}",
            telegram_call,
            target_payload_builder,
        )
        return True

    menu_alias = plain in {
        "功能表", "功能表在哪", "功能選單", "功能選單在哪", "選單", "選單在哪",
    }
    menu_complaint = any(label in plain for label in ("功能表", "功能選單", "選單")) and any(
        intent in plain for intent in ("在哪", "沒有", "沒出現", "不見", "找不到", "顯示", "出現", "打開", "開啟", "叫出")
    )
    if raw.lower() in {"/start", "/menu"} or menu_alias or menu_complaint:
        _update_workspace_state(
            bot_instance,
            chat_id,
            target,
            lambda value: value["settings"].update({"menu_collapsed": False}),
        )
        _send(chat_id, "藍星蝦咩｜功能選單\n常用功能・個人助理・服務支援", telegram_call, target_payload_builder, studio_main_reply_keyboard())
        return True

    studio_alias = plain in {"蝦咩工作室", "蝦咩工作室在哪", "蝦工作室", "蝦工作室在哪", "工作室", "工作室在哪"}
    studio_complaint = any(label in plain for label in ("蝦咩工作室", "蝦工作室")) and any(
        intent in plain for intent in ("在哪", "沒有", "沒出現", "不見", "找不到", "顯示", "出現", "打開", "開啟", "叫出")
    )
    if raw.lower() == "/studio" or studio_alias or studio_complaint:
        _send(chat_id, "蝦咩工作室｜請選擇功能，也可以直接輸入任務。", telegram_call, target_payload_builder, studio_workspace_reply_keyboard())
        return True

    if plain == "一般問答":
        _send(chat_id, "請直接輸入問題，我會依這一則訊息思考後回答。💬", telegram_call, target_payload_builder)
        return True
    if plain in {"製作圖片", "IMAGE2 做圖"}:
        _send(chat_id, "製作圖片｜請選擇純文字或上傳參考圖。", telegram_call, target_payload_builder, _reply_keyboard(IMAGE2_MENU))
        return True
    if plain == "製作影片":
        _send(chat_id, "請輸入影片主題、素材、比例、秒數與希望效果；提交前會先整理確認內容。🎬", telegram_call, target_payload_builder)
        return True
    if plain == "上傳檔案":
        _send(chat_id, "請直接上傳圖片、影片、音訊或文件，再補一句要我完成的結果。📎", telegram_call, target_payload_builder)
        return True
    if plain in {"新增提醒", "新增排程"}:
        _send(chat_id, ACTION_PROMPTS["新增排程"], telegram_call, target_payload_builder)
        return True
    if plain == "查看提醒":
        plain = "查看排程"
    if plain == "個人設定":
        settings = _workspace_state(bot_instance, chat_id, target)["settings"]
        rows = [["🧠 記憶狀態", "🔔 通知設定"], ["↩️ 蝦咩工作室"]]
        _send(chat_id, f"個人設定 ⚙️\n語言：{settings.get('language', '繁體中文')}\n主動通知：{'開啟' if settings.get('notifications', True) else '關閉'}", telegram_call, target_payload_builder, _reply_keyboard(rows))
        return True
    if plain == "Token 統計":
        _send(chat_id, token_usage_reply(bot_instance), telegram_call, target_payload_builder)
        return True
    if plain in {"藍星AI客服", "客服協助", "聯絡客服"}:
        markup = {"inline_keyboard": [[{"text": "聯繫藍星AI官方 LINE 客服", "url": "https://lin.ee/FmJ2Ytq"}]]}
        _send(chat_id, "藍星AI官方 LINE 客服\nLINE ID：@977wywdw", telegram_call, target_payload_builder, markup)
        return True
    if plain == "續訂與續期":
        markup = {"inline_keyboard": [[{"text": "聯繫客服辦理續訂", "url": "https://lin.ee/FmJ2Ytq"}]]}
        _send(chat_id, "續訂、續期與額度問題請聯繫藍星AI官方 LINE 客服。💳", telegram_call, target_payload_builder, markup)
        return True

    section = _section_for_text(raw)
    if section == "蝦遊藝":
        markup = {"inline_keyboard": [[{"text": name, "url": url}] for name, url in GAME_URLS.items()]}
        _send(chat_id, "蝦遊藝｜四款遊戲已驗證可直接開啟。", telegram_call, target_payload_builder, markup)
        return True
    if section:
        title, rows = SECTION_MENUS[section]
        _send(chat_id, title, telegram_call, target_payload_builder, _reply_keyboard(rows))
        return True

    if plain in {"高鐵查詢", "台鐵查詢"}:
        _pending[key] = "rail_thsr" if plain == "高鐵查詢" else "rail_tra"
        _send(chat_id, "請輸入「起站到迄站＋日期＋時間」，例如：\n台北到台中 明天早上 8 點\n\n也可輸入上午、下午、晚間或全天；剩餘座位與即時異動請使用官方訂位頁查看。🚆", telegram_call, target_payload_builder)
        return True

    pending = _pending.get(key, "")
    if pending.startswith("studio_"):
        state = _workspace_state(bot_instance, int(chat_id), target)
        if pending in {"studio_task_create", "studio_task_continue"}:
            if pending == "studio_task_create":
                task = {
                    "id": f"T{time.time_ns()}", "title": plain[:240], "status": "submitted",
                    "created_at": datetime.now(TAIPEI).isoformat(), "updated_at": datetime.now(TAIPEI).isoformat(),
                }
                _update_workspace_state(bot_instance, chat_id, target, lambda value: value["tasks"].append(task))
            else:
                def continue_latest(value: Dict) -> None:
                    if value["tasks"]:
                        value["tasks"][-1]["status"] = "submitted"
                        value["tasks"][-1]["updated_at"] = datetime.now(TAIPEI).isoformat()
                _update_workspace_state(bot_instance, chat_id, target, continue_latest)
            _pending.pop(key, None)
            return False
        if pending == "studio_task_delete":
            number_match = re.search(r"\d+", plain)
            number = int(number_match.group(0)) if number_match else 0
            removed = []
            def delete_task(value: Dict) -> None:
                ordered = list(reversed(value["tasks"]))
                if 1 <= number <= len(ordered):
                    removed.append(ordered[number - 1])
                    value["tasks"] = [task for task in value["tasks"] if task.get("id") != removed[0].get("id")]
            _update_workspace_state(bot_instance, chat_id, target, delete_task)
            _pending.pop(key, None)
            _send(chat_id, f"已刪除任務：{removed[0]['title']}" if removed else "找不到這一筆任務。", telegram_call, target_payload_builder)
            return True
        if pending in {"studio_skill_enable", "studio_skill_disable", "studio_skill_priority"}:
            priority_match = re.search(r"\s(高|中|低)(?:優先)?\s*$", plain)
            skill_name = re.sub(r"\s(高|中|低)(?:優先)?\s*$", "", plain).strip()
            def update_skill(value: Dict) -> None:
                enabled = set(value["skills"].get("enabled") or [])
                if pending == "studio_skill_disable":
                    enabled.discard(skill_name)
                else:
                    enabled.add(skill_name)
                value["skills"]["enabled"] = sorted(enabled)
                if pending == "studio_skill_priority":
                    value["skills"].setdefault("priorities", {})[skill_name] = priority_match.group(1) if priority_match else "中"
            _update_workspace_state(bot_instance, chat_id, target, update_skill)
            _pending.pop(key, None)
            action_text = "已停用" if pending == "studio_skill_disable" else (f"已設為{priority_match.group(1) if priority_match else '中'}優先" if pending == "studio_skill_priority" else "已啟用")
            _send(chat_id, f"{action_text}技能：{skill_name}。🧩", telegram_call, target_payload_builder)
            return True
        if pending == "studio_tracking_add":
            parts = plain.split()
            symbol = normalize_market_symbol(parts[0] if parts else "")
            if not symbol:
                _send(chat_id, "請輸入標的代碼或名稱。", telegram_call, target_payload_builder)
                return True
            item = {"id": f"I{time.time_ns()}", "symbol": symbol, "label": parts[0], "note": " ".join(parts[1:])[:200], "status": "active", "created_at": datetime.now(TAIPEI).isoformat()}
            def add_instrument(value: Dict) -> None:
                rows = value["tracking"]["instruments"]
                existing = next((row for row in rows if row.get("symbol") == symbol), None)
                if existing:
                    existing.update({"note": item["note"] or existing.get("note", ""), "status": "active"})
                else:
                    rows.append(item)
            _update_workspace_state(bot_instance, chat_id, target, add_instrument)
            _pending.pop(key, None)
            try:
                quote = query_market_quote(symbol)
            except Exception:
                quote = {"ok": False, "symbol": symbol}
            _send(chat_id, f"已加入投資追蹤：{_market_quote_line(quote)}", telegram_call, target_payload_builder)
            return True
        if pending in {"studio_tracking_note", "studio_tracking_pause", "studio_tracking_remove"}:
            number_match = re.match(r"\s*(\d+)", plain)
            number = int(number_match.group(1)) if number_match else 0
            note = re.sub(r"^\s*\d+\s*[:：-]?\s*", "", plain)[:200]
            changed = []
            def update_tracking(value: Dict) -> None:
                ordered = list(reversed(value["tracking"]["instruments"]))
                if not 1 <= number <= len(ordered):
                    return
                item = ordered[number - 1]
                changed.append(dict(item))
                if pending == "studio_tracking_remove":
                    value["tracking"]["instruments"] = [row for row in value["tracking"]["instruments"] if row.get("id") != item.get("id")]
                elif pending == "studio_tracking_pause":
                    item["status"] = "active" if item.get("status") == "paused" else "paused"
                    changed[0]["status"] = item["status"]
                else:
                    item["note"] = note
            _update_workspace_state(bot_instance, chat_id, target, update_tracking)
            _pending.pop(key, None)
            _send(chat_id, f"已更新：{changed[0]['symbol']}" if changed else "找不到這一筆追蹤。", telegram_call, target_payload_builder)
            return True
        if pending == "studio_tracking_daily":
            match = re.search(r"([01]?\d|2[0-3])[:：](\d{2})", plain)
            hour, minute = (int(match.group(1)), int(match.group(2))) if match else (8, 0)
            next_at = datetime.now(TAIPEI).replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_at <= datetime.now(TAIPEI):
                next_at += timedelta(days=1)
            def set_daily(value: Dict) -> None:
                value["tracking"]["daily_summary"] = {"enabled": True, "time": f"{hour:02d}:{minute:02d}", "next_at": next_at.isoformat()}
            _update_workspace_state(bot_instance, chat_id, target, set_daily)
            _pending.pop(key, None)
            _send(chat_id, f"每日投資摘要已啟用，會在每天 {hour:02d}:{minute:02d} 推送。🌅", telegram_call, target_payload_builder)
            return True
        if pending == "studio_product_track":
            url_match = re.search(r"https://\S+", plain)
            price_text = plain.replace(url_match.group(0), "") if url_match else plain
            prices = [float(value.replace(",", "")) for value in re.findall(r"(?<![A-Za-z])([0-9][0-9,]*(?:\.\d+)?)", price_text)]
            label = re.sub(r"https://\S+", "", plain).strip()[:220] or (url_match.group(0) if url_match else "")
            next_check = datetime.now(TAIPEI).replace(hour=9, minute=0, second=0, microsecond=0)
            if next_check <= datetime.now(TAIPEI):
                next_check += timedelta(days=1)
            item = {"id": f"P{time.time_ns()}", "label": label, "url": url_match.group(0) if url_match else "", "target_price": prices[-1] if prices else None, "status": "tracking", "next_check_at": next_check.isoformat() if url_match else None, "created_at": datetime.now(TAIPEI).isoformat()}
            _update_workspace_state(bot_instance, chat_id, target, lambda value: value["tracking"]["products"].append(item))
            _pending.pop(key, None)
            _send(chat_id, f"已加入降價追蹤：{label}", telegram_call, target_payload_builder)
            return True
        if pending in {"studio_product_purchased", "studio_product_stop"}:
            number_match = re.search(r"\d+", plain)
            number = int(number_match.group(0)) if number_match else 0
            changed = []
            def update_product(value: Dict) -> None:
                ordered = list(reversed(value["tracking"]["products"]))
                if 1 <= number <= len(ordered):
                    item = ordered[number - 1]
                    item["status"] = "purchased" if pending == "studio_product_purchased" else "cancelled"
                    changed.append(dict(item))
            _update_workspace_state(bot_instance, chat_id, target, update_product)
            _pending.pop(key, None)
            _send(chat_id, f"已更新商品：{changed[0]['label']}" if changed else "找不到這一筆商品追蹤。", telegram_call, target_payload_builder)
            return True
        if pending in {"studio_classroom_favorite", "studio_classroom_complete"}:
            field = "favorites" if pending.endswith("favorite") else "completed"
            def update_classroom(value: Dict) -> None:
                if plain not in value["classroom"][field]:
                    value["classroom"][field].append(plain[:160])
            _update_workspace_state(bot_instance, chat_id, target, update_classroom)
            _pending.pop(key, None)
            _send(chat_id, f"已{'收藏' if field == 'favorites' else '標記完成'}：{plain}。🎓", telegram_call, target_payload_builder)
            return True
        if pending == "studio_feedback":
            record = {"id": f"F{time.time_ns()}", "text": plain[:1000], "status": "submitted", "created_at": datetime.now(TAIPEI).isoformat()}
            _update_workspace_state(bot_instance, chat_id, target, lambda value: value["feedback"].append(record))
            _pending.pop(key, None)
            _send(chat_id, f"回饋已保存，編號 {record['id']}。", telegram_call, target_payload_builder)
            return True
        if pending == "studio_notifications":
            enabled = not re.search(r"關閉|停用|不要|off", plain, re.I)
            _update_workspace_state(bot_instance, chat_id, target, lambda value: value["settings"].update({"notifications": enabled}))
            _pending.pop(key, None)
            _send(chat_id, f"主動通知已{'開啟' if enabled else '關閉'}。🔔", telegram_call, target_payload_builder)
            return True
    direct_rail = ""
    if re.match(r"^(?:高鐵|台鐵)查詢\s*[:：]?\s*.+(?:到|至|→|->).+", plain):
        direct_rail = "rail_thsr" if plain.startswith("高鐵") else "rail_tra"
    if direct_rail or pending in {"rail_thsr", "rail_tra"}:
        operator = "THSR" if (direct_rail or pending) == "rail_thsr" else "TRA"
        try:
            result = query_rail(plain, operator)
            if not result.get("ok"):
                message = "還缺乘車日期，請用「台北到台中 7/30 早上 8 點」再傳一次。" if result.get("error") == "date_missing" else "沒有辨識到不同的起站與迄站，請用「台北到台中 明天上午」再傳一次。"
                _send(chat_id, message, telegram_call, target_payload_builder)
                return True
            _pending.pop(key, None)
            _send(chat_id, result["reply"], telegram_call, target_payload_builder)
        except Exception:
            _send(chat_id, "官方鐵路查詢這次沒有正常回傳班次，沒有用舊資料代替；請稍後用同一個查詢再試一次。🌐", telegram_call, target_payload_builder)
        return True

    if plain in {"高鐵開賣提醒", "台鐵開賣提醒"}:
        _pending[key] = "sale_thsr" if plain == "高鐵開賣提醒" else "sale_tra"
        _send(chat_id, "請輸入乘車日期，可加起迄站與備註，例如：\n2026-08-30 台北到左營 兩張票\n\n系統會在預估開賣日前一晚 21:00 提醒；連假調整仍以官方公告為準。🔔", telegram_call, target_payload_builder)
        return True

    direct_sale = ""
    if re.match(r"^(?:高鐵|台鐵)開賣提醒\s*[:：]?\s*.+", plain):
        direct_sale = "sale_thsr" if plain.startswith("高鐵") else "sale_tra"
    if direct_sale or pending in {"sale_thsr", "sale_tra"}:
        operator = "THSR" if (direct_sale or pending) == "sale_thsr" else "TRA"
        result = sale_reminder(plain, operator)
        if not result.get("ok"):
            message = "這個日期依一般提前 28 天規則已經開賣或接近開賣，請直接到官方訂票頁確認。" if result.get("error") == "reminder_in_past" else "還缺完整乘車日期，請輸入像「2026-08-30 台北到左營」。"
            _send(chat_id, message, telegram_call, target_payload_builder)
            return True
        _add_sale_reminder(bot_instance, chat_id, target, result, plain)
        _pending.pop(key, None)
        operator_name = "高鐵" if operator == "THSR" else "台鐵"
        _send(chat_id, f"已建立{operator_name}開賣提醒 🔔\n乘車日：{result['travel_date']}\n預估開賣日：{result['sale_date']}\n提醒時間：{datetime.fromisoformat(result['remind_at']).strftime('%Y-%m-%d 21:00')}\n連假或臨時調整仍以官方公告為準。", telegram_call, target_payload_builder)
        return True

    if plain == "查看排程":
        rows = _list_sale_reminders(bot_instance, chat_id, target)
        if not rows:
            _send(chat_id, "目前沒有尚未發送的鐵路開賣提醒；一般排程可直接輸入要執行的內容與時間。", telegram_call, target_payload_builder)
        else:
            lines = ["目前的鐵路開賣提醒："]
            for index, row in enumerate(rows, 1):
                operator_name = "高鐵" if row.get("operator") == "THSR" else "台鐵"
                lines.append(f"{index}. {operator_name} {row['travel_date']}｜{datetime.fromisoformat(row['remind_at']).strftime('%Y-%m-%d %H:%M')}")
            lines.append("\n要刪除請按「取消排程」後輸入編號。")
            _send(chat_id, "\n".join(lines), telegram_call, target_payload_builder)
        return True

    if plain == "取消排程":
        _pending[key] = "cancel_reminder"
        _send(chat_id, "請輸入要取消的提醒編號；可先按「查看排程」取得清單。", telegram_call, target_payload_builder)
        return True
    if pending == "cancel_reminder" and re.fullmatch(r"\d+", plain):
        cancelled = _cancel_sale_reminder(bot_instance, chat_id, target, int(plain))
        if cancelled:
            _pending.pop(key, None)
            _send(chat_id, f"已取消 {cancelled['travel_date']} 的鐵路開賣提醒。", telegram_call, target_payload_builder)
        else:
            _send(chat_id, "找不到這個提醒編號，請先按「查看排程」。", telegram_call, target_payload_builder)
        return True

    if plain == "官方訂票":
        markup = {"inline_keyboard": [[{"text": "高鐵官方訂位／座位", "url": THSR_BOOKING_URL}], [{"text": "台鐵官方訂票", "url": TRA_BOOKING_URL}]]}
        _send(chat_id, "請選擇官方訂票系統；剩餘座位與付款狀態以官方頁面為準。", telegram_call, target_payload_builder, markup)
        return True

    if plain in {"建立任務", "繼續任務"}:
        _pending[key] = "studio_task_create" if plain == "建立任務" else "studio_task_continue"
        _send(chat_id, "請輸入任務目標、成品格式與期限；下一則會保存任務並直接交給目前固定模型執行。" if plain == "建立任務" else "請輸入要接續的內容；會接續最近一筆任務與目前素材。", telegram_call, target_payload_builder)
        return True
    if plain in {"任務狀態", "任務歷史"}:
        tasks = list(reversed(_workspace_state(bot_instance, chat_id, target)["tasks"]))[:20]
        _send(chat_id, "\n".join(["蝦任務紀錄：", *[f"{index}. [{task.get('status', 'submitted')}] {task.get('title', '')}" for index, task in enumerate(tasks, 1)]]) if tasks else "目前沒有已保存的蝦任務。", telegram_call, target_payload_builder)
        return True
    if plain == "刪除任務":
        _pending[key] = "studio_task_delete"
        _send(chat_id, "請先查看任務歷史，再輸入要刪除的編號。", telegram_call, target_payload_builder)
        return True
    if plain in {"啟用技能", "停用技能", "技能優先級"}:
        _pending[key] = {"啟用技能": "studio_skill_enable", "停用技能": "studio_skill_disable", "技能優先級": "studio_skill_priority"}[plain]
        _send(chat_id, "請輸入技能名稱。" if plain != "技能優先級" else "請輸入「技能名稱 高／中／低」。", telegram_call, target_payload_builder)
        return True
    if plain in {"技能市集", "已安裝技能"}:
        state = _workspace_state(bot_instance, chat_id, target)
        enabled = state["skills"].get("enabled") or []
        text_out = "技能市集分類：AI 工具、行銷、財經、程式開發、教育學習、創意寫作、商業法務、生產力、健康醫療、生活娛樂、職涯求職。\n\n直接按「搜尋技能」並描述成果，系統會從目前 Bot 已安裝技能中選用。" if plain == "技能市集" else ("個人啟用技能：\n" + "\n".join(f"{index}. {name}｜{state['skills'].get('priorities', {}).get(name, '中')}優先" for index, name in enumerate(enabled, 1)) if enabled else "目前沒有個人指定技能；Bot 仍會依任務自動選用可執行技能。")
        _send(chat_id, text_out, telegram_call, target_payload_builder)
        return True
    if plain in {"加入投資標的", "追蹤備註", "暫停追蹤", "移除追蹤", "每日投資摘要"}:
        _pending[key] = {"加入投資標的": "studio_tracking_add", "追蹤備註": "studio_tracking_note", "暫停追蹤": "studio_tracking_pause", "移除追蹤": "studio_tracking_remove", "每日投資摘要": "studio_tracking_daily"}[plain]
        prompts = {"加入投資標的": "請輸入代碼或名稱與備註，例如「2330 成本 580」。", "追蹤備註": "請輸入「清單編號＋新備註」。", "暫停追蹤": "請輸入清單編號；再次操作可恢復。", "移除追蹤": "請輸入要移除的清單編號。", "每日投資摘要": "請輸入每天通知時間，例如「08:00」。"}
        _send(chat_id, prompts[plain], telegram_call, target_payload_builder)
        return True
    if plain == "投資追蹤":
        rows = list(reversed(_workspace_state(bot_instance, chat_id, target)["tracking"]["instruments"]))[:20]
        lines = []
        for index, row in enumerate(rows, 1):
            if row.get("status") == "paused":
                lines.append(f"{index}. {row.get('symbol')}｜已暫停")
                continue
            try:
                quote = query_market_quote(str(row.get("symbol") or ""))
            except Exception:
                quote = {"ok": False, "symbol": row.get("symbol")}
            lines.append(f"{index}. {_market_quote_line(quote)}" + (f"｜{row.get('note')}" if row.get("note") else ""))
        _send(chat_id, "投資追蹤：\n" + "\n".join(lines) + "\n\n公開市場報價可能延遲，不構成投資建議。" if lines else "目前沒有追蹤標的。", telegram_call, target_payload_builder)
        return True
    if plain == "降價追蹤":
        _pending[key] = "studio_product_track"
        _send(chat_id, "請輸入商品名稱或 HTTPS 商品網址、目前價格與目標價。", telegram_call, target_payload_builder)
        return True
    if plain == "比價紀錄":
        products = list(reversed(_workspace_state(bot_instance, chat_id, target)["tracking"]["products"]))[:30]
        _send(chat_id, "\n".join(["商品追蹤紀錄：", *[f"{index}. [{item.get('status', 'tracking')}] {item.get('label', '')}" for index, item in enumerate(products, 1)]]) if products else "目前沒有商品追蹤紀錄。", telegram_call, target_payload_builder)
        return True
    if plain in {"標記已購買", "停止商品追蹤"}:
        _pending[key] = "studio_product_purchased" if plain == "標記已購買" else "studio_product_stop"
        _send(chat_id, "請先查看比價紀錄，再輸入要操作的編號。", telegram_call, target_payload_builder)
        return True
    if plain in {"搜尋教學", "收藏教學", "標記完成"}:
        if plain == "搜尋教學":
            _send(chat_id, "請輸入想完成的成果或關鍵字；下一則會交給目前模型搜尋對應技能並帶你執行。", telegram_call, target_payload_builder)
            return True
        _pending[key] = "studio_classroom_favorite" if plain == "收藏教學" else "studio_classroom_complete"
        _send(chat_id, "請輸入教學名稱。", telegram_call, target_payload_builder)
        return True
    if plain in {"我的最愛", "完成進度"}:
        classroom = _workspace_state(bot_instance, chat_id, target)["classroom"]
        _send(chat_id, f"蝦教室進度：\n- 已收藏 {len(classroom['favorites'])} 項" + (f"：{'、'.join(classroom['favorites'])}" if classroom["favorites"] else "") + f"\n- 已完成 {len(classroom['completed'])} 項" + (f"：{'、'.join(classroom['completed'])}" if classroom["completed"] else ""), telegram_call, target_payload_builder)
        return True
    if plain in {"蝦飼料／用量", "訂閱方案", "功能解鎖", "企業／團隊", "兌換企業碼", "我的權限"}:
        replies = {
            "蝦飼料／用量": "請輸入 /status 查看目前 Bot 任務與用量狀態；IMAGE2 與影片額度以各 Bot 實際回覆為準。",
            "訂閱方案": "請由目前 Bot 的訂閱／續期流程查看方案；不會在選單點擊時自行扣款。",
            "功能解鎖": "功能依目前 Bot 與帳號授權開放；需要新增權限請透過客服申請。",
            "企業／團隊": "企業／團隊提供統一授權、成員權限與共享流程；管理員工具不會顯示給一般客戶。",
            "兌換企業碼": "請輸入由官方提供的企業授權碼；驗證碼、密碼與金鑰請勿貼在公開群組。",
            "我的權限": "請輸入 /status 查看目前 Bot 與帳號實際可用功能。",
        }
        _send(chat_id, replies[plain], telegram_call, target_payload_builder)
        return True
    if plain in {"教學引導", "客服中心"}:
        _send(chat_id, "已開啟蝦教室；請選擇分類或輸入想完成的成果。" if plain == "教學引導" else "請直接描述問題、發生步驟與期望結果；可附截圖，但不要包含密碼、驗證碼或金鑰。", telegram_call, target_payload_builder, _reply_keyboard(SECTION_MENUS["蝦教室"][1]) if plain == "教學引導" else None)
        return True
    if plain == "提交回饋":
        _pending[key] = "studio_feedback"
        _send(chat_id, "請輸入問題、建議或發生步驟；可先附截圖。", telegram_call, target_payload_builder)
        return True
    if plain == "回饋紀錄":
        feedback = list(reversed(_workspace_state(bot_instance, chat_id, target)["feedback"]))[:20]
        _send(chat_id, "\n".join(["回饋紀錄：", *[f"{index}. [{item.get('status')}] {item.get('id')}｜{item.get('text', '')[:100]}" for index, item in enumerate(feedback, 1)]]) if feedback else "目前沒有回饋紀錄。", telegram_call, target_payload_builder)
        return True
    if plain == "蝦設定":
        settings = _workspace_state(bot_instance, chat_id, target)["settings"]
        _send(chat_id, f"蝦設定：\n- 語言：{settings.get('language', '繁體中文')}\n- 主動通知：{'開啟' if settings.get('notifications', True) else '關閉'}", telegram_call, target_payload_builder)
        return True
    if plain == "通知設定":
        _pending[key] = "studio_notifications"
        _send(chat_id, "請輸入「開啟通知」或「關閉通知」。", telegram_call, target_payload_builder)
        return True

    if plain in CLASSROOM_EXAMPLES:
        _send(chat_id, f"{plain}可用教學：{CLASSROOM_EXAMPLES[plain]}。\n\n直接告訴我想完成哪一項，我會依步驟帶你完成。🧑‍🏫", telegram_call, target_payload_builder)
        return True

    prompt = ACTION_PROMPTS.get(plain)
    if prompt:
        _send(chat_id, prompt, telegram_call, target_payload_builder)
        return True

    return False


__all__ = [
    "GAME_URLS",
    "BOT_COMMANDS",
    "MAIN_MENU",
    "STUDIO_MENU",
    "SECTION_MENUS",
    "persistent_menu_reply_keyboard",
    "sync_bot_commands",
    "token_usage_reply",
    "parse_rail_request",
    "query_rail",
    "normalize_market_symbol",
    "query_market_quote",
    "query_product_price",
    "sale_reminder",
    "handle_studio_menu_message",
    "poll_due_studio_reminders",
]
