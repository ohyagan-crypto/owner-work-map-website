﻿param(
    [string]$ConfigPath = (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex\config.toml')
)

$ErrorActionPreference = 'Stop'
$utf8 = [System.Text.UTF8Encoding]::new($false)
$parent = Split-Path -Parent $ConfigPath
if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
$content = if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
    [System.IO.File]::ReadAllText($ConfigPath)
} else {
    ''
}
$newline = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$content = [regex]::Replace($content, '(?m)^[ \t]*service_tier[ \t]*=[^\r\n]*(?:\r?\n)?', '')
$line = 'service_tier = "fast"'
$anchor = [regex]::Match($content, '(?m)^[ \t]*model_reasoning_effort[ \t]*=[^\r\n]*')
if (-not $anchor.Success) { $anchor = [regex]::Match($content, '(?m)^[ \t]*model[ \t]*=[^\r\n]*') }
if ($anchor.Success) {
    $updated = $content.Insert($anchor.Index + $anchor.Length, $newline + $line)
} elseif ([string]::IsNullOrWhiteSpace($content)) {
    $updated = $line + $newline
} else {
    $updated = $line + $newline + $content.TrimStart("`r", "`n")
}
if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    Copy-Item -LiteralPath $ConfigPath -Destination "$ConfigPath.pre_tgbot_menu_$stamp.bak" -Force
}
[System.IO.File]::WriteAllText($ConfigPath, $updated, $utf8)
$count = [regex]::Matches($updated, '(?m)^service_tier[ \t]*=[ \t]*"fast"[ \t]*\r?$').Count
if ($count -ne 1) { throw "FAST 設定驗證失敗：找到 $count 條 service_tier。" }
Write-Host 'FAST 已啟用；模型、供應商與推理強度未變更。'
