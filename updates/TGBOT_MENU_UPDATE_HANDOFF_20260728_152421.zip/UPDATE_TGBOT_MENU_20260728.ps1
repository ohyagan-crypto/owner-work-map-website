﻿param(
    [string[]]$TargetBotRoots = @(),
    [string]$CodexSkillsRoot = (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.codex\skills'),
    [switch]$SkipFast
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillSource = Join-Path $packageRoot 'skills\tgbot-lbot-menu-parity'
$moduleSource = Join-Path $skillSource 'assets\telegram_studio_menu_20260728.py'
$verifyScript = Join-Path $skillSource 'scripts\verify_tgbot_menu_20260728.py'
if (-not (Test-Path -LiteralPath $moduleSource -PathType Leaf)) { throw "找不到共用模組：$moduleSource" }

if (-not $SkipFast) {
    & (Join-Path $packageRoot 'SET_FAST_SERVICE_TIER_20260728.ps1')
}

New-Item -ItemType Directory -Path $CodexSkillsRoot -Force | Out-Null
$skillTarget = Join-Path $CodexSkillsRoot 'tgbot-lbot-menu-parity'
if (Test-Path -LiteralPath $skillTarget) {
    $backup = "$skillTarget.pre_20260728_$(Get-Date -Format 'HHmmss')"
    Copy-Item -LiteralPath $skillTarget -Destination $backup -Recurse -Force
}
Copy-Item -LiteralPath $skillSource -Destination $skillTarget -Recurse -Force

if ($TargetBotRoots.Count -eq 0) {
    $profile = [Environment]::GetFolderPath('UserProfile')
    $TargetBotRoots = @(Get-ChildItem -LiteralPath $profile -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^tg-openai-bot(?:-\d+)?$' } |
        Select-Object -ExpandProperty FullName)
}

$results = @()
foreach ($root in $TargetBotRoots) {
    $resolved = Resolve-Path -LiteralPath $root -ErrorAction SilentlyContinue
    if (-not $resolved) {
        $results += [pscustomobject]@{ Root = $root; Module = '略過'; Integration = '找不到資料夾' }
        continue
    }
    $rootPath = $resolved.Path
    $botFiles = @(Get-ChildItem -LiteralPath $rootPath -File -Filter 'codex_bot*.py' -ErrorAction SilentlyContinue)
    if ($botFiles.Count -eq 0) {
        $results += [pscustomobject]@{ Root = $rootPath; Module = '略過'; Integration = '找不到 codex_bot*.py' }
        continue
    }

    $moduleTarget = Join-Path $rootPath 'telegram_studio_menu.py'
    if (Test-Path -LiteralPath $moduleTarget) {
        Copy-Item -LiteralPath $moduleTarget -Destination "$moduleTarget.pre_20260728_$(Get-Date -Format 'HHmmss').bak" -Force
    }
    Copy-Item -LiteralPath $moduleSource -Destination $moduleTarget -Force
    & py -3 -m py_compile $moduleTarget

    $combined = ($botFiles | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8 }) -join "`n"
    $required = @('handle_studio_menu_message', 'persistent_menu_reply_keyboard', 'sync_bot_commands')
    $missing = @($required | Where-Object { $combined -notmatch [regex]::Escape($_) })
    $integration = if ($missing.Count -eq 0) { '偵測到既有掛接點；仍需真實聊天室驗證' } else { '需要依整合指南加入：' + ($missing -join '、') }
    $results += [pscustomobject]@{ Root = $rootPath; Module = '已安裝並通過 py_compile'; Integration = $integration }
}

& py -3 $verifyScript
$results | Format-Table -AutoSize
Write-Host '技能與共用模組已處理。請依整合指南補齊掛接點，只重啟目前 Bot，並完成 Telegram 真實選單測試。'
