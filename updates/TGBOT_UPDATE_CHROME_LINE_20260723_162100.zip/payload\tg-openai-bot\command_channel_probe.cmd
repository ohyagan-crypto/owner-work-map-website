@echo off
setlocal
if "%~1"=="" (
  cmd.exe /d /c echo COMMAND_OK
  exit /b %ERRORLEVEL%
)
>"%~1" echo COMMAND_OK
type "%~1"
exit /b %ERRORLEVEL%
