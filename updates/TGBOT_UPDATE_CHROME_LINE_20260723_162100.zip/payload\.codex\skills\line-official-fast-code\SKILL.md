---
name: line-official-fast-code
description: Use when an authorized owner asks to log in to LINE Official Account Manager from a server by QR code, says 已掃, asks 截圖驗證碼 or 最快回報密碼, reports 認證碼不符, or asks whether LINE Official login succeeded. Prioritize immediate extraction and same-origin Telegram delivery of the short-lived four-digit verification code while never exposing the account password.
---

# LINE Official Fast Code

Complete the LINE Official Account Manager QR login with minimum delay between the owner's scan and delivery of the short-lived verification code.

## Interpret the Request

Treat 「最快回報密碼」 in this workflow as a request for the temporary four-digit LINE verification code, not the account password. Never display, store, screenshot, package, or repeat a real account password.

Use a visible persistent browser session so the owner can authorize the server login from their phone. Operate only accounts the owner controls or authorizes.

## Fast QR Login Workflow

1. Open `https://manager.line.biz/` in the existing visible persistent browser.
2. If already logged in, verify that the official-account list is visible and report success. Do not start a new login.
3. If logged out, choose LINE account login and QR-code login.
4. Capture the current QR code and return it immediately to the originating Telegram conversation. Keep the same page open.
5. When the owner says 「已掃」, make this the highest-priority event. Do not run unrelated checks, create status messages, or take a screenshot first.
6. Inspect the current page immediately. Prefer visible page text or DOM extraction over OCR. Find the newly displayed four-digit verification code.
7. Return the actual four-digit code as plain text immediately and tell the owner to enter it now. Keep the wording natural for the current state; do not route through a fixed reply template or place extra explanation before the digits.
8. Only after the text reply has been sent, capture and return a verification screenshot when requested or useful.
9. After the owner says the code was entered, inspect the same browser page. Confirm success only when the LINE Official account list or authenticated manager page is visible and the login page is gone.
10. Preserve the authenticated browser profile for later authorized use.

## Expiry and Retry Rules

- Never resend an earlier code.
- If the page still shows the QR code and no four-digit code, state that the scan did not produce a valid code, refresh the QR code, and return the new QR immediately.
- If the code expired or LINE reports a mismatch, refresh the login page, generate a new QR code, and tell the owner to scan only the newest image.
- Keep old QR images and old codes clearly invalidated in the reply.
- Do not claim success because the phone says login succeeded. Verify the server-side browser page.

## Email Login Branch

When the owner explicitly switches to email login, use authorized credentials only through the available protected login mechanism. Fill them without echoing them in replies, files, screenshots, memory, command lines, or logs. Stop for CAPTCHA, SMS/email code, authenticator, passkey, biometric approval, payment, or account-security lock, and explain the exact required action in Traditional Chinese.

## Telegram Delivery

For Telegram-origin tasks, return QR images and screenshots only to the originating conversation. When the local sender is available, use:

```powershell
& "$env:USERPROFILE\tg-openai-bot\tools\send_telegram_document.ps1" -Path <檔案路徑> -ChatId $env:TELEGRAM_ORIGIN_CHAT_ID
```

Never use an allowed-chat list, saved/default chat ID, previous chat ID, another bot, or another bot's sender. If `TELEGRAM_ORIGIN_CHAT_ID` is missing, do not upload; report the validated local backup path and this exact blocker.

## Owner-Facing Reply Style

Use clean Traditional Chinese. Give the result first. Do not expose passwords, tokens, cookies, browser profiles, internal tool names, raw logs, or debug output. Do not finish with only 「收到」、「處理中」 or an estimate.

## Completion Criteria

Complete the workflow only after one of these outcomes:

- The authenticated LINE Official account list is visibly confirmed and reported.
- A real platform security step blocks progress and the owner receives the exact required action.
- Delivery cannot proceed because the originating Telegram chat ID is missing; provide the validated local backup path.
