# TGBOT 跨電腦獨立升級包

- 建立日期：2026-07-23
- 入口：`UPDATE_INSTALLED_TGBOT.cmd`
- 預檢：`PORTABILITY_SELF_TEST.cmd`
- 目標：接收電腦的 `%USERPROFILE%\tg-openai-bot`
- 保留：`.env`、Token、API、CHAT ID、技能、記憶、瀏覽器 profile
- Chrome：缺少時從 Google 官方來源安裝並驗證數位簽章；TGBOT 第一順位使用 Chrome
- 登入狀態：沿用 `%USERPROFILE%\tgbot_browser_profiles\shared-chrome`，不主動登出
- LINE：只合併或更新 `line-official-fast-code`，其他既有技能與記憶不覆蓋
- 路徑：接收端 `%USERPROFILE%`、`LOCALAPPDATA`、`.codex-api2` 動態產生
- 回覆：一般訊息由 Codex 即時處理，固定 ACK/進度/待命/direct shortcuts 不可執行
- 驗證：PowerShell、Python、reply routing、browser、COMMAND_OK marker、新 PID、fresh heartbeat
- 排除：來源索引、Token、API Key、密碼、Cookie、log、SQLite、session、browser profile
