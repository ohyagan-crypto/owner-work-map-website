param(
    [int]$ShutdownDelaySeconds = 30
)

$ErrorActionPreference = 'Stop'
$Shutdown = Join-Path $env:SystemRoot 'System32\shutdown.exe'
if (-not (Test-Path -LiteralPath $Shutdown)) {
    throw "Windows shutdown.exe was not found."
}

Start-Sleep -Seconds 2
& $Shutdown /r /t ([Math]::Max(15, $ShutdownDelaySeconds)) /f /d p:4:1 /c 'Owner-authorized TGBOT computer restart'
if ($LASTEXITCODE -ne 0) {
    throw "shutdown.exe failed with exit code $LASTEXITCODE"
}
