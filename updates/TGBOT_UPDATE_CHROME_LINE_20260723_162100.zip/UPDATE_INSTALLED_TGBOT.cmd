@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
fltmc >nul 2>nul
if errorlevel 1 ("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs" & exit /b)
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
title Update Installed TGBOT
echo Starting TGBOT update. Keep this window open.
echo Progress will be shown for every step and long-running download.
echo.
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_INSTALLED_TGBOT.ps1"
if errorlevel 1 (
  echo.
  echo TGBOT runtime files may already be updated. Existing Token, API, CHAT ID, and browser profiles were preserved.
  echo The updater now verifies a direct new TGBOT PID and heartbeat before returning success.
  echo Review the concrete PowerShell error and the installed TGBOT logs before retrying.
  pause
  exit /b 1
)
echo.
echo TGBOT Chrome and LINE update completed. Existing Token, API, CHAT ID, skills, memories, and browser profiles were preserved.
pause
