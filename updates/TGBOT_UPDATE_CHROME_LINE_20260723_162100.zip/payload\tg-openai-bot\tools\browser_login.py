"""Visible Playwright login helper.

Credentials are accepted only through stdin JSON and are never written to disk,
printed, or included in status output. Browser cookies remain in a per-site local
profile so a successful login can be reused.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlparse
from urllib.request import urlopen


USERNAME_SELECTORS = (
    'input[autocomplete="username"]',
    'input[type="email"]',
    'input[name*="email" i]',
    'input[id*="email" i]',
    'input[name*="user" i]',
    'input[id*="user" i]',
    'input[name*="account" i]',
    'input[type="text"]',
)
PASSWORD_SELECTORS = (
    'input[autocomplete="current-password"]',
    'input[type="password"]',
    'input[name*="password" i]',
    'input[id*="password" i]',
)
OTP_SELECTORS = (
    'input[autocomplete="one-time-code"]',
    'input[name*="otp" i]',
    'input[id*="otp" i]',
    'input[name*="code" i]',
    'input[id*="verification" i]',
)

LOGIN_ENTRY_PATTERN = re.compile(
    r"sign\s*in|log\s*in|login|登入|登錄|登录|會員登入|帳號登入",
    re.IGNORECASE,
)
CONTINUE_PATTERN = re.compile(
    r"next|continue|下一步|繼續|继续|確定|确认|submit|sign\s*in|log\s*in|登入|登錄|登录",
    re.IGNORECASE,
)
TWO_FACTOR_TERMS = (
    "two-factor",
    "two factor",
    "2fa",
    "verification code",
    "security code",
    "authenticator",
    "one-time code",
    "one time code",
    "簡訊驗證",
    "短信验证",
    "驗證碼",
    "验证码",
    "雙重驗證",
    "双重验证",
    "兩步驟驗證",
    "两步验证",
)
CAPTCHA_TERMS = (
    "captcha",
    "recaptcha",
    "hcaptcha",
    "verify you are human",
    "not a robot",
    "人機驗證",
    "人机验证",
    "我不是機器人",
    "我不是机器人",
)
PASSKEY_TERMS = (
    "passkey",
    "security key",
    "windows hello",
    "biometric",
    "指紋",
    "指纹",
    "臉部辨識",
    "面容",
)
INVALID_TERMS = (
    "incorrect password",
    "invalid password",
    "wrong password",
    "invalid credentials",
    "couldn't find your google account",
    "couldn’t find your google account",
    "could not find your google account",
    "account or password",
    "email or password",
    "帳號或密碼錯誤",
    "账号或密码错误",
    "密碼錯誤",
    "密码错误",
    "找不到帳號",
    "找不到账号",
)
SUCCESS_TERMS = (
    "log out",
    "logout",
    "sign out",
    "my account",
    "account settings",
    "登出",
    "退出登入",
    "退出登录",
    "我的帳戶",
    "我的账户",
)
GOOGLE_REJECTED_PATHS = (
    "/signin/rejected",
    "/v3/signin/rejected",
)


def emit(status: str, message: str, url: str = "", *, final: bool = True) -> None:
    safe_url = ""
    if url:
        try:
            parsed = urlparse(url)
            safe_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        except Exception:
            safe_url = ""
    print(
        json.dumps(
            {"status": status, "message": message, "url": safe_url, "final": final},
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        flush=True,
    )


def browser_candidates() -> Iterable[Path]:
    explicit = os.getenv("TGBOT_BROWSER_EXECUTABLE", "").strip()
    if explicit:
        yield Path(explicit)
    program_files = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    program_files_x86 = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))
    local_app_data = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
    yield program_files / "Google" / "Chrome" / "Application" / "chrome.exe"
    yield program_files_x86 / "Google" / "Chrome" / "Application" / "chrome.exe"
    yield local_app_data / "Google" / "Chrome" / "Application" / "chrome.exe"
    yield program_files_x86 / "Microsoft" / "Edge" / "Application" / "msedge.exe"
    yield program_files / "Microsoft" / "Edge" / "Application" / "msedge.exe"


def find_browser_executable() -> Optional[Path]:
    return next((path for path in browser_candidates() if path.is_file()), None)


def usable_browser_executables(playwright: Any) -> list[Path]:
    candidates = list(browser_candidates())
    try:
        candidates.append(Path(playwright.chromium.executable_path))
    except Exception:
        pass
    result: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        try:
            resolved = path.resolve()
        except Exception:
            resolved = path
        key = str(resolved).lower()
        if key in seen or not resolved.is_file():
            continue
        seen.add(key)
        result.append(resolved)
    return result


def browser_route_label(path: Path) -> str:
    lowered = str(path).lower()
    if "ms-playwright" in lowered:
        return "playwright_chromium"
    if "msedge" in lowered:
        return "system_edge"
    if "chrome" in lowered:
        return "system_chrome"
    return "configured_browser"


def visible_locator(page: Any, selectors: Iterable[str]) -> Optional[Any]:
    for selector in selectors:
        locator = page.locator(selector)
        try:
            count = min(locator.count(), 12)
        except Exception:
            continue
        for index in range(count):
            item = locator.nth(index)
            try:
                if item.is_visible(timeout=500) and item.is_enabled(timeout=500):
                    return item
            except Exception:
                continue
    return None


def wait_for_visible_locator(
    page: Any,
    selectors: Iterable[str],
    timeout_ms: int,
) -> Optional[Any]:
    deadline = time.time() + max(0, timeout_ms) / 1000
    while True:
        locator = visible_locator(page, selectors)
        if locator is not None:
            return locator
        if time.time() >= deadline:
            return None
        page.wait_for_timeout(250)


def click_named_button(page: Any, pattern: re.Pattern[str]) -> bool:
    candidates = (
        page.get_by_role("button", name=pattern),
        page.get_by_role("link", name=pattern),
        page.locator('button[type="submit"]'),
        page.locator('input[type="submit"]'),
    )
    for locator in candidates:
        try:
            count = min(locator.count(), 8)
        except Exception:
            continue
        for index in range(count):
            item = locator.nth(index)
            try:
                if item.is_visible(timeout=500) and item.is_enabled(timeout=500):
                    item.click(timeout=5000)
                    return True
            except Exception:
                continue
    return False


def body_text(page: Any) -> str:
    try:
        return page.locator("body").inner_text(timeout=5000).lower()[:60000]
    except Exception:
        return ""


def any_term(text: str, terms: Iterable[str]) -> bool:
    return any(term in text for term in terms)


def is_google_signin(parsed: Any) -> bool:
    hostname = str(parsed.hostname or "").lower()
    return hostname == "accounts.google.com"


def is_provider_automation_rejected(page: Any) -> bool:
    try:
        parsed = urlparse(page.url)
        return is_google_signin(parsed) and any(
            parsed.path.lower().endswith(path) for path in GOOGLE_REJECTED_PATHS
        )
    except Exception:
        return False


def classify_page(page: Any, original_url: str) -> str:
    if is_provider_automation_rejected(page):
        return "provider_automation_rejected"
    text = body_text(page)
    if visible_locator(page, OTP_SELECTORS) is not None or any_term(text, TWO_FACTOR_TERMS):
        return "two_factor_required"
    try:
        captcha_frame = page.locator(
            'iframe[src*="recaptcha" i],iframe[src*="hcaptcha" i],iframe[title*="captcha" i]'
        ).count()
    except Exception:
        captcha_frame = 0
    if captcha_frame or any_term(text, CAPTCHA_TERMS):
        return "captcha_required"
    if any_term(text, PASSKEY_TERMS):
        return "passkey_required"
    if any_term(text, INVALID_TERMS):
        return "invalid_credentials"
    password = visible_locator(page, PASSWORD_SELECTORS)
    if password is not None:
        return "login_form_visible"
    if any_term(text, SUCCESS_TERMS):
        return "login_completed"
    try:
        old = urlparse(original_url)
        new = urlparse(page.url)
        if is_google_signin(old) and str(new.hostname or "").lower() == "myaccount.google.com":
            return "login_completed"
        old_path = old.path.lower()
        new_path = new.path.lower()
        if page.url != original_url and new.netloc == old.netloc:
            if not any(term in new_path for term in ("login", "signin", "auth")) or new_path != old_path:
                return "login_completed"
    except Exception:
        pass
    return "login_submitted"


def reserve_local_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        return int(listener.getsockname()[1])


def wait_for_cdp(port: int, process: subprocess.Popen[Any], seconds: int = 20) -> str:
    endpoint = f"http://127.0.0.1:{port}"
    deadline = time.time() + seconds
    while time.time() < deadline:
        if process.poll() is not None:
            break
        try:
            with urlopen(f"{endpoint}/json/version", timeout=1) as response:
                if response.status == 200:
                    return endpoint
        except Exception:
            time.sleep(0.25)
    raise RuntimeError("Chromium CDP endpoint did not become ready.")


def launch_external_browser_cdp(
    playwright: Any,
    executable: Path,
    profile_dir: Path,
    url: str,
) -> tuple[Any, Any, Any, subprocess.Popen[Any]]:
    port = reserve_local_port()
    command = [
        str(executable),
        f"--remote-debugging-port={port}",
        "--remote-debugging-address=127.0.0.1",
        f"--user-data-dir={profile_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--start-maximized",
        url,
    ]
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    process = subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
    )
    try:
        browser = playwright.chromium.connect_over_cdp(wait_for_cdp(port, process))
        context = browser.contexts[0] if browser.contexts else browser.new_context(no_viewport=True)
        page = context.pages[-1] if context.pages else context.new_page()
        return browser, context, page, process
    except Exception:
        if process.poll() is None:
            process.terminate()
        time.sleep(0.5)
        force_close_profile_processes(profile_dir)
        raise


def force_close_profile_processes(profile_dir: Path) -> None:
    if os.name != "nt":
        return
    cleanup_env = os.environ.copy()
    cleanup_env["TGBOT_EDGE_PROFILE_TO_CLOSE"] = str(profile_dir.resolve())
    cleanup_script = (
        "$target=$env:TGBOT_EDGE_PROFILE_TO_CLOSE; "
        "Get-CimInstance Win32_Process -Filter \"name='msedge.exe' or name='chrome.exe'\" | "
        "Where-Object { $_.CommandLine -like \"*$target*\" } | "
        "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
    )
    subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", cleanup_script],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=cleanup_env,
        timeout=10,
        check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


def close_external_browser(browser: Any, process: subprocess.Popen[Any], profile_dir: Path) -> None:
    try:
        session = browser.new_browser_cdp_session()
        try:
            session.send("Browser.close")
        finally:
            try:
                session.detach()
            except Exception:
                pass
    except Exception:
        try:
            browser.close()
        except Exception:
            pass

    try:
        process.wait(timeout=4)
    except Exception:
        pass

    if os.name != "nt":
        if process.poll() is None:
            process.terminate()
        return
    force_close_profile_processes(profile_dir)


def wait_for_manual_verification(page: Any, original_url: str, seconds: int) -> None:
    deadline = time.time() + max(60, seconds)
    while time.time() < deadline:
        if page.is_closed():
            emit("browser_closed", "The browser was closed before verification completed.")
            return
        time.sleep(2)
        status = classify_page(page, original_url)
        if status in {"login_completed", "login_submitted"}:
            emit(
                "login_completed_after_verification",
                "Manual verification completed and the browser session is signed in.",
                page.url,
            )
            return
        if status == "invalid_credentials":
            emit("invalid_credentials", "The site rejected the supplied account or password.", page.url)
            return
    emit(
        "manual_verification_timeout",
        "The browser waited for manual verification but it was not completed in time.",
        page.url,
    )


def perform_login(payload: dict[str, Any]) -> int:
    url = str(payload.get("url") or "").strip()
    username = str(payload.get("username") or "").strip()
    password = str(payload.get("password") or "")
    manual_wait_seconds = int(payload.get("manual_wait_seconds") or 600)
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or not username or not password:
        emit("invalid_request", "URL, username, and password are required.")
        return 2

    shared_profile = os.getenv("TGBOT_CHROME_PROFILE_DIR", "").strip()
    if shared_profile:
        profile_dir = Path(shared_profile)
    else:
        profile_root = Path(
            os.getenv("TGBOT_BROWSER_PROFILE_ROOT", str(Path.home() / "tgbot_browser_profiles"))
        )
        profile_dir = profile_root / "shared-chrome"
    profile_dir.mkdir(parents=True, exist_ok=True)

    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        emit("browser_unavailable", "Playwright is not installed.")
        return 3

    try:
        with sync_playwright() as playwright:
            executables = usable_browser_executables(playwright)
            browser = None
            external_process: Optional[subprocess.Popen[Any]] = None
            if is_google_signin(parsed):
                launch_error: Optional[Exception] = None
                for executable in executables:
                    try:
                        browser, context, page, external_process = launch_external_browser_cdp(
                            playwright, executable, profile_dir, url
                        )
                        break
                    except Exception as error:
                        launch_error = error
                if browser is None:
                    raise launch_error or RuntimeError("No external Chromium CDP route is available.")
            else:
                context = None
                launch_error = None
                for executable in executables or [None]:
                    launch_options: dict[str, Any] = {
                        "user_data_dir": str(profile_dir),
                        "headless": False,
                        "no_viewport": True,
                        "args": ["--start-maximized"],
                    }
                    if executable is not None:
                        launch_options["executable_path"] = str(executable)
                    try:
                        context = playwright.chromium.launch_persistent_context(**launch_options)
                        break
                    except Exception as error:
                        launch_error = error
                if context is None:
                    raise launch_error or RuntimeError("No persistent Chromium route is available.")
                page = context.pages[0] if context.pages else context.new_page()
            try:
                if page.url != url:
                    page.goto(url, wait_until="domcontentloaded", timeout=60000)
                page.wait_for_timeout(1200)

                username_field = visible_locator(page, USERNAME_SELECTORS)
                password_field = visible_locator(page, PASSWORD_SELECTORS)
                if username_field is None and password_field is None:
                    if click_named_button(page, LOGIN_ENTRY_PATTERN):
                        page.wait_for_timeout(1500)
                        username_field = visible_locator(page, USERNAME_SELECTORS)
                        password_field = visible_locator(page, PASSWORD_SELECTORS)

                if username_field is not None:
                    username_field.fill(username)
                if password_field is None and username_field is not None:
                    if click_named_button(page, CONTINUE_PATTERN):
                        password_field = wait_for_visible_locator(
                            page, PASSWORD_SELECTORS, 15000
                        )
                if password_field is None:
                    status = classify_page(page, url)
                    if status in {"two_factor_required", "captcha_required", "passkey_required"}:
                        emit(status, "The site requires manual verification.", page.url, final=False)
                        wait_for_manual_verification(page, url, manual_wait_seconds)
                        return 0
                    if status == "provider_automation_rejected":
                        emit(
                            status,
                            "Google rejected this browser sign-in session before the password page.",
                            page.url,
                        )
                        return 8
                    if status == "invalid_credentials":
                        emit(
                            status,
                            "The site rejected the supplied account or password.",
                            page.url,
                        )
                        return 5
                    if status == "login_completed":
                        emit(
                            status,
                            "The saved browser profile is already signed in.",
                            page.url,
                        )
                        return 0
                    emit("login_form_not_found", "A usable password field was not found.", page.url)
                    return 4

                password_field.fill(password)
                if not click_named_button(page, CONTINUE_PATTERN):
                    password_field.press("Enter")
                page.wait_for_timeout(4500)
                status = classify_page(page, url)
                if status in {"two_factor_required", "captcha_required", "passkey_required"}:
                    emit(status, "The account and password were submitted; manual verification is required.", page.url, final=False)
                    wait_for_manual_verification(page, url, manual_wait_seconds)
                    return 0
                if status == "invalid_credentials":
                    emit(status, "The site rejected the supplied account or password.", page.url)
                    return 5
                if status == "login_form_visible":
                    emit("login_not_completed", "The login form is still visible after submission.", page.url)
                    return 6
                emit(status, "The account and password were submitted successfully.", page.url)
                return 0
            finally:
                if browser is not None:
                    if external_process is not None:
                        close_external_browser(browser, external_process, profile_dir)
                    else:
                        browser.close()
                else:
                    context.close()
    except Exception as error:
        lowered = str(error).lower()
        if "profile" in lowered and ("lock" in lowered or "in use" in lowered):
            emit("browser_busy", "The browser profile is already in use.")
        elif "executable" in lowered or "browser" in lowered:
            emit("browser_unavailable", "No usable Chromium browser is installed.")
        else:
            emit("browser_error", "The browser login flow could not be completed.")
        return 7
    finally:
        password = ""
        payload["password"] = ""


def self_test() -> int:
    stage = "playwright_import"
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as playwright:
            executables = usable_browser_executables(playwright)
            direct_route = ""
            direct_error: Optional[Exception] = None
            for executable in executables or [None]:
                stage = f"direct_{browser_route_label(executable) if executable else 'default_chromium'}"
                options: dict[str, Any] = {"headless": True}
                if executable is not None:
                    options["executable_path"] = str(executable)
                try:
                    browser = playwright.chromium.launch(**options)
                    try:
                        page = browser.new_page()
                        page.set_content("<title>TGBOT browser test</title><input type='password'>")
                        if page.title() != "TGBOT browser test":
                            raise RuntimeError("browser title check failed")
                        direct_route = browser_route_label(executable) if executable else "default_chromium"
                        break
                    finally:
                        browser.close()
                except Exception as error:
                    direct_error = error
            if not direct_route:
                raise direct_error or RuntimeError("No direct Chromium route passed.")

            cdp_route = ""
            cdp_error: Optional[Exception] = None
            for executable in executables:
                route = browser_route_label(executable)
                stage = f"cdp_{route}"
                temp_dir = Path(tempfile.mkdtemp(prefix="tgbot-browser-cdp-"))
                cdp_browser = None
                process = None
                try:
                    cdp_browser, context, page, process = launch_external_browser_cdp(
                        playwright,
                        executable,
                        temp_dir,
                        "about:blank",
                    )
                    page.set_content("<title>TGBOT external CDP test</title>")
                    if page.title() != "TGBOT external CDP test":
                        raise RuntimeError("external CDP title check failed")
                    cdp_route = route
                    break
                except Exception as error:
                    cdp_error = error
                finally:
                    if cdp_browser is not None and process is not None:
                        close_external_browser(cdp_browser, process, temp_dir)
                    time.sleep(0.5)
                    shutil.rmtree(temp_dir, ignore_errors=True)
            if not cdp_route:
                raise cdp_error or RuntimeError("No external Chromium CDP route passed.")
        print(f"BROWSER_LOGIN_SELF_TEST_OK direct={direct_route} cdp={cdp_route}")
        return 0
    except Exception as error:
        print(f"BROWSER_LOGIN_SELF_TEST_FAILED stage={stage} type={type(error).__name__}")
        return 1


def main() -> int:
    if "--self-test" in sys.argv:
        return self_test()
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except Exception:
        emit("invalid_request", "Login input must be valid JSON.")
        return 2
    if not isinstance(payload, dict):
        emit("invalid_request", "Login input must be a JSON object.")
        return 2
    return perform_login(payload)


if __name__ == "__main__":
    raise SystemExit(main())
