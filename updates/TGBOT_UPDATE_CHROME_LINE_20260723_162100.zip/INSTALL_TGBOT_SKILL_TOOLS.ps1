param([switch]$Quiet)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$userHome=[Environment]::GetFolderPath('UserProfile')
$target=Join-Path $userHome 'tg-openai-bot'
$statusPath=Join-Path $target 'tgbot_auxiliary_tools_status.txt'
New-Item -ItemType Directory -Path $target -Force | Out-Null

function Refresh-Path{$env:Path="$( [Environment]::GetEnvironmentVariable('Path','User') );$( [Environment]::GetEnvironmentVariable('Path','Machine') )"}
function Add-UserPath([string]$Path){
    if(-not $Path -or -not (Test-Path -LiteralPath $Path)){return}
    $current=[Environment]::GetEnvironmentVariable('Path','User')
    $parts=@($current -split ';'|Where-Object{$_ -and $_.Trim()})
    if(-not($parts|Where-Object{$_.TrimEnd('\') -ieq $Path.TrimEnd('\')})){
        [Environment]::SetEnvironmentVariable('Path',(($Path+';'+($parts -join ';')).TrimEnd(';')),'User')
    }
    if(-not(($env:Path -split ';')|Where-Object{$_.TrimEnd('\') -ieq $Path.TrimEnd('\')})){$env:Path="$Path;$env:Path"}
}
function Ensure-Git{
    Refresh-Path
    $git=Get-Command git.exe -ErrorAction SilentlyContinue
    if($git){& $git.Source --version *> $null;if($LASTEXITCODE -eq 0){return $git.Source}}
    $root=Join-Path $env:LOCALAPPDATA 'Programs\TGBOT\PortableGit';$exe=Join-Path $root 'cmd\git.exe'
    if(-not(Test-Path -LiteralPath $exe)){
        Write-Host 'Downloading PortableGit 2.54.0...' -ForegroundColor Yellow
        $archive=Join-Path $env:TEMP "PortableGit-2.54.0-64-bit-$PID.7z.exe"
        Invoke-WebRequest -Uri 'https://github.com/git-for-windows/git/releases/download/v2.54.0.windows.1/PortableGit-2.54.0-64-bit.7z.exe' -OutFile $archive -UseBasicParsing -TimeoutSec 600
        if((Get-Item -LiteralPath $archive).Length -lt 30MB){throw 'PortableGit download is incomplete.'}
        New-Item -ItemType Directory -Path $root -Force | Out-Null
        & $archive -y "-o$root" | Out-Null
        if($LASTEXITCODE -ne 0){throw "PortableGit extraction returned $LASTEXITCODE."}
    }
    if(-not(Test-Path -LiteralPath $exe)){throw 'git.exe is missing after extraction.'}
    Add-UserPath (Join-Path $root 'cmd');& $exe --version *> $null
    if($LASTEXITCODE -ne 0){throw 'PortableGit verification failed.'}
    return $exe
}
function Ensure-FFmpeg{
    Refresh-Path
    $ffmpeg=Get-Command ffmpeg.exe -ErrorAction SilentlyContinue;$ffprobe=Get-Command ffprobe.exe -ErrorAction SilentlyContinue
    if($ffmpeg -and $ffprobe){& $ffmpeg.Source -version *> $null;if($LASTEXITCODE -eq 0){return $ffmpeg.Source}}
    $root=Join-Path $env:LOCALAPPDATA 'Programs\TGBOT\ffmpeg'
    $exe=Get-ChildItem -LiteralPath $root -Recurse -Filter ffmpeg.exe -File -ErrorAction SilentlyContinue|Select-Object -First 1
    $probe=Get-ChildItem -LiteralPath $root -Recurse -Filter ffprobe.exe -File -ErrorAction SilentlyContinue|Select-Object -First 1
    if(-not($exe -and $probe)){
        Write-Host 'Downloading FFmpeg Windows essentials build...' -ForegroundColor Yellow
        $archive=Join-Path $env:TEMP "ffmpeg-release-essentials-$PID.zip"
        Invoke-WebRequest -Uri 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile $archive -UseBasicParsing -TimeoutSec 900
        if((Get-Item -LiteralPath $archive).Length -lt 20MB){throw 'FFmpeg download is incomplete.'}
        New-Item -ItemType Directory -Path $root -Force | Out-Null
        Expand-Archive -LiteralPath $archive -DestinationPath $root -Force
        $exe=Get-ChildItem -LiteralPath $root -Recurse -Filter ffmpeg.exe -File|Select-Object -First 1
        $probe=Get-ChildItem -LiteralPath $root -Recurse -Filter ffprobe.exe -File|Select-Object -First 1
    }
    if(-not($exe -and $probe)){throw 'ffmpeg.exe or ffprobe.exe is missing after extraction.'}
    Add-UserPath $exe.DirectoryName;& $exe.FullName -version *> $null
    if($LASTEXITCODE -ne 0){throw 'FFmpeg verification failed.'}
    return $exe.FullName
}

$gitReady=$false;$ffmpegReady=$false;$gitDetail='unavailable';$ffmpegDetail='unavailable'
try{$gitDetail=Ensure-Git;$gitReady=$true;Write-Host "Git ready: $gitDetail" -ForegroundColor Green}catch{$gitDetail=$_.Exception.Message;Write-Warning "Git remains unavailable: $gitDetail"}
try{$ffmpegDetail=Ensure-FFmpeg;$ffmpegReady=$true;Write-Host "FFmpeg ready: $ffmpegDetail" -ForegroundColor Green}catch{$ffmpegDetail=$_.Exception.Message;Write-Warning "FFmpeg remains unavailable: $ffmpegDetail"}
$lines=@("Checked: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')","Git ready: $gitReady","Git detail: $gitDetail","FFmpeg ready: $ffmpegReady","FFmpeg detail: $ffmpegDetail",'Core TGBOT was not changed by this auxiliary installer.')
[IO.File]::WriteAllLines($statusPath,$lines,[Text.UTF8Encoding]::new($false))
if(-not $Quiet){Write-Host "Status: $statusPath" -ForegroundColor Cyan}
if($gitReady -and $ffmpegReady){exit 0}else{exit 2}
