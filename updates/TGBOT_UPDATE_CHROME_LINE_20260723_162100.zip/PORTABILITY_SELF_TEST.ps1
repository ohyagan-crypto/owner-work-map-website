param([string]$PackageRoot = $PSScriptRoot)

$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($PackageRoot)
$bot=Join-Path $root 'payload\tg-openai-bot\codex_bot.py'
$setup=Join-Path $root 'payload\tg-openai-bot\setup_env.ps1'
$installer=Join-Path $root 'INSTALL_TGBOT_UNIFIED.ps1'
$updater=Join-Path $root 'UPDATE_INSTALLED_TGBOT.ps1'
$routingTest=Join-Path $root 'payload\tg-openai-bot\failure_routing_self_test.py'
$browserTool=Join-Path $root 'payload\tg-openai-bot\tools\browser_login.py'
$lineSkill=Join-Path $root 'payload\.codex\skills\line-official-fast-code\SKILL.md'

foreach($required in @($bot,$routingTest,$browserTool,$lineSkill)){
    if(-not(Test-Path -LiteralPath $required)){throw "Portable package is missing: $required"}
}
if(Test-Path -LiteralPath (Join-Path $root 'payload\tg-openai-bot\codex_learning_index.json')){
    throw 'A source-computer learning index is present in the package.'
}

$forbiddenFiles=@(Get-ChildItem -LiteralPath $root -Recurse -Force -File|Where-Object{
    $_.Name -eq '.env' -or
    $_.Extension.ToLowerInvariant() -in @('.log','.sqlite','.sqlite3','.db','.pyc') -or
    $_.Name -match '^(cookies?|auth|credentials?|secrets?|session)(\.|$)'
})
if($forbiddenFiles){throw "Private/runtime files are present: $($forbiddenFiles.Name -join ', ')"}

$botText=[IO.File]::ReadAllText($bot)
if($botText -match 'send_task_ack\s*\('){throw 'Fixed acknowledgement routing remains in codex_bot.py.'}
if($botText -match 'and\s+DIRECT_SHORTCUTS_ENABLED\s*:'){throw 'Conversational shortcut routing remains reachable.'}
if($botText -notmatch 'DIRECT_SHORTCUTS_ENABLED\s*=\s*False'){throw 'Conversational shortcut routing is not permanently disabled.'}
foreach($shortcut in @('/help','/status','/config','/skills','/learned','/read')){
    $needle='owner_command_text.startswith("{0}")' -f $shortcut
    if($botText.Contains($needle)){throw "Fixed slash-command routing remains: $shortcut"}
}

if(Test-Path -LiteralPath $setup){
    $setupText=[IO.File]::ReadAllText($setup)
    if($setupText -match 'TELEGRAM_DIRECT_SHORTCUTS_ENABLED=true'){throw 'Setup would enable fixed conversational shortcuts.'}
}
$pathMigrationHost=if(Test-Path -LiteralPath $installer){$installer}elseif(Test-Path -LiteralPath $updater){$updater}else{$null}
if(-not $pathMigrationHost){throw 'Neither installer nor updater exists for current-user path migration.'}
$migrationText=[IO.File]::ReadAllText($pathMigrationHost)
if($migrationText -notmatch 'Convert-PortableSkillPaths'){throw 'Current-user path conversion is missing.'}
foreach($sourceRoot in @('C:\Users\Administrator','C:\Users\max')){
    if(-not $migrationText.Contains($sourceRoot)){throw "Source-user migration mapping is missing: $sourceRoot"}
}
if($migrationText -notmatch '\.codex-api2'){throw 'Receiving-computer CODEX_HOME mapping is missing.'}
if($migrationText -notmatch 'GetFolderPath\("UserProfile"\)|\$env:USERPROFILE'){
    throw 'Package does not derive the receiving user profile dynamically.'
}
if($migrationText -notmatch 'Ensure-GoogleChrome' -or $migrationText -notmatch 'dl\.google\.com/chrome/install/latest/chrome_installer\.exe'){
    throw 'Official Google Chrome installation support is missing.'
}
$browserText=[IO.File]::ReadAllText($browserTool)
if($browserText.IndexOf('Google" / "Chrome') -gt $browserText.IndexOf('Microsoft" / "Edge')){
    throw 'Google Chrome is not the first TGBOT browser candidate.'
}
if($browserText -notmatch 'TGBOT_CHROME_PROFILE_DIR' -or $browserText -notmatch 'shared-chrome'){
    throw 'Persistent shared Chrome profile support is missing.'
}
$lineText=[IO.File]::ReadAllText($lineSkill)
if($lineText -notmatch 'manager\.line\.biz' -or $lineText -notmatch 'four-digit'){
    throw 'LINE Official fast-code skill is incomplete.'
}

$secretPatterns=@(
    '(?<![A-Za-z0-9_])\d{8,12}:[A-Za-z0-9_-]{25,}(?![A-Za-z0-9_])',
    '(?<![A-Za-z0-9_-])sk-[A-Za-z0-9_-]{20,}(?![A-Za-z0-9_-])'
)
$textFiles=Get-ChildItem -LiteralPath $root -Recurse -Force -File|Where-Object{
    $_.Length -lt 5MB -and $_.Extension.ToLowerInvariant() -in @('.ps1','.py','.md','.txt','.json','.toml','.cmd','.js','.yml','.yaml')
}
foreach($file in $textFiles){
    try{$text=[IO.File]::ReadAllText($file.FullName)}catch{continue}
    foreach($pattern in $secretPatterns){if([regex]::IsMatch($text,$pattern)){throw "Possible secret found in $($file.Name)."}}
}

Write-Host 'PORTABILITY_SELF_TEST_OK' -ForegroundColor Green
exit 0
