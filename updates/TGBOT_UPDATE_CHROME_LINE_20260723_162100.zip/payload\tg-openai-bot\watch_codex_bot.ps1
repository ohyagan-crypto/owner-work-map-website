﻿$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BotScript = Join-Path $ProjectDir "codex_bot.py"

try {
    [Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
} catch {}
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
if (-not $env:LANG) { $env:LANG = "C.UTF-8" }
if (-not $env:LC_ALL) { $env:LC_ALL = "C.UTF-8" }
$env:NO_COLOR = "1"

$HeartbeatPath = Join-Path $ProjectDir "codex_bot_heartbeat.json"
$WatchdogLog = Join-Path $ProjectDir "codex_bot_watchdog.log"
$StdoutLog = Join-Path $ProjectDir "codex_bot.stdout.log"
$StderrLog = Join-Path $ProjectDir "codex_bot.stderr.log"
$MaxHeartbeatAgeSeconds = 120   # 2 min - heartbeat should update every 30s
$MaxInvalidHeartbeatGraceSeconds = 90
$MaxCodexRunningAgeSeconds = 7200  # 120 min - do not restart long-running owner tasks before Codex hard timeout

function Write-WatchdogLog {
    param([string]$Message)
    $Line = "$(Get-Date -Format o) $Message"
    Add-Content -Path $WatchdogLog -Value $Line -Encoding UTF8
    Write-Host $Line
}

function Get-PythonPath {
    $PortablePython = Join-Path $env:USERPROFILE 'AppData\Local\Programs\TGBOT\python-3.13.14\python.exe'
    if (Test-Path -LiteralPath $PortablePython) {
        return $PortablePython
    }
    foreach ($PythonVersion in @('Python313','Python312','Python311')) {
        $PythonPath = Join-Path $env:LOCALAPPDATA "Programs\Python\$PythonVersion\python.exe"
        if (Test-Path -LiteralPath $PythonPath) {
            return $PythonPath
        }
    }
    if (Get-Command python -ErrorAction SilentlyContinue) {
        return "python"
    }
    if (Get-Command py -ErrorAction SilentlyContinue) {
        return "py"
    }
    throw "Python was not found."
}

function Test-NativeCommandChannel {
    $Cmd = Join-Path $env:SystemRoot 'System32\cmd.exe'
    if (-not (Test-Path -LiteralPath $Cmd)) { return $false }
    $Info = [Diagnostics.ProcessStartInfo]::new()
    $Info.FileName = $Cmd
    $Info.Arguments = '/d /c echo COMMAND_OK'
    $Info.UseShellExecute = $false
    $Info.CreateNoWindow = $true
    $Info.RedirectStandardOutput = $true
    $Info.RedirectStandardError = $true
    $Process = [Diagnostics.Process]::new()
    $Process.StartInfo = $Info
    try {
        if (-not $Process.Start()) { return $false }
        if (-not $Process.WaitForExit(5000)) {
            try { $Process.Kill() } catch {}
            return $false
        }
        $Output = $Process.StandardOutput.ReadToEnd().Trim()
        return $Process.ExitCode -eq 0 -and $Output -eq 'COMMAND_OK'
    }
    catch { return $false }
    finally { $Process.Dispose() }
}

function Get-BotProcesses {
    Get-CimInstance Win32_Process | Where-Object {
        $Name = [string]$_.Name
        $CommandLine = [string]$_.CommandLine
        ($Name -in @("python.exe", "pythonw.exe")) -and $CommandLine.Contains("codex_bot.py")
    }
}

function Get-CodexBotProcesses {
    $BotProcessIds = @(Get-BotProcesses | ForEach-Object { [int]$_.ProcessId })
    if ($BotProcessIds.Count -eq 0) {
        return @()
    }

    $AllProcesses = @(Get-CimInstance Win32_Process)
    $DescendantIds = New-Object 'System.Collections.Generic.HashSet[int]'
    $Frontier = @($BotProcessIds)
    while ($Frontier.Count -gt 0) {
        $Next = @()
        foreach ($Process in $AllProcesses) {
            if ($Frontier -contains [int]$Process.ParentProcessId) {
                $ProcessId = [int]$Process.ProcessId
                if ($DescendantIds.Add($ProcessId)) {
                    $Next += $ProcessId
                }
            }
        }
        $Frontier = $Next
    }

    $AllProcesses | Where-Object {
        $CommandLine = [string]$_.CommandLine
        $DescendantIds.Contains([int]$_.ProcessId) -and
            $CommandLine.Contains("--output-last-message") -and
            $CommandLine.Contains("codex_bot_") -and
            (
                $CommandLine.Contains("codex.cmd") -or
                $CommandLine.Contains(" codex ") -or
                $CommandLine.Contains("@openai\codex")
            )
    }
}

function Get-FileAgeSeconds {
    param([string]$Path)

    $Item = Get-Item -LiteralPath $Path
    $FileTime = [DateTimeOffset]$Item.LastWriteTimeUtc
    return [Math]::Max(0, [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - $FileTime.ToUnixTimeSeconds())
}

function Stop-BotProcesses {
    foreach ($Process in Get-BotProcesses) {
        if ($Process.ProcessId -eq $PID) {
            continue
        }
        try {
            Stop-Process -Id $Process.ProcessId -Force
            Write-WatchdogLog "Stopped stale bot process PID=$($Process.ProcessId)."
        }
        catch {
            Write-WatchdogLog "Failed to stop PID=$($Process.ProcessId): $($_.Exception.Message)"
        }
    }
}

function Stop-CodexBotProcesses {
    foreach ($Process in Get-CodexBotProcesses) {
        if ($Process.ProcessId -eq $PID) {
            continue
        }
        try {
            Stop-Process -Id $Process.ProcessId -Force
            Write-WatchdogLog "Stopped stale Codex child PID=$($Process.ProcessId)."
        }
        catch {
            Write-WatchdogLog "Failed to stop Codex child PID=$($Process.ProcessId): $($_.Exception.Message)"
        }
    }
}

function Start-Bot {
    $Python = Get-PythonPath
    $ProcessArgs = @()
    if ($Python -eq "py") {
        $ProcessArgs = @("-3", "codex_bot.py")
    }
    else {
        $ProcessArgs = @("codex_bot.py")
    }

    $Process = Start-Process `
        -FilePath $Python `
        -ArgumentList $ProcessArgs `
        -WorkingDirectory $ProjectDir `
        -WindowStyle Hidden `
        -RedirectStandardOutput $StdoutLog `
        -RedirectStandardError $StderrLog `
        -PassThru
    Write-WatchdogLog "Started codex_bot.py PID=$($Process.Id)."
}

function Load-Env {
    $EnvPath = Join-Path $ProjectDir ".env"
    if (-not (Test-Path $EnvPath)) {
        throw ".env not found: $EnvPath"
    }

    Get-Content $EnvPath -Encoding UTF8 | ForEach-Object {
        $Line = $_.Trim()
        if (-not $Line -or $Line.StartsWith("#") -or -not $Line.Contains("=")) {
            return
        }
        $Key, $Value = $Line.Split("=", 2)
        [Environment]::SetEnvironmentVariable($Key.Trim(), $Value.Trim().Trim('"').Trim("'"), "Process")
    }
}

function Test-Telegram {
    Load-Env
    if (-not $env:TELEGRAM_BOT_TOKEN) {
        throw "TELEGRAM_BOT_TOKEN is missing."
    }
    $Base = if ($env:TELEGRAM_API_BASE) { $env:TELEGRAM_API_BASE.TrimEnd("/") } else { "https://api.telegram.org" }
    $Url = "$Base/bot$env:TELEGRAM_BOT_TOKEN/getMe"
    $Result = Invoke-RestMethod -Uri $Url -Method Get -TimeoutSec 30
    if (-not $Result.ok) {
        throw "Telegram getMe returned ok=false."
    }
    return $Result.result.username
}

function Test-CodexCli {
    $Launcher = Join-Path $env:USERPROFILE "bin\codex.cmd"
    if (-not (Test-Path -LiteralPath $Launcher)) { $Launcher = Join-Path $ProjectDir "codex.cmd" }
    if (-not (Test-Path -LiteralPath $Launcher)) { throw "codex launcher was not found." }
    return $true
}

function Get-HeartbeatState {
    if (-not (Test-Path $HeartbeatPath)) {
        return [pscustomobject]@{
            Exists = $false
            AgeSeconds = [double]::PositiveInfinity
            FileAgeSeconds = [double]::PositiveInfinity
            Phase = "missing"
            Timestamp = 0
        }
    }

    try {
        $FileAge = Get-FileAgeSeconds -Path $HeartbeatPath
        $Raw = Get-Content -Raw -Path $HeartbeatPath -Encoding UTF8
        $Data = $Raw | ConvertFrom-Json
        $Age = [Math]::Max(0, [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - [Int64]$Data.timestamp)
        $ActiveRequests = 0
        $OldestActiveRequestAge = 0
        if ($null -ne $Data.active_requests) {
            $ActiveRequests = [int]$Data.active_requests
        }
        if ($null -ne $Data.oldest_active_request_age) {
            $OldestActiveRequestAge = [int]$Data.oldest_active_request_age
        }
        return [pscustomobject]@{
            Exists = $true
            AgeSeconds = $Age
            FileAgeSeconds = $FileAge
            Phase = [string]$Data.phase
            Timestamp = [double]$Data.timestamp
            ActiveRequests = $ActiveRequests
            OldestActiveRequestAge = $OldestActiveRequestAge
        }
    }
    catch {
        $FileAge = [double]::PositiveInfinity
        try {
            $FileAge = Get-FileAgeSeconds -Path $HeartbeatPath
        }
        catch {}
        return [pscustomobject]@{
            Exists = $false
            AgeSeconds = [double]::PositiveInfinity
            FileAgeSeconds = $FileAge
            Phase = "invalid"
            Timestamp = 0
            ActiveRequests = 0
            OldestActiveRequestAge = 0
        }
    }
}

function Test-Health {
    Test-CodexCli
    if (-not (Test-NativeCommandChannel)) {
        return "command_channel_failed"
    }
    $BotName = Test-Telegram
    $Processes = @(Get-BotProcesses)
    if ($Processes.Count -eq 0) {
        return "no_process"
    }
    if ($Processes.Count -gt 1) {
        return "duplicate_process"
    }

    $Heartbeat = Get-HeartbeatState
    $CodexChildren = @(Get-CodexBotProcesses)
    if ($Heartbeat.Exists -and $Heartbeat.ActiveRequests -le 0 -and $CodexChildren.Count -gt 0) {
        Stop-CodexBotProcesses
    }
    if (-not $Heartbeat.Exists) {
        if ($Heartbeat.Phase -eq "invalid" -and $Heartbeat.FileAgeSeconds -le $MaxInvalidHeartbeatGraceSeconds) {
            Write-WatchdogLog "Heartbeat is temporarily invalid but recent; skipping restart age=$([int]$Heartbeat.FileAgeSeconds)s."
            return "healthy"
        }
        return "missing_heartbeat"
    }
    if ($MaxCodexRunningAgeSeconds -gt 0 -and $Heartbeat.Phase -eq "codex_running" -and $Heartbeat.AgeSeconds -gt $MaxCodexRunningAgeSeconds) {
        return "codex_stuck_$([int]$Heartbeat.AgeSeconds)s"
    }
    if ($MaxCodexRunningAgeSeconds -gt 0 -and $Heartbeat.ActiveRequests -gt 0 -and $Heartbeat.OldestActiveRequestAge -gt $MaxCodexRunningAgeSeconds) {
        return "codex_worker_stuck_$($Heartbeat.OldestActiveRequestAge)s"
    }
    if ($Heartbeat.AgeSeconds -gt $MaxHeartbeatAgeSeconds) {
        return "stale_heartbeat_$([int]$Heartbeat.AgeSeconds)s"
    }

    Write-WatchdogLog "Healthy bot=@$BotName PID=$($Processes[0].ProcessId) heartbeat=$($Heartbeat.Phase) age=$([int]$Heartbeat.AgeSeconds)s active=$($Heartbeat.ActiveRequests) oldest_active=$($Heartbeat.OldestActiveRequestAge)s."
    return "healthy"
}

try {
    Set-Location $ProjectDir
    $Status = Test-Health
    if ($Status -eq "healthy") {
        exit 0
    }

    Write-WatchdogLog "Unhealthy status=$Status. Restarting bot."
    Stop-BotProcesses
    Stop-CodexBotProcesses
    Start-Sleep -Seconds 2
    Start-Bot
    Start-Sleep -Seconds 8
    $After = Test-Health
    if ($After -ne "healthy") {
        Write-WatchdogLog "Post-restart status=$After."
        exit 2
    }
    exit 0
}
catch {
    Write-WatchdogLog "Watchdog error: $($_.Exception.Message)"
    try {
        Stop-BotProcesses
        Stop-CodexBotProcesses
        Start-Sleep -Seconds 2
        Start-Bot
    }
    catch {
        Write-WatchdogLog "Recovery start failed: $($_.Exception.Message)"
        exit 3
    }
    exit 1
}
