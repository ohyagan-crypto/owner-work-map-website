@echo off
setlocal
title TGBOT Portability Self-Test
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0PORTABILITY_SELF_TEST.ps1" -PackageRoot "%~dp0"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" echo TGBOT portability and no-fixed-reply checks passed.
if not "%RC%"=="0" echo TGBOT portability self-test failed. Do not install this package.
pause
exit /b %RC%
