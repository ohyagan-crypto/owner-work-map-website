@echo off
setlocal
title TGBOT Git and FFmpeg Skill Tools
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_TGBOT_SKILL_TOOLS.ps1"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" echo TGBOT skill tool check completed.
if not "%RC%"=="0" echo One or more optional skill tools remain unavailable. Core TGBOT was not changed.
pause
exit /b %RC%
