param(
    [string]$TargetOverride='',
    [switch]$Quiet
)
$ErrorActionPreference='Stop'
$target=if($TargetOverride){[IO.Path]::GetFullPath($TargetOverride)}else{Join-Path $env:USERPROFILE 'tg-openai-bot'}
$envPath=Join-Path $target '.env'
$probeScript=Join-Path $target 'command_channel_probe.cmd'
$statusPath=Join-Path $target 'command_channel_install_test_status.txt'

function Write-Status([bool]$Success,[string]$Stage,[string]$Detail){
    $lines=@(
        "Checked: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
        "Success: $Success",
        "Stage: $Stage",
        "Detail: $Detail",
        "Current user home: $env:USERPROFILE"
    )
    [IO.File]::WriteAllLines($statusPath,$lines,[Text.UTF8Encoding]::new($false))
    if(-not $Quiet){Write-Host ($lines -join [Environment]::NewLine)}
}

$native=& $env:ComSpec /d /c echo COMMAND_OK 2>&1 | Out-String
if($LASTEXITCODE -ne 0 -or $native.Trim() -ne 'COMMAND_OK'){
    Write-Status $false 'native_cmd' 'cmd.exe did not return COMMAND_OK.'
    exit 2
}
if(-not(Test-Path -LiteralPath $envPath) -or -not(Test-Path -LiteralPath $probeScript)){
    Write-Status $false 'installed_files' 'Installed .env or command_channel_probe.cmd is missing.'
    exit 2
}

$settings=@{}
foreach($line in Get-Content -LiteralPath $envPath){
    $separator=$line.IndexOf('=')
    if($separator -le 0){continue}
    $name=$line.Substring(0,$separator).Trim();$value=$line.Substring($separator+1)
    if($name){$settings[$name]=$value}
}
foreach($name in @('API2_KEY','OPENAI_API_KEY','OPENAI_BASE_URL','CODEX_HOME')){
    if($settings.ContainsKey($name) -and -not [string]::IsNullOrWhiteSpace([string]$settings[$name])){Set-Item -Path "Env:$name" -Value ([string]$settings[$name])}
}
$model=if($settings.ContainsKey('CODEX_MODEL')){[string]$settings['CODEX_MODEL']}else{'gpt-5.4-mini'}
$command=Join-Path $target 'codex.cmd'
if(-not(Test-Path -LiteralPath $command)){$command=Join-Path $env:USERPROFILE 'bin\codex.cmd'}
if(-not(Test-Path -LiteralPath $command)){
    Write-Status $false 'codex_command' 'Installed codex.cmd shim is missing.'
    exit 2
}

$lastReason='not_started'
for($attempt=1;$attempt -le 2;$attempt++){
    $job=$null
    $marker=Join-Path $env:TEMP "tgbot_verify_marker_$PID`_$attempt.txt"
    $answer=Join-Path $env:TEMP "tgbot_verify_answer_$PID`_$attempt.txt"
    try{
        $probeCommand='cmd.exe /d /c ""{0}" "{1}""' -f $probeScript,$marker
        $prompt="Use the shell command execution tool to run this exact authorized command once: $probeCommand . Wait for COMMAND_OK, then answer only COMMAND_OK. Do not create the marker with a file editing tool."
        $commandArgs=@('exec','-C',$env:USERPROFILE,'--skip-git-repo-check','--sandbox','danger-full-access','--color','never','--output-last-message',$answer,'--dangerously-bypass-approvals-and-sandbox','--model',$model,$prompt)
        $commandArgsJson=ConvertTo-Json -InputObject $commandArgs -Compress
        $job=Start-Job -ScriptBlock {param($path,$argumentsJson);$arguments=[string[]](ConvertFrom-Json -InputObject $argumentsJson);$output=& $path @arguments 2>&1|Out-String;[pscustomobject]@{ExitCode=$LASTEXITCODE;Output=$output}} -ArgumentList $command,$commandArgsJson
        if(-not(Wait-Job -Job $job -Timeout 240)){Stop-Job -Job $job -ErrorAction SilentlyContinue;$lastReason='Codex command round trip timed out.';continue}
        $result=Receive-Job -Job $job
        $markerText=if(Test-Path -LiteralPath $marker){[IO.File]::ReadAllText($marker).Trim()}else{''}
        $answerText=if(Test-Path -LiteralPath $answer){[IO.File]::ReadAllText($answer).Trim()}else{''}
        if($result.ExitCode -eq 0 -and $markerText -eq 'COMMAND_OK' -and $answerText -match 'COMMAND_OK'){
            Write-Status $true 'codex_shell_round_trip' "COMMAND_OK marker verified on attempt $attempt."
            exit 0
        }
        $lastReason='Codex returned without a verified shell-created COMMAND_OK marker.'
    }catch{$lastReason=$_.Exception.Message}
    finally{
        if($job){Remove-Job -Job $job -Force -ErrorAction SilentlyContinue}
        Remove-Item -LiteralPath $marker,$answer -Force -ErrorAction SilentlyContinue
    }
}
Write-Status $false 'codex_shell_round_trip' $lastReason
exit 2
