"""Offline checks for safe, actionable Codex failure routing."""

import os
import inspect
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
os.environ["TGBOT_FAILURE_ROUTING_SELF_TEST"] = "1"
os.environ.setdefault("TELEGRAM_BOT_TOKEN", ("0" * 9) + ":" + ("A" * 30))
import codex_bot as bot


def main() -> int:
    if bot.ACK_MESSAGES_ENABLED:
        raise AssertionError("fixed Telegram acknowledgements must remain disabled in the package")
    if bot.PROGRESS_MESSAGES_ENABLED:
        raise AssertionError("fixed timer-based progress messages must remain disabled in the package")
    if bot.DIRECT_SHORTCUTS_ENABLED:
        raise AssertionError("fixed conversational shortcut replies must remain disabled in the package")
    message_source = inspect.getsource(bot.handle_message)
    if "send_task_ack" in message_source or "DIRECT_SHORTCUTS_ENABLED" in message_source:
        raise AssertionError("fixed acknowledgement or conversational shortcut routing remains reachable")
    for shortcut in ("/help", "/status", "/config", "/skills", "/learned", "/read"):
        if f'owner_command_text.startswith("{shortcut}")' in message_source:
            raise AssertionError(f"fixed slash-command reply remains reachable: {shortcut}")
    if bot.CODEX_MAX_PARALLEL_REQUESTS != 1:
        raise AssertionError("the unified bot must serialize Codex CLI workers to protect the command channel")
    command_probe = bot.native_command_channel_probe()
    if not command_probe.get("ok"):
        raise AssertionError(f"native Windows command channel failed: {command_probe.get('detail')}")
    if not bot.system_health_query_text("請檢查這台雲端伺服器狀態"):
        raise AssertionError("server health request did not route to the direct local provider")
    if not bot.system_health_query_text("/system_status"):
        raise AssertionError("/system_status did not route to the direct local provider")
    if bot.system_health_query_text("請重啟雲端伺服器"):
        raise AssertionError("server reboot request must not be consumed by the read-only health provider")
    original_learning_summary = bot.learning_index_summary
    try:
        bot.learning_index_summary = lambda: "self-test index"
        context_summary = bot.codex_context_summary()
    finally:
        bot.learning_index_summary = original_learning_summary
    stale_paths = ["C:" + "\\Users\\" + name for name in ("max", "Administrator")]
    current_home = str(bot.Path.home()).lower().rstrip("\\")
    if any(path.lower().rstrip("\\") != current_home and path in context_summary for path in stale_paths):
        raise AssertionError("runtime instructions still contain a source-computer Windows user path")
    if str(bot.Path.home()) not in context_summary or str(bot.CODEX_HOME) not in context_summary:
        raise AssertionError("runtime instructions do not identify the receiving computer's current paths")
    missing_path = "C:" + "\\Users\\" + "nonexistent_tgbot_user" + "\\wenxiu-" + "ai-skills\\quiz.md"
    checked_link = bot.validate_local_markdown_links(f"[測驗檔]({missing_path})\n已完成 ZIP 與 Telegram 回傳。")
    if "檔案驗證未通過" not in checked_link or "未視為完成" not in checked_link:
        raise AssertionError("nonexistent local Markdown link was not blocked before delivery")
    rebase_dir = bot.Path.home() / f".tgbot_path_rebase_self_test_{os.getpid()}"
    rebase_file = rebase_dir / "result.md"
    try:
        rebase_dir.mkdir(parents=True, exist_ok=False)
        rebase_file.write_text("self-test", encoding="utf-8")
        stale_link = f"C:\\Users\\source-user\\{rebase_dir.name}\\{rebase_file.name}"
        rebased_link = bot.validate_local_markdown_links(f"[結果]({stale_link})")
        if stale_link in rebased_link or str(rebase_file) not in rebased_link:
            raise AssertionError("source-computer user path was not rebased to the receiving user's home")
    finally:
        shutil.rmtree(rebase_dir, ignore_errors=True)
    restart_cases = {
        "重啟": "restart_service",
        "重啟服務器": "restart_service",
        "/restart_service": "restart_service",
        "重啟電腦": "request_reboot",
        "重開機": "request_reboot",
        "/reboot_pc": "request_reboot",
        "/confirm_reboot_pc": "confirm_reboot",
        "/cancel_reboot_pc": "cancel_reboot",
        "要加入能重啟服務器或電腦的功能": "",
    }
    for text, expected in restart_cases.items():
        if bot.restart_management_action(text) != expected:
            raise AssertionError(f"restart routing mismatch for {text!r}")
    if not bot.RESTART_SERVICE_SCRIPT_PATH.exists() or not bot.REBOOT_WINDOWS_SCRIPT_PATH.exists():
        raise AssertionError("restart helper scripts are missing")

    original_owner_chat_id = bot.TELEGRAM_OWNER_CHAT_ID
    original_allowed_chat_ids = bot.ALLOWED_CHAT_IDS
    original_allow_all = bot.CODEX_ALLOW_ALL_CHATS
    try:
        bot.TELEGRAM_OWNER_CHAT_ID = "123"
        bot.ALLOWED_CHAT_IDS = {123, 456}
        bot.CODEX_ALLOW_ALL_CHATS = True
        if not bot.is_admin_chat(123) or bot.is_admin_chat(456):
            raise AssertionError("restart administration must be restricted to the owner chat")
    finally:
        bot.TELEGRAM_OWNER_CHAT_ID = original_owner_chat_id
        bot.ALLOWED_CHAT_IDS = original_allowed_chat_ids
        bot.CODEX_ALLOW_ALL_CHATS = original_allow_all

    originals = {
        "is_admin_chat": bot.is_admin_chat,
        "stop_running_codex_processes": bot.stop_running_codex_processes,
        "launch_detached_powershell": bot.launch_detached_powershell,
        "send_message": bot.send_message,
        "save_restart_state": bot.save_restart_state,
        "load_restart_state": bot.load_restart_state,
        "clear_restart_state": bot.clear_restart_state,
        "windows_boot_time_epoch": bot.windows_boot_time_epoch,
    }
    restart_state = {}
    launches = []
    try:
        bot.is_admin_chat = lambda _chat_id: True
        bot.stop_running_codex_processes = lambda: 0
        bot.launch_detached_powershell = lambda script, args: launches.append((script.name, list(args)))
        bot.send_message = lambda *_args, **_kwargs: None
        bot.save_restart_state = lambda data: (restart_state.clear(), restart_state.update(data))
        bot.load_restart_state = lambda: dict(restart_state)
        bot.clear_restart_state = lambda: restart_state.clear()
        message = {"chat": {"id": 123, "type": "private"}}
        if not bot.handle_restart_management_request(123, message, "/restart_service"):
            raise AssertionError("service restart command was not handled")
        if not launches or launches[-1][0] != "restart_tgbot_service.ps1":
            raise AssertionError("service restart helper was not launched")
        if not bot.handle_restart_management_request(123, message, "/reboot_pc"):
            raise AssertionError("computer reboot request was not handled")
        if restart_state.get("status") != "computer_reboot_pending_confirmation":
            raise AssertionError("computer reboot did not require confirmation")
        if not bot.handle_restart_management_request(123, message, "/confirm_reboot_pc"):
            raise AssertionError("computer reboot confirmation was not handled")
        if restart_state.get("status") != "computer_reboot_scheduled":
            raise AssertionError("computer reboot was not scheduled after confirmation")
        if launches[-1][0] != "reboot_windows.ps1":
            raise AssertionError("Windows reboot helper was not launched")
        bot.windows_boot_time_epoch = lambda: float(restart_state.get("confirmed_at") or 0) + 1
        if not bot.report_restart_completion_if_needed() or restart_state:
            raise AssertionError("post-reboot Telegram completion report did not clear its state")
    finally:
        for name, value in originals.items():
            setattr(bot, name, value)

    login_request = bot.extract_browser_login_request(
        "/login_browser\n登入網址：https://example.com/login\n帳號：owner@example.com\n密碼：test-only-password"
    )
    if not login_request or login_request.get("url") != "https://example.com/login":
        raise AssertionError("labeled browser login request was not recognized")
    if login_request.get("username") != "owner@example.com" or login_request.get("password") != "test-only-password":
        raise AssertionError("browser login fields were not parsed correctly")
    if bot.extract_browser_login_request("請幫我登入，但沒有提供完整資料") is not None:
        raise AssertionError("incomplete browser login request must not be treated as credentials")
    if "test-only-password" in bot.browser_login_status_reply("login_completed"):
        raise AssertionError("browser login replies must never expose credentials")

    cases = [
        (bot.CodexNoResult("empty"), "no_result"),
        (bot.CodexNoProgress("stall"), "no_progress"),
        (RuntimeError("Codex timed out after 300 seconds"), "timeout"),
        (RuntimeError("model not found"), "model_unavailable"),
        (RuntimeError("Codex exited with code 1"), "codex_runtime"),
    ]
    forbidden = [
        "主人" + "這輪任務沒有完成原因",
        "任務處理失敗" + "但原始錯誤可能含內部資訊",
        "我已保留續跑狀態" + "你不用重新組指令",
    ]
    for error, expected_kind in cases:
        kind, reason = bot.codex_failure_kind_and_reason(error, "測試任務")
        if kind != expected_kind or not reason:
            raise AssertionError(f"failure classifier mismatch: {kind!r}, {reason!r}")
        if not bot.is_recoverable_codex_failure(error, "測試任務"):
            raise AssertionError(f"recoverable failure was not marked recoverable: {kind}")
        reply = bot.user_facing_codex_failure(error, "測試任務")
        if not reply or any(fragment in reply for fragment in forbidden):
            raise AssertionError("failure reply was empty or used the forbidden generic wording")

    if bot.is_recoverable_codex_failure(RuntimeError("401 unauthorized"), "測試任務"):
        raise AssertionError("invalid credentials must not be blindly retried")
    if bot.is_transient_codex_error("HTTP 502 Upstream access forbidden"):
        raise AssertionError("upstream permission failures must not be retried as transient 502 errors")
    if not bot.is_transient_codex_error("HTTP 502 Bad Gateway"):
        raise AssertionError("ordinary 502 failures should remain recoverable")
    forbidden_error = RuntimeError("HTTP 502 Upstream access forbidden")
    kind, _ = bot.codex_failure_kind_and_reason(forbidden_error, "測試任務")
    if kind != "api_forbidden" or bot.is_recoverable_codex_failure(forbidden_error, "測試任務"):
        raise AssertionError("API permission failures must fail fast with api_forbidden")

    original_once = bot.run_subprocess_once
    original_sleep = bot.time.sleep
    retry_calls = []
    try:
        def fake_once(*args, **kwargs):
            retry_calls.append(1)
            if len(retry_calls) == 1:
                raise subprocess.TimeoutExpired(cmd="codex", timeout=1)
            return subprocess.CompletedProcess(args=["codex"], returncode=0, stdout="OK", stderr="")

        bot.run_subprocess_once = fake_once
        bot.time.sleep = lambda _seconds: None
        result = bot.run_subprocess_with_retry(["codex"], bot.Path.cwd(), "test", 1)
        if result.returncode != 0 or len(retry_calls) != 2:
            raise AssertionError("timeout retry did not complete on the second attempt")
    finally:
        bot.run_subprocess_once = original_once
        bot.time.sleep = original_sleep

    original_current = bot.current_codex_model
    original_candidates = bot.codex_model_candidates
    original_run_model = bot.run_codex_with_model
    model_calls = []
    try:
        bot.current_codex_model = lambda: "primary-model"
        bot.codex_model_candidates = lambda _model: ["primary-model", "fallback-model"]

        def fake_run_model(_text, model):
            model_calls.append(model)
            if model == "primary-model":
                raise RuntimeError("model not found")
            return "OK"

        bot.run_codex_with_model = fake_run_model
        if bot.run_codex("test") != "OK" or model_calls != ["primary-model", "fallback-model"]:
            raise AssertionError("recoverable model failure did not switch to the fallback model")
    finally:
        bot.current_codex_model = original_current
        bot.codex_model_candidates = original_candidates
        bot.run_codex_with_model = original_run_model
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
