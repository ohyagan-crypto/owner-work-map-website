Option Explicit
Dim shell, project, command
Set shell = CreateObject("WScript.Shell")
project = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & project & "\watch_codex_bot.ps1"""
shell.Run command, 0, False
Set shell = Nothing
