param(
    [Parameter(Mandatory = $true)]
    [int]$BotPid,
    [int]$DelaySeconds = 4
)

$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$WatchdogScript = Join-Path $ProjectDir 'watch_codex_bot.ps1'
$PowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

if (-not (Test-Path -LiteralPath $WatchdogScript)) {
    throw "Missing watchdog script: $WatchdogScript"
}

Start-Sleep -Seconds ([Math]::Max(2, $DelaySeconds))
$BotProcess = Get-Process -Id $BotPid -ErrorAction SilentlyContinue
if ($BotProcess) {
    Stop-Process -Id $BotPid -Force
}
Start-Sleep -Seconds 2

& $PowerShell -NoProfile -ExecutionPolicy Bypass -File $WatchdogScript
exit $LASTEXITCODE
