param(
    [string]$TargetOverride = '',
    [string]$CodexHomeOverride = '',
    [switch]$SkipRestart,
    [switch]$SkipAuxiliaryTools,
    [switch]$SkipCommandChannelTest
)

$ErrorActionPreference = 'Stop'

$Package = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $Package 'payload\tg-openai-bot'
$Target = if ($TargetOverride) {
    [IO.Path]::GetFullPath($TargetOverride)
}
else {
    Join-Path $env:USERPROFILE 'tg-openai-bot'
}
$TaskName = 'Unified TGBOT Watchdog'
$Timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$UpdateStatusPath = Join-Path $Target 'tgbot_update_status.txt'

function Write-UpdateStep {
    param([string]$Message, [ConsoleColor]$Color = [ConsoleColor]::Cyan)
    $line = "[$(Get-Date -Format 'HH:mm:ss')] $Message"
    Write-Host $line -ForegroundColor $Color
    try { Add-Content -LiteralPath $UpdateStatusPath -Value $line -Encoding UTF8 } catch {}
}

function Find-Python {
    $portable = Join-Path $env:USERPROFILE 'AppData\Local\Programs\TGBOT\python-3.13.14\python.exe'
    if (Test-Path -LiteralPath $portable) {
        & $portable -c "import sys; print(sys.executable)" *> $null
        if ($LASTEXITCODE -eq 0) { return @{ Path = $portable; Args = @() } }
    }
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) {
        & $py.Source -3 -c "import sys; print(sys.executable)" *> $null
        if ($LASTEXITCODE -eq 0) { return @{ Path = $py.Source; Args = @('-3') } }
    }
    $python = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($python) {
        & $python.Source -c "import sys; print(sys.executable)" *> $null
        if ($LASTEXITCODE -eq 0) { return @{ Path = $python.Source; Args = @() } }
    }
    throw 'Python is missing. Run INSTALL_TGBOT_UNIFIED.cmd once to repair prerequisites.'
}

function Find-GoogleChrome {
    $candidates=@(
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )
    foreach($registryPath in @(
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
        'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'
    )){
        try {
            $registered=[string](Get-Item -LiteralPath $registryPath -ErrorAction Stop).GetValue('')
            if($registered){$candidates += $registered}
        } catch {}
    }
    return ($candidates | Where-Object {$_ -and (Test-Path -LiteralPath $_ -PathType Leaf)} | Select-Object -First 1)
}

function Ensure-GoogleChrome {
    $chrome=Find-GoogleChrome
    if($chrome){
        $version=[Diagnostics.FileVersionInfo]::GetVersionInfo($chrome).FileVersion
        Write-UpdateStep "Reusing installed Google Chrome $version`: $chrome" Green
        return $chrome
    }
    Write-UpdateStep 'Google Chrome is missing. Downloading the official installer from dl.google.com.' Yellow
    $downloadDir=Join-Path $env:TEMP 'tgbot-chrome'
    New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null
    $installer=Join-Path $downloadDir "chrome-installer-$PID.exe"
    Invoke-WebRequest -Uri 'https://dl.google.com/chrome/install/latest/chrome_installer.exe' -OutFile $installer -UseBasicParsing -TimeoutSec 600
    if((Get-Item -LiteralPath $installer).Length -lt 1MB){throw 'Google Chrome installer download is incomplete.'}
    Unblock-File -LiteralPath $installer -ErrorAction SilentlyContinue
    $signature=Get-AuthenticodeSignature -LiteralPath $installer
    if($signature.Status -ne 'Valid' -or [string]$signature.SignerCertificate.Subject -notmatch 'Google'){
        throw 'Google Chrome installer signature verification failed.'
    }
    $process=Start-Process -FilePath $installer -ArgumentList @('/silent','/install') -PassThru -WindowStyle Hidden
    if(-not $process.WaitForExit(600000)){
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        throw 'Google Chrome installation timed out after 10 minutes.'
    }
    if($process.ExitCode -ne 0){throw "Google Chrome installer returned exit code $($process.ExitCode)."}
    for($attempt=1;$attempt -le 30;$attempt++){
        $chrome=Find-GoogleChrome
        if($chrome){break}
        Start-Sleep -Seconds 2
    }
    if(-not $chrome){throw 'Google Chrome installer completed, but chrome.exe was not found.'}
    $version=[Diagnostics.FileVersionInfo]::GetVersionInfo($chrome).FileVersion
    Write-UpdateStep "Google Chrome ready $version`: $chrome" Green
    return $chrome
}

function Invoke-Python {
    param([hashtable]$Python, [string[]]$Arguments)
    & $Python.Path @($Python.Args + $Arguments) | Out-Host
    $exitCode = $LASTEXITCODE
    return [int]$exitCode
}

function Set-EnvRuntimeValues {
    param([string]$Path,[hashtable]$Values)
    $source=@(Get-Content -LiteralPath $Path)
    $written=@{}
    $updated=@()
    foreach($line in $source){
        $separator=$line.IndexOf('=')
        if($separator -gt 0){
            $name=$line.Substring(0,$separator)
            if($Values.ContainsKey($name)){$updated+="$name=$($Values[$name])";$written[$name]=$true;continue}
        }
        $updated+=$line
    }
    foreach($name in $Values.Keys){if(-not $written.ContainsKey($name)){$updated+="$name=$($Values[$name])"}}
    [IO.File]::WriteAllLines($Path,$updated,[Text.UTF8Encoding]::new($false))
}

function Convert-PortableSkillPaths {
    param([string]$UserHome,[string]$CodexHome,[string[]]$Roots)
    $replacements=[ordered]@{
        'C:\Users\Administrator\.codex-tgbot'=$CodexHome
        'C:\Users\max\.codex-tgbot'=$CodexHome
        'C:\Users\Administrator\.codex'=$CodexHome
        'C:\Users\max\.codex'=$CodexHome
        'C:\Users\Administrator'=$UserHome
        'C:\Users\max'=$UserHome
    }
    $extensions=@('.md','.txt','.ps1','.psm1','.cmd','.bat','.py','.js','.mjs','.cjs','.json','.toml','.yaml','.yml')
    $changed=0
    foreach($root in $Roots){
        if(-not(Test-Path -LiteralPath $root)){continue}
        $items=if((Get-Item -LiteralPath $root).PSIsContainer){Get-ChildItem -LiteralPath $root -Recurse -File -Force}else{Get-Item -LiteralPath $root}
        foreach($item in $items){
            if($extensions -notcontains $item.Extension.ToLowerInvariant()){continue}
            try{$text=[IO.File]::ReadAllText($item.FullName)}catch{continue}
            $updated=$text
            foreach($source in $replacements.Keys){$updated=$updated.Replace($source,[string]$replacements[$source])}
            if($updated -ne $text){[IO.File]::WriteAllText($item.FullName,$updated,[Text.UTF8Encoding]::new($false));$changed++}
        }
    }
    return $changed
}

function Get-TargetBotProcesses {
    $candidateIds = @()
    foreach ($stateFile in @('codex_bot_instance.lock', 'codex_bot_heartbeat.json')) {
        $path = Join-Path $Target $stateFile
        if (-not (Test-Path -LiteralPath $path)) { continue }
        try {
            $state = Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
            if ($state.pid) { $candidateIds += [int]$state.pid }
        }
        catch {}
    }
    foreach ($processId in @($candidateIds | Select-Object -Unique)) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId=$processId" -ErrorAction SilentlyContinue
        if ($process -and [string]$process.CommandLine -match 'codex_bot\.py') {
            $process
        }
    }
}

function Stop-TargetBotProcesses {
    $taskKill = Join-Path $env:SystemRoot 'System32\taskkill.exe'
    foreach ($process in @(Get-TargetBotProcesses)) {
        & $taskKill /PID $process.ProcessId /T /F *> $null
    }
}

function Get-FreshTargetBotProcess {
    param([datetime]$StartedAfter)
    $heartbeatPath = Join-Path $Target 'codex_bot_heartbeat.json'
    if (-not (Test-Path -LiteralPath $heartbeatPath)) { return $null }
    $heartbeatFile = Get-Item -LiteralPath $heartbeatPath -ErrorAction SilentlyContinue
    if (-not $heartbeatFile -or $heartbeatFile.LastWriteTime -lt $StartedAfter.AddSeconds(-2)) {
        return $null
    }
    try {
        $heartbeat = Get-Content -Raw -LiteralPath $heartbeatPath | ConvertFrom-Json
        $processId = [int]$heartbeat.pid
    }
    catch { return $null }
    $process = Get-CimInstance Win32_Process -Filter "ProcessId=$processId" -ErrorAction SilentlyContinue
    if ($process -and [string]$process.CommandLine -match 'codex_bot\.py') {
        return $process
    }
    return $null
}

if (-not (Test-Path -LiteralPath $Target)) {
    throw "Installed TGBOT was not found at $Target. Use INSTALL_TGBOT_UNIFIED.cmd for a new installation."
}
if (-not (Test-Path -LiteralPath (Join-Path $Target '.env'))) {
    throw 'Installed TGBOT .env is missing. Update stopped to avoid replacing existing settings.'
}
[IO.File]::WriteAllText(
    $UpdateStatusPath,
    "[$(Get-Date -Format 'HH:mm:ss')] TGBOT updater started.`r`n",
    [Text.UTF8Encoding]::new($false)
)
Write-UpdateStep 'Step 1/8: Validating the update package and installed settings.'
foreach ($relative in @(
    'codex_bot.py',
    'failure_routing_self_test.py',
    'requirements.txt',
    'restart_tgbot_service.ps1',
    'reboot_windows.ps1',
    'watch_codex_bot.ps1',
    'run_watchdog_hidden.vbs',
    'command_channel_probe.cmd',
    'tools\browser_login.py'
)) {
    if (-not (Test-Path -LiteralPath (Join-Path $Payload $relative))) {
        throw "Update payload is incomplete: $relative"
    }
}
if(-not(Test-Path -LiteralPath (Join-Path $Package 'VERIFY_TGBOT_COMMAND_CHANNEL.ps1'))){throw 'Update package is missing VERIFY_TGBOT_COMMAND_CHANNEL.ps1.'}
if(-not(Test-Path -LiteralPath (Join-Path $Package 'PORTABILITY_SELF_TEST.ps1'))){throw 'Update package is missing PORTABILITY_SELF_TEST.ps1.'}
if(-not(Test-Path -LiteralPath (Join-Path $Package 'payload\.codex\skills\line-official-fast-code\SKILL.md'))){throw 'Update package is missing the LINE Official fast-code skill.'}
& (Join-Path $Package 'PORTABILITY_SELF_TEST.ps1') -PackageRoot $Package
if($LASTEXITCODE -ne 0){throw 'Update package portability or no-fixed-reply verification failed.'}

$Task = if ($SkipRestart -or $TargetOverride) {
    $null
}
else {
    Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
}
if ($Task) {
    Write-UpdateStep 'Step 2/8: Pausing the existing watchdog and TGBOT process.'
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
}

$TargetPath = [IO.Path]::GetFullPath($Target).TrimEnd('\')
$OldBotPids = @(Get-TargetBotProcesses | ForEach-Object { [int]$_.ProcessId })
Stop-TargetBotProcesses
Start-Sleep -Seconds 2
$StillRunning = @(Get-TargetBotProcesses | ForEach-Object { [int]$_.ProcessId })
if ($StillRunning.Count -gt 0) {
    throw "Could not stop the previous TGBOT process PID(s): $($StillRunning -join ', '). Existing settings were preserved."
}
Write-UpdateStep 'Step 3/8: Backing up the current runtime files.'
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $line = [string]$_.CommandLine
    $line -and $line.IndexOf($TargetPath, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and
        ($line -match 'codex_bot\.py|watch_codex_bot\.ps1|run_watchdog_hidden\.vbs')
} | ForEach-Object {
    if ($_.ProcessId -ne $PID) {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
}
Start-Sleep -Seconds 1

$Backup = Join-Path $Target "update-backups\$Timestamp"
New-Item -ItemType Directory -Path (Join-Path $Backup 'tools') -Force | Out-Null
foreach ($relative in @(
    'codex_bot.py',
    'failure_routing_self_test.py',
    'requirements.txt',
    'restart_tgbot_service.ps1',
    'reboot_windows.ps1',
    'watch_codex_bot.ps1',
    'run_watchdog_hidden.vbs',
    'command_channel_probe.cmd',
    'tools\browser_login.py'
)) {
    $existing = Join-Path $Target $relative
    if (Test-Path -LiteralPath $existing) {
        $backupPath = Join-Path $Backup $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $backupPath) -Force | Out-Null
        Copy-Item -LiteralPath $existing -Destination $backupPath -Force
    }
}

New-Item -ItemType Directory -Path (Join-Path $Target 'tools') -Force | Out-Null
foreach ($relative in @(
    'codex_bot.py',
    'failure_routing_self_test.py',
    'requirements.txt',
    'restart_tgbot_service.ps1',
    'reboot_windows.ps1',
    'watch_codex_bot.ps1',
    'run_watchdog_hidden.vbs',
    'command_channel_probe.cmd',
    'tools\browser_login.py'
)) {
    Copy-Item -LiteralPath (Join-Path $Payload $relative) -Destination (Join-Path $Target $relative) -Force
}
foreach($verifierName in @('VERIFY_TGBOT_COMMAND_CHANNEL.cmd','VERIFY_TGBOT_COMMAND_CHANNEL.ps1')){
    $existing=Join-Path $Target $verifierName
    if(Test-Path -LiteralPath $existing){Copy-Item -LiteralPath $existing -Destination (Join-Path $Backup $verifierName) -Force}
    Copy-Item -LiteralPath (Join-Path $Package $verifierName) -Destination $Target -Force
}

$codexHome=if($CodexHomeOverride){[IO.Path]::GetFullPath($CodexHomeOverride)}else{Join-Path $env:USERPROFILE '.codex-api2'}
$lineSkillSource=Join-Path $Package 'payload\.codex\skills\line-official-fast-code'
$lineSkillTarget=Join-Path $codexHome 'skills\line-official-fast-code'
if(Test-Path -LiteralPath $lineSkillTarget){
    $lineSkillBackup=Join-Path $Backup 'codex-api2\skills\line-official-fast-code'
    New-Item -ItemType Directory -Path (Split-Path -Parent $lineSkillBackup) -Force | Out-Null
    Copy-Item -LiteralPath $lineSkillTarget -Destination $lineSkillBackup -Recurse -Force
}
New-Item -ItemType Directory -Path (Join-Path $codexHome 'skills') -Force | Out-Null
New-Item -ItemType Directory -Path $lineSkillTarget -Force | Out-Null
Copy-Item -Path (Join-Path $lineSkillSource '*') -Destination $lineSkillTarget -Recurse -Force
if(-not(Test-Path -LiteralPath (Join-Path $lineSkillTarget 'SKILL.md'))){throw 'LINE Official fast-code skill merge verification failed.'}
$portablePathCount=Convert-PortableSkillPaths -UserHome $env:USERPROFILE -CodexHome $codexHome -Roots @(
    (Join-Path $codexHome 'skills'),
    (Join-Path $codexHome 'memories'),
    (Join-Path $env:USERPROFILE 'AGENTS.md')
)
Set-EnvRuntimeValues -Path (Join-Path $Target '.env') -Values @{
    CODEX_MAX_PARALLEL_REQUESTS='1'
    CODEX_WORKDIR=$env:USERPROFILE
    CODEX_HOME=$codexHome
    TELEGRAM_DIRECT_SHORTCUTS_ENABLED='false'
}
$ChromeReady=$false
$ChromeDetail='unavailable'
$SharedChromeProfile=if($CodexHomeOverride){
    Join-Path (Split-Path -Parent $codexHome) 'tgbot_browser_profiles\shared-chrome'
}else{
    Join-Path $env:USERPROFILE 'tgbot_browser_profiles\shared-chrome'
}
try {
    $ChromeDetail=Ensure-GoogleChrome
    $ChromeReady=$true
    New-Item -ItemType Directory -Path $SharedChromeProfile -Force | Out-Null
    $env:TGBOT_BROWSER_EXECUTABLE=$ChromeDetail
    $env:TGBOT_CHROME_PROFILE_DIR=$SharedChromeProfile
    if(-not $TargetOverride -and -not $CodexHomeOverride){
        [Environment]::SetEnvironmentVariable('TGBOT_BROWSER_EXECUTABLE',$ChromeDetail,'User')
        [Environment]::SetEnvironmentVariable('TGBOT_CHROME_PROFILE_DIR',$SharedChromeProfile,'User')
    }
    Set-EnvRuntimeValues -Path (Join-Path $Target '.env') -Values @{
        TGBOT_BROWSER_EXECUTABLE=$ChromeDetail
        TGBOT_CHROME_PROFILE_DIR=$SharedChromeProfile
    }
} catch {
    $ChromeDetail=$_.Exception.Message
    Write-UpdateStep "Google Chrome setup could not finish: $ChromeDetail Existing Chromium fallback remains available." Yellow
}
Write-UpdateStep "Merged line-official-fast-code, applied current-user/CODEX_HOME paths to $portablePathCount file(s), and enabled single-worker command-channel safety." Green

Write-UpdateStep 'Step 4/8: Verifying Python syntax.'
$Python = Find-Python
$compileExit = Invoke-Python $Python @(
    '-m', 'py_compile',
    (Join-Path $Target 'codex_bot.py'),
    (Join-Path $Target 'tools\browser_login.py')
)
if ($compileExit -ne 0) { throw 'Python syntax verification failed. The previous files are in the update backup folder.' }

$dependencyExit=Invoke-Python $Python @('-c','import openai, telegram, playwright, psutil')
if($dependencyExit -ne 0){
    Write-UpdateStep 'Installing updated Python dependencies, including the direct system health provider.' Yellow
    $dependencyExit=Invoke-Python $Python @(
        '-m','pip','install','--disable-pip-version-check','--no-input','--default-timeout','120','-r',(Join-Path $Target 'requirements.txt')
    )
    if($dependencyExit -ne 0){Write-UpdateStep 'Updated dependency installation failed; core update continues, but direct system health will report psutil unavailable.' Yellow}
}

$routingExit=Invoke-Python $Python @((Join-Path $Target 'failure_routing_self_test.py'))
if($routingExit -ne 0){throw 'Reply-routing self-test failed. Fixed acknowledgement or conversational shortcut routing is still reachable.'}

$BrowserLoginReady = $false
$CommandChannelReady = $false
Write-UpdateStep 'Step 5/8: Testing persistent Google Chrome browser support.'
$browserExit = Invoke-Python $Python @((Join-Path $Target 'tools\browser_login.py'), '--self-test')
if ($browserExit -ne 0) {
    Write-UpdateStep 'Playwright Python dependencies are missing or incomplete; repairing them.' Yellow
    $pipExit = Invoke-Python $Python @(
        '-m', 'pip', 'install', '--disable-pip-version-check', '--no-input',
        '--default-timeout', '120', '-r', (Join-Path $Target 'requirements.txt')
    )
    if ($pipExit -eq 0) {
        $browserExit = Invoke-Python $Python @((Join-Path $Target 'tools\browser_login.py'), '--self-test')
    }
    else {
        Write-UpdateStep 'Playwright dependency repair failed; browser login will remain optional while the core update continues.' Yellow
    }
}
if ($browserExit -ne 0) {
    Write-UpdateStep 'Playwright Chromium is missing; downloading it now. This can take several minutes.' Yellow
    $env:PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT = '120000'
    $browserInstallExit = Invoke-Python $Python @('-m', 'playwright', 'install', 'chromium')
    if ($browserInstallExit -eq 0) {
        $browserExit = Invoke-Python $Python @((Join-Path $Target 'tools\browser_login.py'), '--self-test')
    }
    else {
        Write-UpdateStep 'Playwright Chromium download failed; browser login will remain optional while the core update continues.' Yellow
    }
}
if ($browserExit -eq 0) {
    $BrowserLoginReady = $true
    Write-UpdateStep 'Step 6/8: Browser login self-test passed.' Green
}
else {
    Write-UpdateStep 'Step 6/8: Browser login remains unavailable after repair; continuing the core TGBOT update.' Yellow
}

$skillToolInstaller=Join-Path $Package 'INSTALL_TGBOT_SKILL_TOOLS.ps1'
if((Test-Path -LiteralPath $skillToolInstaller) -and -not $SkipAuxiliaryTools){
    Write-UpdateStep 'Checking Git and FFmpeg skill tools; failures here will not block the TGBOT restart.'
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $skillToolInstaller -Quiet
    if($LASTEXITCODE -ne 0){Write-UpdateStep 'Git or FFmpeg remains unavailable. Core TGBOT update will continue; see tgbot_auxiliary_tools_status.txt.' Yellow}
}

$commandVerifier=Join-Path $Package 'VERIFY_TGBOT_COMMAND_CHANNEL.ps1'
if($SkipCommandChannelTest){
    Write-UpdateStep 'Codex command-channel test skipped by explicit test-harness option.' Yellow
}else{
    Write-UpdateStep 'Verifying the Codex-to-Windows COMMAND_OK round trip; this may take up to four minutes.'
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $commandVerifier -TargetOverride $Target -Quiet
    if($LASTEXITCODE -eq 0){
        $CommandChannelReady=$true
        Write-UpdateStep 'Codex local command channel passed the shell-created COMMAND_OK marker test.' Green
    }else{
        Write-UpdateStep 'Codex command round trip remains unavailable. The bot will still restart and /system_status will use the direct local provider; see command_channel_install_test_status.txt.' Yellow
    }
}

$Allowed = Get-Content -LiteralPath (Join-Path $Target '.env') | Where-Object {
    $_ -match '^(TELEGRAM_ALLOWED_CHAT_IDS|TELEGRAM_OWNER_CHAT_ID)=\s*\S+'
} | Select-Object -First 1
if ($Allowed -and -not $SkipRestart) {
    Write-UpdateStep 'Step 7/8: Starting the updated TGBOT directly.'
    $restartStarted = Get-Date
    $botScript = Join-Path $Target 'codex_bot.py'
    $stdoutLog = Join-Path $Target 'codex_bot.stdout.log'
    $stderrLog = Join-Path $Target 'codex_bot.stderr.log'
    $botProcess = Start-Process `
        -FilePath $Python.Path `
        -ArgumentList @($Python.Args + @($botScript)) `
        -WorkingDirectory $Target `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutLog `
        -RedirectStandardError $stderrLog `
        -PassThru
    $deadline = (Get-Date).AddSeconds(90)
    $lastProgressSecond = -15
    do {
        Start-Sleep -Seconds 1
        $Bot = Get-FreshTargetBotProcess -StartedAfter $restartStarted
        $elapsedSeconds = [int]((Get-Date) - $restartStarted).TotalSeconds
        if (-not $Bot -and $elapsedSeconds -ge ($lastProgressSecond + 15)) {
            Write-UpdateStep "Waiting for a fresh TGBOT heartbeat: $elapsedSeconds / 90 seconds."
            $lastProgressSecond = $elapsedSeconds
        }
    } until ($Bot -or (Get-Date) -ge $deadline)
    if (-not $Bot) {
        throw "Runtime files were updated and existing settings were preserved, but the new TGBOT process did not produce a fresh heartbeat within 90 seconds. Direct launch PID: $($botProcess.Id). Check $Target\codex_bot.stderr.log and $Target\codex_bot_watchdog.log."
    }
    if ($Task) {
        Start-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    }
    Write-UpdateStep "Step 8/8: Fresh TGBOT heartbeat verified (PID $($Bot.ProcessId))." Green
}
elseif (-not $SkipRestart) {
    Write-UpdateStep 'Step 7/8: CHAT ID is not bound; runtime was updated but TGBOT start was intentionally skipped.' Yellow
    Write-UpdateStep 'Step 8/8: Run BIND_CHAT_ID.cmd after binding is ready.' Yellow
}

Write-UpdateStep 'TGBOT runtime update verified.' Green
Write-Host 'Existing .env, Token, API, CHAT ID, skills, memories, and browser profiles were preserved; line-official-fast-code was merged.' -ForegroundColor Green
Write-Host "Google Chrome ready: $ChromeReady ($ChromeDetail)" -ForegroundColor $(if($ChromeReady){'Green'}else{'Yellow'})
Write-Host "Persistent Chrome profile: $SharedChromeProfile" -ForegroundColor DarkGray
if (-not $BrowserLoginReady) {
    Write-Host 'Core TGBOT is updated. Browser login is unavailable on this Windows installation and was not allowed to block the bot restart.' -ForegroundColor Yellow
}
Write-Host "Runtime backup: $Backup" -ForegroundColor DarkGray
Write-Host "Update status: $UpdateStatusPath" -ForegroundColor DarkGray
Write-Host "Codex command channel verified: $CommandChannelReady" -ForegroundColor $(if($CommandChannelReady){'Green'}else{'Yellow'})
