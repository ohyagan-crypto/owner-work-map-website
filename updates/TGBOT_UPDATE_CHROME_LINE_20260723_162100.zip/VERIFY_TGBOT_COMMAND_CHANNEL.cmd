@echo off
setlocal
title Verify TGBOT Codex Command Channel
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0VERIFY_TGBOT_COMMAND_CHANNEL.ps1"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" echo TGBOT command channel verified.
if not "%RC%"=="0" echo TGBOT command channel did not pass. Review command_channel_install_test_status.txt.
pause
exit /b %RC%
